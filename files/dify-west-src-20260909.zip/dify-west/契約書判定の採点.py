#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""契約書判定の採点(3形式比較): 共有フォルダの契約書+正解を読み、Difyの判定アプリを
APIで1件ずつ呼び出して正答率を比較し、「どこに何を追記すれば次から正解に近づくか」を出力する。

■ フォルダの置き方(どちらでもよい。混在も可)
  A) 案件ごとのサブフォルダ方式(おすすめ)
       対象フォルダ/
         ├─ 案件001/ … 契約書.pdf(複数ファイル可)+ 正解.txt
         └─ 案件002/ … 決済文書.docx + 正解.txt
  B) 同じフォルダにペアで置く方式
       対象フォルダ/
         ├─ 賃貸借契約.pdf
         └─ 賃貸借契約.正解.txt
  正解.txt の1行目に「科目名」または「科目名 [10桁コード]」を書く(2行目以降はメモ扱い)。
  正解=その契約のキャッシュ(現金・預金)の相手勘定となる勘定科目1つ。

■ 使い方
  python3 契約書判定の採点.py 対象フォルダ \
      --base-url https://<Difyのホスト>/v1 \
      --key tree=app-yyyy --key flat=app-zzzz --key pick=app-wwww

  - base-url とキーは環境変数でも渡せる: DIFY_BASE_URL / DIFY_KEY_TREE /
    DIFY_KEY_FLAT / DIFY_KEY_PICK(キーは各判定アプリの「APIアクセス」画面で発行する app-…)
  - キーを渡した形式だけが採点される(--formats tree,pick で更に絞り込み可)
  - 結果は画面と「採点結果.md」(--out で変更可)に出る

■ 動き(判定アプリ側には一切手を入れない)
  1案件×1形式ごとに、実際の使い方と同じ2ターンで呼ぶ:
    ①文書ファイルをアップロードして送信(アプリは読み取り内容の確認を返す)
    ②「OK」を返信 → 判定結果を受け取る
  採点は機械的な包含チェック(正解コードがあればコード、無ければ科目名が回答に含まれるか)。
  「質問: 」で止まった場合は「質問で停止」として不正解扱いで集計する(内訳に別掲)。
  3形式とも回答は「キャッシュの相手勘定1科目+確定コード」の同じ形なので、採点基準も同一。

Python 3 の標準ライブラリだけで動く(pip不要)。
"""
import argparse
import io
import json
import mimetypes
import os
import re
import sys
import time
import unicodedata
import urllib.error
import urllib.request
import uuid

FORMATS = [('tree', 'ツリー判定形式'), ('flat', 'コード2段選択形式'),
           ('pick', 'コード一発選択形式')]
DOC_EXTS = {'.pdf', '.txt', '.md', '.markdown', '.docx', '.xlsx', '.xls', '.pptx', '.ppt', '.csv',
            '.png', '.jpg', '.jpeg', '.webp', '.gif'}
IMG_EXTS = {'.png', '.jpg', '.jpeg', '.webp', '.gif'}
MARK = {'ok': '○', 'ng': '×', 'ask': '?', 'error': 'E', 'skip': '-'}


def nk(s):
    return unicodedata.normalize('NFKC', (s or '')).strip()


# ---------------------------------------------------------------- 対象の収集
def parse_answer_file(path):
    for line in io.open(path, encoding='utf-8-sig').read().split('\n'):
        line = nk(line)
        if line.startswith('- '):
            line = line[2:].strip()
        if not line or line.startswith('#'):
            continue
        m = re.search(r'\[([0-9]{7,10})\]', line)
        code = m.group(1) if m else ''
        name = nk(re.sub(r'\[[0-9]{7,10}\]', '', line))
        return name, code
    return '', ''


def is_answer_file(name):
    low = name.lower()
    return low.endswith('.txt') and ('正解' in name)


def collect_cases(root):
    """(案件名, [文書パス], 正解名, 正解コード) の一覧。サブフォルダ方式とペア方式の両対応。"""
    cases = []
    entries = sorted(os.listdir(root))
    for e in entries:
        p = os.path.join(root, e)
        if os.path.isdir(p):
            files = sorted(os.listdir(p))
            ans = [f for f in files if is_answer_file(f)]
            docs = [os.path.join(p, f) for f in files
                    if not is_answer_file(f) and os.path.splitext(f)[1].lower() in DOC_EXTS]
            if ans and docs:
                name, code = parse_answer_file(os.path.join(p, ans[0]))
                cases.append({'label': e, 'docs': docs, 'expect_name': name, 'expect_code': code})
    for e in entries:
        if not is_answer_file(e):
            continue
        stem = re.sub(r'\.?正解\.txt$', '', e, flags=re.IGNORECASE)
        docs = [os.path.join(root, f) for f in entries
                if f != e and os.path.isfile(os.path.join(root, f))
                and os.path.splitext(f)[0] == stem and os.path.splitext(f)[1].lower() in DOC_EXTS]
        if docs:
            name, code = parse_answer_file(os.path.join(root, e))
            cases.append({'label': stem, 'docs': docs, 'expect_name': name, 'expect_code': code})
    return cases


# ---------------------------------------------------------------- Dify API
def http_json(url, api_key, payload, timeout):
    req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), method='POST')
    req.add_header('Content-Type', 'application/json')
    req.add_header('Authorization', 'Bearer %s' % api_key)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode('utf-8'))


def upload_file(base, api_key, path, timeout):
    boundary = '----kanjo%s' % uuid.uuid4().hex
    fname = os.path.basename(path)
    ctype = mimetypes.guess_type(fname)[0] or 'application/octet-stream'
    body = io.BytesIO()

    def part(s):
        body.write(s.encode('utf-8'))
    part('--%s\r\nContent-Disposition: form-data; name="user"\r\n\r\neval-runner\r\n' % boundary)
    part('--%s\r\nContent-Disposition: form-data; name="file"; filename="%s"\r\n'
         'Content-Type: %s\r\n\r\n' % (boundary, fname, ctype))
    body.write(io.open(path, 'rb').read())
    part('\r\n--%s--\r\n' % boundary)
    req = urllib.request.Request(base + '/files/upload', data=body.getvalue(), method='POST')
    req.add_header('Content-Type', 'multipart/form-data; boundary=%s' % boundary)
    req.add_header('Authorization', 'Bearer %s' % api_key)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode('utf-8'))['id']


def run_one(base, api_key, docs, timeout, retry=1):
    """1案件×1形式: ファイル添付→確認に「OK」→判定結果(最終回答文字列)を返す。"""
    last = None
    for attempt in range(retry + 1):
        try:
            files = []
            for p in docs:
                fid = upload_file(base, api_key, p, timeout)
                ftype = 'image' if os.path.splitext(p)[1].lower() in IMG_EXTS else 'document'
                files.append({'type': ftype, 'transfer_method': 'local_file', 'upload_file_id': fid})
            r1 = http_json(base + '/chat-messages', api_key,
                           {'inputs': {}, 'query': '.', 'response_mode': 'blocking',
                            'user': 'eval-runner', 'files': files, 'auto_generate_name': False},
                           timeout)
            conv = r1.get('conversation_id', '')
            r2 = http_json(base + '/chat-messages', api_key,
                           {'inputs': {}, 'query': 'OK', 'response_mode': 'blocking',
                            'user': 'eval-runner', 'conversation_id': conv,
                            'auto_generate_name': False}, timeout)
            return r2.get('answer', ''), None
        except urllib.error.HTTPError as e:
            try:
                detail = e.read().decode('utf-8')[:200]
            except Exception:
                detail = ''
            return '', 'HTTP %s: %s' % (e.code, detail)
        except Exception as e:  # ネットワーク断など。1回だけ再試行
            last = 'error: %s' % e
            if attempt < retry:
                time.sleep(2)
    return '', last


def grade(answer, err, expect_name, expect_code):
    if err:
        return 'error', err
    a = nk(answer)
    got = ' '.join(a[:400].split())
    if '質問:' in a:
        return 'ask', got
    hit = (expect_code in a) if expect_code else (nk(expect_name) in a)
    return ('ok' if hit else 'ng'), got


# ---------------------------------------------------------------- レポート
def build_report(cases, keys, results):
    used = [(k, l) for k, l in FORMATS if keys.get(k)]
    lines = ['# 契約書判定の採点結果(3形式比較)', '',
             '## 📊 正答率(%d件)' % len(cases), '',
             '| 形式 | 正答率 | 正解 | 不正解 | 質問で停止 | エラー |', '|---|---|---|---|---|---|']
    stats = {}
    for k, label in FORMATS:
        if not keys.get(k):
            lines.append('| %s | (キー未設定) | - | - | - | - |' % label)
            continue
        c = {'ok': 0, 'ng': 0, 'ask': 0, 'error': 0}
        for i in range(len(cases)):
            c[results[i][k][0]] += 1
        graded = sum(c.values())
        rate = 100.0 * c['ok'] / graded if graded else 0.0
        stats[k] = rate
        lines.append('| %s | **%.0f%%** (%d/%d) | %d | %d | %d | %d |'
                     % (label, rate, c['ok'], graded, c['ok'], c['ng'], c['ask'], c['error']))
    if stats:
        top = max(stats.values())
        names = '、'.join(l for k, l in FORMATS if stats.get(k) == top)
        lines += ['', '**いちばん正答率が高い形式: %s(%.0f%%)**' % (names, top),
                  '',
                  '※ 3形式とも回答は「キャッシュの相手勘定1科目+確定コード」の同じ形なので、'
                  '採点基準も同一です(正解のコード、コードが無ければ科目名が回答に含まれるか)。']
    lines += ['', '## 📋 1件ごとの結果(○=正解 ×=不正解 ?=質問で停止 E=エラー -=キー未設定)', '',
              '| # | 案件 | 正解 | ' + ' | '.join(l for _, l in FORMATS) + ' |',
              '|---|---|---|' + '---|' * len(FORMATS)]
    for i, c in enumerate(cases):
        expect = c['expect_name'] + ((' [%s]' % c['expect_code']) if c['expect_code'] else '')
        marks = [MARK[results[i][k][0]] if keys.get(k) else '-' for k, _ in FORMATS]
        lines.append('| %d | %s | %s | %s |' % (i + 1, c['label'], expect or '(なし)', ' | '.join(marks)))

    misses = []
    for i, c in enumerate(cases):
        for k, label in used:
            outcome, got = results[i][k]
            if outcome in ('ng', 'ask'):
                expect = c['expect_name'] + ((' [%s]' % c['expect_code']) if c['expect_code'] else '')
                misses.append('- 形式: %s / 案件: %s / 正解: %s\n  アプリの回答(抜粋): %s%s'
                              % (label, c['label'], expect,
                                 '(質問で停止)' if outcome == 'ask' else '', got[:300]))

    lines += ['', '## 🎓 どこに何を書けば次から正解になるか(学習の書き込み先)', '']
    if not misses:
        lines.append('誤答がないため、追記は不要です。')
    else:
        lines += [
            'どれもDifyの各判定アプリの「アプリ設定 → 環境変数」に**行を追記するだけ**です(再インポート不要・即反映)。',
            '',
            '- **どの形式にも効く**: `accounting_policy` に「◯◯のような契約(見分けられる条件)は「正解科目」に分類する」を1行。',
            '  相手勘定の取り違え(敷金・手数料など付随の行を選んだ等)も、ここに「◯◯契約の主目的は◯◯」の形で書く',
            '- **ツリー判定形式**: 正解科目が属する細分の `rules_*` の該当行に、見分ける条件を書き足す',
            '- **コード2段選択形式**: `codes10_list` の該当行の定義に条件を書き足す(7桁の選び間違いなら `codes7_list`)',
            '- **コード一発選択形式**: `codes_list` の正解科目の行の定義に条件を書き足す',
            '- 正解科目がどの候補一覧にも無い場合は、分類ツリーに科目を足して③で各形式を再生成する',
            '',
            '具体的な追記文を作りたいときは、下の「誤答一覧」をそのまま判定アプリのチャットに貼り、',
            '「この誤答をなくすには、上の書き込み先のどこに、どんな行を追記すべきか。コピペできる形で提案して」と続けてください。',
            '追記したら、もう一度この採点を実行して正答率が上がったか確認してください(効果は保証ではありません)。',
            '', '### 誤答一覧', ''] + misses
    return '\n'.join(lines) + '\n'


# ---------------------------------------------------------------- 実行
def main():
    ap = argparse.ArgumentParser(description='共有フォルダの契約書+正解でDify判定アプリ(3形式)を採点する')
    ap.add_argument('folder', help='対象フォルダ(案件サブフォルダ+正解.txt、または 文書+同名.正解.txt)')
    ap.add_argument('--base-url', default=os.environ.get('DIFY_BASE_URL', ''),
                    help='DifyのAPIエンドポイント(例: https://dify.example.com/v1)。環境変数 DIFY_BASE_URL でも可')
    ap.add_argument('--key', action='append', default=[],
                    help='形式=APIキー(例: --key pick=app-xxxx)。tree/flat/pick。'
                         '環境変数 DIFY_KEY_PICK などでも可')
    ap.add_argument('--formats', default='', help='採点する形式をコンマ区切りで絞る(例: tree,pick)')
    ap.add_argument('--limit', type=int, default=0, help='先頭からこの件数だけ採点(0=全件)')
    ap.add_argument('--timeout', type=int, default=300, help='API1回あたりの待ち秒数(既定300)')
    ap.add_argument('--out', default='', help='レポートの保存先(既定: 対象フォルダ/採点結果.md)')
    args = ap.parse_args()

    base = args.base_url.rstrip('/')
    if not base:
        sys.exit('■ --base-url(または環境変数 DIFY_BASE_URL)を指定してください(例: https://dify.example.com/v1)')
    keys = {k: os.environ.get('DIFY_KEY_%s' % k.upper(), '') for k, _ in FORMATS}
    for kv in args.key:
        if '=' not in kv:
            sys.exit('■ --key は 形式=APIキー の形で指定してください: %r' % kv)
        k, v = kv.split('=', 1)
        if k not in keys:
            sys.exit('■ 形式は tree / flat / pick のどれかです: %r' % k)
        keys[k] = v.strip()
    if args.formats:
        allow = {s.strip() for s in args.formats.split(',') if s.strip()}
        bad = allow - {k for k, _ in FORMATS}
        if bad:
            sys.exit('■ --formats に不明な形式があります: %s' % '、'.join(sorted(bad)))
        keys = {k: (v if k in allow else '') for k, v in keys.items()}
    if not any(keys.values()):
        sys.exit('■ APIキーが1つもありません。--key pick=app-xxxx などを指定してください')

    cases = collect_cases(args.folder)
    if not cases:
        sys.exit('■ 採点対象が見つかりません。サブフォルダに 文書+正解.txt、または 文書+同名.正解.txt を置いてください: %s'
                 % args.folder)
    if args.limit:
        cases = cases[:args.limit]
    used = [(k, l) for k, l in FORMATS if keys[k]]
    print('■ %d件 × %d形式(%s)を採点します(1件あたり形式ごとにAPI呼び出し3回)'
          % (len(cases), len(used), '・'.join(l for _, l in used)))

    results = []
    for i, c in enumerate(cases):
        row = {}
        for k, label in FORMATS:
            if not keys[k]:
                row[k] = ('skip', '')
                continue
            answer, err = run_one(base, keys[k], c['docs'], args.timeout)
            row[k] = grade(answer, err, c['expect_name'], c['expect_code'])
            print('  [%d/%d] %s / %s → %s' % (i + 1, len(cases), c['label'], label, MARK[row[k][0]]))
        results.append(row)

    report = build_report(cases, keys, results)
    out = args.out or os.path.join(args.folder, '採点結果.md')
    io.open(out, 'w', encoding='utf-8').write(report)
    print('')
    print(report)
    print('■ レポートを保存しました: %s' % out)


if __name__ == '__main__':
    main()
