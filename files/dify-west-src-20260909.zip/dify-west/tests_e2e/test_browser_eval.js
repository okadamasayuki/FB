// ④「ブラウザで採点」のE2E: モックDify(CORS対応)に対して、フォルダ取り込み→実行→停止→再開→結果まで
const { chromium } = require('playwright');
const http = require('http');

const ROOT = require('path').resolve(__dirname, '..');
let ok = 0, ng = 0;
function check(name, cond, detail) {
  if (cond) { ok++; console.log('  [PASS] ' + name); }
  else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); }
}

// ---- モックDify(CORSプリフライト対応。Authorizationキー×会話で回答を出し分け)
const ANSWERS = {
  'app-tree': {c1: '| 相手勘定(科目) | 預金 |\n| 確定コード | 1010003001 |',
               c2: '| 相手勘定(科目) | 会議費 |\n| 確定コード | 9999999999 |'},
  'app-pick': {c1: '| 相手勘定(科目) | 預金 |\n| 確定コード | 1010003001 |',
               c2: '| 相手勘定(科目) | 賃借料 |\n| 確定コード | 5030001001 |'},
};
const state = {uploads: [], chats: 0, convCase: {}, delayMs: 0};

const srv = http.createServer((req, res) => {
  const cors = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Authorization, Content-Type',
  };
  if (req.method === 'OPTIONS') { res.writeHead(204, cors); res.end(); return; }
  const key = (req.headers.authorization || '').replace('Bearer ', '');
  let body = [];
  req.on('data', c => body.push(c));
  req.on('end', () => {
    const raw = Buffer.concat(body);
    const send = (code, obj) => {
      const b = JSON.stringify(obj);
      res.writeHead(code, Object.assign({'Content-Type': 'application/json'}, cors));
      res.end(b);
    };
    if (req.url.endsWith('/info') || req.url.endsWith('/parameters')) {
      if (key === 'app-bad') return send(401, {message: 'unauthorized'});
      return send(200, {name: 'mock-app'});
    }
    if (req.url.endsWith('/files/upload')) {
      const m = raw.toString('utf8').match(/filename="([^"]+)"/);
      const fname = m ? m[1] : '';
      state.uploads.push(fname);
      const c = fname.indexOf('賃貸') >= 0 ? 'c2' : 'c1';
      return send(200, {id: 'file-' + c + '-' + key + '-' + state.uploads.length});
    }
    if (req.url.endsWith('/chat-messages')) {
      const d = JSON.parse(raw.toString('utf8'));
      state.chats++;
      const finish = () => {
        if (d.files && d.files.length) {
          const c = d.files[0].upload_file_id.indexOf('-c2-') >= 0 ? 'c2' : 'c1';
          const conv = 'conv-' + c + '-' + key + '-' + Math.random().toString(36).slice(2, 7);
          state.convCase[conv] = {c, nfiles: d.files.length};
          return send(200, {conversation_id: conv, answer: '読み取りました。OKと返信してください。'});
        }
        const info = state.convCase[d.conversation_id] || {c: 'c1'};
        return send(200, {conversation_id: d.conversation_id, answer: ANSWERS[key][info.c]});
      };
      setTimeout(finish, state.delayMs);
      return;
    }
    send(404, {message: 'not found'});
  });
});

(async () => {
  await new Promise(r => srv.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + srv.address().port + '/v1';

  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto('file://' + ROOT + '/判定の採点.html');

  console.log('--- 接続テスト(キー未入力=URL疎通のCORSチェックだけ)---');
  await page.fill('#brUrl', base);
  await page.click('#brTest');
  await page.waitForFunction(() => document.getElementById('brTestOut').textContent.includes('届きました'));
  let t = await page.evaluate(() => document.getElementById('brTestOut').textContent);
  check('キー未入力でもURL疎通チェックが動く(CORS通過を報告)', t.includes('CORSは通っています') && t.includes('HTTP 200'), t);
  await page.fill('#brUrl', 'http://127.0.0.1:1/v1');
  await page.click('#brTest');
  await page.waitForFunction(() => document.getElementById('brTestOut').textContent.includes('通信できません'));
  t = await page.evaluate(() => document.getElementById('brTestOut').textContent);
  check('キー未入力の到達不可は切り分け案内(アドレスバー直打ち+CORS依頼文)',
    t.includes('WEB_API_CORS_ALLOW_ORIGINS') && t.includes('/info'), t);

  console.log('--- 接続テスト ---');
  await page.fill('#brUrl', base);
  await page.fill('#brKeyTree', 'app-tree');
  await page.fill('#brKeyPick', 'app-bad');
  await page.click('#brTest');
  await page.waitForFunction(() => document.getElementById('brTestOut').textContent.includes('OK'));
  t = await page.evaluate(() => document.getElementById('brTestOut').textContent);
  check('接続OKと401(キー違い)を出し分け', t.includes('ツリー判定形式: ✅') && t.includes('401'), t);
  await page.fill('#brUrl', 'http://127.0.0.1:1/v1');
  await page.click('#brTest');
  await page.waitForFunction(() => document.getElementById('brTestOut').textContent.includes('通信できません'));
  t = await page.evaluate(() => document.getElementById('brTestOut').textContent);
  check('到達不可はCORS/到達性の案内', t.includes('WEB_API_CORS_ALLOW_ORIGINS'), t);
  await page.fill('#brUrl', base);
  await page.fill('#brKeyPick', 'app-pick');

  console.log('--- 正解.txt の読み方(科目名 [コード] / コードだけ / 正解: 付き / ×N付き / 7桁)---');
  const parsed = await page.evaluate(() => [
    evParseAnswer('賃借料 [5030001001]'), evParseAnswer('5030001001'), evParseAnswer('賃借料 5030001001'),
    evParseAnswer('正解: 賃借料 [5030001001] ×3'), evParseAnswer('# コメント\n\n- 賃借料'), evParseAnswer('﻿[5030001]'),
  ].map(x => x.name + '|' + x.code));
  check('どの書き方でも科目名とコードに分かれる', JSON.stringify(parsed) === JSON.stringify(
    ['賃借料|5030001001', '|5030001001', '賃借料|5030001001', '賃借料|5030001001', '賃借料|', '|5030001']), JSON.stringify(parsed));

  console.log('--- フォルダ取り込み(ラッパー1段+サブフォルダ=決裁。正解なし・下位フォルダ・直下の余りファイル)---');
  await page.evaluate(async () => {
    const mk = (rel, text) => ({rel, file: new File([text], rel.split('/').pop(), {type: 'text/plain'})});
    const items = [
      mk('元データ/案件001_金銭消費貸借/金銭消費貸借契約書.txt', '貸付 一千万円'),
      mk('元データ/案件001_金銭消費貸借/添付/返済予定表.xlsx', 'xlsxダミー'),
      mk('元データ/案件001_金銭消費貸借/見積書.pdf', 'pdfダミー'),
      mk('元データ/案件001_金銭消費貸借/正解.txt', '預金 [1010003001]\n# メモ'),
      mk('元データ/案件002_賃貸借/事務所賃貸借契約.txt', '賃料 月額'),
      mk('元データ/案件002_賃貸借/正解.txt', '5030001001'),
      mk('元データ/案件003_正解なし/何か.txt', 'x'),
      mk('元データ/読み飛ばし.exe', 'x'),
      mk('元データ/一覧.xlsx', 'x'),
    ];
    await brIngest(items);
  });
  let s = await page.evaluate(() => ({
    n: BR.cases.length,
    labels: BR.cases.map(c => c.label),
    docs: BR.cases.map(c => c.docs.map(d => d.name)),
    expects: BR.cases.map(c => c.expect_name + '|' + c.expect_code),
    has: BR.cases.map(c => c.has_answer),
    summary: document.getElementById('brSummary').textContent,
    runDisabled: document.getElementById('brRun').disabled,
    amb: BR.amb,
  }));
  check('ラッパーを降りて3決裁を認識(正解なしの決裁も入る)', s.n === 3 && s.labels.join(',') === '案件001_金銭消費貸借,案件002_賃貸借,案件003_正解なし', JSON.stringify(s.labels));
  check('複数ファイル(下位フォルダの xlsx も含む)を決裁に束ねる', JSON.stringify(s.docs[0]) === JSON.stringify(['添付/返済予定表.xlsx', '見積書.pdf', '金銭消費貸借契約書.txt']), JSON.stringify(s.docs));
  check('正解.txt を読めている(コードだけの書き方も)・正解なしは has_answer=false',
    s.expects[0] === '預金|1010003001' && s.expects[1] === '|5030001001' && s.expects[2] === '|' && JSON.stringify(s.has) === '[true,true,false]', JSON.stringify(s.expects));
  check('サマリー: 3決裁・正解なし1件は判定だけ・直下の余りファイル2件・実行ボタン有効',
    s.summary.includes('3決裁') && s.summary.includes('正解.txt が無い決裁 1件') && s.summary.includes('決裁に含めなかったファイル 2件') && !s.runDisabled, s.summary);
  check('ラッパー直下の余りファイルでは「読み取り方」の切り替えは出ない(サブフォルダが2つ以上)', s.amb && s.amb.nSub === 3 && s.summary.includes('読み取り方'), JSON.stringify(s.amb));

  console.log('--- 実行(tree=1誤答 / pick=全問正解 / 正解なしは判定結果だけ)---');
  await page.click('#brRun');
  await page.waitForFunction(() => document.getElementById('brProg').textContent.includes('完了:'), null, {timeout: 30000});
  s = await page.evaluate(() => ({
    prog: document.getElementById('brProg').textContent,
    report: document.getElementById('brReport').textContent,
    cells: [...document.querySelectorAll('[id^="br-cell-"]')].map(td => td.id + '=' + td.textContent),
    dlDisabled: document.getElementById('brDlMd').disabled,
  }));
  check('6タスク完了', s.prog.includes('6 / 6'), s.prog);
  check('明細: 印の後ろにアプリの答え(科目 [コード])。正解なしは「判」',
    s.cells.includes('br-cell-0-tree=○ 預金 [1010003001]') && s.cells.includes('br-cell-1-tree=× 会議費 [9999999999]')
    && s.cells.includes('br-cell-0-pick=○ 預金 [1010003001]') && s.cells.includes('br-cell-1-pick=○ 賃借料 [5030001001]')
    && s.cells.includes('br-cell-2-tree=判 預金 [1010003001]') && s.cells.includes('br-cell-2-pick=判 預金 [1010003001]'), JSON.stringify(s.cells));
  check('レポート: pick 100% / tree 50%(正解なしは母数に入れない)/ flat キー未設定',
    s.report.includes('| コード一発選択形式 | **100%** (2/2)')
    && s.report.includes('| ツリー判定形式 | **50%** (1/2)')
    && s.report.includes('| コード2段選択形式 | (キー未設定) |')
    && s.report.includes('正解なし(判定結果だけ)の決裁 1件は正答率に含めていません'), s.report.slice(0, 600));
  check('レポートの明細に判定結果(正解なしの行は「判 科目 [コード]」)',
    s.report.includes('| 3 | 案件003_正解なし | (なし) | 判 預金 [1010003001] | - | 判 預金 [1010003001] |')
    && s.report.includes('| 2 | 案件002_賃貸借 | [5030001001] | × 会議費 [9999999999] | - | ○ 賃借料 [5030001001] |'), s.report.slice(600, 1400));
  check('勝者はコード一発選択+誤答一覧', s.report.includes('いちばん正答率が高い形式: コード一発選択形式(100%)')
    && s.report.includes('決裁: 案件002_賃貸借'), '');
  check('md保存ボタン有効', !s.dlDisabled);
  check('1決裁の3ファイル(下位フォルダの分も)が1会話に添付・ファイル名は下位フォルダ名なし',
    Object.values(state.convCase).some(v => v.nfiles === 3) && state.uploads.includes('返済予定表.xlsx') && !state.uploads.some(u => u.includes('/')),
    JSON.stringify(state.convCase) + JSON.stringify(state.uploads));

  console.log('--- 読み取り方の切り替え(直下にもサブフォルダにも書類がある1フォルダ)---');
  const mkItems = (list) => list.map(([rel, text]) => ({rel, text}));
  await page.evaluate(async (list) => {
    await brIngest(list.map(x => ({rel: x.rel, file: new File([x.text], x.rel.split('/').pop(), {type: 'text/plain'})})));
  }, mkItems([['案件Y/契約書.txt', 'a'], ['案件Y/添付/見積.pdf', 'b']]));
  s = await page.evaluate(() => ({n: BR.cases.length, labels: BR.cases.map(c => c.label), docs: BR.cases.map(c => c.docs.length),
                                  summary: document.getElementById('brSummary').textContent, amb: BR.amb,
                                  rootChecked: !![...document.querySelectorAll('input[name="brRoot"]')].find(r => r.value === 'root' && r.checked)}));
  check('書類入りサブフォルダが1つなら既定は「フォルダ全体=1決裁」(添付が2ファイル)', s.n === 1 && s.labels[0] === '案件Y' && s.docs[0] === 2 && s.rootChecked && s.summary.includes('読み取り方'), JSON.stringify(s));
  await page.check('input[name="brRoot"][value="sub"]');
  await page.waitForFunction(() => BR.cases.length === 1 && BR.cases[0].label === '添付');
  s = await page.evaluate(() => ({labels: BR.cases.map(c => c.label), summary: document.getElementById('brSummary').textContent}));
  check('「サブフォルダ=決裁」に切り替えると添付フォルダが決裁になり、直下のファイルは読み飛ばし', s.labels[0] === '添付' && s.summary.includes('決裁に含めなかったファイル 1件'), JSON.stringify(s));
  await page.evaluate(async (list) => {
    await brIngest(list.map(x => ({rel: x.rel, file: new File([x.text], x.rel.split('/').pop(), {type: 'text/plain'})})));
  }, mkItems([['案件X/契約書.txt', 'a'], ['案件X/添付A/見積.pdf', 'b'], ['案件X/添付B/図面.pdf', 'c']]));
  s = await page.evaluate(() => ({labels: BR.cases.map(c => c.label)}));
  check('書類入りサブフォルダが2つ以上なら既定は「サブフォルダ=決裁」', JSON.stringify(s.labels) === JSON.stringify(['添付A', '添付B']), JSON.stringify(s));
  await page.check('input[name="brRoot"][value="root"]');
  await page.waitForFunction(() => BR.cases.length === 1);
  s = await page.evaluate(() => ({labels: BR.cases.map(c => c.label), docs: BR.cases.map(c => c.docs.map(d => d.name))}));
  check('「フォルダ全体=1決裁」に切り替えると3ファイルが1決裁に', s.labels[0] === '案件X' && s.docs[0].length === 3, JSON.stringify(s));
  await page.evaluate(async (list) => {
    await brIngest(list.map(x => ({rel: x.rel, file: new File([x.text], x.rel.split('/').pop(), {type: 'text/plain'})})));
  }, mkItems([['メモ/readme.exe', 'a']]));
  s = await page.evaluate(() => ({n: BR.cases.length, summary: document.getElementById('brSummary').textContent}));
  check('書類が1つも無いときは、読み取ったファイルと対象の拡張子を添えて案内', s.n === 0 && s.summary.includes('決裁が見つかりません') && s.summary.includes('.exe 1') && s.summary.includes('正解.txt は無くても'), s.summary);

  // 元の3決裁に戻して続きのテストへ
  await page.evaluate(async () => {
    const mk = (rel, text) => ({rel, file: new File([text], rel.split('/').pop(), {type: 'text/plain'})});
    await brIngest([
      mk('元データ/案件001_金銭消費貸借/金銭消費貸借契約書.txt', '貸付 一千万円'),
      mk('元データ/案件001_金銭消費貸借/添付/返済予定表.xlsx', 'xlsxダミー'),
      mk('元データ/案件001_金銭消費貸借/見積書.pdf', 'pdfダミー'),
      mk('元データ/案件001_金銭消費貸借/正解.txt', '預金 [1010003001]\n# メモ'),
      mk('元データ/案件002_賃貸借/事務所賃貸借契約.txt', '賃料 月額'),
      mk('元データ/案件002_賃貸借/正解.txt', '5030001001'),
      mk('元データ/案件003_正解なし/何か.txt', 'x'),
    ]);
  });
  await page.click('#brRun');
  await page.waitForFunction(() => document.getElementById('brProg').textContent.includes('完了:'), null, {timeout: 30000});

  const dl = await page.evaluate(() => {
    const captured = [];
    URL.createObjectURL = () => 'blob:x';
    HTMLAnchorElement.prototype.click = function(){ captured.push(this.download); };
    document.getElementById('brDlMd').click();
    return captured;
  });
  check('採点結果.md の保存名', JSON.stringify(dl) === JSON.stringify(['採点結果.md']), JSON.stringify(dl));

  console.log('--- 停止→再開 ---');
  await page.evaluate(() => { BR.results = {}; });
  state.delayMs = 700;
  await page.fill('#brPar', '1');
  await page.click('#brRun');
  await page.waitForFunction(() => Object.keys(BR.results).length >= 1, null, {timeout: 20000});
  await page.click('#brStop');
  await page.waitForFunction(() => document.getElementById('brProg').textContent.includes('停止しました'), null, {timeout: 20000});
  s = await page.evaluate(() => ({prog: document.getElementById('brProg').textContent,
                                  label: document.getElementById('brRun').textContent,
                                  done: Object.keys(BR.results).length}));
  check('停止で部分結果が残る+再開ラベル', s.done >= 1 && s.done < 6 && s.label.indexOf('再開') === 0, JSON.stringify(s));
  state.delayMs = 0;
  await page.click('#brRun');
  await page.waitForFunction(() => document.getElementById('brProg').textContent.includes('完了:'), null, {timeout: 30000});
  s = await page.evaluate(() => ({done: Object.keys(BR.results).length,
                                  report: document.getElementById('brReport').textContent}));
  check('再開で残りを回して6/6', s.done === 6 && s.report.includes('**100%** (2/2)'), JSON.stringify(s.done));

  check('全操作を通してJSエラーなし', errors.length === 0, errors.join(' | '));
  await browser.close();
  srv.close();
  console.log('\nPASS ' + ok + ' / FAIL ' + ng);
  process.exit(ng ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
