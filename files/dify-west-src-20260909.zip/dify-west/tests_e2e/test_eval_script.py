#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""契約書判定の採点.py を、Dify API を模したローカルサーバに対して end-to-end で検証する。

モックの挙動(Authorization ヘッダのキーで形式を判別):
  app-pick: 2案件とも正解コード/科目名を含む回答          → 100%
  app-tree: 案件1だけ正解                                 → 50%
  app-flat: 案件1は「質問: 」で停止、案件2は HTTP 500      → 0%(質問1・エラー1)
"""
import http.server
import io
import json
import os
import re
import subprocess
import sys
import tempfile
import threading

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ok = ng = 0


def check(name, cond, detail=''):
    global ok, ng
    if cond:
        ok += 1
        print('  [PASS] %s' % name)
    else:
        ng += 1
        print('  [FAIL] %s %s' % (name, detail))


ANSWERS2 = {  # 2ターン目(判定結果)の回答: キー → 案件ラベル(query内の契約名で判別しないため会話IDで)
    'app-pick': {'c1': '| 相手勘定(科目) | 預金 |\n| 確定コード | 1010003001 |\n| 根拠の仕訳 | (実行時) 貸付金 / 預金 |',
                 'c2': '| 相手勘定(科目) | 賃借料 |\n| 確定コード | 未確定 |\n| 根拠の仕訳 | (毎月) 賃借料 / 預金 |'},
    'app-tree': {'c1': '| 相手勘定(科目) | 預金 |\n| 確定コード | 1010003001 |',
                 'c2': '| 相手勘定(科目) | 会議費 |\n| 確定コード | 9999999999 |'},
    'app-flat': {'c1': '質問: 貴社は貸主・借主のどちらですか?\n回答例: 貸主です / 借主です'},  # c2 は 500
}
CONV_CASE = {}  # conversation_id → 'c1'/'c2'


class Mock(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        key = (self.headers.get('Authorization') or '').replace('Bearer ', '')
        n = int(self.headers.get('Content-Length') or 0)
        raw = self.rfile.read(n)
        if self.path.endswith('/files/upload'):
            m = re.search(rb'filename="([^"]+)"', raw)
            fname = m.group(1).decode('utf-8') if m else ''
            case = 'c1' if ('金銭' in fname or 'kinsen' in fname) else 'c2'
            return self._json(200, {'id': 'file-%s-%s' % (case, key)})
        if self.path.endswith('/chat-messages'):
            req = json.loads(raw.decode('utf-8'))
            if req.get('files'):  # 1ターン目(添付あり)
                case = 'c1' if 'c1' in req['files'][0]['upload_file_id'] else 'c2'
                conv = 'conv-%s-%s' % (case, key)
                CONV_CASE[conv] = case
                return self._json(200, {'conversation_id': conv,
                                        'answer': '読み取りました。OKと返信してください。'})
            conv = req.get('conversation_id', '')
            case = CONV_CASE.get(conv, 'c1')
            if key == 'app-flat' and case == 'c2':
                return self._json(500, {'message': 'internal error'})
            return self._json(200, {'conversation_id': conv,
                                    'answer': ANSWERS2[key][case]})
        self._json(404, {'message': 'not found'})


srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Mock)
port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()

# ---- テスト用フォルダ(A: サブフォルダ方式 ×2案件、B: ペア方式は走査だけ確認)
tmp = tempfile.mkdtemp(prefix='saiten')
os.makedirs(os.path.join(tmp, '案件001_金銭消費貸借'))
io.open(os.path.join(tmp, '案件001_金銭消費貸借', '金銭消費貸借契約書.txt'), 'w', encoding='utf-8').write('貸付 一千万円 …')
io.open(os.path.join(tmp, '案件001_金銭消費貸借', '正解.txt'), 'w', encoding='utf-8').write('預金 [1010003001]\n# 摘要メモ')
os.makedirs(os.path.join(tmp, '案件002_賃貸借'))
io.open(os.path.join(tmp, '案件002_賃貸借', '事務所賃貸借契約.txt'), 'w', encoding='utf-8').write('賃料 月額 …')
io.open(os.path.join(tmp, '案件002_賃貸借', '正解.txt'), 'w', encoding='utf-8').write('賃借料')

r = subprocess.run([sys.executable, os.path.join(ROOT, '契約書判定の採点.py'), tmp,
                    '--base-url', 'http://127.0.0.1:%d/v1' % port,
                    '--key', 'tree=app-tree',
                    '--key', 'flat=app-flat', '--key', 'pick=app-pick'],
                   capture_output=True, text=True)
out = r.stdout
print(out[-2200:])
check('正常終了', r.returncode == 0, r.stderr[-300:])
check('pick 100%', '| コード一発選択形式 | **100%** (2/2) | 2 | 0 | 0 | 0 |' in out, out[:400])
check('tree 50%', '| ツリー判定形式 | **50%** (1/2) | 1 | 1 | 0 | 0 |' in out)
check('flat 0%(質問1・エラー1)', '| コード2段選択形式 | **0%** (0/2) | 0 | 0 | 1 | 1 |' in out)
check('勝者はコード一発選択', 'いちばん正答率が高い形式: コード一発選択形式(100%)' in out)
check('明細に ○×?E が並ぶ', '| ○ | ? | ○ |' in out and '| × | E | ○ |' in out, out)
check('学習の書き込み先(共通)+旧形式の記載なし',
      'accounting_policy' in out and 'account_aliases' not in out and '仕訳フロー' not in out)
check('誤答一覧に tree の誤答', '形式: ツリー判定形式 / 案件: 案件002_賃貸借' in out)
report_path = os.path.join(tmp, '採点結果.md')
check('レポート保存', os.path.exists(report_path))

# ---- ペア方式(B)の走査だけ確認
tmp2 = tempfile.mkdtemp(prefix='saitenB')
io.open(os.path.join(tmp2, '保守契約.txt'), 'w', encoding='utf-8').write('保守 …')
io.open(os.path.join(tmp2, '保守契約.正解.txt'), 'w', encoding='utf-8').write('支払手数料 [5030002001]')
sys.path.insert(0, ROOT)
import importlib.util
spec = importlib.util.spec_from_file_location('saiten', os.path.join(ROOT, '契約書判定の採点.py'))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
cases = mod.collect_cases(tmp2)
check('ペア方式の走査', len(cases) == 1 and cases[0]['label'] == '保守契約'
      and cases[0]['expect_code'] == '5030002001', str(cases))

# ---- --formats の絞り込み
r2 = subprocess.run([sys.executable, os.path.join(ROOT, '契約書判定の採点.py'), tmp,
                     '--base-url', 'http://127.0.0.1:%d/v1' % port,
                     '--key', 'pick=app-pick', '--key', 'tree=app-tree',
                     '--formats', 'pick'], capture_output=True, text=True)
check('--formats で絞ると他形式はキー未設定', r2.returncode == 0
      and '| ツリー判定形式 | (キー未設定) |' in r2.stdout, r2.stdout[:300])

srv.shutdown()
print('\nPASS %d / FAIL %d' % (ok, ng))
sys.exit(1 if ng else 0)
