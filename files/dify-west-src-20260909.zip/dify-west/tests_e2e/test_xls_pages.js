// ①と②-2で古い .xls(Excel 97-2003 / 5.0-95)をそのまま読めることの通しテスト(パスワード付き・壊れたファイル・Word文書の案内も)
const { chromium } = require('playwright');
const ROOT = require('path').resolve(__dirname, '..');
const FX = __dirname + '/fixtures/';
let ok = 0, ng = 0;
function check(name, cond, detail) {
  if (cond) { ok++; console.log('  [PASS] ' + name); }
  else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); }
}
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage();
  const errors = [], dialogs = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('dialog', d => { dialogs.push(d.message()); d.dismiss(); });
  const checks = () => page.evaluate(() => document.getElementById('checks').textContent);

  console.log('--- ① Excelからツリー ---');
  await page.goto('file://' + ROOT + '/Excelからツリー.html');
  await page.evaluate(() => KS.ready);
  await page.setInputFiles('#file', [FX + 'master.xls']);   // LibreOffice が書いた Excel 97-2003 のブック
  await page.waitForFunction(() => document.querySelector('#drop b').textContent === 'master.xls');
  let s = await page.evaluate(() => ({opts: [...document.getElementById('sheet').options].map(o => o.textContent), rows: DATA.table['科目マスタ'].length, r1: DATA.table['科目マスタ'][1]}));
  check('①: Excel 97-2003 の .xls をそのまま読める(シート名・10行・中身)', s.opts.length === 1 && s.opts[0].includes('科目マスタ') && s.opts[0].includes('10行') && s.r1[4] === '1010001001' && s.r1[3] === '現金' && s.r1[9] === '○', JSON.stringify(s));
  await page.click('#run');
  await page.waitForFunction(() => !document.getElementById('treeCard').classList.contains('hide'));
  const tree = await page.evaluate(() => document.getElementById('tree').textContent);
  check('①: そのままツリーが作れる', tree.includes('現金') && tree.includes('[1010001001]') && tree.includes('通信費'), tree.slice(0, 120));
  await page.setInputFiles('#file', [FX + 'biff5_small.xls']);   // Excel 5.0/95(Shift_JIS・ミニストリーム)
  await page.waitForFunction(() => document.querySelector('#drop b').textContent === 'biff5_small.xls');
  s = await page.evaluate(() => ({opts: [...document.getElementById('sheet').options].map(o => o.textContent), r1: DATA.table['科目マスタ'][1]}));
  check('①: Excel 5.0/95 の .xls も読める(日本語・数値のコード・日付書式)', s.opts.length === 2 && s.r1[0] === '1010001001' && s.r1[1] === '現金' && s.r1[3] === '2024/3/5' && s.r1[4] === '12.34', JSON.stringify(s));
  await page.setInputFiles('#file', [FX + 'bigsst.xls']);   // 共有文字列表が CONTINUE に分かれる大きさ
  await page.waitForFunction(() => document.querySelector('#drop b').textContent === 'bigsst.xls');
  s = await page.evaluate(() => { const t = DATA.table['大きい表']; return {rows: t.length, last: t[t.length - 1]}; });
  check('①: 2001行・共有文字列 6000件の .xls も読める', s.rows === 2001 && s.last[0] === '5030001999' && s.last[2].startsWith('説明1999:'), JSON.stringify(s).slice(0, 200));
  await page.setInputFiles('#file', [FX + 'encrypted.xls']);
  await page.waitForFunction(() => document.getElementById('checks').textContent.includes('暗号化'));
  s = await checks();
  check('①: パスワード付きは「暗号化されています」と外し方を表示', s.includes('パスワードで暗号化されています') && s.includes('パスワードを外し'), s.slice(0, 200));
  await page.setInputFiles('#file', [FX + 'old.xls']);
  await page.waitForFunction(() => document.getElementById('checks').textContent.includes('目次'));
  s = await checks();
  check('①: 壊れた .xls は理由(目次が壊れている)と直し方(保存し直す)', s.includes('古い形式の .xls') && s.includes('目次') && s.includes('保存し直して') && s.includes('608バイト'), s.slice(0, 200));
  await page.setInputFiles('#file', [FX + 'word.doc']);
  await page.waitForFunction(() => document.getElementById('checks').textContent.includes('Word'));
  s = await checks();
  check('①: Word文書(.doc)は「Wordの文書です」と案内', s.includes('Wordの文書(.doc)です') && s.includes('Excelのブックを入れてください'), s.slice(0, 200));

  console.log('--- ②-2 十桁の定義(Excelから定義を転記)---');
  await page.goto('file://' + ROOT + '/十桁定義.html');
  await page.evaluate(() => KS.ready);
  await page.click('#sample');
  await page.setInputFiles('#xlFile', [FX + 'defs1.xls']);   // LibreOffice が書いた Excel 97-2003 版
  await page.waitForFunction(() => document.querySelectorAll('.xlp').length === 1);
  s = await page.evaluate(() => XL.map(p => ({name: p.name, key: p.key, src: p.src, hdrRow: p.hdrRow, label: p.label, rows: p.rows.length, kind: p.kind})));
  check('②-2: .xls を読んで列を自動検出(A列=コード・見出し行あり・説明の列)', s[0].key === 0 && s[0].src === 2 && s[0].hdrRow === 0 && s[0].label === '勘定科目の説明' && s[0].rows === 7 && s[0].kind === 'xls', JSON.stringify(s));
  await page.click('#xlApply');
  const v = await page.evaluate(() => { const it = ITEMS.find(x => x.parsed.code === '5030012001'); return document.querySelector('[data-line="' + it.lineIdx + '"]').value; });
  check('②-2: .xls からの転記が .xlsx のときと同じ結果', v === '【勘定科目の説明】従業員・取引先の慶弔に伴う支出。 香典や祝儀を含む', v);
  const res = await page.evaluate(() => document.getElementById('xlResult').textContent);
  check('②-2: 転記件数(4回)', res.includes('Excel 1件から 4回転記'), res);
  await page.setInputFiles('#xlFile', [FX + 'biff5_big.xls']);
  await page.waitForFunction(() => document.querySelectorAll('.xlp').length === 2);
  s = await page.evaluate(() => XL[1] && {rows: XL[1].rows.length, key: XL[1].key, first: XL[1].rows[0]});
  check('②-2: Excel 5.0/95(300行)も読めてコード列を検出', s && s.rows === 300 && s.key === 0 && s.first[0] === '5030000000' && s.first[1] === '科目000', JSON.stringify(s));
  await page.setInputFiles('#xlFile', [FX + 'encrypted.xls']);
  await page.waitForFunction(() => document.querySelectorAll('.xlp').length === 2 && window.__d !== undefined || true);
  await new Promise(r => setTimeout(r, 800));
  check('②-2: パスワード付きはポップアップで理由を表示', dialogs.length === 1 && dialogs[0].includes('暗号化されています'), dialogs.join(' | '));
  check('②-2: 読み込み欄の説明に「古い形式の .xls もそのまま読む」とある', await page.evaluate(() => document.getElementById('xlDrop').textContent.includes('そのまま読みます')));
  check('JSエラーなし', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log('\nPASS ' + ok + ' / FAIL ' + ng);
  process.exit(ng ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
