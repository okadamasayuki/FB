// ③「動画で見る: 空の事例ナレッジの作り方」のE2E: 全ステップ描画・一覧ジャンプ・前後・自動再生・一時停止・ボタン導線
const { chromium } = require('playwright');
const ROOT = require('path').resolve(__dirname, '..');
let ok = 0, ng = 0;
function check(name, cond, detail) {
  if (cond) { ok++; console.log('  [PASS] ' + name); }
  else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); }
}
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto('file://' + ROOT + '/ツリーからDify.html');

  let s = await page.evaluate(() => ({
    card: !!document.getElementById('dvCard'),
    steps: document.querySelectorAll('#dvSteps li').length,
    n: DV_STEPS.length, i: DV.i,
    idle: document.getElementById('dvScreen').textContent.includes('▶ 再生'),
    cursorHidden: document.getElementById('dvCursor').hidden,
  }));
  check('動画カード+20ステップ一覧+待機画面', s.card && s.steps === 20 && s.n === 20 && s.i === -1 && s.idle && s.cursorHidden, JSON.stringify(s));

  const bad = await page.evaluate(() => {
    const out = [];
    for (let k = 0; k < DV_STEPS.length; k++) {
      dvShow(k);
      const scr = document.getElementById('dvScreen').innerHTML;
      const capT = document.getElementById('dvCapT').textContent;
      const url = document.getElementById('dvUrl').textContent;
      const on = document.querySelectorAll('#dvSteps li.dv-on').length;
      if (scr.length < 300 || !capT.startsWith((k + 1) + '. ') || !url.includes('https://') || on !== 1) out.push(k + 1);
    }
    dvStop();
    return out;
  });
  check('全20ステップが描画できる(画面・キャプション・URL・一覧の強調)', bad.length === 0, JSON.stringify(bad));

  s = await page.evaluate(() => {
    dvShow(6);
    const m = document.getElementById('dv-urlmark');
    return {mark: !!m, text: m ? m.textContent : '', same: m ? m.textContent === DV_ID : false,
            urlHasDatasets: document.getElementById('dvUrl').textContent.includes('/datasets/')};
  });
  check('ステップ7でアドレスバーのナレッジIDが強調される', s.mark && s.same && s.urlHasDatasets, JSON.stringify(s));

  s = await page.evaluate(() => {
    const seen = {};
    [3, 12, 17].forEach(k => { dvShow(k); seen[k] = {
      empty: !!document.getElementById('dv-emptylink'),
      run: !!document.getElementById('dv-run'),
      kr: !!document.getElementById('dv-krnode') && !!document.getElementById('dv-kbchip') && !!document.getElementById('dv-checklist'),
    }; });
    dvStop();
    return seen;
  });
  check('要所の画面部品(空ナレッジのリンク/③の生成ボタン/検索ノード+ナレッジ+チェックリスト)',
    s[3].empty && s[12].run && s[17].kr, JSON.stringify(s));

  await page.click('#dvSteps li:nth-child(13)');
  s = await page.evaluate(() => ({i: DV.i, cap: document.getElementById('dvCapT').textContent,
                                  count: document.getElementById('dvCount').textContent}));
  check('一覧クリックで13へ飛ぶ', s.i === 12 && s.cap.startsWith('13. ') && s.count === '13 / 20', JSON.stringify(s));
  await page.click('#dvNext'); await page.click('#dvNext'); await page.click('#dvPrev');
  s = await page.evaluate(() => DV.i);
  check('次へ×2・前へ×1で14', s === 13, String(s));

  await page.evaluate(() => { dvShow(12); });
  await page.waitForFunction(() => (document.getElementById('dv-lc1') || {textContent: ''}).textContent.startsWith('3f2a9c'), null, {timeout: 8000});
  s = await page.evaluate(() => document.getElementById('dv-lc1').textContent);
  check('入力の打ち込みアニメが動く(IDが入っていく)', DV_ID_PREFIX(s), s);
  function DV_ID_PREFIX(t){ return '3f2a9c1e-7b4d-4e2a-9c1f-0a8b7d6e5f43'.startsWith(t) && t.length > 5; }

  await page.evaluate(() => { DV_STEPS.forEach(st => { st.t = 80; }); });
  await page.click('#dvRestart');
  await page.waitForFunction(() => DV.i === DV_STEPS.length - 1 && !DV.playing, null, {timeout: 20000});
  s = await page.evaluate(() => ({label: document.getElementById('dvPlay').textContent,
                                  bar: document.getElementById('dvBar').style.width,
                                  row: !!document.getElementById('dv-row0')}));
  check('自動再生で最後まで到達(もう一度・100%・カードが1枚)', s.label.includes('もう一度') && s.bar === '100%' && s.row, JSON.stringify(s));

  await page.evaluate(() => { DV_STEPS.forEach(st => { st.t = 5000; }); });
  await page.click('#dvRestart');
  await page.click('#dvPlay');
  s = await page.evaluate(() => ({playing: DV.playing, label: document.getElementById('dvPlay').textContent, i: DV.i}));
  check('一時停止できる(続きを再生の表示)', !s.playing && s.label.includes('続き') && s.i === 0, JSON.stringify(s));
  await page.click('#dvPlay');
  s = await page.evaluate(() => ({playing: DV.playing, label: document.getElementById('dvPlay').textContent}));
  check('再開できる', s.playing && s.label.includes('一時停止'), JSON.stringify(s));
  await page.evaluate(() => { DV.playing = false; dvStop(); });

  await page.check('#learnCheck');
  s = await page.evaluate(() => [document.getElementById('learnCfgBox').style.display, document.getElementById('learnKbBox').style.display]);
  check('自己学習チェックで設定欄が出るが、既定(環境変数方式)では動画ボタン入りの設定込み欄は隠れている', s[0] === 'block' && s[1] === 'none', JSON.stringify(s));
  await page.check('#learnKb');   // 動画ボタンは「Difyの事例ナレッジ」方式の設定込み欄の中
  s = await page.evaluate(() => document.getElementById('learnKbBox').style.display);
  check('事例ナレッジ方式にすると設定込み欄(動画ボタン入り)が出る', s === 'block' && (await page.evaluate(() => !!document.getElementById('dvGo'))), s);
  await page.click('#dvGo');
  s = await page.evaluate(() => ({playing: DV.playing, i: DV.i}));
  check('設定込み欄の「動画で見る」で最初から再生', s.playing && s.i === 0, JSON.stringify(s));
  await page.evaluate(() => { DV.playing = false; dvStop(); });

  check('全操作を通してJSエラーなし', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log('\nPASS ' + ok + ' / FAIL ' + ng);
  process.exit(ng ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
