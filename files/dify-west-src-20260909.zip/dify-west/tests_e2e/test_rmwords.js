// ②-2: 転記した定義欄から決まり文句を一括で消す(1行に1つ・空になった項目は行ごと削除・元に戻す・書き込みに反映・再読込後も残る)
const { chromium } = require('playwright');
const ROOT = require('path').resolve(__dirname, '..');
const FX = __dirname + '/fixtures/';
let ok = 0, ng = 0;
function check(name, cond, detail) {
  if (cond) { ok++; console.log('  [PASS] ' + name); }
  else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); }
}
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage();
  const errors = [], dialogs = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('dialog', d => { dialogs.push(d.message()); d.dismiss(); });
  await page.goto('file://' + ROOT + '/十桁定義.html'); await page.evaluate(() => KS.ready);
  await page.click('#sample');
  await page.setInputFiles('#xlFile', [FX + 'defs1.xlsx', FX + 'defs2.xlsx']);
  await page.waitForFunction(() => document.querySelectorAll('.xlp').length === 2);
  await page.fill('.xlp[data-i="1"] .xlp-label', '事例');
  await page.click('#xlApply');
  const valOf = code => page.evaluate(c => { const it = ITEMS.find(x => x.parsed.code === c); return document.querySelector('textarea[data-line="' + it.lineIdx + '"]').value; }, code);
  const result = () => page.evaluate(() => document.getElementById('rmResult').textContent);
  check('「文言を消す」の箱はExcel取り込みの下・定義欄の上にある', await page.evaluate(() => document.getElementById('rmBox').previousElementSibling.id === 'xlBox' && document.getElementById('rmBox').nextElementSibling.id === 'groups'));
  const v0 = await valOf('5030012001');
  check('(前提)2つのExcelから2行で転記されている', v0 === '【勘定科目の説明】従業員・取引先の慶弔に伴う支出。 香典や祝儀を含む\n【事例】香典、祝儀、花輪代、供花', v0);

  console.log('--- 同じExcelの見出しを変えて転記し直すと、前回の項目が置き換わる ---');
  await page.fill('.xlp[data-i="1"] .xlp-label', '参考');
  await page.click('#xlApply');
  const vr = await valOf('5030012001');
  check('【事例】の項目が【参考】に置き換わり、二重にならない', vr === '【勘定科目の説明】従業員・取引先の慶弔に伴う支出。 香典や祝儀を含む\n【参考】香典、祝儀、花輪代、供花' && (await valOf('5030001002')) === '【参考】新幹線・航空券・宿泊費・日当', vr);
  check('転記の結果に「空にしてから入れ直し」と出る', (await page.evaluate(() => document.getElementById('xlResult').textContent)).includes('空にしてから入れ直し'));
  await page.click('#apply');
  const outr = await page.evaluate(() => OUT);
  check('書き込んだツリーにも前回の見出しは残らない', outr.includes('[5030012001]: 【勘定科目の説明】従業員・取引先の慶弔に伴う支出。 香典や祝儀を含む / 【参考】香典、祝儀、花輪代、供花') && !outr.includes('【事例】'), outr.slice(0, 160));
  await page.fill('.xlp[data-i="1"] .xlp-label', '事例');
  await page.click('#xlApply');
  check('見出しを戻して転記し直しても元の形に戻る', (await valOf('5030012001')) === v0, await valOf('5030012001'));

  check('「項目を見出しごと消す」の欄は無い(Excelごとの「転記を取り消す」だけ)', await page.evaluate(() => !document.getElementById('rmLabel') && !document.getElementById('rmLabelApply') && !!document.querySelector('.xlp-undo')));

  console.log('--- 消すと項目が空になる場合は行ごと消える ---');
  await page.fill('#rmWords', '満期日のある預け入れ');
  await page.click('#rmApply');
  check('見出しだけ残った行は消える(1010003003 が空に)', (await valOf('1010003003')) === '' && (await result()).includes('1箇所を消しました') && (await result()).includes('空になった項目 1行を削除'), await result());
  await page.click('#rmUndo');
  check('「元に戻す」で直前の状態に戻り、ボタンは無効に', (await valOf('1010003003')) === '【事例】満期日のある預け入れ' && (await result()) === '元に戻しました' && await page.evaluate(() => document.getElementById('rmUndo').disabled));

  console.log('--- Excel 1件ぶんの転記を見出しごと取り消す ---');
  await page.click('.xlp[data-i="1"] .xlp-undo');   // 見出し「事例」のExcel
  const xr = () => page.evaluate(() => document.getElementById('xlResult').textContent);
  check('【事例】の項目が全定義欄から見出しごと消える(3件)', (await valOf('5030012001')) === '【勘定科目の説明】従業員・取引先の慶弔に伴う支出。 香典や祝儀を含む' && (await valOf('5030001002')) === '' && (await valOf('1010003003')) === '' && (await xr()).includes('見出し 【事例】 の項目を 3件(定義欄 3件)'), await xr());
  check('空になった欄は転記の印(色)が外れる(6→4)', await page.evaluate(() => document.querySelectorAll('textarea.xl-hit').length === 4));
  await page.click('#rmUndo');
  check('「元に戻す」で内容も印も戻る', (await valOf('5030001002')) === '【事例】新幹線・航空券・宿泊費・日当' && (await valOf('5030012001')) === v0 && await page.evaluate(() => document.querySelectorAll('textarea.xl-hit').length === 6));
  await page.click('.xlp[data-i="1"] .xlp-undo'); await page.click('.xlp[data-i="1"] .xlp-undo');
  check('もう一度押すと「ありませんでした」', (await xr()).includes('【事例】 の項目は定義欄にありませんでした'));
  await page.click('#rmUndo');

  console.log('--- 手で中身を消して欄を離れると、見出しも消える ---');
  const sel = '[data-line="' + await page.evaluate(() => String(ITEMS.find(x => x.parsed.code === '1010003001').lineIdx)) + '"]';
  await page.fill(sel, '【勘定科目の説明】\nメモ');
  await page.press(sel, 'Tab');
  check('見出しだけ残った行は欄を離れたときに落ちる', (await valOf('1010003001')) === 'メモ', await valOf('1010003001'));
  await page.fill(sel, '【勘定科目の説明】');
  await page.press(sel, 'Tab');
  check('見出しだけなら欄が空になる', (await valOf('1010003001')) === '', await valOf('1010003001'));
  await page.fill(sel, '【勘定科目の説明】日常の入出金に使う預金口座。給与振込や自動引落もここ');
  await page.press(sel, 'Tab');

  console.log('--- 複数の文言を1行に1つで一括削除 ---');
  await page.fill('#rmWords', '香典や祝儀を含む\n【事例】');
  await page.click('#rmApply');
  const v1 = await valOf('5030012001');
  check('語句と見出しが全部の定義欄から消え、残りは整った形', v1 === '【勘定科目の説明】従業員・取引先の慶弔に伴う支出。\n香典、祝儀、花輪代、供花' && (await valOf('5030001002')) === '新幹線・航空券・宿泊費・日当' && (await valOf('1010003003')) === '満期日のある預け入れ', v1);
  check('件数の表示(4箇所・定義欄3件)', (await result()) === '4箇所を消しました(定義欄 3件)。「元に戻す」で戻せます。', await result());
  check('転記した印(色)は残る', await page.evaluate(() => document.querySelectorAll('textarea.xl-hit').length === 6));
  await page.fill('#rmWords', 'この文言は無い');
  await page.click('#rmApply');
  check('無い文言なら何も変えずに「ありませんでした」(直前の削除は引き続き戻せる)', (await result()) === 'その文言は定義欄にありませんでした' && (await valOf('5030012001')) === v1 && !(await page.evaluate(() => document.getElementById('rmUndo').disabled)));

  console.log('--- 書き込み・自動保存 ---');
  await page.fill('#rmWords', '香典や祝儀を含む\n【事例】');
  await page.click('#apply');
  const out = await page.evaluate(() => OUT);
  check('消したあとの内容でツリーに書き込まれる', out.includes('[5030012001]: 【勘定科目の説明】従業員・取引先の慶弔に伴う支出。 / 香典、祝儀、花輪代、供花') && out.includes('[5030001002]: 新幹線・航空券・宿泊費・日当') && !out.includes('香典や祝儀を含む'), out.slice(0, 200));
  await new Promise(r => setTimeout(r, 700));
  await page.reload(); await page.evaluate(() => KS.ready);
  check('再読込後も、消したい文言の欄と消したあとの定義欄が残る', (await page.evaluate(() => document.getElementById('rmWords').value)) === '香典や祝儀を含む\n【事例】' && (await valOf('5030012001')) === v1, await valOf('5030012001'));
  check('JSエラー・alertなし', errors.length === 0 && dialogs.length === 0, errors.join(' | ') + dialogs.join(' | '));
  await page.click('#ksClear').catch(() => {});
  await browser.close();
  console.log('\nPASS ' + ok + ' / FAIL ' + ng);
  process.exit(ng ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
