// 自動保存(このブラウザ内のみ)の通しテスト: ①②②-2③の復元・ページを離れるときの書き込み・OFF・ページ単位の消去・まとめ版の全消去・localStorage退避
const { chromium } = require('playwright');
const ROOT = require('path').resolve(__dirname, '..');
const FX = __dirname + '/fixtures/';
let ok = 0, ng = 0;
function check(name, cond, detail) {
  if (cond) { ok++; console.log('  [PASS] ' + name); }
  else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); }
}
const P = {excel: 'Excelからツリー.html', check: 'ツリー検査.html', defs: '十桁定義.html', dify: 'ツリーからDify.html', bundle: '勘定科目分類ツール.html'};
const url = k => 'file://' + ROOT + '/' + P[k];
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const errors = [], dialogs = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('dialog', d => { dialogs.push(d.message()); d.accept(); });
  const ready = (p) => (p || page).evaluate(() => KS.ready);
  const goto = async k => { await page.goto(url(k)); await ready(); };
  const hidden = (id, p) => (p || page).evaluate(i => document.getElementById(i).classList.contains('hide'), id);
  const val = (id, p) => (p || page).evaluate(i => document.getElementById(i).value, id);
  const note = (p) => (p || page).evaluate(() => document.getElementById('ksNote').textContent);
  const reloadWith = async fn => { await Promise.all([page.waitForEvent('load'), fn()]); await ready(); };

  console.log('--- ① Excelからツリー: 読み込んだ表・リスト・設定・結果が復元される ---');
  await goto('excel');
  check('① バナー(自動保存ON・ページ消去ボタン)が見出しの下に出る',
    await page.evaluate(() => document.getElementById('ksBanner').previousElementSibling.className === 'lead' && document.getElementById('ksOn').checked && !!document.getElementById('ksClear')));
  check('① IndexedDB が使える(退避ではない)', await page.evaluate(() => !!window.indexedDB));
  await page.setInputFiles('#file', [FX + 'master.xlsx']);
  await page.waitForFunction(() => !document.getElementById('setup').classList.contains('hide'));
  await page.fill('#rootlabel', '区分判定テスト');
  await page.fill('#exclude', '買掛金');
  await page.setInputFiles('#freqFile', [FX + 'freq.csv']);
  await page.waitForFunction(() => !document.getElementById('freqCond').classList.contains('hide'));
  await page.fill('#freqMin', '2');
  await page.click('#run');
  await page.waitForFunction(() => !document.getElementById('treeCard').classList.contains('hide'));
  const tree1 = await page.evaluate(() => document.getElementById('tree').textContent);
  check('① (前提)ツリーができている', tree1.includes('現金') && tree1.includes('1010001001') && !tree1.includes('通信費'), tree1.slice(0, 200));
  await sleep(700);
  await page.reload(); await ready();
  let s = await page.evaluate(() => ({label: document.querySelector('#drop b').textContent, opts: [...document.getElementById('sheet').options].map(o => o.textContent),
    root: document.getElementById('rootlabel').value, ex: document.getElementById('exclude').value, setup: !document.getElementById('setup').classList.contains('hide'),
    preview: document.getElementById('preview').textContent.includes('普通預金'), freq: FREQ && FREQ.entries.length, fmin: document.getElementById('freqMin').value,
    finfo: document.getElementById('freqInfo').textContent, fprev: document.getElementById('freqPreview').textContent.includes('普通預金'),
    tree: document.getElementById('tree').textContent, treeCard: !document.getElementById('treeCard').classList.contains('hide'), note: document.getElementById('ksNote').textContent}));
  check('① ファイル名・シート・列の設定・除外・見出しが復元される', s.label === 'master.xlsx' && s.opts.length === 1 && s.opts[0].includes('科目マスタ') && s.root === '区分判定テスト' && s.ex === '買掛金' && s.setup && s.preview, JSON.stringify(s).slice(0, 300));
  check('① よく使う科目リスト(表のプレビューつき)と条件も復元される', s.freq === 3 && s.fmin === '2' && s.finfo.includes('freq.csv') && s.fprev, JSON.stringify([s.freq, s.fmin, s.finfo, s.fprev]));
  check('① 結果(ツリー)が同じ内容で自動再生成される', s.treeCard && s.tree === tree1, s.tree.slice(0, 120));
  check('① 「前回の内容を復元しました」と保存日時が出る', /前回の内容を復元しました\(\d+\/\d+ \d+:\d\d 保存\)/.test(s.note), s.note);
  await page.click('#freqClear'); await sleep(700);
  await page.reload(); await ready();
  check('① 「リストを外す」後は、リストなしで復元される', await page.evaluate(() => FREQ === null && document.getElementById('freqCond').classList.contains('hide') && DATA !== null));
  await page.evaluate(() => localStorage.setItem('kanjoLearnCfg', '{"keep":1}'));
  const nd = dialogs.length;
  await reloadWith(() => page.click('#ksClear'));
  check('① 「このページの保存内容を消す」→確認→開いた直後の状態に戻る', dialogs.length === nd + 1 && dialogs[nd].includes('このページがこのブラウザに保存した内容') && await page.evaluate(() => DATA === null && document.getElementById('setup').classList.contains('hide') && document.getElementById('ksNote').textContent === ''));
  check('① ページ単位の消去は他の保存(③の任意保存など)に触らない', await page.evaluate(() => localStorage.getItem('kanjoLearnCfg') === '{"keep":1}'));
  await page.evaluate(() => localStorage.removeItem('kanjoLearnCfg'));

  console.log('--- ② ツリー検査: 入力欄・結果・反映が復元される ---');
  await goto('check');
  await page.click('#sample2'); await page.click('#run');
  await page.waitForFunction(() => !document.getElementById('resultCard').classList.contains('hide'));
  const ops1 = await page.evaluate(() => document.getElementById('opsOut').textContent);
  check('② (前提)修正後ツリーが出ている', ops1.length > 100 && (await val('taM7')) === ops1);
  await page.fill('#taCond', '現金が相手勘定になる科目');
  await sleep(700);
  await page.reload(); await ready();
  s = await page.evaluate(() => ({a: document.getElementById('taA').value, b: document.getElementById('taB').value, c: document.getElementById('taCond').value,
    ops: document.getElementById('opsOut').textContent, res: !document.getElementById('resultCard').classList.contains('hide'), m7: document.getElementById('taM7').value,
    verdict: document.getElementById('verdict').textContent}));
  check('② 左右の欄と絞り込みの条件が復元される', s.a.includes('区分判定') && s.b.includes('昇格') && s.c === '現金が相手勘定になる科目', JSON.stringify([s.a.slice(0, 30), s.b.slice(0, 30), s.c]));
  check('② 結果が同じ入力から再計算され、修正後ツリーも反映欄も同じ', s.res && s.ops === ops1 && s.m7 === ops1, s.verdict.slice(0, 80));
  await page.fill('#taM10', 'テスト10桁');
  await page.reload(); await ready();   // 0.4秒待たずに離れる → pagehide で書かれる
  check('② 保存待ちの入力も、ページを離れるときに書かれる', (await val('taM10')) === 'テスト10桁', await val('taM10'));
  await page.click('#clear'); await sleep(700);
  await page.reload(); await ready();
  check('② 「入力を消す」のあとは空のまま復元され、結果カードは出ない', (await val('taA')) === '' && (await val('taB')) === '' && (await hidden('resultCard')) && (await val('taM7')) === ops1);

  console.log('--- ②-2 十桁定義: ツリー・Excel・定義欄・出力が復元される ---');
  await goto('defs');
  await page.click('#sample');
  await page.setInputFiles('#xlFile', [FX + 'defs1.xlsx']);
  await page.waitForFunction(() => document.querySelectorAll('.xlp').length === 1);
  await page.fill('.xlp[data-i="0"] .xlp-label', '説明');
  await page.click('#xlApply');
  const lineOf = code => page.evaluate(c => String(ITEMS.find(x => x.parsed.code === c).lineIdx), code);
  await page.fill('[data-line="' + await lineOf('5030012002') + '"]', '手入力の定義');
  await page.click('#apply');
  await page.waitForFunction(() => !document.getElementById('outCard').classList.contains('hide'));
  const out1 = await page.evaluate(() => document.getElementById('out').textContent);
  const nd2 = dialogs.length;
  await sleep(700);
  await page.reload(); await ready();
  s = await page.evaluate(() => ({src: document.getElementById('src').value, xl: XL.map(p => [p.name, p.label, p.key, p.src, p.hdrRow, p.rows.length]),
    panel: document.querySelectorAll('.xlp').length, plabel: (document.querySelector('.xlp-label') || {}).value,
    edit: !document.getElementById('editCard').classList.contains('hide'), out: document.getElementById('out').textContent,
    outCard: !document.getElementById('outCard').classList.contains('hide'), hits: document.querySelectorAll('textarea.xl-hit').length,
    v1: document.querySelector('[data-line="' + ITEMS.find(x => x.parsed.code === '5030012002').lineIdx + '"]').value,
    v2: document.querySelector('[data-line="' + ITEMS.find(x => x.parsed.code === '5030012001').lineIdx + '"]').value, scrollY: window.scrollY}));
  check('②-2 ツリーと読み込んだExcel(見出し「説明」・列の指定)が復元される', s.src.includes('慶弔費') && s.panel === 1 && s.xl.length === 1 && s.xl[0][1] === '説明' && s.plabel === '説明' && s.xl[0][5] === 7, JSON.stringify(s.xl));
  check('②-2 定義欄(手入力・Excelからの転記と印)が復元される', s.edit && s.v1 === '手入力の定義' && s.v2.includes('【説明】') && s.hits === 4, JSON.stringify([s.v1, s.v2, s.hits]));
  check('②-2 出力(定義入りツリー)が同じ内容で再生成される', s.outCard && s.out === out1 && s.out.includes('手入力の定義'), s.out.slice(0, 100));
  check('②-2 復元のときは alert もスクロールも起きない', dialogs.length === nd2 && s.scrollY === 0, JSON.stringify([dialogs.length - nd2, s.scrollY]));
  await reloadWith(() => page.click('#ksClear'));
  check('②-2 ページ単位の消去で、ツリーもExcelも空に戻る', await page.evaluate(() => document.getElementById('src').value === '' && XL.length === 0 && document.getElementById('editCard').classList.contains('hide')));

  console.log('--- ③ ツリーからDify: ツリー・形式・チェック・モデル名が復元され、DSLが再生成される ---');
  await goto('dify');
  check('③ バナーに「ナレッジID・URL・キーは対象外」と書いてある', await page.evaluate(() => document.getElementById('ksBanner').textContent.includes('ナレッジID・URL・キーは対象外')));
  await page.click('#sample');
  await page.check('#styleTree');
  await page.check('#learnCheck');
  await page.check('#learnKb');   // 事例の置き場(既定は環境変数)も復元の対象
  await page.fill('#mName', 'GPT-4.1');
  await page.click('#run');
  await page.waitForFunction(() => !document.getElementById('resultCard').classList.contains('hide') && OUTPUTS.length === 1);
  const yaml1 = await page.evaluate(() => OUTPUTS[0].yaml);
  await page.fill('#lcDsId', 'ds-should-not-persist');   // 生成後に入れる(保存チェックなし) → 自動保存の対象外のはず
  await sleep(700);
  await page.reload(); await ready();
  s = await page.evaluate(() => ({tree: document.getElementById('tree').value.length, st: document.getElementById('styleTree').checked, pk: document.getElementById('stylePick').checked,
    learn: document.getElementById('learnCheck').checked, box: document.getElementById('learnCfgBox').style.display, m: document.getElementById('mName').value,
    kb: document.getElementById('learnKb').checked, kbBox: document.getElementById('learnKbBox').style.display,
    label: document.querySelector('#drop b').textContent, n: OUTPUTS.length, yaml: OUTPUTS.length ? OUTPUTS[0].yaml : '', res: !document.getElementById('resultCard').classList.contains('hide'),
    ds: document.getElementById('lcDsId').value}));
  check('③ ツリー・形式(ツリー判定)・自己学習チェック・モデル名・ファイル名が復元される', s.tree > 1000 && s.st && !s.pk && s.learn && s.box === 'block' && s.m === 'GPT-4.1' && s.label.includes('サンプル'), JSON.stringify([s.tree, s.st, s.learn, s.box, s.m, s.label]));
  check('③ 事例の置き場(Difyの事例ナレッジ)も復元され、設定込み欄が開く', s.kb && s.kbBox === 'block', JSON.stringify([s.kb, s.kbBox]));
  check('③ DSLが同じ内容で再生成される', s.res && s.n === 1 && s.yaml === yaml1 && yaml1.includes('GPT-4.1'), String(s.n));
  check('③ ナレッジIDなど(任意保存の欄)は自動保存の対象外', s.ds === '');
  await page.evaluate(() => localStorage.setItem('kanjoLearnCfg', '{"dataset_id":"x"}'));
  const nd3 = dialogs.length;
  await reloadWith(() => page.click('#ksClear'));
  check('③ ページ単位の消去は、任意保存したナレッジID・URL・キーも消す(確認文にも書く)', dialogs[nd3].includes('任意保存したナレッジID・URL・キー') && await page.evaluate(() => document.getElementById('tree').value === '' && localStorage.getItem('kanjoLearnCfg') === null && document.getElementById('stylePick').checked));
  check('③ 消去後は事例の置き場も既定(環境変数)に戻る', await page.evaluate(() => document.getElementById('learnEnv').checked && !document.getElementById('learnKb').checked));

  console.log('--- 自動保存のOFF/ON(全ツール共通) ---');
  await goto('check');
  check('(前提)②にはまだ反映欄の内容が残っている', (await val('taM7')) === ops1);
  await page.uncheck('#ksOn');
  await page.waitForFunction(() => document.getElementById('ksNote').textContent.includes('OFF'));
  await page.reload(); await ready();
  check('OFFにすると、②の保存済みの内容が消え、復元されない', (await val('taM7')) === '' && !(await page.evaluate(() => document.getElementById('ksOn').checked)) && (await note()) === '');
  await page.click('#sample2'); await sleep(700);
  await page.reload(); await ready();
  check('OFFのあいだは何も保存しない', (await val('taA')) === '' && await page.evaluate(() => localStorage.getItem('kanjoAutosave') === '0'));
  await goto('excel');
  check('OFFは全ツール共通(①でもOFF表示)', !(await page.evaluate(() => document.getElementById('ksOn').checked)));
  await page.setInputFiles('#file', [FX + 'master.xlsx']);
  await page.waitForFunction(() => !document.getElementById('setup').classList.contains('hide'));
  await page.check('#ksOn');
  await page.waitForFunction(() => document.getElementById('ksNote').textContent.includes('ON'));
  await sleep(300);
  await page.reload(); await ready();
  check('ONに戻すと、その時点の内容から保存が再開される(読み込み済みの表が復元)', await page.evaluate(() => DATA !== null && document.querySelector('#drop b').textContent === 'master.xlsx' && document.getElementById('ksOn').checked));

  console.log('--- まとめ版(iframe): 各タブの復元・iframe内のページ消去・右上の全消去 ---');
  await page.goto(url('bundle'));
  const frameOf = async title => { const h = await page.waitForSelector('iframe[title="' + title + '"]', {state: 'attached'}); const f = await h.contentFrame(); await f.waitForFunction(() => window.KS && KS.ready); await f.evaluate(() => KS.ready); return f; };
  let f1 = await frameOf('① Excelからツリー');
  check('まとめ版: 単体で保存した①の内容が同じブラウザのまとめ版でも復元される(同じ保存先)', await f1.evaluate(() => DATA !== null && document.querySelector('#drop b').textContent === 'master.xlsx'));
  await page.click('nav button:nth-child(4)');
  let f3 = await frameOf('③ ツリーからDify');
  await f3.click('#sample');
  await page.click('nav button:nth-child(2)');
  let f2 = await frameOf('② 検査(AIに投げて適用)');
  await f2.fill('#taA', 'まとめ版で入力');
  // 最後に②-2(十桁の定義)を開いた状態で更新する → ①へ飛ばず、②-2が開いたまま
  await page.click('nav button:nth-child(3)');
  const fdefs = await frameOf('②-2 10桁の定義');
  await fdefs.click('#sample');
  await sleep(700);
  await page.reload();
  await page.waitForFunction(() => !!document.querySelector('nav button.on'));
  check('まとめ版: 更新すると、最後に開いていたタブ(②-2)がそのまま開く(①へ飛ばない)',
    await page.evaluate(() => { const on = document.querySelectorAll('nav button.on'); return on.length === 1 && on[0].textContent.indexOf('②-2') === 0; }),
    await page.evaluate(() => [...document.querySelectorAll('nav button.on')].map(b => b.textContent)));
  const fdefs2 = await frameOf('②-2 10桁の定義');
  check('まとめ版: ②-2 の内容も復元される', (await val('src', fdefs2)).length > 0);
  await page.click('nav button:nth-child(1)');
  f1 = await frameOf('① Excelからツリー');
  check('まとめ版: ①に切り替えると①も復元', await f1.evaluate(() => DATA !== null && [...document.getElementById('sheet').options].length === 1));
  await page.click('nav button:nth-child(4)');
  f3 = await frameOf('③ ツリーからDify');
  check('まとめ版: ③のツリーも復元', (await val('tree', f3)).length > 1000);
  await page.click('nav button:nth-child(2)');
  f2 = await frameOf('② 検査(AIに投げて適用)');
  check('まとめ版: ②の入力も復元', (await val('taA', f2)) === 'まとめ版で入力');
  check('まとめ版: ヘッダーに全消去ボタンと自動保存の説明がある', await page.evaluate(() => !!document.getElementById('clearAllBtn') && document.querySelector('header p').textContent.includes('このブラウザの中にだけ')));
  await page.click('nav button:nth-child(4)');
  await f3.click('#ksClear');
  await page.waitForFunction(() => { const f = document.querySelector('iframe[title="③ ツリーからDify"]'); try{ return !!(f.contentWindow.KS && f.contentDocument.getElementById('ksBanner') && f.contentDocument.getElementById('tree').value === '' && f.contentDocument.getElementById('ksNote').textContent === ''); }catch(e){ return false; } }, null, {timeout: 8000});
  check('まとめ版: iframe内の「このページの保存内容を消す」で③だけ開いた直後の状態に戻る', true);
  f2 = await frameOf('② 検査(AIに投げて適用)');
  check('まとめ版: ③を消しても①②は残っている', (await val('taA', f2)) === 'まとめ版で入力' && await (await frameOf('① Excelからツリー')).evaluate(() => DATA !== null));
  await page.evaluate(() => { localStorage.setItem('kanjoBrEval', '{"x":1}'); localStorage.setItem('kanjoLearn', '{"y":1}'); localStorage.setItem('kanjoLearnLedger:app:abc', '{}'); localStorage.setItem('kanjoLearnCfg', '{}'); });
  const nd4 = dialogs.length;
  await Promise.all([page.waitForEvent('load'), page.click('#clearAllBtn')]);
  f1 = await frameOf('① Excelからツリー');
  check('まとめ版: 右上「保存した内容をすべて消す」→確認→再読込で①が空', dialogs.length === nd4 + 1 && dialogs[nd4].includes('すべて消して') && await f1.evaluate(() => DATA === null && document.getElementById('setup').classList.contains('hide')));
  check('まとめ版: 全消去のあとは①に戻る(タブ記憶もリセット)', await page.evaluate(() => { const on = document.querySelectorAll('nav button.on'); return on.length === 1 && on[0].textContent.indexOf('①') === 0; }));
  check('まとめ版: ④⑤の接続設定・⑤の仮ナレッジ・③の任意保存・タブ記憶(kanjo で始まる localStorage)も消える', await page.evaluate(() => Object.keys(localStorage).filter(k => k.indexOf('kanjo') === 0).length === 0));
  check('まとめ版: IndexedDB のストアが空', await page.evaluate(() => new Promise(res => { const r = indexedDB.open('kanjoTool', 1); r.onsuccess = () => { const db = r.result; const c = db.transaction('kv').objectStore('kv').count(); c.onsuccess = () => { res(c.result === 0); db.close(); }; }; r.onerror = () => res(false); })));
  await page.click('nav button:nth-child(2)');
  f2 = await frameOf('② 検査(AIに投げて適用)');
  check('まとめ版: ②も空', (await val('taA', f2)) === '');

  console.log('--- IndexedDB が使えないブラウザでは localStorage に退避する ---');
  const ctx2 = await browser.newContext();
  await ctx2.addInitScript(() => { Object.defineProperty(window, 'indexedDB', {get(){ return undefined; }, configurable: true}); });
  const p2 = await ctx2.newPage();
  p2.on('pageerror', e => errors.push('noidb: ' + e));
  p2.on('dialog', d => d.accept());
  await p2.goto(url('check')); await ready(p2);
  await p2.click('#sample2'); await sleep(700);
  check('退避: localStorage に kanjo:kv:check:form が書かれる', await p2.evaluate(() => !!localStorage.getItem('kanjo:kv:check:form') && !!localStorage.getItem('kanjo:kv:check:_t')));
  await p2.reload(); await ready(p2);
  check('退避: 復元できる(復元の表示つき)', (await val('taA', p2)).includes('区分判定') && (await note(p2)).includes('前回の内容を復元しました'));
  await p2.click('#ksClear'); await p2.waitForFunction(() => document.getElementById('taA').value === '' && Object.keys(localStorage).filter(k => k.indexOf('kanjo:kv:check:') === 0).length === 0);
  check('退避: ページ単位の消去で localStorage 側も消える', true);
  await ctx2.close();

  check('JSエラーなし', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log('\nPASS ' + ok + ' / FAIL ' + ng);
  process.exit(ng ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
