# -*- coding: utf-8 -*-
"""古い .xls のテスト用ファイルを作る。
  自前の OLE2 ライタ(512/4096バイトセクタ・ミニストリーム・DIFAT)+ BIFF8 / BIFF5 / BIFF2 ライタで、
  共有文字列表の CONTINUE 分割・ふりがな・書式付き文字列・日付書式・数式の結果などを含むファイルを作る。
  LibreOffice Calc が使えれば本物の変換(BIFF8 / Excel 5.0-95)も加える。期待値は fixtures/xls_expected.json。"""
import io, json, os, struct, subprocess, datetime, shutil
FX = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fixtures')
expected = {}

# ---------------------------------------------------------------- OLE2 ライタ
def ole_write(path, streams, ssz=512):
    MSEC, CUT = 64, 4096
    END, FREE, FATSEC, DIFSEC, NOS = 0xFFFFFFFE, 0xFFFFFFFF, 0xFFFFFFFD, 0xFFFFFFFC, 0xFFFFFFFF
    per = ssz // 4
    pad = lambda b, n: b + b'\0' * ((-len(b)) % n)
    mini = b''; minifat = []; small = {}; bigs = []
    for name, data in streams:
        if len(data) < CUT:
            start = len(mini) // MSEC; cnt = (len(data) + MSEC - 1) // MSEC
            mini += pad(data, MSEC)
            minifat += [start + i + 1 for i in range(cnt - 1)] + [END]
            small[name] = (start, len(data))
        else:
            bigs.append((name, data))
    minifat_b = pad(b''.join(struct.pack('<I', x) for x in minifat), ssz) if minifat else b''
    n_minifat = len(minifat_b) // ssz
    mini_b = pad(mini, ssz); n_mini = len(mini_b) // ssz
    big_b = [(name, pad(d, ssz)) for name, d in bigs]
    n_big = sum(len(b) // ssz for _, b in big_b)
    n_dir = 1
    rest = n_dir + n_minifat + n_mini + n_big
    nfat = 1
    while True:
        ndifat = 0 if nfat <= 109 else -(-(nfat - 109) // (per - 1))
        if nfat * per >= nfat + ndifat + rest: break
        nfat += 1
    s = 0
    fat_secs = list(range(nfat)); s += nfat
    difat_secs = list(range(s, s + ndifat)); s += ndifat
    dir_sec = s; s += n_dir
    minifat_sec = s if n_minifat else END; s += n_minifat
    mini_sec = s if n_mini else END; s += n_mini
    big_start = {}
    for name, b in big_b: big_start[name] = s; s += len(b) // ssz
    total = s
    fat = [FREE] * (nfat * per)
    for x in fat_secs: fat[x] = FATSEC
    for x in difat_secs: fat[x] = DIFSEC
    fat[dir_sec] = END
    def chain(start, n):
        for i in range(n): fat[start + i] = start + i + 1 if i < n - 1 else END
    if n_minifat: chain(minifat_sec, n_minifat)
    if n_mini: chain(mini_sec, n_mini)
    for name, b in big_b: chain(big_start[name], len(b) // ssz)
    def entry(name, typ, left, right, child, start, size):
        nb = name.encode('utf-16le') + b'\0\0'
        e = nb + b'\0' * (64 - len(nb)) + struct.pack('<HBB', len(nb), typ, 1) + struct.pack('<III', left, right, child)
        e += b'\0' * 36 + struct.pack('<II', start, size) + b'\0' * 4
        assert len(e) == 128
        return e
    entries = [entry('Root Entry', 5, NOS, NOS, 1 if streams else NOS, mini_sec if n_mini else END, len(mini))]
    for i, (name, data) in enumerate(streams):
        right = i + 2 if i + 1 < len(streams) else NOS
        start, size = small[name] if name in small else (big_start[name], len(data))
        entries.append(entry(name, 2, NOS, right, NOS, start, size))
    while len(entries) < ssz // 128:
        entries.append(b'\0' * 0x40 + struct.pack('<HBB', 0, 0, 0) + struct.pack('<III', NOS, NOS, NOS) + b'\0' * 36 + b'\0' * 12)
    hdr = b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1' + b'\0' * 16 + struct.pack('<HHHHH', 0x3e, 4 if ssz == 4096 else 3, 0xfffe, 12 if ssz == 4096 else 9, 6) + b'\0' * 6
    hdr += struct.pack('<IIIIIIII', n_dir if ssz == 4096 else 0, nfat, dir_sec, 0, CUT, minifat_sec, n_minifat, difat_secs[0] if ndifat else END) + struct.pack('<I', ndifat)
    hdr += b''.join(struct.pack('<I', x) for x in fat_secs[:109] + [FREE] * max(0, 109 - nfat))
    assert len(hdr) == 512, len(hdr)
    hdr = pad(hdr, ssz)   # 4096バイトセクタでは残りを 0 で埋める
    difat_b = b''
    for k in range(ndifat):
        ids = fat_secs[109 + k * (per - 1): 109 + (k + 1) * (per - 1)]
        ids += [FREE] * (per - 1 - len(ids))
        difat_b += b''.join(struct.pack('<I', x) for x in ids) + struct.pack('<I', difat_secs[k + 1] if k + 1 < ndifat else END)
    body = b''.join(struct.pack('<I', x) for x in fat) + difat_b + b''.join(entries) + minifat_b + mini_b + b''.join(b for _, b in big_b)
    assert len(body) == total * ssz, (len(body), total * ssz)
    open(path, 'wb').write(hdr + body)

# ---------------------------------------------------------------- BIFF 共通
rec = lambda i, d: struct.pack('<HH', i, len(d)) + d
sjis = lambda s: s.encode('cp932')
def rk_int(v): return ((v << 2) | 2) & 0xffffffff
def rk_x100(v): return ((int(round(v * 100)) << 2) | 3) & 0xffffffff
def rk_dbl(v):
    bits = struct.unpack('<Q', struct.pack('<d', v))[0]
    assert bits & 0x3ffffffff == 0, v
    return (bits >> 32) & 0xfffffffc
def rk(r, c, v, xf=0): return rec(0x027e, struct.pack('<HHHI', r, c, xf, v))
def numcell(r, c, v, xf=0):
    if float(v).is_integer() and -2**29 <= v < 2**29: return rk(r, c, rk_int(int(v)), xf)
    return number(r, c, float(v), xf)
def mulrk(r, c0, vs): return rec(0x00bd, struct.pack('<HH', r, c0) + b''.join(struct.pack('<HI', 0, v) for v in vs) + struct.pack('<H', c0 + len(vs) - 1))
def number(r, c, v, xf=0): return rec(0x0203, struct.pack('<HHHd', r, c, xf, v))
def boolerr(r, c, val, err): return rec(0x0205, struct.pack('<HHHBB', r, c, 0, val, 1 if err else 0))
def formula_num(r, c, v): return rec(0x0006, struct.pack('<HHHd', r, c, 0, v) + struct.pack('<HIH', 0, 0, 0))
def formula_special(r, c, t, val): return rec(0x0006, struct.pack('<HHH', r, c, 0) + bytes([t, 0, val, 0, 0, 0, 0xff, 0xff]) + struct.pack('<HIH', 0, 0, 0))
SERIAL = (datetime.date(2024, 3, 5) - datetime.date(1899, 12, 30)).days   # 45356
SERIAL1904 = (datetime.date(2024, 3, 5) - datetime.date(1904, 1, 1)).days

# ---------------------------------------------------------------- BIFF8 ライタ
def ustr8(s, w=2, runs=None, ext=None):
    wide = any(ord(ch) > 0xff for ch in s)
    fl = (1 if wide else 0) | (8 if runs else 0) | (4 if ext else 0)
    b = (struct.pack('<H', len(s)) if w == 2 else bytes([len(s)])) + bytes([fl])
    if runs: b += struct.pack('<H', len(runs))
    if ext: b += struct.pack('<I', len(ext))
    b += s.encode('utf-16le') if wide else s.encode('latin-1')
    if runs: b += b''.join(struct.pack('<HH', a, f) for a, f in runs)
    if ext: b += ext
    return b
def sst_records(items, limit=8224):
    """items: [(s, runs, ext)] → SST + CONTINUE レコード列。文字の途中で分けるときは続きの先頭にフラグ1バイト"""
    recs = []
    cur = bytearray(struct.pack('<II', len(items), len(items)))
    for s, runs, ext in items:
        wide = any(ord(ch) > 0xff for ch in s)
        fl = (1 if wide else 0) | (8 if runs else 0) | (4 if ext else 0)
        hdr = struct.pack('<H', len(s)) + bytes([fl]) + (struct.pack('<H', len(runs)) if runs else b'') + (struct.pack('<I', len(ext)) if ext else b'')
        chars = s.encode('utf-16le') if wide else s.encode('latin-1')
        csize = 2 if wide else 1
        if len(cur) + len(hdr) + (csize if chars else 0) > limit:
            recs.append(cur); cur = bytearray()
        cur += hdr
        pos = 0
        while pos < len(chars):
            room = (limit - len(cur)) // csize * csize
            if room <= 0:
                recs.append(cur); cur = bytearray([1 if wide else 0]); continue
            n = min(len(chars) - pos, room)
            cur += chars[pos:pos + n]; pos += n
        tail = (b''.join(struct.pack('<HH', a, f) for a, f in runs) if runs else b'') + (ext or b'')
        tpos = 0
        while tpos < len(tail):
            room = limit - len(cur)
            if room <= 0:
                recs.append(cur); cur = bytearray(); continue
            n = min(len(tail) - tpos, room)
            cur += tail[tpos:tpos + n]; tpos += n
    recs.append(cur)
    return rec(0x00fc, bytes(recs[0])) + b''.join(rec(0x003c, bytes(r)) for r in recs[1:]), len(recs)
def labelsst(r, c, i, xf=0): return rec(0x00fd, struct.pack('<HHHI', r, c, xf, i))
def label8(r, c, s): return rec(0x0204, struct.pack('<HHH', r, c, 0) + ustr8(s))
def rstring8(r, c, s): return rec(0x00d6, struct.pack('<HHH', r, c, 0) + ustr8(s) + struct.pack('<H', 1) + struct.pack('<HH', 0, 0))
def formula_str8(r, c, s): return formula_special(r, c, 0, 0) + rec(0x0207, ustr8(s))
FORMATS8 = [(164, 'yyyy/m/d'), (165, 'yyyy-mm-dd hh:mm'), (166, '0.00"円"'), (167, '[$-411]ggge"年"m"月"d"日"'), (168, '#,##0 "個"'), (169, 'General'), (170, 'h"時"mm"分"')]
XFS8 = [0, 164, 14, 21, 165, 166, 167, 168, 169, 170]   # ixfe → ifmt
def biff8_workbook(sheets, sst_items, date1904=False, limit=8224, extra_bounds=None):
    """sheets: [(name, body)] / extra_bounds: [(name, body, dt)] グラフなどワークシート以外の substream"""
    g = rec(0x0809, struct.pack('<HHHHII', 0x0600, 0x0005, 0x0dbb, 0x07cc, 0, 0)) + rec(0x0042, struct.pack('<H', 1200)) + rec(0x0022, struct.pack('<H', 1 if date1904 else 0))
    for ifmt, f in FORMATS8: g += rec(0x041e, struct.pack('<H', ifmt) + ustr8(f))
    for ifmt in XFS8: g += rec(0x00e0, struct.pack('<HH', 0, ifmt) + b'\0' * 16)
    subs = [(name, body, 0x0010) for name, body in sheets] + (extra_bounds or [])
    bs = []
    for name, _, dt in subs:
        bs.append(len(g)); g += rec(0x0085, struct.pack('<IBB', 0, 0, 2 if dt == 0x0020 else 0) + ustr8(name, w=1))
    sst_b, nrec = sst_records(sst_items, limit)
    g += sst_b + rec(0x000a, b'')
    bufs = [rec(0x0809, struct.pack('<HHHHII', 0x0600, dt, 0x0dbb, 0x07cc, 0, 0)) + body + rec(0x000a, b'') for _, body, dt in subs]
    out = bytearray(g); off = len(g)
    for i in range(len(subs)):
        struct.pack_into('<I', out, bs[i] + 4, off); off += len(bufs[i])
    return bytes(out) + b''.join(bufs), nrec

long5000 = ''.join('長文%04d。' % i for i in range(1000))   # 5000字 = UTF-16 で 10000 バイト(1レコードに収まらない)
phon = b'\x01\x00' + b'\0' * 30     # ふりがな(ExtRst)のつもりのバイト列(長さだけ見る)
sst_items = [('現金', None, phon), (long5000, None, None), ('', None, None), ('改行\nあり', None, None), ('  前後に空白  ', None, None),
             ('English', None, None), ('特殊 & < > "', [(0, 1), (3, 0)], phon), ('２枚目のメモ', None, None)]
sheet1 = (b''.join(label8(0, c, h) for c, h in enumerate(['コード', '名称', '説明', '日付', '時刻', '日時', '金額', '数式', '真偽', 'エラー']))
  + numcell(1, 0, 1010001001) + labelsst(1, 1, 0) + labelsst(1, 2, 1) + number(1, 3, SERIAL, 1) + number(1, 4, 12.5 / 24, 3) + number(1, 5, SERIAL + (23 * 60 + 59) / 1440, 4)
  + number(1, 6, 1234.5, 5) + formula_num(1, 7, 2020002002) + boolerr(1, 8, 1, False) + boolerr(1, 9, 7, True)
  + label8(2, 0, '1010002001') + rstring8(2, 1, '普通預金') + labelsst(2, 2, 2) + number(2, 3, SERIAL, 2) + number(2, 4, 0.5, 9) + number(2, 5, SERIAL, 6)
  + rk(2, 6, rk_x100(12.34)) + formula_str8(2, 7, '普通預金の説明') + formula_special(2, 8, 1, 0) + formula_special(2, 9, 2, 0x2a)
  + numcell(3, 0, 5030002001) + mulrk(3, 1, [rk_int(-3), rk_x100(-0.25)]) + number(3, 3, 100000, 7) + number(3, 4, 3.14159265358979, 8) + rk(3, 5, rk_dbl(0.5))
  + number(3, 6, 1e21) + number(3, 7, 123456789012)
  + labelsst(5, 0, 3) + labelsst(5, 1, 4) + labelsst(5, 2, 5) + labelsst(5, 3, 6))
sheet2 = labelsst(0, 0, 7) + rk(1, 0, rk_int(7))
chart = rec(0x1001, b'\0' * 4)   # グラフの substream(セルは無い)
exp8 = {'sheets': ['テスト①', '２枚目'], 'table': {'テスト①': [
    ['コード', '名称', '説明', '日付', '時刻', '日時', '金額', '数式', '真偽', 'エラー'],
    ['1010001001', '現金', long5000, '2024/3/5', '12:30:00', '2024/3/5 23:59', '1234.5', '2020002002', 'TRUE', '#DIV/0!'],
    ['1010002001', '普通預金', '', '2024/3/5', '12:00:00', '2024/3/5', '12.34', '普通預金の説明', 'FALSE', '#N/A'],
    ['5030002001', '-3', '-0.25', '100000', '3.14159265358979', '0.5', '1e+21', '123456789012'],
    [],
    ['改行\nあり', '前後に空白', 'English', '特殊 & < > "']], '２枚目': [['２枚目のメモ'], ['7']]}}
wb, _ = biff8_workbook([('テスト①', sheet1), ('２枚目', sheet2)], sst_items, extra_bounds=[('グラフ', chart, 0x0020)])
assert len(wb) > 4096
ole_write(os.path.join(FX, 'biff8.xls'), [('Workbook', wb), ('\x05SummaryInformation', b'\0' * 100)])
expected['biff8.xls'] = exp8
ole_write(os.path.join(FX, 'biff8_4096.xls'), [('Workbook', wb)], ssz=4096)    # 4096バイトセクタ(v4)
expected['biff8_4096.xls'] = exp8
wb_tiny, nrec = biff8_workbook([('テスト①', sheet1), ('２枚目', sheet2)], sst_items, limit=61)   # CONTINUE をあらゆる位置で発生させる
assert nrec > 100, nrec
ole_write(os.path.join(FX, 'biff8_continue.xls'), [('Workbook', wb_tiny)])
expected['biff8_continue.xls'] = exp8
# 1904 日付システム
wb1904, _ = biff8_workbook([('日付', number(0, 0, SERIAL1904, 1) + number(0, 1, SERIAL1904 + 0.5, 4))], [], date1904=True)
ole_write(os.path.join(FX, 'biff8_1904.xls'), [('Workbook', wb1904)])
expected['biff8_1904.xls'] = {'sheets': ['日付'], 'table': {'日付': [['2024/3/5', '2024/3/5 12:00']]}}
# 共有文字列 3000 件(重複なし・ふりがな付き混在)→ CONTINUE 多数
items = []; rows = b''; exp_rows = []
for i in range(3000):
    code = '%010d' % (5030000000 + i); name = '科目%04d' % i; desc = '説明%04d: この科目は第%d番目の説明文で、判定の目安を書く。' % (i, i)
    items += [(code, None, None), (name, None, phon if i % 3 == 0 else None), (desc, [(0, 1)] if i % 5 == 0 else None, None)]
    rows += labelsst(i, 0, 3 * i) + labelsst(i, 1, 3 * i + 1) + labelsst(i, 2, 3 * i + 2)
    exp_rows.append([code, name, desc])
wb_big, nrec = biff8_workbook([('大きい表', rows)], items)
assert nrec > 20, nrec
ole_write(os.path.join(FX, 'biff8_bigsst.xls'), [('Workbook', wb_big)])
expected['biff8_bigsst.xls'] = {'sheets': ['大きい表'], 'table': {'大きい表': exp_rows}}
# DIFAT が要る大きさ(7MB超): 20万行。中身は先頭と末尾だけ確かめる
rows = b''
for i in range(65000):   # 行は 16bit(最大 65536 行)。1行を長くして 7MB を超えさせる
    rows += numcell(i, 0, 5030000000 + i) + label8(i, 1, 'Item %d ' % i + 'x' * 100)
wb_huge, _ = biff8_workbook([('huge', rows)], [])
ole_write(os.path.join(FX, 'biff8_huge.xls'), [('Workbook', wb_huge)])
assert os.path.getsize(os.path.join(FX, 'biff8_huge.xls')) > 7 * 1024 * 1024
expected['biff8_huge.xls'] = {'sheets': ['huge'], 'rows': 65000, 'samples': {'0': ['5030000000', 'Item 0 ' + 'x' * 100], '64999': ['5030064999', 'Item 64999 ' + 'x' * 100]}}

# ---------------------------------------------------------------- BIFF5 ライタ(Excel 5.0/95: 文字列は Shift_JIS)
def label(r, c, s, xf=0): b = sjis(s); return rec(0x0204, struct.pack('<HHHH', r, c, xf, len(b)) + b)
def rstring(r, c, s): b = sjis(s); return rec(0x00d6, struct.pack('<HHHH', r, c, 0, len(b)) + b + bytes([1, 0, 0]))
def formula_str(r, c, s): b = sjis(s); return formula_special(r, c, 0, 0) + rec(0x0207, struct.pack('<H', len(b)) + b)
def biff5_book(sheets):
    g = rec(0x0809, struct.pack('<HHHH', 0x0500, 0x0005, 0x0dbb, 0x07cc)) + rec(0x0042, struct.pack('<H', 932)) + rec(0x0022, struct.pack('<H', 0))
    g += rec(0x041e, struct.pack('<HB', 164, 8) + b'yyyy/m/d') + rec(0x041e, struct.pack('<HB', 165, 7) + b'h:mm:ss')
    for ifmt in [0, 164, 14, 165]: g += rec(0x00e0, struct.pack('<HH', 0, ifmt) + b'\0' * 12)
    bs = []
    for name, _ in sheets:
        bs.append(len(g)); nb = sjis(name); g += rec(0x0085, struct.pack('<IHB', 0, 0, len(nb)) + nb)
    g += rec(0x000a, b'')
    bufs = [rec(0x0809, struct.pack('<HHHH', 0x0500, 0x0010, 0x0dbb, 0x07cc)) + body + rec(0x000a, b'') for _, body in sheets]
    out = bytearray(g); off = len(g)
    for i in range(len(sheets)):
        struct.pack_into('<I', out, bs[i] + 4, off); off += len(bufs[i])
    return bytes(out) + b''.join(bufs)
sheet1 = (label(0, 0, '勘定科目コード') + label(0, 1, '勘定科目名') + label(0, 2, '説明') + label(0, 3, '更新日') + label(0, 4, '単価')
  + numcell(1, 0, 1010001001) + label(1, 1, '現金') + rstring(1, 2, '手元の現金（小口現金を含む）') + number(1, 3, SERIAL, 1) + rk(1, 4, rk_x100(12.34))
  + label(2, 0, '1010002001') + label(2, 1, '普通預金') + formula_str(2, 2, '説明: 普通預金') + number(2, 3, SERIAL + 0.5, 3) + rk(2, 4, rk_dbl(0.5))
  + numcell(3, 0, 5030002001) + mulrk(3, 1, [rk_int(-3), rk_x100(-0.25)]) + boolerr(3, 3, 1, False) + boolerr(3, 4, 0x2a, True)
  + formula_num(5, 0, 2020002002) + number(5, 1, SERIAL, 2))
sheet2 = label(0, 0, 'メモ') + label(0, 1, '２枚目') + rk(1, 0, rk_int(7))
book_small = biff5_book([('科目マスタ', sheet1), ('メモ', sheet2)])
assert len(book_small) < 4096
ole_write(os.path.join(FX, 'biff5_small.xls'), [('Book', book_small), ('\x05SummaryInformation', b'\0' * 100)])
expected['biff5_small.xls'] = {'sheets': ['科目マスタ', 'メモ'], 'table': {'科目マスタ': [
    ['勘定科目コード', '勘定科目名', '説明', '更新日', '単価'],
    ['1010001001', '現金', '手元の現金（小口現金を含む）', '2024/3/5', '12.34'],
    ['1010002001', '普通預金', '説明: 普通預金', '12:00:00', '0.5'],
    ['5030002001', '-3', '-0.25', 'TRUE', '#N/A'],
    [],
    ['2020002002', '2024/3/5']], 'メモ': [['メモ', '２枚目'], ['7']]}}
big = b''; big_rows = []
for i in range(300):
    big += numcell(i, 0, 5030000000 + i) + label(i, 1, '科目%03d' % i) + label(i, 2, '説明%03d: ながい説明のテキスト' % i)
    big_rows.append(['%d' % (5030000000 + i), '科目%03d' % i, '説明%03d: ながい説明のテキスト' % i])
book_big = biff5_book([('大きい', big)])
assert len(book_big) > 4096
ole_write(os.path.join(FX, 'biff5_big.xls'), [('Book', book_big)])
expected['biff5_big.xls'] = {'sheets': ['大きい'], 'table': {'大きい': big_rows}}

# ---------------------------------------------------------------- 生の BIFF2(Excel 2.x)・暗号化・Word
b2 = rec(0x0009, struct.pack('<HH', 0x0000, 0x0010))
def l2(r, c, s): b = sjis(s); return rec(0x0004, struct.pack('<HH', r, c) + b'\0\0\0' + bytes([len(b)]) + b)
b2 += l2(0, 0, 'コード') + l2(0, 1, '名前') + rec(0x0002, struct.pack('<HH', 1, 0) + b'\0\0\0' + struct.pack('<H', 12345)) + l2(1, 1, '現金') \
    + rec(0x0003, struct.pack('<HH', 2, 0) + b'\0\0\0' + struct.pack('<d', 1010001001.0)) + l2(2, 1, '預金') + rec(0x000a, b'')
open(os.path.join(FX, 'biff2.xls'), 'wb').write(b2)
expected['biff2.xls'] = {'sheets': ['Sheet1'], 'table': {'Sheet1': [['コード', '名前'], ['12345', '現金'], ['1010001001', '預金']]}}
book_enc = rec(0x0809, struct.pack('<HHHHII', 0x0600, 0x0005, 0x0dbb, 0x07cc, 0, 0)) + rec(0x002f, b'\x01\x00' + b'\0' * 52) + rec(0x000a, b'')
ole_write(os.path.join(FX, 'encrypted.xls'), [('Workbook', book_enc)])
ole_write(os.path.join(FX, 'word.doc'), [('WordDocument', b'\0' * 200), ('1Table', b'\0' * 100)])

# ---------------------------------------------------------------- LibreOffice Calc があれば本物の変換も
def lo(args):
    try:
        r = subprocess.run(['soffice', '-env:UserInstallation=file:///tmp/lo_profile', '--headless', '--norestore'] + args,
                           capture_output=True, text=True, timeout=240, env=dict(os.environ, HOME='/tmp'))
        return 'could not be loaded' not in (r.stdout + r.stderr)
    except Exception as e:
        return False
master_rows = [
    ['No', '勘定科目区分1', '勘定科目区分2', '勘定科目明細', '勘定科目コード', '', '', '', '', '利用区分'],
    ['1', '資産', '流動資産', '現金', '1010001001', '', '', '', '', '○'],
    ['2', '資産', '流動資産', '普通預金', '1010002001', '', '', '', '', '○'],
    ['3', '資産', '流動資産', '当座預金', '1010002002', '', '', '', '', '○'],
    ['4', '資産', '流動資産', '売掛金', '1010003001', '', '', '', '', '○'],
    ['5', '負債', '流動負債', '買掛金', '2010001001', '', '', '', '', '○'],
    ['6', '費用', '経費', '通信費', '5030002001', '', '', '', '', '○'],
    ['7', '費用', '経費', '旅費交通費', '5030001001', '', '', '', '', '○'],
    ['8', '費用', '経費', '出張旅費', '5030001002', '', '', '', '', '○'],
    ['9', '費用', '経費', '雑費', '5030009001', '', '', '', '', ''],
]
def fods(sheets):
    out = ['<?xml version="1.0" encoding="UTF-8"?>',
      '<office:document xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" '
      'xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" '
      'xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0" xmlns:of="urn:oasis:names:tc:opendocument:xmlns:of:1.2" '
      'office:version="1.2" office:mimetype="application/vnd.oasis.opendocument.spreadsheet">',
      '<office:automatic-styles>',
      '<number:date-style style:name="N1"><number:year number:style="long"/><number:text>/</number:text><number:month/><number:text>/</number:text><number:day/></number:date-style>',
      '<style:style style:name="ce1" style:family="table-cell" style:data-style-name="N1"/>',
      '<number:time-style style:name="N2"><number:hours/><number:text>:</number:text><number:minutes number:style="long"/><number:text>:</number:text><number:seconds number:style="long"/></number:time-style>',
      '<style:style style:name="ce2" style:family="table-cell" style:data-style-name="N2"/>',
      '<number:date-style style:name="N3"><number:year number:style="long"/><number:text>-</number:text><number:month number:style="long"/><number:text>-</number:text><number:day number:style="long"/><number:text> </number:text><number:hours/><number:text>:</number:text><number:minutes number:style="long"/></number:date-style>',
      '<style:style style:name="ce3" style:family="table-cell" style:data-style-name="N3"/>',
      '</office:automatic-styles><office:body><office:spreadsheet>']
    esc = lambda t: t.replace('&', '&amp;').replace('<', '&lt;').replace('"', '&quot;')
    for name, rows in sheets:
        out.append('<table:table table:name="%s">' % esc(name))
        for row in rows:
            out.append('<table:table-row>')
            for c in row:
                if c is None: out.append('<table:table-cell/>'); continue
                t = c['t']
                if t == 'str': out.append('<table:table-cell office:value-type="string"><text:p>%s</text:p></table:table-cell>' % esc(c['v']))
                elif t == 'num': out.append('<table:table-cell office:value-type="float" office:value="%s"/>' % c['v'])
                elif t == 'date': out.append('<table:table-cell office:value-type="date" office:date-value="%s" table:style-name="ce1"/>' % c['v'])
                elif t == 'datetime': out.append('<table:table-cell office:value-type="date" office:date-value="%s" table:style-name="ce3"/>' % c['v'])
                elif t == 'time': out.append('<table:table-cell office:value-type="time" office:time-value="%s" table:style-name="ce2"/>' % c['v'])
                elif t == 'bool': out.append('<table:table-cell office:value-type="boolean" office:boolean-value="%s"/>' % c['v'])
                elif t == 'fnum': out.append('<table:table-cell table:formula="of:%s" office:value-type="float" office:value="%s"/>' % (esc(c['f']), c['v']))
                elif t == 'fstr': out.append('<table:table-cell table:formula="of:%s" office:value-type="string" office:string-value="%s"/>' % (esc(c['f']), esc(c['v'])))
            out.append('</table:table-row>')
        out.append('</table:table>')
    out.append('</office:spreadsheet></office:body></office:document>')
    return '\n'.join(out)
S = lambda v: {'t': 'str', 'v': v}
N = lambda v: {'t': 'num', 'v': v}
long_text = 'この科目は' + '長い説明文を含む。' * 40 + '以上。'
various = [
  ('いろいろ', [
    [S('勘定科目コード'), S('勘定科目名'), S('説明'), S('更新日'), S('単価'), S('区分'), S('数式')],
    [N('1010001001'), S('現金'), S('手元の現金(小口現金を含む)'), {'t': 'date', 'v': '2024-03-05'}, N('12.34'), {'t': 'bool', 'v': 'true'}, {'t': 'fnum', 'f': '=[.A2]*2', 'v': '2020002002'}],
    [S('1010002001'), S('普通預金'), S(long_text), {'t': 'time', 'v': 'PT12H30M15S'}, N('0.5'), {'t': 'bool', 'v': 'false'}, {'t': 'fstr', 'f': '=[.B3]&"の説明"', 'v': '普通預金の説明'}],
    [N('5030002001'), S('通信費'), S('English text only'), {'t': 'datetime', 'v': '2023-12-31T23:59:00'}, N('-3'), S('特殊文字 & <タグ> "引用"'), N('123456789012')],
    [None, None, None, None, None, None, None],
    [N('-0.25'), S('  前後に空白  '), S('改行\nあり'), N('1e21'), N('3.14159265358979'), N('100000000000000000000'), N('0.1')],
  ]),
  ('二枚目', [[S('メモ'), S('２枚目のシート')], [N('7'), S('七')]]),
]
io.open(os.path.join(FX, 'various.fods'), 'w', encoding='utf-8').write(fods(various))
exp_various = {'sheets': ['いろいろ', '二枚目'], 'table': {
  'いろいろ': [
    ['勘定科目コード', '勘定科目名', '説明', '更新日', '単価', '区分', '数式'],
    ['1010001001', '現金', '手元の現金(小口現金を含む)', '2024/3/5', '12.34', '1', '2020002002'],   # LibreOffice は真偽値を数値で書く
    ['1010002001', '普通預金', long_text, '12:30:15', '0.5', '0', '0'],   # LibreOffice の .xls 書き出しは文字列の数式結果を落として 0 を書く(自前ライタの fixture で文字列結果を検証)
    ['5030002001', '通信費', 'English text only', '2023/12/31 23:59', '-3', '特殊文字 & <タグ> "引用"', '123456789012'],
    [],
    ['-0.25', '前後に空白', '改行\nあり', '1e+21', '3.14159265358979', '100000000000000000000', '0.1'],
  ],
  '二枚目': [['メモ', '２枚目のシート'], ['7', '七']],
}}
big_rows = [[S('コード'), S('名称'), S('説明')]]; big_exp = [['コード', '名称', '説明']]
for i in range(2000):
    code = '%010d' % (5030000000 + i); name = '科目%04d' % i; desc = '説明%04d: この科目は第%d番目の説明文で、判定の目安を書く。' % (i, i)
    big_rows.append([S(code), S(name), S(desc)]); big_exp.append([code, name, desc])
io.open(os.path.join(FX, 'bigsst.fods'), 'w', encoding='utf-8').write(fods([('大きい表', big_rows)]))
import importlib.util
spec = importlib.util.spec_from_file_location('mk', os.path.join(os.path.dirname(FX), 'make_master_fixture.py'))
mk = importlib.util.module_from_spec(spec); spec.loader.exec_module(mk)
ascii_rows = [['Code', 'Name', 'Note'], ['1010001001', 'Cash', 'petty cash included'], ['5030002001', 'Telecom', 'phone & net']]
mk.xlsx(os.path.join(FX, 'ascii.xlsx'), 'Sheet A', ascii_rows)
for f in ['master.xls', 'master5.xls', 'defs1.xls', 'various.xls', 'bigsst.xls', 'ascii5.xls']:
    if os.path.exists(os.path.join(FX, f)): os.remove(os.path.join(FX, f))
if lo(['--convert-to', 'xls', '--outdir', FX, os.path.join(FX, 'master.xlsx')]) and os.path.exists(os.path.join(FX, 'master.xls')):
    expected['master.xls'] = {'sheets': ['科目マスタ'], 'table': {'科目マスタ': master_rows}}
    lo(['--convert-to', 'xls', '--outdir', FX, os.path.join(FX, 'defs1.xlsx')])
    if lo(['--convert-to', 'xls', '--outdir', FX, os.path.join(FX, 'various.fods')]): expected['various.xls'] = exp_various
    if lo(['--convert-to', 'xls', '--outdir', FX, os.path.join(FX, 'bigsst.fods')]): expected['bigsst.xls'] = {'sheets': ['大きい表'], 'table': {'大きい表': big_exp}}
    os.makedirs(os.path.join(FX, 'x5'), exist_ok=True)
    if lo(['--convert-to', 'xls:MS Excel 5.0/95', '--outdir', os.path.join(FX, 'x5'), os.path.join(FX, 'ascii.xlsx')]) and os.path.exists(os.path.join(FX, 'x5', 'ascii.xls')):
        shutil.move(os.path.join(FX, 'x5', 'ascii.xls'), os.path.join(FX, 'ascii5.xls'))
        expected['ascii5.xls'] = {'sheets': ['Sheet A'], 'table': {'Sheet A': ascii_rows}}
    if lo(['--convert-to', 'xls:MS Excel 5.0/95', '--outdir', os.path.join(FX, 'x5'), os.path.join(FX, 'master.xlsx')]) and os.path.exists(os.path.join(FX, 'x5', 'master.xls')):
        shutil.move(os.path.join(FX, 'x5', 'master.xls'), os.path.join(FX, 'master5.xls'))   # 日本語の BIFF5(LibreOffice のコードページ次第。期待値はテスト側で緩く)
    print('LibreOffice: converted')
else:
    print('LibreOffice: not available (Calc missing) — 自前ライタのファイルだけ')
json.dump(expected, io.open(os.path.join(FX, 'xls_expected.json'), 'w', encoding='utf-8'), ensure_ascii=False)
print('fixtures:', sorted(f for f in os.listdir(FX) if f.endswith('.xls') or f.endswith('.doc')))
