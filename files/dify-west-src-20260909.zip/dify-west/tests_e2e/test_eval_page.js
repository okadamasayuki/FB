// ④「判定の採点」ページと、まとめ版の5タブ化の検証
const { chromium } = require('playwright');

const ROOT = require('path').resolve(__dirname, '..');
let ok = 0, ng = 0;
function check(name, cond, detail) {
  if (cond) { ok++; console.log('  [PASS] ' + name); }
  else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); }
}

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));

  console.log('--- ④ 単体ページ ---');
  await page.goto('file://' + ROOT + '/判定の採点.html');
  const s = await page.evaluate(() => ({
    nodes: document.querySelectorAll('#canvas g[data-nid]').length,
    svg: !!document.querySelector('#canvas svg'),
    yamlHead: DSL_YAML.slice(0, 4),
    yamlApp: DSL_YAML.includes('契約書判定の採点(3形式比較)'),
    pyHead: SCRIPT_PY.includes('契約書判定の採点'),
    iterBox: !!document.querySelector('#canvas g[data-nid="iter"] rect[stroke-dasharray]'),
  }));
  check('図に14ノード', s.nodes === 14, String(s.nodes));
  check('SVGが描画される', s.svg);
  check('イテレーションは点線枠', s.iterBox);
  check('DSLが埋め込まれている(app:先頭・アプリ名)', s.yamlHead === 'app:' && s.yamlApp, s.yamlHead);
  check('スクリプトが埋め込まれている', s.pyHead);

  const dls = await page.evaluate(() => {
    const captured = [];
    URL.createObjectURL = () => 'blob:x';
    HTMLAnchorElement.prototype.click = function(){ captured.push(this.download); };
    document.getElementById('dlYaml').click();
    document.getElementById('dlNb').click();
    document.getElementById('dlPy').click();
    return captured;
  });
  check('保存名 yml/ipynb/py', JSON.stringify(dls) === JSON.stringify(['contract-account-eval.yml', '契約書判定の採点.ipynb', '契約書判定の採点.py']), JSON.stringify(dls));
  const nbOk = await page.evaluate(() => { const nb = JSON.parse(NOTEBOOK); return nb.nbformat === 4 && nb.cells.length === 6; });
  check('ノートブックが正しいJSONで埋め込まれている', nbOk);

  await page.click('#canvas g[data-nid="http_tree"]');
  const hit = await page.evaluate(() => ({
    exp: document.getElementById('exp-iter').classList.contains('exp-hit'),
    fill: document.querySelector('#canvas g[data-nid="http_tree"] rect').getAttribute('fill'),
  }));
  check('ノードクリック→解説ハイライト+塗りつぶし', hit.exp && hit.fill === '#ffd43b', JSON.stringify(hit));

  const w1 = await page.evaluate(() => document.querySelector('#canvas svg').getAttribute('width'));
  await page.click('#zoomIn');
  const w2 = await page.evaluate(() => document.querySelector('#canvas svg').getAttribute('width'));
  check('拡大でSVG幅が増える', parseFloat(w2) > parseFloat(w1), w1 + ' -> ' + w2);
  await page.click('#zoomFit');

  console.log('--- 逆方向: 解説クリック → 図のノード群ハイライト ---');
  await page.click('#exp-iter');
  const rev = await page.evaluate(() => ({
    iter: document.querySelector('#canvas g[data-nid="iter"] rect').getAttribute('fill'),
    http: document.querySelector('#canvas g[data-nid="http_tree"] rect').getAttribute('fill'),
    grade: document.querySelector('#canvas g[data-nid="grade"] rect').getAttribute('fill'),
    agg: document.querySelector('#canvas g[data-nid="agg"] rect').getAttribute('fill'),
  }));
  check('exp-iterでイテレーション一式が塗られる', rev.iter === '#ffd43b' && rev.http === '#ffd43b' && rev.grade === '#ffd43b', JSON.stringify(rev));
  check('対象外(集計)は塗られない', rev.agg !== '#ffd43b', rev.agg);
  await page.click('#exp-agg');
  const rev2 = await page.evaluate(() => ({
    agg: document.querySelector('#canvas g[data-nid="agg"] rect').getAttribute('fill'),
    http: document.querySelector('#canvas g[data-nid="http_tree"] rect').getAttribute('fill'),
  }));
  check('exp-aggで集計へ移り、前のハイライトは解除', rev2.agg === '#ffd43b' && rev2.http !== '#ffd43b', JSON.stringify(rev2));

  console.log('--- 動画(準備/ブラウザで採点/Dify版採点アプリ)---');
  await page.click('#dvPick1');
  const d1 = await page.evaluate(() => ({i: DV.i, n: DV.steps.length, playing: DV.playing,
    cap: document.getElementById('dvCapT').textContent, scr: document.getElementById('dvScreen').innerHTML.length,
    name: document.getElementById('dvScriptName').textContent, lis: document.querySelectorAll('#dvSteps li').length}));
  check('準備の動画が始まる(8ステップ・画面・キャプション)', d1.i === 0 && d1.playing && d1.n === 8 && d1.lis === 8
    && d1.cap.startsWith('1. ') && d1.scr > 300 && d1.name.includes('準備'), JSON.stringify(d1));
  await page.click('#dvNext');
  const d2 = await page.evaluate(() => DV.i);
  check('次へで進む', d2 === 1, String(d2));
  await page.click('#dvPlay');
  const p1 = await page.evaluate(() => ({playing: DV.playing, label: document.getElementById('dvPlay').textContent}));
  check('一時停止(続きを再生の表示)', !p1.playing && p1.label.includes('続き'), JSON.stringify(p1));
  await page.click('#dvPick2');
  const d3 = await page.evaluate(() => ({name: document.getElementById('dvScriptName').textContent, i: DV.i, n: DV.steps.length,
    url: document.getElementById('dvUrl').textContent}));
  check('ブラウザで採点の動画に切り替わる(8ステップ)', d3.name.includes('ブラウザ') && d3.i === 0 && d3.n === 8 && d3.url.includes('kanjo-tool'), JSON.stringify(d3));
  await page.click('#dvPick3');
  const d4 = await page.evaluate(() => ({name: document.getElementById('dvScriptName').textContent, n: DV.steps.length}));
  check('Dify版採点アプリの動画に切り替わる(8ステップ)', d4.name.includes('Dify版') && d4.n === 8, JSON.stringify(d4));
  const bad = await page.evaluate(() => {
    const out = [];
    [EVAL_DEMO_PREP, EVAL_DEMO_BROWSER, EVAL_DEMO_DIFY].forEach((sc, si) => {
      dvSetup(sc.steps, sc);
      for (let k = 0; k < sc.steps.length; k++) {
        dvShow(k);
        if (document.getElementById('dvScreen').innerHTML.length < 200
            || !document.getElementById('dvCapT').textContent.startsWith((k + 1) + '. ')
            || !document.getElementById('dvUrl').textContent.includes('https://')) out.push(si + ':' + (k + 1));
      }
    });
    dvStop(); DV.playing = false;
    return out;
  });
  check('3本・全24ステップが描画できる', bad.length === 0, JSON.stringify(bad));
  await page.evaluate(() => { dvSetup(EVAL_DEMO_BROWSER.steps, EVAL_DEMO_BROWSER); dvShow(1); });
  await page.waitForFunction(() => (document.getElementById('dv-b-k1') || {textContent: ''}).textContent.startsWith('app-'), null, {timeout: 8000});
  check('キーの打ち込みアニメが動く', true);
  await page.evaluate(() => { DV.playing = false; dvStop(); });
  const note = await page.evaluate(() => document.body.textContent.includes('画面は説明用のイメージです'));
  check('イメージである注記', note);

  console.log('--- まとめ版(6タブ)---');
  await page.goto('file://' + ROOT + '/勘定科目分類ツール.html');
  const tabs = await page.evaluate(() => [...document.querySelectorAll('nav button')].map(b => b.textContent));
  check('タブが6つ(④⑤あり)', tabs.length === 6 && tabs[4] === '④ 採点(正答率くらべ)'
    && tabs[5] === '⑤ 自動学習(正答率を上げる)', JSON.stringify(tabs));
  await page.click('nav button:nth-child(5)');
  await page.waitForTimeout(1200);
  let found = false;
  for (const f of page.frames()) {
    try {
      const t = await f.evaluate(() => document.body ? document.body.textContent.slice(0, 3000) : '');
      if (t.includes('3形式の正答率くらべと自己学習')) found = true;
    } catch (e) {}
  }
  check('④タブの中身が表示される', found);
  await page.click('nav button:nth-child(6)');
  await page.waitForTimeout(1200);
  let found5 = false;
  for (const f of page.frames()) {
    try {
      const t = await f.evaluate(() => document.body ? document.body.textContent.slice(0, 3000) : '');
      if (t.includes('誤答を教えて正答率を上げるループ')) found5 = true;
    } catch (e) {}
  }
  check('⑤タブの中身が表示される', found5);
  const about = await page.evaluate(() => { document.getElementById('aboutBtn').click();
    return document.getElementById('aboutText').textContent; });
  check('説明文に④採点と⑤自動学習', about.includes('④ 採点(任意)') && about.includes('⑤ 自動学習(任意)')
    && about.includes('エポック学習'), about.slice(0, 120));
  const headerP = await page.evaluate(() => document.querySelector('header p').textContent);
  check('ヘッダーの通信断り書きが④⑤両方',
    headerP.includes('④の「ブラウザで採点」と⑤の「自動学習」'), headerP);

  check('全操作を通してJSエラーなし', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log('\nPASS ' + ok + ' / FAIL ' + ng);
  process.exit(ng ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
