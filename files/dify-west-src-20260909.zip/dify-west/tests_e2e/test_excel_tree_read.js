// ①(Excelからツリー): 共通化した表ファイル読み込み(中身の判定・HTML表・エラー文言)の確認
const { chromium } = require('playwright');
const ROOT = require('path').resolve(__dirname, '..');
const FX = __dirname + '/fixtures/';
let ok = 0, ng = 0;
function check(name, cond, detail) {
  if (cond) { ok++; console.log('  [PASS] ' + name); }
  else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); }
}
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto('file://' + ROOT + '/Excelからツリー.html');
  await page.setInputFiles('#file', [FX + 'defs1.xlsx']);
  await page.waitForFunction(() => !document.getElementById('setup').classList.contains('hide'));
  let s = await page.evaluate(() => ({opts: [...document.getElementById('sheet').options].map(o => o.textContent), label: document.querySelector('#drop b').textContent}));
  check('①: .xlsx はこれまでどおり読める(Sheet1・7行)', s.opts.length === 1 && s.opts[0].includes('Sheet1') && s.opts[0].includes('7行') && s.label === 'defs1.xlsx', JSON.stringify(s));
  await page.setInputFiles('#file', [FX + 'htmlexport.xls']);
  await page.waitForFunction(() => document.querySelector('#drop b').textContent === 'htmlexport.xls');
  s = await page.evaluate(() => ({opts: [...document.getElementById('sheet').options].map(o => o.textContent), rows: DATA.table[DATA.sheets[0]]}));
  check('①: HTMLの表(Shift_JIS・拡張子.xls)も中身を見て読める', s.opts.length === 1 && s.opts[0].includes('3行') && s.rows[1][2] === '満期まで引き出さない預金(1年もの)', JSON.stringify(s));
  await page.setInputFiles('#file', [FX + 'sysexport.xls']);
  await page.waitForFunction(() => document.querySelector('#drop b').textContent === 'sysexport.xls');
  s = await page.evaluate(() => ({opts: [...document.getElementById('sheet').options].map(o => o.textContent)}));
  check('①: SpreadsheetML 2003 も読める(科目一覧・5行)', s.opts.length === 1 && s.opts[0].includes('科目一覧') && s.opts[0].includes('5行'), JSON.stringify(s));
  await page.setInputFiles('#file', [FX + 'old.xls']);
  await page.waitForFunction(() => document.getElementById('checks').textContent.includes('できませんでした'));
  s = await page.evaluate(() => document.getElementById('checks').textContent);
  check('①: 古い .xls は理由と直し方を表示', s.includes('古い形式の .xls') && s.includes('保存し直して'), s.slice(0, 120));
  await page.setInputFiles('#file', [FX + 'fake.xlsx']);
  await page.waitForFunction(() => document.getElementById('checks').textContent.includes('拡張子は .xlsx'));
  s = await page.evaluate(() => document.getElementById('checks').textContent);
  check('①: 中身がテキストの .xlsx は「拡張子は .xlsx ですが…」と案内', s.includes('中身がExcelブック(zip形式)ではありません'), s.slice(0, 160));
  check('JSエラーなし', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log('\nPASS ' + ok + ' / FAIL ' + ng);
  process.exit(ng ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
