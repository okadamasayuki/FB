// 塗りつぶしハイライトの実機検証(縮小表示を想定)
const { chromium } = require('playwright');
const fs = require('fs');
const ROOT = require('path').resolve(__dirname, '..');
const TREE_CODED = fs.readFileSync(process.env.SCRATCH + '/tree_coded.md', 'utf8');

let ok = 0, ng = 0;
function check(name, cond, detail) {
  if (cond) { ok++; console.log('  [PASS] ' + name); }
  else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); }
}

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto('file://' + ROOT + '/ツリーからDify.html');
  await page.evaluate(t => { document.getElementById('tree').value = t; }, TREE_CODED);
  await page.check('#styleTree');
  await page.click('#run');

  // 極小倍率(9%相当)に縮小して再描画
  await page.evaluate(() => { ZOOM = 0.09; drawCanvas(false); });
  const zoomText = await page.evaluate(() => document.getElementById('canvasInfo').textContent);
  check('9%表示になっている', zoomText.includes('9%'), zoomText);

  function fills() {
    return page.evaluate(() => {
      const out = {};
      for (const g of document.querySelectorAll('#canvas g[data-nid]')) {
        const r = g.querySelector('rect');
        out[g.getAttribute('data-nid')] = r.getAttribute('fill') + '|' + r.getAttribute('stroke');
      }
      return out;
    });
  }

  console.log('--- 解説クリック → 塗りつぶし ---');
  await page.click('#exp-t-path');
  let f = await fills();
  check('template_path が黄色で塗られる', f['template_path'] === '#ffd43b|#f08c00', f['template_path']);
  check('他ノードは塗られない', !f['start'].startsWith('#ffd43b'), f['start']);
  await page.click('#exp-t-tree');
  f = await fills();
  const filled = Object.entries(f).filter(([k, v]) => v.startsWith('#ffd43b')).map(([k]) => k);
  check('ツリー判定の複数ノードがまとめて塗られる', filled.length >= 5, JSON.stringify(filled));
  check('前の塗り(template_path)は元に戻る', !f['template_path'].startsWith('#ffd43b'), f['template_path']);
  const origFillRestored = await page.evaluate(() => {
    const r = document.querySelector('#canvas g[data-nid="template_path"] rect');
    return r.getAttribute('fill') === r.getAttribute('data-fill0');
  });
  check('元の塗り色が正しく復元される', origFillRestored);

  console.log('--- ノードクリック側も塗りつぶし ---');
  await page.evaluate(() => {
    document.querySelector('#canvas g[data-nid="template_code"]')
      .dispatchEvent(new MouseEvent('click', {bubbles: true}));
  });
  f = await fills();
  check('クリックしたノードが塗られ、他は戻る', f['template_code'] === '#ffd43b|#f08c00'
    && Object.entries(f).filter(([k, v]) => v.startsWith('#ffd43b')).length === 1, f['template_code']);

  check('全操作を通してJSエラーなし', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log('\nPASS ' + ok + ' / FAIL ' + ng);
  process.exit(ng ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
