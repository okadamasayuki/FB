# -*- coding: utf-8 -*-
"""①用の勘定科目マスタ(master.xlsx: B=区分1 C=区分2 D=明細 E=コード J=利用区分)と、よく使う科目リスト(freq.csv)を作る"""
import io, os, zipfile
from xml.sax.saxutils import escape
FX = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fixtures')

def col(i):
    s = ''
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s

def cell(ref, v):
    if v is None or v == '':
        return ''
    return '<c r="%s" t="inlineStr"><is><t>%s</t></is></c>' % (ref, escape(str(v)))

def xlsx(path, sheet_name, rows):
    sd = ''.join('<row r="%d">%s</row>' % (r + 1, ''.join(cell('%s%d' % (col(c), r + 1), v) for c, v in enumerate(row)))
                 for r, row in enumerate(rows))
    files = {
        '[Content_Types].xml': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            '</Types>',
        '_rels/.rels': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            '</Relationships>',
        'xl/workbook.xml': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            '<sheets><sheet name="%s" sheetId="1" r:id="rId1"/></sheets></workbook>' % escape(sheet_name),
        'xl/_rels/workbook.xml.rels': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
            '</Relationships>',
        'xl/worksheets/sheet1.xml': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>%s</sheetData></worksheet>' % sd,
    }
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        for name, body in files.items():
            z.writestr(name, body)

rows = [
    ['No', '勘定科目区分1', '勘定科目区分2', '勘定科目明細', '勘定科目コード', '', '', '', '', '利用区分'],
    ['1', '資産', '流動資産', '現金', '1010001001', '', '', '', '', '○'],
    ['2', '資産', '流動資産', '普通預金', '1010002001', '', '', '', '', '○'],
    ['3', '資産', '流動資産', '当座預金', '1010002002', '', '', '', '', '○'],
    ['4', '資産', '流動資産', '売掛金', '1010003001', '', '', '', '', '○'],
    ['5', '負債', '流動負債', '買掛金', '2010001001', '', '', '', '', '○'],
    ['6', '費用', '経費', '通信費', '5030002001', '', '', '', '', '○'],
    ['7', '費用', '経費', '旅費交通費', '5030001001', '', '', '', '', '○'],
    ['8', '費用', '経費', '出張旅費', '5030001002', '', '', '', '', '○'],
    ['9', '費用', '経費', '雑費', '5030009001', '', '', '', '', ''],
]
xlsx(os.path.join(FX, 'master.xlsx'), '科目マスタ', rows)
io.open(os.path.join(FX, 'freq.csv'), 'w', encoding='utf-8', newline='').write(
    '勘定科目コード,勘定科目名,データ件数\r\n1010001001,現金,5\r\n1010002001,普通預金,3\r\n5030002001,通信費,1\r\n')
print('fixtures written')
