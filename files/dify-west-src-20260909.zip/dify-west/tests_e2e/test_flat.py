#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""コード選択形式(flat: 7桁横並び→10桁絞り込み)の生成とコード確定ノードのテスト。"""
import io
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ROOT, 'tools'))
import miniyaml  # noqa: E402
import generate_workflow as gw  # noqa: E402

extras = miniyaml.load(io.open(os.path.join(ROOT, 'tools', 'workflow_extras.yml'), encoding='utf-8').read())
tree = io.open(os.path.join(HERE, 'tree_coded.md'), encoding='utf-8').read()
root = gw.parse_tree(tree)

ok = ng = 0


def check(name, cond, detail=''):
    global ok, ng
    if cond:
        ok += 1
        print('  [PASS] %s' % name)
    else:
        ng += 1
        print('  [FAIL] %s %s' % (name, detail))

print('--- 派生(codes7 / codes10)---')
c7 = gw.codes7_lines(root)
check('7桁候補は4件', len(c7) == 4, str(c7))
check('中間段の7桁', '- 資産/流動資産 [1100000]: 1年以内に現金化される資産' in c7, str(c7))
check('◆行の7桁(7桁止まり)', '- 資産/固定資産/電話加入権 [1230000]' in c7, str(c7))
c10 = gw.codes10_lines(root)
text10 = '\n'.join(c10)
check('見出し+配下の形', '[1100000] 資産/流動資産' in c10 and '  - 現金 [110]: 手元現金・小口現金' in c10, text10)
check('フルコードは[3桁]に分解', '  - 土地 [220]' in c10, text10)
check('候補なしの7桁も見出しは出る', '[1230000] 資産/固定資産/電話加入権' in c10, text10)
check('コード無しの科目は載らない', '短期貸付金' not in text10, text10)

print('--- generate_flat の構造 ---')
d = gw.generate_flat(tree, extras)
g = d['workflow']['graph']
ids = [n['id'] for n in g['nodes']]
check('ノード16個', len(ids) == 16, str(len(ids)))
check('llm_code7 / llm_code10 / code_final がある',
      all(i in ids for i in ('llm_code7', 'llm_code10', 'code_final')), str(ids))
check('エッジ18本', len(g['edges']) == 18, str(len(g['edges'])))
check('mode は workflow', d['app']['mode'] == 'workflow', d['app']['mode'])
envs = {e['name']: e for e in d['workflow']['environment_variables']}
check('環境変数5個(codes7/codes10/extra/company/policy)',
      set(envs) == {'codes7_list', 'codes10_list', 'extra_accounts', 'company_name', 'accounting_policy'},
      str(set(envs)))
check('codes7_list の値が入っている', envs['codes7_list']['value'] == '\n'.join(c7))
llms = [n for n in g['nodes'] if n['data'].get('type') == 'llm']
check('LLMノード4個(read/summary/code7/code10)', len(llms) == 4, str([n['id'] for n in llms]))
end = [n for n in g['nodes'] if n['id'] == 'end'][0]
check('end に account_code(code_final.code)',
      any(o['variable'] == 'account_code' and o['value_selector'] == ['code_final', 'code']
          for o in end['data']['outputs']))
yaml_text = miniyaml.dump(d)
check('YAMLダンプ→ロードが往復できる', miniyaml.load(yaml_text)['app']['mode'] == 'workflow')
srcs = {e['source'] for e in g['edges']}
tgts = {e['target'] for e in g['edges']}
check('全ノードが配線されている(startとend以外に入出力)',
      all(i in srcs or i == 'end' for i in ids) and all(i in tgts or i == 'start' for i in ids),
      'src欠け:%s tgt欠け:%s' % ([i for i in ids if i not in srcs and i != 'end'],
                                 [i for i in ids if i not in tgts and i != 'start']))

print('--- コード確定ノード ---')
node = {n['id']: n for n in extras['flat']['scaffold_nodes']}['code_final']
ns = {}
exec(node['data']['code'], ns)
main = ns['main']
C7 = '\n'.join(c7)
C10 = '\n'.join(c10)


def run(sel7, sel10, extra=''):
    return main(sel7=sel7, sel10=sel10, codes7=C7, codes10=C10, extra=extra)

r = run('経路: 資産/流動資産\n理由: 現金化が近い', '経路: 資産/流動資産\n名称: 預金\n理由: 銀行預金のため')
check('通常: 7桁+3桁で10桁確定', r['code'] == '1100000120', str(r))
check('表に理由が入る', '銀行預金のため' in r['text'], r['text'])
r = run('経路: 資産/固定資産/電話加入権\n理由: 加入権', '経路: 同上\n名称: 7桁止まり\n理由: 候補なし')
check('7桁止まり', r['code'] == '1230000', str(r))
r = run('経路: 資産/固定資産/有形固定資産\n理由: 建物系', '経路: 同上\n名称: 土地\n理由: 土地の取得')
check('フルコード由来の10桁', r['code'] == '1210000220', str(r))
r = run('質問: この契約は貸付ですか?\n回答例: はい / いいえ', '質問: この契約は貸付ですか?\n回答例: はい / いいえ')
check('質問はそのまま通す(コード空)', r['code'] == '' and r['text'].startswith('質問:') and '補足情報欄' in r['text'], str(r))
r = run('経路: 費用/経費\n理由: 経費', '質問: 通信費と会議費のどちらですか?\n回答例: 通信費 / 会議費')
check('10桁側の質問も通す', r['code'] == '' and '通信費と会議費' in r['text'], str(r))
r = run('経路: 存在しない経路\n理由: x', '経路: 同上\n名称: 7桁止まり\n理由: x')
check('未知の経路は未確定+要確認', r['code'] == '' and '見つかりません' in r['text'], str(r))
r = run('経路: 経費\n理由: 部分表記', '経路: 同上\n名称: 会議費\n理由: 会議のため')
check('経路の後方一致で解決', r['code'] == '5100000320', str(r))
r = run('経路: 資産/流動資産\n理由: x', '経路: 同上\n名称: 知らない名前\n理由: x')
check('未知の名称は7桁止まり+候補列挙', r['code'] == '1100000' and '候補: 現金、預金' in r['text'], str(r))
r = run('経路: 資産/流動資産\n理由: x', '経路: 同上\n名称: 外貨預金\n理由: 追加科目に該当',
        extra='外貨預金 [1100000130]: 外貨建ての預金')
check('追加科目(extra)の10桁が引ける', r['code'] == '1100000130', str(r))
r = run('経路: 資産/流動資産\n理由: x', '経路: 同上\n名称: 保証金\n理由: x',
        extra='保証金 [1290000110]')
check('追加科目の上7桁不一致は要確認つきで採用', r['code'] == '1290000110' and '上7桁が一致しません' in r['text'], str(r))
r = run('経路: 資産/流動資産\n理由: x', '経路: 同上\n名称: \n理由: x')
check('名称が空で候補ありは7桁+要確認', r['code'] == '1100000' and '10桁候補が2件' in r['text'], str(r))

print('--- コード無しツリーの扱い ---')
plain = io.open(os.path.join(ROOT, '分類ツリー.md'), encoding='utf-8').read()
check('コード無しツリーでは codes7 が空', gw.codes7_lines(gw.parse_tree(plain)) == [])
try:
    gw.generate_flat(plain, extras)
    check('コード無しツリーの generate_flat は明確なエラー', False)
except SystemExit as e:
    check('コード無しツリーの generate_flat は明確なエラー', '[7桁]' in str(e), str(e))

print()
print('PASS %d / FAIL %d' % (ok, ng))
sys.exit(1 if ng else 0)
