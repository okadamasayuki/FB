// ブラウザ版のアプリ形式3モード(チャット/フォーム/両方)のUI実機検証
const { chromium } = require('playwright');
const fs = require('fs');

const ROOT = require('path').resolve(__dirname, '..');
const TREE = fs.readFileSync(ROOT + '/分類ツリー.md', 'utf8');

let ok = 0, ng = 0;
function check(name, cond, detail) {
  if (cond) { ok++; console.log('  [PASS] ' + name); }
  else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); }
}

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto('file://' + ROOT + '/ツリーからDify.html');
  await page.evaluate(t => { document.getElementById('tree').value = t; }, TREE);

  async function state() {
    return page.evaluate(() => ({
      yamlLen: YAML ? YAML.length : 0,
      yaml2Len: YAML2 ? YAML2.length : 0,
      runStyle: RUN_STYLE,
      dl2Hidden: document.getElementById('dl2').classList.contains('hide'),
      cp2Hidden: document.getElementById('cp2').classList.contains('hide'),
      dlLabel: document.getElementById('dl').textContent,
      summary: document.getElementById('summary').textContent,
      nodes: GRAPH ? GRAPH.nodes.length : 0,
      chatEnvs: YAML ? (YAML.match(/^    - description:/gm) || []).length : 0,
    }));
  }

  console.log('--- チャット形式(既定)---');
  await page.click('#run');
  let s = await state();
  check('チャット版が生成される(19ノード)', s.nodes === 19, String(s.nodes));
  check('YAML2なし・フォーム版ボタン非表示', s.yaml2Len === 0 && s.dl2Hidden && s.cp2Hidden);
  check('保存ボタンは通常ラベル', s.dlLabel === 'DSL(YAML)を保存', s.dlLabel);
  check('RUN_STYLE=chat', s.runStyle === 'chat', s.runStyle);

  console.log('--- 両方(2ファイル)---');
  await page.check('#styleBoth');
  await page.click('#run');
  s = await state();
  check('主表示はチャット版(19ノード)', s.nodes === 19, String(s.nodes));
  check('YAML(チャット)とYAML2(フォーム)が両方できる',
    s.yamlLen > 10000 && s.yaml2Len > 100000, s.yamlLen + '/' + s.yaml2Len);
  check('フォーム版の保存/コピーが出る', !s.dl2Hidden && !s.cp2Hidden);
  check('保存ボタンが「チャット版を保存」になる', s.dlLabel === 'チャット版を保存', s.dlLabel);
  check('概要に両形式とフォーム版の内訳', s.summary.includes('チャット形式+フォーム形式')
    && s.summary.includes('フォーム版: ノード 68個'), s.summary.slice(0, 300));
  check('RUN_STYLE=both', s.runStyle === 'both', s.runStyle);
  const yaml2 = await page.evaluate(() => YAML2);
  check('YAML2はフォーム版(workflowモード・環境変数31個)',
    yaml2.includes('mode: workflow') && (yaml2.match(/^    - description:/gm) || []).length === 31);
  const dlName = await page.evaluate(() => {
    let captured = [];
    const orig = URL.createObjectURL;
    URL.createObjectURL = () => 'blob:x';
    const origClick = HTMLAnchorElement.prototype.click;
    HTMLAnchorElement.prototype.click = function(){ captured.push(this.download); };
    document.getElementById('dl').click();
    document.getElementById('dl2').click();
    URL.createObjectURL = orig;
    HTMLAnchorElement.prototype.click = origClick;
    return captured;
  });
  check('保存ファイル名が正しい(chat / 無印)',
    JSON.stringify(dlName) === JSON.stringify(
      ['contract-account-classification-chat.yml', 'contract-account-classification.yml']),
    JSON.stringify(dlName));

  console.log('--- フォーム形式(従来のツリー構造)---');
  await page.check('#styleForm');
  await page.click('#run');
  s = await state();
  check('フォーム版が生成される(68ノード)', s.nodes === 68, String(s.nodes));
  check('YAML2は消える・フォーム版ボタンも隠れる', s.yaml2Len === 0 && s.dl2Hidden);
  check('保存ボタンのラベルが戻る', s.dlLabel === 'DSL(YAML)を保存', s.dlLabel);
  check('概要はフォーム形式表記', s.summary.includes('フォーム形式(workflow'), s.summary.slice(0, 200));
  check('RUN_STYLE=form', s.runStyle === 'form', s.runStyle);
  const dlName2 = await page.evaluate(() => {
    let captured = [];
    URL.createObjectURL = () => 'blob:x';
    HTMLAnchorElement.prototype.click = function(){ captured.push(this.download); };
    document.getElementById('dl').click();
    return captured;
  });
  check('フォーム単独の保存名は無印', JSON.stringify(dlName2) === '["contract-account-classification.yml"]',
    JSON.stringify(dlName2));

  check('全操作を通してJSエラーなし', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log('\nPASS ' + ok + ' / FAIL ' + ng);
  process.exit(ng ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
