// 形式チェックボックスUI(chat/form/flat)+追加科目+フラット完全パリティの実機検証
const { chromium } = require('playwright');
const fs = require('fs');

const ROOT = require('path').resolve(__dirname, '..');
const TREE_CODED = fs.readFileSync(process.env.SCRATCH + '/tree_coded.md', 'utf8');
const TREE_PLAIN = fs.readFileSync(ROOT + '/分類ツリー.md', 'utf8');
const TREE_S7 = fs.readFileSync(ROOT + '/tools/tests/sample7.md', 'utf8');
const SCRATCH = process.env.SCRATCH || '.';

let ok = 0, ng = 0;
function check(name, cond, detail) {
  if (cond) { ok++; console.log('  [PASS] ' + name); }
  else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); }
}

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto('file://' + ROOT + '/ツリーからDify.html');

  async function setStyles(chat, form, flat) {
    await page.evaluate(([c, f, l]) => {
      document.getElementById('styleChat').checked = c;
      document.getElementById('styleForm').checked = f;
      document.getElementById('styleFlat').checked = l;
    }, [chat, form, flat]);
  }
  async function state() {
    return page.evaluate(() => ({
      outs: OUTPUTS.map(o => ({key: o.key, file: o.file, len: o.yaml.length,
                               nodes: o.d.workflow.graph.nodes.length})),
      canvasNodes: GRAPH ? GRAPH.nodes.length : 0,
      btns: ['dl', 'cp', 'dl2', 'cp2', 'dl3', 'cp3'].map(i => {
        const b = document.getElementById(i);
        return b.classList.contains('hide') ? null : b.textContent;
      }),
      summary: document.getElementById('summary').textContent,
      checks: document.getElementById('checks').innerText,
    }));
  }

  console.log('--- 既定(チャットのみ)---');
  await page.evaluate(t => { document.getElementById('tree').value = t; }, TREE_CODED);
  await page.click('#run');
  let s = await state();
  check('出力1つ・チャット19ノード', s.outs.length === 1 && s.outs[0].key === 'chat' && s.outs[0].nodes === 19, JSON.stringify(s.outs));
  check('ボタンは1組・通常ラベル', s.btns[0] === 'DSL(YAML)を保存' && s.btns[2] === null && s.btns[4] === null, JSON.stringify(s.btns));

  console.log('--- コード選択形式のみ ---');
  await setStyles(false, false, true);
  await page.click('#run');
  s = await state();
  check('flat 16ノードが生成される', s.outs.length === 1 && s.outs[0].key === 'flat' && s.outs[0].nodes === 16, JSON.stringify(s.outs));
  check('ファイル名は -flat.yml', s.outs[0].file === 'contract-account-classification-flat.yml', s.outs[0].file);
  check('図もflat(16ノード)', s.canvasNodes === 16, String(s.canvasNodes));
  const flatYaml = await page.evaluate(() => OUTPUTS[0].yaml);
  check('YAMLに codes7_list / codes10_list / llm_code7', ['codes7_list', 'codes10_list', 'llm_code7', 'code_final'].every(k => flatYaml.includes(k)));

  console.log('--- 3形式まとめて ---');
  await setStyles(true, true, true);
  await page.click('#run');
  s = await state();
  check('出力3つ(chat/form/flat)', JSON.stringify(s.outs.map(o => o.key)) === '["chat","form","flat"]', JSON.stringify(s.outs));
  check('ノード数 19/31/16', JSON.stringify(s.outs.map(o => o.nodes)) === '[19,31,16]', JSON.stringify(s.outs.map(o => o.nodes)));
  check('ボタン3組・形式名ラベル', s.btns[0] === 'チャット形式を保存' && s.btns[3] === 'フォーム形式をコピー' && s.btns[4] === 'コード選択形式を保存', JSON.stringify(s.btns));
  check('概要に3形式と案内', s.summary.includes('チャット形式:') && s.summary.includes('フォーム形式:')
    && s.summary.includes('コード選択形式:') && s.summary.includes('下の図とDSL表示はチャット形式'), s.summary.slice(0, 300));
  check('図はチャット(19ノード)', s.canvasNodes === 19, String(s.canvasNodes));
  const dlNames = await page.evaluate(() => {
    const captured = [];
    URL.createObjectURL = () => 'blob:x';
    HTMLAnchorElement.prototype.click = function(){ captured.push(this.download); };
    document.getElementById('dl').click();
    document.getElementById('dl2').click();
    document.getElementById('dl3').click();
    return captured;
  });
  check('保存名 chat/-/flat', JSON.stringify(dlNames) === JSON.stringify([
    'contract-account-classification-chat.yml', 'contract-account-classification.yml',
    'contract-account-classification-flat.yml']), JSON.stringify(dlNames));

  console.log('--- コード無しツリーでの flat 失敗の扱い ---');
  await page.evaluate(t => { document.getElementById('tree').value = t; }, TREE_PLAIN);
  await setStyles(true, false, true);
  await page.click('#run');
  s = await state();
  check('チャットは出て、flatは警告でスキップ', s.outs.length === 1 && s.outs[0].key === 'chat'
    && s.checks.includes('生成できなかった形式') && s.checks.includes('[7桁]'), s.checks.slice(0, 200));
  await setStyles(false, false, true);
  await page.click('#run');
  s = await state();
  check('flat単独の失敗は変換できませんでした表示', s.outs.length === 0 && s.checks.includes('変換できませんでした'), s.checks.slice(0, 150));
  check('失敗時はボタンが全部隠れる', s.btns.every(b => b === null), JSON.stringify(s.btns));

  console.log('--- 何も選ばない ---');
  await setStyles(false, false, false);
  await page.click('#run');
  s = await state();
  check('形式未選択の案内', s.checks.includes('1つも選ばれていません'), s.checks.slice(0, 120));

  console.log('--- 追加科目(チェック・埋め込み)---');
  await page.evaluate(t => { document.getElementById('tree').value = t; }, TREE_CODED);
  await page.fill('#extraAcc', '預金 [1100000140]');
  await page.click('#extraCheck');
  let res = await page.evaluate(() => document.getElementById('extraResult').innerText);
  check('同名(裸)はスラッシュ要求', res.includes('同名の科目が既にあります') && res.includes('親分類/預金'), res.slice(0, 150));
  await page.fill('#extraAcc', '外貨/預金 [1100000140]: 外貨建て');
  await page.click('#extraCheck');
  res = await page.evaluate(() => document.getElementById('extraResult').innerText);
  check('スラッシュ付きはOK', res.includes('見つかりませんでした'), res.slice(0, 120));
  await setStyles(true, true, true);
  await page.click('#run');
  s = await state();
  const vals = await page.evaluate(() => OUTPUTS.map(o => {
    const ev = o.d.workflow.environment_variables.find(e => e.name === 'extra_accounts');
    return ev ? ev.value : null;
  }));
  check('extra はチャットとflatに入り、フォームには無い',
    vals[0] === '外貨/預金 [1100000140]: 外貨建て' && vals[1] === null && vals[2] === vals[0], JSON.stringify(vals));
  check('概要に埋め込み先の形式名', s.summary.includes('チャット形式・コード選択形式'), s.summary.slice(-250));
  await page.fill('#extraAcc', '');

  console.log('--- 追加科目チェックのJS結果書き出し(Python照合用・sample7)---');
  const probe = await page.evaluate((tree) => {
    const root = parseTree(tree, []);
    const lines = codeMapLines(root);
    const withCode = lines[lines.length - 1];
    const i = withCode.lastIndexOf(',');
    return { path: withCode.slice(0, i), leaf: withCode.slice(0, i).split('/').pop(), code: withCode.slice(i + 1) };
  }, TREE_S7);
  const CASES = [
    '', '\n# メモ\n   \n',
    '完全に新しい科目X [9999999990]: テスト用',
    probe.leaf + ' [9999999990]', probe.leaf,
    '新設親/' + probe.leaf + ' [9999999990]',
    probe.path + ' [' + probe.code + ']',
    '完全に新しい科目X [' + probe.code + ']',
    '新科目A [9999999990]\n新科目B [9999999990]',
    '新科目C [999999999]', '新科目D [9999999][990]', '新科目E [9999999]',
    '新科目F,9999999990', '[9999999990]', '- 新科目G [9999999990]',
    '新科目H\n新科目H', '新科目I [9999999990]\n新科目I [9999999990]',
    '新科目J [9999999990]', '完全に新しい科目X: 定義だけの行',
    probe.leaf + ' [9999999990]\n新設親/' + probe.leaf + ' [9999999991]\n' + probe.path + ',x\n新科目K',
  ];
  const results = await page.evaluate(([tree, cases]) => {
    const root = parseTree(tree, []);
    return cases.map(c => {
      const r = checkExtraAccounts(c, root);
      const out = r.warns.length
        ? '\n\n---\n⚠️ 後から追加した科目(環境変数 extra_accounts)に確認が必要な行があります:\n'
          + r.warns.map(w => '- ' + w).join('\n')
        : '';
      return { extra: c, out: out };
    });
  }, [TREE_S7, CASES]);
  fs.writeFileSync(SCRATCH + '/js_check_results.json', JSON.stringify(results, null, 1));
  check('20ケースを書き出した', results.length === CASES.length);

  console.log('--- flat 完全ダンプの書き出し(Python照合用)---');
  const flatDump = await page.evaluate((tree) => {
    const d = generateFlat(tree, JSON.parse(EXTRAS_JSON), []);
    for(const n of d.workflow.graph.nodes){
      if(n.data && n.data.type === 'llm' && n.data.model){
        n.data.model.provider = 'langgenius/azure_openai/azure_openai';
        n.data.model.name = 'GPT-4o';
      }
    }
    return dumpYaml(d);
  }, TREE_CODED);
  fs.writeFileSync(SCRATCH + '/js_flat_dump.yml', flatDump);
  check('flatダンプを書き出した', flatDump.length > 10000, String(flatDump.length));

  check('全操作を通してJSエラーなし', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log('\nPASS ' + ok + ' / FAIL ' + ng);
  process.exit(ng ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
