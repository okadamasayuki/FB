#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""3形式統合(共通の仕訳前段+コードの決め方3種)の生成と、結果整形コードノードのテスト。"""
import io
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ROOT, 'tools'))
import miniyaml  # noqa: E402
import generate_workflow as gw  # noqa: E402

extras = miniyaml.load(io.open(os.path.join(ROOT, 'tools', 'workflow_extras.yml'), encoding='utf-8').read())
tree = io.open(os.path.join(HERE, 'tree_coded.md'), encoding='utf-8').read()
root = gw.parse_tree(tree)

ok = ng = 0


def check(name, cond, detail=''):
    global ok, ng
    if cond:
        ok += 1
        print('  [PASS] %s' % name)
    else:
        ng += 1
        print('  [FAIL] %s %s' % (name, detail))


def byid(d):
    return {n['id']: n for n in d['workflow']['graph']['nodes']}


JOURNAL = '\n'.join([
    '仕訳の流れ:',
    '1. (契約締結時) 敷金 / 普通預金',
    '2. (毎月) 支払家賃 / 普通預金',
    '主目的の行: 2',
    '根拠の仕訳: (毎月) 支払家賃 / 普通預金',
    '相手勘定: 支払家賃',
    '性質: 費用',
    '理由: 事務所賃借の月額賃料の支払いのため',
])

print('--- 共通(チャット入力+仕訳の流れ分析)---')
for name, fn in (('flat', gw.generate_flat), ('pick', gw.generate_pick), ('tree', gw.generate_tree)):
    d = fn(tree, extras)
    ids = byid(d)
    check('%s: advanced-chat' % name, d['app']['mode'] == 'advanced-chat')
    check('%s: 共通の前段一式がある' % name,
          all(i in ids for i in ('start', 'doc-extractor', 'if-else-att', 'llm_summary',
                                 'save-summary', 'answer-confirm', 'save-text', 'save-text-read',
                                 'llm_journal', 'if-else-q', 'answer-q', 'env_check')))
    check('%s: 会話変数(contract_text/summary)' % name,
          [v['name'] for v in d['workflow']['conversation_variables']] == ['contract_text', 'contract_summary'])
    edges = {(e['source'], e['sourceHandle'], e['target']) for e in d['workflow']['graph']['edges']}
    check('%s: 添付ありは確認へ・なしは仕訳の流れ分析へ' % name,
          ('if-else-att', 'true', 'llm_summary') in edges and
          ('if-else-att', 'false', 'llm_journal') in edges)
    check('%s: 分析→更問いチェック→質問はそのまま返信' % name,
          ('llm_journal', 'source', 'if-else-q') in edges and
          ('if-else-q', 'case-question', 'answer-q') in edges)
    check('%s: アプリ名は相手勘定判定' % name, d['app']['name'].startswith('契約書 相手勘定判定('), d['app']['name'])
    check('%s: 説明・オープニングが相手勘定' % name,
          '相手勘定' in d['app']['description'] and
          '相手勘定' in d['workflow']['features']['opening_statement'])
    check('%s: company/policy 環境変数あり' % name,
          {'company_name', 'accounting_policy'} <= {e['name'] for e in d['workflow']['environment_variables']})
    check('%s: エッジは isInLoop 形式' % name,
          all('isInLoop' in e['data'] for e in d['workflow']['graph']['edges']))
    check('%s: 往復ダンプOK' % name, miniyaml.load(miniyaml.dump(d))['app']['mode'] == 'advanced-chat')

print('--- flat(2段選択)---')
d = gw.generate_flat(tree, extras)
ids = byid(d)
check('ノード21・エッジ21', len(ids) == 21 and len(d['workflow']['graph']['edges']) == 21,
      '%d/%d' % (len(ids), len(d['workflow']['graph']['edges'])))
check('判定列: 更問いチェック→code7→code10→確定→回答',
      {('if-else-q', 'false', 'llm_code7'), ('llm_code7', 'source', 'llm_code10'),
       ('llm_code10', 'source', 'code_final'), ('code_final', 'source', 'answer-final')} <=
      {(e['source'], e['sourceHandle'], e['target']) for e in d['workflow']['graph']['edges']})
check('LLMは仕訳分析+会話参照+memory+vision',
      '{{#llm_journal.text#}}' in ids['llm_code7']['data']['prompt_template'][1]['text'] and
      '{{#conversation.contract_text#}}' in ids['llm_code7']['data']['prompt_template'][1]['text'] and
      'memory' in ids['llm_code7']['data'] and
      ids['llm_code7']['data']['vision']['configs']['variable_selector'] == ['sys', 'files'])
check('code10 も仕訳分析と7桁選択を参照',
      '{{#llm_journal.text#}}' in ids['llm_code10']['data']['prompt_template'][1]['text'] and
      '{{#llm_code7.text#}}' in ids['llm_code10']['data']['prompt_template'][1]['text'])
check('answer-final は code_final.text', '{{#code_final.text#}}' in ids['answer-final']['data']['answer'])
check('環境変数4個(codes7/codes10/company/policy)',
      {e['name'] for e in d['workflow']['environment_variables']}
      == {'codes7_list', 'codes10_list', 'company_name', 'accounting_policy'})

print('--- pick(一発選択)---')
d = gw.generate_pick(tree, extras)
ids = byid(d)
check('ノード20・エッジ20', len(ids) == 20 and len(d['workflow']['graph']['edges']) == 20,
      '%d/%d' % (len(ids), len(d['workflow']['graph']['edges'])))
cl = gw.codes_pick_lines(root)
check('codes_pick: 10桁は経路/名称、7桁止まりは経路のみ',
      '- 資産/流動資産/預金 [1100000120]: 銀行預金' in cl and
      '- 資産/固定資産/有形固定資産/土地 [1210000220]' in cl and
      '- 資産/固定資産/電話加入権 [1230000]' in cl, str(cl))
check('コード無しの科目は載らない', not any('短期貸付金' in l for l in cl), str(cl))
envs = {e['name'] for e in d['workflow']['environment_variables']}
check('環境変数(codes_list/company/policy)',
      envs == {'codes_list', 'company_name', 'accounting_policy'}, str(envs))
check('codes_list の値が入っている',
      [e for e in d['workflow']['environment_variables'] if e['name'] == 'codes_list'][0]['value'] == '\n'.join(cl))
check('llm_pick は仕訳分析を参照',
      '{{#llm_journal.text#}}' in ids['llm_pick']['data']['prompt_template'][1]['text'])

print('--- pick 結果整形ノード(code_pick)---')
ns = {}
exec({n['id']: n for n in extras['pick']['scaffold_nodes']}['code_pick']['data']['code'], ns)
pick = ns['main']
CODES = '\n'.join(cl)
r = pick(sel='経路: 資産/流動資産/預金\n理由: 銀行預金のため', codes=CODES, journal=JOURNAL)
check('完全一致で確定+結果表', r['code'] == '1100000120' and '## 🔢 判定結果(キャッシュの相手勘定)' in r['text'], str(r))
check('相手勘定は経路の末端+仕訳上の名称を併記',
      '| 相手勘定(科目) | 預金(仕訳上の名称: 支払家賃) |' in r['text'], r['text'])
check('根拠の仕訳が載る', '| 根拠の仕訳 | (毎月) 支払家賃 / 普通預金 |' in r['text'], r['text'])
r = pick(sel='経路: 電話加入権\n理由: 加入権', codes=CODES, journal=JOURNAL)
check('後方一致で確定(7桁止まり候補)', r['code'] == '1230000', str(r))
r = pick(sel='質問: 貸主ですか?\n回答例: はい / いいえ', codes=CODES, journal=JOURNAL)
check('質問はチャット文言で通す', r['code'] == '' and 'そのまま返信してください' in r['text'], str(r))
r = pick(sel='経路: 知らない科目\n理由: x', codes=CODES, journal=JOURNAL)
check('未知は未確定+要確認', r['code'] == '' and '見つかりません' in r['text'], str(r))
r = pick(sel='経路: 費用/経費/通信費\n理由: y',
         codes=CODES, journal=JOURNAL.replace('相手勘定: 支払家賃', '相手勘定: 通信費'))
check('科目名が一致すれば併記しない', '| 相手勘定(科目) | 通信費 |' in r['text'], r['text'])

print('--- flat 結果整形ノード(code_final)---')
ns2 = {}
exec({n['id']: n for n in extras['flat']['scaffold_nodes']}['code_final']['data']['code'], ns2)
C7 = '\n'.join(gw.codes7_lines(root))
C10 = '\n'.join(gw.codes10_lines(root))
r = ns2['main'](sel7='質問: どちらですか?\n回答例: A / B', sel10='', codes7=C7, codes10=C10, journal=JOURNAL)
check('質問はチャット文言で通す', 'そのまま返信してください' in r['text'], str(r))
r = ns2['main'](sel7='経路: 資産/流動資産\n理由: x', sel10='経路: 同上\n名称: 預金\n理由: y',
                codes7=C7, codes10=C10, journal=JOURNAL)
check('通常の10桁確定', r['code'] == '1100000120', str(r))
check('結果表: 相手勘定=10桁名称+併記・経路・理由・根拠の仕訳',
      '| 相手勘定(科目) | 預金(仕訳上の名称: 支払家賃) |' in r['text'] and
      '| 判定経路 | 資産/流動資産/預金 |' in r['text'] and
      '| 判定の理由 | 7桁: x / 10桁: y |' in r['text'] and
      '| 根拠の仕訳 | (毎月) 支払家賃 / 普通預金 |' in r['text'], r['text'])
r = ns2['main'](sel7='経路: 資産/固定資産/電話加入権\n理由: z', sel10='経路: 同上\n名称: 7桁止まり\n理由: -',
                codes7=C7, codes10=C10, journal=JOURNAL)
check('7桁止まりは経路の末端が相手勘定', r['code'] == '1230000' and '電話加入権' in r['text'], str(r))

print('--- tree 結果整形ノード(code_result)---')
ns3 = {}
exec(gw.CODE_RESULT_CODE, ns3)
r = ns3['main'](path='費用/経費/会議費', code='5100000320', journal=JOURNAL)
check('経路とコードと仕訳分析から結果表',
      r['code'] == '5100000320' and
      '| 相手勘定(科目) | 会議費(仕訳上の名称: 支払家賃) |' in r['text'] and
      '| 判定経路 | 費用/経費/会議費 |' in r['text'] and
      '| 根拠の仕訳 | (毎月) 支払家賃 / 普通預金 |' in r['text'], str(r))
r = ns3['main'](path='費用', code='コード未登録', journal=JOURNAL)
check('コード未登録は code 出力空+表示は未登録',
      r['code'] == '' and '| 確定コード | コード未登録 |' in r['text'], str(r))

print('--- tree(ツリー判定・チャット)---')
d = gw.generate_tree(tree, extras)
ids = byid(d)
check('カスケードLLMがある(llm-classify等)', 'llm-classify' in ids, str(sorted(ids))[:200])
check('段階LLMは memory つき(チャット用)', 'memory' in ids['llm-classify']['data'])
check('段階LLMは仕訳分析を参照(USER_BODY_CHAT)',
      '{{#llm_journal.text#}}' in ids['llm-classify']['data']['prompt_template'][1]['text'])
check('段階LLMのシステムは相手勘定の判定',
      '相手勘定' in ids['llm-classify']['data']['prompt_template'][0]['text'])
check('env_check あり+answer-confirm が参照',
      'env_check' in ids and '{{#env_check.output#}}' in ids['answer-confirm']['data']['answer'])
check('更問いチェック(共通)は llm_journal を見る',
      ids['if-else-q']['data']['cases'][0]['conditions'][0]['variable_selector'] == ['llm_journal', 'text'])
check('更問いチェック(段階判定)は集約を見る',
      ids['if-else-q-tree']['data']['cases'][0]['conditions'][0]['variable_selector'] == ['aggregator', 'output'])
check('answer-q-tree は集約の質問を返す', '{{#aggregator.output#}}' in ids['answer-q-tree']['data']['answer'])
check('answer-final は code_result.text', '{{#code_result.text#}}' in ids['answer-final']['data']['answer'])
edges = {(e['source'], e['sourceHandle'], e['target']) for e in d['workflow']['graph']['edges']}
check('質問分岐の配線(共通+段階判定)',
      ('if-else-q', 'case-question', 'answer-q') in edges and
      ('if-else-q', 'false', 'llm-classify') in edges and
      ('template_code', 'source', 'if-else-q-tree') in edges and
      ('if-else-q-tree', 'case-question', 'answer-q-tree') in edges and
      ('if-else-q-tree', 'false', 'code_result') in edges and
      ('code_result', 'source', 'answer-final') in edges)
envs = [e['name'] for e in d['workflow']['environment_variables']]
check('環境変数は rules_* + code_map + company + policy',
      'code_map' in envs and 'company_name' in envs and 'accounting_policy' in envs, str(envs))

print('--- コード無しツリー ---')
plain = io.open(os.path.join(ROOT, '分類ツリー.md'), encoding='utf-8').read()
check('tree はコード無しでも生成できる',
      gw.generate_tree(plain, extras)['app']['mode'] == 'advanced-chat')
for name, fn in (('flat', gw.generate_flat), ('pick', gw.generate_pick)):
    try:
        fn(plain, extras)
        check('%s はコード無しで明確なエラー' % name, False)
    except SystemExit as e:
        check('%s はコード無しで明確なエラー' % name, '[7桁]' in str(e), str(e))

print('--- フォーム版は据え置き ---')
df = gw.generate(plain, extras)
check('form は workflow のまま・68ノード',
      df['app']['mode'] == 'workflow' and len(df['workflow']['graph']['nodes']) == 68,
      str(len(df['workflow']['graph']['nodes'])))
check('form のプロンプトに仕訳分析は入らない',
      all('{{#llm_journal.text#}}' not in (p.get('text', ''))
          for n in df['workflow']['graph']['nodes'] if n['data'].get('prompt_template')
          for p in n['data']['prompt_template']))

print('--- 自己学習(既定: 環境変数 learned_cases 方式。ナレッジ・APIキー不要) ---')
LEARN_ENV_IDS = ['code_cases', 'if-else-learn', 'llm_case', 'answer-case']
LEARN_KB_IDS = ['kr_cases', 'code_pagecases', 'learn_gate', 'if-else-learn-set', 'code_case_body',
                'http_save_case', 'answer-learned', 'answer-nolearn']
for label, fn, base in (('pick', gw.generate_pick, 20), ('tree', gw.generate_tree, 37), ('flat', gw.generate_flat, 21)):
    d0 = fn(tree, extras, True)
    ids0 = byid(d0)
    check(label + ': learn 既定は環境変数方式 = 4ノード追加(%d)、ナレッジ系ノードなし' % (base + 4),
          len(d0['workflow']['graph']['nodes']) == base + 4 and all(i in ids0 for i in LEARN_ENV_IDS)
          and not any(i in ids0 for i in LEARN_KB_IDS), str(len(d0['workflow']['graph']['nodes'])))
    ev0 = {e['name']: e for e in d0['workflow']['environment_variables']}
    check(label + ': 環境変数は learned_cases(空・string)だけ増え、dify_base_url 等は無い',
          'learned_cases' in ev0 and ev0['learned_cases']['value'] == '' and ev0['learned_cases']['value_type'] == 'string'
          and '判定事例.txt' in ev0['learned_cases']['description']
          and not any(k in ev0 for k in ('dify_base_url', 'dataset_api_key', 'case_dataset_id')))
    check(label + ': 形式ごとのノードのほかに env モードの mode 指定でも同じ結果',
          fn(tree, extras, True, {'mode': ' ENV '}) == d0 and fn(tree, extras, True, {'mode': 'xxx'}) == d0)
d_e = gw.generate_pick(tree, extras, True)
by_e = byid(d_e)
edges_e = set((e['source'], e.get('sourceHandle', ''), e['target']) for e in d_e['workflow']['graph']['edges'])
check('env: 経路 if-else-att(false)→if-else-learn→(case-teach)llm_case→answer-case / (false)code_cases→llm_journal',
      ('if-else-att', 'false', 'if-else-learn') in edges_e and ('if-else-learn', 'case-teach', 'llm_case') in edges_e
      and ('llm_case', 'source', 'answer-case') in edges_e and ('if-else-learn', 'false', 'code_cases') in edges_e
      and ('code_cases', 'source', 'llm_journal') in edges_e
      and not any(t == 'kr_cases' or s == 'kr_cases' for s, _, t in edges_e))
cc = by_e['code_cases']['data']
check('env: code_cases は python3 で query(sys.query)/summary(会話変数)/learned(env.learned_cases) を受け cases を出す',
      cc['type'] == 'code' and cc['code_language'] == 'python3' and 'cases' in cc['outputs']
      and [v['value_selector'] for v in cc['variables']] == [['sys', 'query'], ['conversation', 'contract_summary'], ['env', 'learned_cases']]
      and [v['variable'] for v in cc['variables']] == ['query', 'summary', 'learned'])
jp_e = by_e['llm_journal']['data']['prompt_template'][0]['text']
check('env: 判定プロンプトの【過去の正解事例】は {{#code_cases.cases#}} で、ナレッジの {{#context#}} は使わない(context 無効のまま)',
      '{{#code_cases.cases#}}' in jp_e and '{{#context#}}' not in jp_e and '読み取り内容への訂正ではない' in jp_e
      and not by_e['llm_journal']['data']['context']['enabled'])
ac = by_e['answer-case']['data']['answer']
check('env: 「正解:」の回答はカード本文と learned_cases に貼る案内(保存はしない)',
      '{{#llm_case.text#}}' in ac and 'learned_cases' in ac and 'ナレッジ・APIキー不要' in ac and '保存しました' not in ac)
check('env: 説明文・開始文に「ナレッジ・APIキー不要」と learned_cases',
      'ナレッジ・APIキー不要' in d_e['app']['description'] and 'learned_cases' in d_e['workflow']['features']['opening_statement'])
check('env: 学習レーンは最上部(LEARN_Y)の 7〜10 列目に並ぶ',
      by_e['if-else-learn']['position'] == {'x': gw.colx(7), 'y': gw.LEARN_Y}
      and by_e['code_cases']['position'] == {'x': gw.colx(8), 'y': gw.LEARN_Y}
      and by_e['llm_case']['position'] == {'x': gw.colx(9), 'y': gw.LEARN_Y}
      and by_e['answer-case']['position'] == {'x': gw.colx(10), 'y': gw.LEARN_Y})
check('learn オフでは code_cases も learned_cases も無い',
      'code_cases' not in byid(gw.generate_pick(tree, extras, False))
      and all(e['name'] != 'learned_cases' for e in gw.generate_pick(tree, extras, False)['workflow']['environment_variables']))

print('--- code_cases(参考事例の選択)のコードを実行して確認 ---')
ns = {}
exec(gw.LEARN_CASES_CODE, ns)
cases_main = ns['main']
TXT = ('### 決裁A 清掃業務委託\n【判定事例】\n契約の種類: 業務委託契約(清掃)\n正解: 支払手数料\n決め手: 役務提供の対価\n\n'
       '### 決裁B システム開発\n【判定事例】\n契約の種類: ソフトウェア開発委託契約\n正解: ソフトウェア仮勘定\n決め手: 自社利用ソフトの制作\n\n'
       '### 決裁C 事務所賃貸\n【判定事例】\n契約の種類: 事務所賃貸借契約\n正解: 賃借料\n決め手: 物件を借りて賃料を払う\n')
r1 = cases_main(query='OK', summary='契約名: 清掃業務委託契約 主目的: 建物の清掃業務の委託', learned=TXT)['cases']
check('似た順に並ぶ: 清掃の読み取り内容なら清掃の事例が先頭', r1.startswith('【判定事例】\n契約の種類: 業務委託契約(清掃)'), r1[:60])
check('「### 決裁名」の見出し行は落とし、カード本文だけを空行区切りで返す', '###' not in r1 and r1.count('【判定事例】') == 3)
r2 = cases_main(query='OK\n\n参考事例:\n【判定事例】\n契約の種類: 事務所賃貸借契約\n正解: 賃借料\n決め手: 物件を借りて賃料を払う',
                summary='事務所の賃貸借契約', learned=TXT)['cases']
check('⑤が「OK」に添えた参考事例も候補に入り、同じカードは重複しない', r2.count('【判定事例】') == 3 and r2.startswith('【判定事例】\n契約の種類: 事務所賃貸借契約'), r2[:80])
check('空の環境変数なら空文字(判定はそのまま動く)', cases_main(query='OK', summary='xxx', learned='')['cases'] == ''
      and cases_main(query='OK', summary='', learned=TXT)['cases'] == '')
many = '\n\n'.join('【判定事例】\n契約の種類: 賃貸借契約%d\n正解: 賃借料' % i for i in range(9))
check('カードだけの列(見出し無し)も読め、4件までに絞る', cases_main(query='OK', summary='賃貸借契約', learned=many)['cases'].count('【判定事例】') == 4)
check('文字の重なりが無いカードは出さない', cases_main(query='OK', summary='αβγ', learned=TXT)['cases'] == '')

print('--- 事例ナレッジ方式(mode=kb)の「設定込みDSL」(learn_cfg) ---')
CFG = {'mode': 'kb', 'base_url': 'https://x.example.com/v1', 'dataset_key': 'dataset-abc', 'dataset_id': 'ds-123'}
for label, fn in (('pick', gw.generate_pick), ('tree', gw.generate_tree), ('flat', gw.generate_flat)):
    dc = fn(tree, extras, True, CFG)
    kr = byid(dc)['kr_cases']['data']
    ev = {e['name']: e['value'] for e in dc['workflow']['environment_variables']}
    check(label + ': dataset_ids にナレッジIDが入り desc も設定済み文言',
          kr['dataset_ids'] == ['ds-123'] and '設定済み' in kr['desc'],
          str(kr['dataset_ids']))
    check(label + ': 環境変数3つに値が書き込まれる',
          ev.get('dify_base_url') == CFG['base_url'] and ev.get('dataset_api_key') == CFG['dataset_key']
          and ev.get('case_dataset_id') == CFG['dataset_id'])
d_part = gw.generate_pick(tree, extras, True, {'mode': 'kb', 'dataset_id': '  ds-9  '})
kr_p = byid(d_part)['kr_cases']['data']
ev_p = {e['name']: e['value'] for e in d_part['workflow']['environment_variables']}
check('部分入力: IDだけでも trim して入り、他の環境変数は空のまま',
      kr_p['dataset_ids'] == ['ds-9'] and ev_p['case_dataset_id'] == 'ds-9'
      and ev_p['dify_base_url'] == '' and ev_p['dataset_api_key'] == '')
d_empty = gw.generate_pick(tree, extras, True, {'mode': 'kb'})
kr_e = byid(d_empty)['kr_cases']['data']
check('kb でID なしは従来どおり(dataset_ids 空・インポート後の案内文言)・30ノード・learned_cases 無し',
      kr_e['dataset_ids'] == [] and 'インポート後' in kr_e['desc'] and len(d_empty['workflow']['graph']['nodes']) == 30
      and all(e['name'] != 'learned_cases' for e in d_empty['workflow']['environment_variables']))
d_off = gw.generate_pick(tree, extras, False, CFG)
check('learn オフなら cfg を渡しても learn ノード/環境変数は入らない',
      'kr_cases' not in byid(d_off)
      and all(e['name'] != 'case_dataset_id' for e in d_off['workflow']['environment_variables']))

print('--- 事例ナレッジ方式: キー未設定でもカードを返す/「OK」に添えた参考事例を判定に使う ---')
d_l = gw.generate_pick(tree, extras, True, {'mode': 'kb'})
by_l = byid(d_l)
edges_l = set((e['source'], e.get('sourceHandle', ''), e['target']) for e in d_l['workflow']['graph']['edges'])
check('learn: code_pagecases(参考事例の取り出し)ノードがあり、OK側の経路 if-else-learn(false)→code_pagecases→kr_cases',
      'code_pagecases' in by_l and ('if-else-learn', 'false', 'code_pagecases') in edges_l
      and ('code_pagecases', 'source', 'kr_cases') in edges_l)
check('learn: 正解側の経路 learn_gate→llm_case→if-else-learn-set→(case-set)code_case_body / (false)answer-nolearn',
      ('learn_gate', 'source', 'llm_case') in edges_l and ('llm_case', 'source', 'if-else-learn-set') in edges_l
      and ('if-else-learn-set', 'case-set', 'code_case_body') in edges_l
      and ('if-else-learn-set', 'false', 'answer-nolearn') in edges_l)
nol = by_l['answer-nolearn']['data']['answer']
check('learn: 保存先未設定の回答にカード本文({{#llm_case.text#}})と「保存していません」が入る',
      '{{#llm_case.text#}}' in nol and '事例ナレッジには保存していません' in nol, nol[:80])
jp = by_l['llm_journal']['data']['prompt_template'][0]['text']
check('learn: 判定プロンプトの【過去の正解事例】に {{#context#}} と {{#code_pagecases.cases#}} が並び、参考事例は訂正でないと明記(context 有効)',
      '{{#context#}}' in jp and '{{#code_pagecases.cases#}}' in jp and '読み取り内容への訂正ではない' in jp
      and by_l['llm_journal']['data']['context'] == {'enabled': True, 'variable_selector': ['kr_cases', 'result']})
pc = by_l['code_pagecases']['data']
check('learn: code_pagecases は sys.query から「参考事例:」以下を cases に出す python3 コード',
      pc['type'] == 'code' and pc['code_language'] == 'python3' and '参考事例:' in pc['code']
      and pc['variables'][0]['value_selector'] == ['sys', 'query'] and 'cases' in pc['outputs'])
check('learn オフでは code_pagecases も無い', 'code_pagecases' not in byid(gw.generate_pick(tree, extras, False)))

print()
print('PASS %d / FAIL %d' % (ok, ng))
sys.exit(1 if ng else 0)
