// ②-2 十桁の定義: Excel(複数)から定義を自動転記する機能の通しテスト
const { chromium } = require('playwright');
const ROOT = require('path').resolve(__dirname, '..');
const FX = __dirname + '/fixtures/';
let ok = 0, ng = 0;
function check(name, cond, detail) {
  if (cond) { ok++; console.log('  [PASS] ' + name); }
  else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); }
}
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage();
  const errors = [], dialogs = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('dialog', d => { dialogs.push(d.message()); d.dismiss(); });
  await page.goto('file://' + ROOT + '/十桁定義.html');
  await page.click('#sample');
  const valOf = code => page.evaluate(c => {
    const it = ITEMS.find(x => x.parsed.code === c);
    return document.querySelector('[data-line="' + it.lineIdx + '"]').value;
  }, code);
  const setVal = (code, v) => page.evaluate(([c, val]) => {
    const it = ITEMS.find(x => x.parsed.code === c);
    document.querySelector('[data-line="' + it.lineIdx + '"]').value = val;
  }, [code, v]);

  console.log('--- 読み込みと自動検出 ---');
  await page.setInputFiles('#xlFile', [FX + 'defs1.xlsx', FX + 'defs2.xlsx']);
  await page.waitForFunction(() => document.querySelectorAll('.xlp').length === 2);
  let s = await page.evaluate(() => XL.map(p => ({name: p.name, key: p.key, src: p.src, hdrRow: p.hdrRow, label: p.label, sheets: p.sheets, sheet: p.sheet, rows: p.rows.length})));
  check('xlsx 2件を読み、コード列A・見出し行あり・転記列は説明文の列(C / E)を自動検出',
    s[0].key === 0 && s[0].src === 2 && s[0].hdrRow === 0 && s[0].label === '勘定科目の説明' && s[0].rows === 7
    && s[1].key === 0 && s[1].src === 4 && s[1].hdrRow === 0 && s[1].label === '事例表示内容' && s[1].sheets.length === 2 && s[1].sheet === '科目事例',
    JSON.stringify(s));
  let st = await page.evaluate(() => [...document.querySelectorAll('.xlp-stat')].map(e => e.textContent));
  check('一致件数のプレビュー(説明: 一致4・空1・ツリー外1 / 事例: 一致3)',
    st[0].includes('一致 4件') && st[0].includes('内容が空 1件') && st[0].includes('Excelにだけあるコード 1件') && st[0].includes('【勘定科目の説明】')
    && st[1].includes('一致 3件'), JSON.stringify(st));
  let prev = await page.evaluate(() => document.querySelector('.xlp[data-i="1"] .xlprev').textContent);
  check('プレビュー表に見出しと先頭行が出る(数値セルのコードも文字として)', prev.includes('事例表示内容') && prev.includes('5030012001') && prev.includes('香典'), prev.slice(0, 120));

  console.log('--- 転記(定義欄をいったん空にしてから入れ直す)---');
  await page.fill('.xlp[data-i="1"] .xlp-label', '事例');
  await setVal('5030012001', '手入力');
  await page.click('#xlApply');
  let v1 = await valOf('5030012001'), v2 = await valOf('1010003001'), v3 = await valOf('5030001002'), v4 = await valOf('1010003003'), v5 = await valOf('5030012003');
  check('定義欄を空にしてから【見出し】内容を項目ごとに改行して転記(転記前の手入力は残らない・セル内の改行は空白に)', v1 === '【勘定科目の説明】従業員・取引先の慶弔に伴う支出。 香典や祝儀を含む\n【事例】香典、祝儀、花輪代、供花', v1);
  check('転記モードの選択欄と「見出しごと消す」欄は無い', await page.evaluate(() => !document.querySelector('input[name="xlMode"]') && !document.getElementById('rmLabel') && !document.getElementById('rmLabelApply')));
  const fit = await page.evaluate(() => { const it = ITEMS.find(x => x.parsed.code === '5030012001'); const ta = document.querySelector('[data-line="' + it.lineIdx + '"]'); return {tag: ta.tagName, lines: ta.value.split('\n').length, h: ta.offsetHeight, sh: ta.scrollHeight, ch: ta.clientHeight}; });
  check('定義欄は複数行で、2つのExcelからの転記が改行され、高さが中身に合って全体が見える', fit.tag === 'TEXTAREA' && fit.lines === 2 && fit.h >= 40 && fit.sh <= fit.ch + 2, JSON.stringify(fit));
  check('他のコードにも転記される(C列 / E列)', v2 === '【勘定科目の説明】日常の入出金に使う預金口座。給与振込や自動引落もここ' && v3 === '【事例】新幹線・航空券・宿泊費・日当' && v4 === '【事例】満期日のある預け入れ', JSON.stringify([v2, v3, v4]));
  check('内容が空のセルは転記しない', v5 === '', v5);
  let res = await page.evaluate(() => document.getElementById('xlResult').textContent);
  check('結果の件数表示', res.includes('Excel 2件から 7回転記') && res.includes('定義が入った科目 6件') && res.includes('空欄のままの科目 3件'), res);
  let hit = await page.evaluate(() => document.querySelectorAll('textarea.xl-hit').length);
  check('転記した欄に印が付く(6件)', hit === 6, String(hit));
  await page.click('#xlApply');
  check('もう一度転記しても二重にならない', (await valOf('5030012001')) === v1, await valOf('5030012001'));
  await setVal('5030012001', '転記のあとの手入力');
  await page.fill('.xlp[data-i="0"] .xlp-label', '説明');
  await page.click('#xlApply');
  let v6 = await valOf('5030012001');
  check('見出しを変えて転記し直すと、空にしてから入れ直すので前回の見出しも手入力も残らない', v6 === '【説明】従業員・取引先の慶弔に伴う支出。 香典や祝儀を含む\n【事例】香典、祝儀、花輪代、供花' && (await page.evaluate(() => document.getElementById('xlResult').textContent)).includes('空にしてから入れ直し'), v6 + ' / ' + await page.evaluate(() => document.getElementById('xlResult').textContent));
  let v7 = v6;

  console.log('--- CSV追加 ---');
  await page.setInputFiles('#xlFile', [FX + 'extra.csv']);
  await page.waitForFunction(() => document.querySelectorAll('.xlp').length === 3);
  s = await page.evaluate(() => XL[2] && ({key: XL[2].key, src: XL[2].src, hdrRow: XL[2].hdrRow, label: XL[2].label, rows: XL[2].rows.length}));
  check('CSV(見出しなし)は1行目を見出し扱いせず、見出しは既定の「解説」', s && s.key === 0 && s.src === 1 && s.hdrRow === -1 && s.label === '解説' && s.rows === 2, JSON.stringify(s));
  await page.click('#xlApply');
  let v8 = await valOf('5030012002');
  check('CSVの内容も転記される', v8 === '【説明】取引先との飲食による接待\n【解説】社内の懇親会は含めない(福利厚生費)', v8);

  console.log('--- ツリーへの書き込みと往復 ---');
  await page.click('#apply');
  let out = await page.evaluate(() => ({out: OUT, verdict: document.getElementById('verdict').textContent}));
  check('定義入りツリーにコードごとの定義が入り、コードは変わらない',
    out.out.includes('[5030012001]: 【説明】従業員・取引先の慶弔に伴う支出。 香典や祝儀を含む / 【事例】香典、祝儀、花輪代、供花')
    && out.out.includes('[5030001002]: 【事例】新幹線・航空券・宿泊費・日当') && out.verdict.includes('コードは1つも変わっていません'), out.verdict);
  await page.evaluate(() => { document.getElementById('src').value = OUT; });
  await page.click('#make');
  check('定義入りツリーを貼り直すと転記した定義が入った状態で開く', (await valOf('5030012001')) === v7 && (await valOf('5030012002')) === v8, await valOf('5030012001'));
  await page.click('.xlp[data-i="2"] .xlp-del');
  s = await page.evaluate(() => XL.length);
  check('「外す」でパネルが減る', s === 2, String(s));

  console.log('--- Excelに見えて中身が別形式のファイル ---');
  await page.setInputFiles('#xlFile', [FX + 'sysexport.xls', FX + 'htmlexport.xls', FX + 'sjis.csv']);
  await page.waitForFunction(() => document.querySelectorAll('.xlp').length === 5);
  s = await page.evaluate(() => XL.slice(2).map(p => ({kind: p.kind, key: p.key, src: p.src, hdrRow: p.hdrRow, label: p.label, rows: p.rows.length, r1: p.rows[1] || p.rows[0]})));
  check('SpreadsheetML 2003(拡張子.xls)を読む: Index飛びも列・行に反映、見出しは「備考」',
    s[0].kind === 'xml' && s[0].rows === 5 && s[0].hdrRow === 0 && s[0].key === 0 && s[0].src === 3 && s[0].label === '備考'
    && s[0].r1[0] === '5030002001' && s[0].r1[3] === '電話・郵便・インターネット回線の費用', JSON.stringify(s[0]));
  check('HTMLの表(Shift_JIS・拡張子.xls)を文字化けなく読む',
    s[1].kind === 'html' && s[1].rows === 3 && s[1].hdrRow === 0 && s[1].src === 2 && s[1].label === '説明'
    && s[1].r1[2] === '満期まで引き出さない預金(1年もの)', JSON.stringify(s[1]));
  check('Shift_JISのCSVも文字化けなく読む', s[2].kind === 'csv' && s[2].r1[2] === '交通費と宿泊費(日当を含む)', JSON.stringify(s[2]));
  await page.click('#xlApply');
  let v9 = await valOf('5030002001'), v10 = await valOf('5030012003'), v11 = await valOf('5030001002');
  check('XML/HTML/CSVの内容も定義欄に転記される',
    v9 === '【備考】電話・郵便・インターネット回線の費用' && v10.endsWith('【説明】贈答品・ゴルフ等、飲食以外の接待')
    && v11.endsWith('【解説】交通費と宿泊費(日当を含む)'), JSON.stringify([v9, v10, v11]));
  await page.setInputFiles('#xlFile', [FX + 'old.xls']);
  await page.waitForFunction(n => window.__d === undefined || true, null, {timeout: 1000}).catch(() => {});
  await page.waitForTimeout(600);
  await page.setInputFiles('#xlFile', [FX + 'empty.xlsx']);
  await page.waitForTimeout(600);
  await page.setInputFiles('#xlFile', [FX + 'fake.xlsx']);
  await page.waitForTimeout(600);
  s = await page.evaluate(() => XL.length);
  check('読めないファイルはパネルに増えず、理由つきのメッセージが出る(古い.xls / 0バイト / 中身がテキストの.xlsx)',
    s === 5 && dialogs.length === 3 && dialogs[0].includes('古い形式の .xls') && dialogs[0].includes('608バイト')
    && dialogs[1].includes('0バイト') && dialogs[2].includes('拡張子は .xlsx ですが') && dialogs[2].includes('保存し直して'),
    JSON.stringify(dialogs));

  console.log('--- まとめ版(バンドル)の②-2にも入っている ---');
  const page2 = await browser.newPage();
  page2.on('pageerror', e => errors.push('bundle: ' + String(e)));
  await page2.goto('file://' + ROOT + '/勘定科目分類ツール.html');
  const btn = page2.locator('nav button', { hasText: '②-2' });
  await btn.click();
  await page2.waitForFunction(() => [...document.querySelectorAll('iframe')].some(f => f.contentDocument && f.contentDocument.getElementById('xlBox')), null, {timeout: 20000});
  check('バンドルの②-2タブに「Excelから定義を取り込む」がある', true);

  check('全操作を通してJSエラーなし(ダイアログは想定の3件だけ)', errors.length === 0 && dialogs.length === 3, errors.join(' | '));
  await browser.close();
  console.log('\nPASS ' + ok + ' / FAIL ' + ng);
  process.exit(ng ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
