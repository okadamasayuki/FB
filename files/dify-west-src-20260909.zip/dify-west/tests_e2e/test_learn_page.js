// ⑤「自動学習ループ」のE2E: モックDify(アプリ+ナレッジAPI)に対して、
// エポック学習(33%→67%→100%)・カード差し替え(DELETE+再作成)・ホールドアウト・
// 停止→再開・異常系(自己学習なしアプリ)までを検証する
const { chromium } = require('playwright');
const http = require('http');

const ROOT = require('path').resolve(__dirname, '..');
let ok = 0, ng = 0;
function check(name, cond, detail) {
  if (cond) { ok++; console.log('  [PASS] ' + name); }
  else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); }
}

// ---- モックDify
// アプリ: cA=最初から正解 / cB=1回教えると正解 / cC=2回教えないと正解しない
// 「正解: …」の返信で kb を更新し、ナレッジにカード(doc)を1枚作る
const CORRECT = {
  cA: '| 相手勘定(科目) | 預金 |\n| 確定コード | 1010003001 |',
  cB: '| 相手勘定(科目) | 賃借料 |\n| 確定コード | 5030001001 |',
  cC: '| 相手勘定(科目) | リース料 |\n| 確定コード | 5030009001 |',
};
const WRONG_B = '| 相手勘定(科目) | 会議費 |\n| 確定コード | 9999999999 |';
const WRONG_C0 = '| 相手勘定(科目) | 修繕費 |\n| 確定コード | 8888888888 |';
const WRONG_C1 = '| 相手勘定(科目) | 賃借料 |\n| 確定コード | 5030001001 |';
const SAVED_REPLY = '✅ 正解を事例ナレッジに保存しました(HTTP 200)。'
  + '次回から、似た契約の判定前に自動で検索して参考にします。\n\n# 判定事例カード(モック)';
// キー未設定のアプリ(app-learn-nokey): 保存せずカード本文を返す(新しい生成器の回答)。
// 判定は「OK」に添えられた参考事例にそのケースのカードが入っていれば正解する(cCは2回目のカードが必要)
const NOSAVE_HEAD = '📋 正解を受け取り、判定事例カードを作りました。保存先(環境変数 dify_base_url / dataset_api_key / '
  + 'case_dataset_id)が未設定のため、事例ナレッジには保存していません。';
// ③の既定(環境変数 learned_cases 方式)のアプリ(app-learn-env): 保存の仕組み自体が無く、カードを返すだけ
const ENV_HEAD = '📋 正解を受け取り、判定事例カードを作りました。';
const ENV_TAIL = '\n\n---\nこのカードは⑤の自動学習が集めて 判定事例.txt にまとめます。社内で使うアプリには、その中身をアプリの環境変数 '
  + 'learned_cases に貼ると、次回から似た契約の判定前に参考にします(ナレッジ・APIキー不要)。';
const SUMMARY = {
  cA: '読み取りました。契約の種類: 金銭消費貸借契約(貸付)。OKと返信してください。',
  cB: '読み取りました。契約の種類: 事務所賃貸借契約(賃料月額)。OKと返信してください。',
  cC: '読み取りました。契約の種類: 設備リース契約(リース資産)。OKと返信してください。',
};
const CARD = {
  cA: '【判定事例】\n契約の種類: 金銭消費貸借契約\n当社の立場: 貸主\n正解: 預金 [1010003001]\n決め手: 貸付金の実行',
  cB: '【判定事例】\n契約の種類: 事務所賃貸借契約\n当社の立場: 借主\n間違えやすい判定: 会議費\n正解: 賃借料 [5030001001]\n決め手: 物件を借りて毎月賃料を払う',
  cC: '【判定事例】\n契約の種類: 設備リース契約\n当社の立場: 借主\n間違えやすい判定: 賃借料\n正解: リース料 [5030009001]\n決め手: リース会社との契約',
};

const state = {kb: {}, docs: [], seq: 0, docSeq: 0, convSeq: 0, deletes: 0, teaches: [], convCase: {}, delayMs: 0,
               cards: {}, okQueries: []};
function resetState() {
  state.kb = {}; state.docs = []; state.seq = 0; state.docSeq = 0; state.convSeq = 0;
  state.deletes = 0; state.teaches = []; state.convCase = {}; state.delayMs = 0;
  state.cards = {}; state.okQueries = [];
}
function answerFor(key, c) {
  if (key === 'app-nolearn') return c === 'cB' ? WRONG_B : CORRECT[c];
  if (c === 'cB') return (state.kb.cB || 0) >= 1 ? CORRECT.cB : WRONG_B;
  if (c === 'cC') {
    const n = state.kb.cC || 0;
    return n >= 2 ? CORRECT.cC : (n === 1 ? WRONG_C1 : WRONG_C0);
  }
  return CORRECT.cA;
}

const srv = http.createServer((req, res) => {
  const cors = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Authorization, Content-Type',
  };
  if (req.method === 'OPTIONS') { res.writeHead(204, cors); res.end(); return; }
  const key = (req.headers.authorization || '').replace('Bearer ', '');
  const path = req.url.split('?')[0];
  let body = [];
  req.on('data', c => body.push(c));
  req.on('end', () => {
    const raw = Buffer.concat(body);
    const send = (code, obj) => {
      res.writeHead(code, Object.assign({'Content-Type': 'application/json'}, cors));
      res.end(JSON.stringify(obj));
    };
    // ---- ナレッジ(データセット)API
    if (path.startsWith('/v1/datasets/')) {
      if (key !== 'dataset-key') return send(401, {message: 'unauthorized'});
      const m = path.match(/^\/v1\/datasets\/([^/]+)\/documents(?:\/([^/]+))?$/);
      if (!m || m[1] !== 'ds-1') return send(404, {message: 'dataset not found'});
      if (req.method === 'DELETE') {
        const i = state.docs.findIndex(d => d.id === m[2]);
        if (i < 0) return send(404, {message: 'document not found'});
        state.docs.splice(i, 1);
        state.deletes++;
        return send(200, {result: 'success'});
      }
      return send(200, {data: state.docs.slice(), has_more: false});
    }
    // ---- アプリAPI
    if (path.endsWith('/info') || path.endsWith('/parameters')) {
      if (key !== 'app-learn' && key !== 'app-nolearn' && key !== 'app-learn-nokey' && key !== 'app-learn-env') return send(401, {message: 'unauthorized'});
      return send(200, {name: 'mock-learn-app'});
    }
    if (path.endsWith('/files/upload')) {
      const mm = raw.toString('utf8').match(/filename="([^"]+)"/);
      const fname = mm ? mm[1] : '';
      const c = fname.indexOf('賃貸借') >= 0 ? 'cB' : (fname.indexOf('リース') >= 0 ? 'cC' : 'cA');
      return send(200, {id: 'file-' + c + '-' + (++state.seq)});
    }
    if (path.endsWith('/chat-messages')) {
      const d = JSON.parse(raw.toString('utf8'));
      const finish = () => {
        if (d.files && d.files.length) {
          const c = d.files[0].upload_file_id.indexOf('-cB-') >= 0 ? 'cB'
            : (d.files[0].upload_file_id.indexOf('-cC-') >= 0 ? 'cC' : 'cA');
          const conv = 'conv-' + c + '-' + (++state.convSeq);
          state.convCase[conv] = c;
          return send(200, {conversation_id: conv, answer: SUMMARY[c]});
        }
        const c = state.convCase[d.conversation_id] || 'cA';
        if ((d.query || '').indexOf('正解') === 0) {
          if (key === 'app-nolearn') {
            return send(200, {conversation_id: d.conversation_id, answer: answerFor(key, c)});
          }
          if (key === 'app-learn-nokey' || key === 'app-learn-env') {
            state.cards[c] = (state.cards[c] || 0) + 1;
            state.teaches.push({c: c, q: d.query});
            const card = CARD[c] + (state.cards[c] >= 2 ? '\n決め手の補足(2回目): 賃借料と混同しない。リース期間とリース料の定めがある' : '');
            if (key === 'app-learn-env') {
              return send(200, {conversation_id: d.conversation_id, answer: ENV_HEAD + '\n\n' + card + ENV_TAIL});
            }
            return send(200, {conversation_id: d.conversation_id,
              answer: NOSAVE_HEAD + '\n\n' + card + '\n\n---\nこのカードは、事例ナレッジに「テキストを追加」で貼るか…'});
          }
          state.kb[c] = (state.kb[c] || 0) + 1;
          const doc = {id: 'doc-' + (++state.docSeq), name: '判定事例: ' + c};
          state.docs.push(doc);
          state.teaches.push({c: c, q: d.query});
          return send(200, {conversation_id: d.conversation_id, answer: SAVED_REPLY});
        }
        if (key === 'app-learn-nokey' || key === 'app-learn-env') {
          const q = d.query || '';
          state.okQueries.push({c: c, q: q});
          const has = (t) => q.indexOf('参考事例:') >= 0 && q.indexOf(t) >= 0;
          let ans = CORRECT.cA;
          if (c === 'cB') ans = has('正解: 賃借料') ? CORRECT.cB : WRONG_B;
          if (c === 'cC') ans = has('(2回目)') ? CORRECT.cC : (has('正解: リース料') ? WRONG_C1 : WRONG_C0);
          return send(200, {conversation_id: d.conversation_id, answer: ans});
        }
        return send(200, {conversation_id: d.conversation_id, answer: answerFor(key, c)});
      };
      setTimeout(finish, state.delayMs);
      return;
    }
    send(404, {message: 'not found'});
  });
});

(async () => {
  await new Promise(r => srv.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + srv.address().port + '/v1';

  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));

  async function openAndFill(appKey) {
    await page.goto('file://' + ROOT + '/自動学習.html');
    await page.fill('#lnUrl', base);
    await page.fill('#lnKey', appKey);
    await page.fill('#lnDsKey', 'dataset-key');
    await page.fill('#lnDsId', 'ds-1');
  }
  async function ingest() {
    await page.evaluate(async () => {
      const mk = (rel, text) => ({rel, file: new File([text], rel.split('/').pop(), {type: 'text/plain'})});
      const items = [
        mk('元データ/案件A_預金/貸付契約.txt', '貸付 一千万円'),
        mk('元データ/案件A_預金/正解.txt', '預金 [1010003001]'),
        mk('元データ/案件B_賃貸借/賃貸借契約.txt', '賃料 月額'),
        mk('元データ/案件B_賃貸借/正解.txt', '賃借料 [5030001001]'),
        mk('元データ/案件C_リース/リース契約.txt', 'リース資産'),
        mk('元データ/案件C_リース/正解.txt', 'リース料 [5030009001]'),
      ];
      await lnIngest(items);
    });
  }
  const waitDone = (t) => page.waitForFunction(
    () => document.getElementById('lnProg').textContent.indexOf('終了') === 0, null, {timeout: t || 60000});

  console.log('--- 接続テスト(キー未入力=URL疎通のCORSチェックだけ)---');
  await page.goto('file://' + ROOT + '/自動学習.html');
  await page.fill('#lnUrl', base);
  await page.click('#lnTest');
  await page.waitForFunction(() => document.getElementById('lnTestOut').textContent.includes('届きました'));
  let tp = await page.evaluate(() => document.getElementById('lnTestOut').textContent);
  check('キー未入力でもURL疎通チェックが動く(401応答でもCORS通過を報告)',
    tp.includes('HTTP 401') && tp.includes('CORSは通っています'), tp);

  console.log('--- 接続テスト(アプリ+ナレッジAPI)---');
  await openAndFill('app-learn');
  await page.click('#lnTest');
  await page.waitForFunction(() => document.getElementById('lnTestOut').textContent.includes('事例ナレッジ'));
  let t = await page.evaluate(() => document.getElementById('lnTestOut').textContent);
  check('アプリ・ナレッジとも接続OK', t.includes('判定アプリ: ✅') && t.includes('事例ナレッジ: ✅'), t);
  await page.fill('#lnDsKey', 'dataset-bad');
  await page.click('#lnTest');
  await page.waitForFunction(() => document.getElementById('lnTestOut').textContent.includes('401'));
  t = await page.evaluate(() => document.getElementById('lnTestOut').textContent);
  check('ナレッジAPIキー違いは401案内', t.includes('dataset-…)が違います'), t);
  await page.fill('#lnDsKey', 'dataset-key');

  console.log('--- 正解.txt が無い決裁は⑤では除外(案内つき)---');
  await page.evaluate(async () => {
    const mk = (rel, text) => ({rel, file: new File([text], rel.split('/').pop(), {type: 'text/plain'})});
    await lnIngest([mk('元データ/案件A_預金/貸付契約.txt', '貸付'), mk('元データ/案件A_預金/正解.txt', '預金 [1010003001]'),
                    mk('元データ/案件Z_正解なし/何か.txt', 'x')]);
  });
  const s0 = await page.evaluate(() => ({n: LN.cases.length, sum: document.getElementById('lnSummary').textContent}));
  check('正解なしの決裁は除外され、件数つきで④への案内', s0.n === 1 && s0.sum.includes('正解.txt が無い決裁 1件は除外') && s0.sum.includes('④'), JSON.stringify(s0));

  console.log('--- シナリオA: 3決裁でエポック学習(33%→67%→100%・カード差し替え)---');
  await ingest();
  let s = await page.evaluate(() => ({n: LN.cases.length, sum: document.getElementById('lnSummary').textContent,
                                      runDisabled: document.getElementById('lnRun').disabled}));
  check('3決裁を認識し実行ボタン有効', s.n === 3 && s.sum.includes('3決裁') && !s.runDisabled, JSON.stringify(s));
  await page.click('#lnRun');
  await waitDone();
  s = await page.evaluate(() => ({
    curve: LN.curve.map(e => Math.round(e.tr)),
    va: LN.curve.map(e => e.va),
    reason: LN.stopReason,
    ledger: LN.ledger,
    cells: [0, 1, 2].map(i => document.getElementById('ln-cell-' + i).textContent),
    report: LN.report,
    dlDisabled: document.getElementById('lnDlMd').disabled,
    runLabel: document.getElementById('lnRun').textContent,
  }));
  check('学習曲線が 33%→67%→100%', JSON.stringify(s.curve) === JSON.stringify([33, 67, 100]), JSON.stringify(s.curve));
  check('目標到達で停止', s.reason.indexOf('🎯') === 0, s.reason);
  check('最終エポックは全問○', JSON.stringify(s.cells) === JSON.stringify(['○', '○', '○']), JSON.stringify(s.cells));
  check('B=1回・C=2回教えた', state.kb.cB === 1 && state.kb.cC === 2, JSON.stringify(state.kb));
  check('再誤答のカードはDELETE→作り直し(DELETE 1回)', state.deletes === 1, String(state.deletes));
  check('ナレッジは1決裁1カードのまま(doc-1とdoc-3)',
    JSON.stringify(state.docs.map(d => d.id)) === JSON.stringify(['doc-1', 'doc-3']),
    JSON.stringify(state.docs));
  check('台帳: Cは差し替え2回で最新doc-3',
    s.ledger['案件C_リース'] && s.ledger['案件C_リース'].count === 2 && s.ledger['案件C_リース'].docId === 'doc-3'
    && s.ledger['案件B_賃貸借'] && s.ledger['案件B_賃貸借'].docId === 'doc-1', JSON.stringify(s.ledger));
  const cTeaches = state.teaches.filter(x => x.c === 'cC');
  check('再teachには誤答情報つき(1回目にはなし)',
    cTeaches.length === 2 && cTeaches[0].q.indexOf('誤答したまま') < 0
    && cTeaches[1].q.includes('誤答したまま') && cTeaches[1].q.includes('賃借料'),
    JSON.stringify(cTeaches));
  check('teachは正解のコード入り', cTeaches[1].q.includes('正解: リース料 [5030009001]'), cTeaches[1].q);
  check('レポート: 曲線・停止理由・台帳・正直な注意',
    s.report.includes('| 1 | **33%**') && s.report.includes('| 2 | **67%**') && s.report.includes('| 3 | **100%**')
    && s.report.includes('停止理由: 🎯') && s.report.includes('差し替え済み')
    && s.report.includes('教えた後') && s.report.includes('検証0件のため'), s.report.slice(0, 400));
  check('レポート保存有効+ボタンは再学習表示', !s.dlDisabled && s.runLabel.includes('最初から'), s.runLabel);
  const dl = await page.evaluate(() => {
    const captured = [];
    URL.createObjectURL = () => 'blob:x';
    HTMLAnchorElement.prototype.click = function(){ captured.push(this.download); };
    document.getElementById('lnDlMd').click();
    return captured;
  });
  check('自動学習レポート.md の保存名', JSON.stringify(dl) === JSON.stringify(['自動学習レポート.md']), JSON.stringify(dl));

  console.log('--- シナリオA2: 台帳がブラウザに保存され、再読み込み後も前回のカードを差し替える ---');
  await openAndFill('app-learn');
  await ingest();
  s = await page.evaluate(() => ({ledger: LN.ledger}));
  check('再読み込み後に台帳が復元される(C=doc-3・2回, B=doc-1)',
    s.ledger['案件C_リース'] && s.ledger['案件C_リース'].docId === 'doc-3' && s.ledger['案件C_リース'].count === 2
    && s.ledger['案件B_賃貸借'] && s.ledger['案件B_賃貸借'].docId === 'doc-1', JSON.stringify(s.ledger));
  // ナレッジにはカード(doc-1, doc-3)が残ったまま、アプリの学習だけ忘れさせて再実行 → 前回カードを削除して差し替えるはず
  state.kb = {}; state.teaches = []; state.deletes = 0;
  await page.click('#lnRun');
  await waitDone();
  s = await page.evaluate(() => ({ledger: LN.ledger, curve: LN.curve.map(e => Math.round(e.tr))}));
  check('再実行でも1決裁1カードを維持(DELETE 3回・残るのは doc-4 と doc-6)',
    state.deletes === 3 && JSON.stringify(state.docs.map(d => d.id)) === JSON.stringify(['doc-4', 'doc-6'])
    && s.ledger['案件C_リース'].docId === 'doc-6' && s.ledger['案件C_リース'].count === 4
    && JSON.stringify(s.curve) === JSON.stringify([33, 67, 100]),
    JSON.stringify({deletes: state.deletes, docs: state.docs, ledger: s.ledger, curve: s.curve}));
  const clearLedger = () => page.evaluate(() => localStorage.removeItem('kanjoLearnLedger:ds-1'));
  await clearLedger();

  console.log('--- シナリオB: ホールドアウト(検証の決裁は教えない)---');
  resetState();
  await openAndFill('app-learn');
  await ingest();
  await page.fill('#lnHoldout', '33');
  await page.click('#lnRun');
  await waitDone();
  s = await page.evaluate(() => ({
    train: LN.train.map(c => c.label), val: LN.val.map(c => c.label),
    curve: LN.curve.map(e => [Math.round(e.tr), e.va === null ? null : Math.round(e.va)]),
    report: LN.report, reason: LN.stopReason,
  }));
  check('末尾1件が検証に回る', JSON.stringify(s.val) === JSON.stringify(['案件C_リース']) && s.train.length === 2,
    JSON.stringify(s));
  check('曲線: 学習50→100・検証は0のまま',
    JSON.stringify(s.curve) === JSON.stringify([[50, 0], [100, 0]]), JSON.stringify(s.curve));
  check('検証の決裁は一度も教えていない', !state.kb.cC && state.kb.cB === 1, JSON.stringify(state.kb));
  check('レポートに検証の内訳と誤答(検証)',
    s.report.includes('学習 2件 + 検証 1件') && s.report.includes('案件C_リース(検証)'), s.report.slice(0, 300));

  console.log('--- シナリオC: 停止→再開 ---');
  resetState();
  await openAndFill('app-learn');
  await clearLedger();
  await ingest();
  await page.fill('#lnPar', '1');
  state.delayMs = 600;
  await page.click('#lnRun');
  await page.waitForFunction(() => Object.keys(LN.results).length >= 1, null, {timeout: 20000});
  await page.click('#lnStop');
  await page.waitForFunction(() => document.getElementById('lnProg').textContent.includes('停止しました'), null, {timeout: 20000});
  s = await page.evaluate(() => ({label: document.getElementById('lnRun').textContent, ep: LN.epoch,
                                  done: Object.keys(LN.results).length}));
  check('エポック1の途中で停止+再開ラベル', s.ep === 1 && s.done >= 1 && s.done < 3 && s.label.indexOf('再開') === 0,
    JSON.stringify(s));
  state.delayMs = 0;
  await page.click('#lnRun');
  await waitDone();
  s = await page.evaluate(() => ({curve: LN.curve.map(e => Math.round(e.tr)), reason: LN.stopReason}));
  check('再開して33%→67%→100%で完走', JSON.stringify(s.curve) === JSON.stringify([33, 67, 100])
    && s.reason.indexOf('🎯') === 0, JSON.stringify(s));

  console.log('--- シナリオD: 自己学習なしアプリは中断して案内 ---');
  resetState();
  await openAndFill('app-nolearn');
  await clearLedger();
  await ingest();
  await page.click('#lnRun');
  await waitDone();
  s = await page.evaluate(() => ({prog: document.getElementById('lnProg').textContent, reason: LN.stopReason}));
  check('学習の応答でないと中断+③の案内', s.prog.includes('中断') && s.reason.includes('自己学習'), s.prog);
  check('教えられていない(kb空・カードなし)', !state.teaches.length && !state.docs.length,
    JSON.stringify(state.teaches));

  console.log('--- シナリオE: ナレッジAPIキーなし(仮ナレッジモード: カードはブラウザに溜め、OKに参考事例として添える)---');
  resetState();
  await openAndFill('app-learn-nokey');
  await page.fill('#lnDsKey', '');
  await page.fill('#lnDsId', '');
  const clearAllLedgers = () => page.evaluate(() => Object.keys(localStorage).forEach(k => { if (k.indexOf('kanjoLearnLedger:') === 0) localStorage.removeItem(k); }));
  await clearAllLedgers();
  await page.click('#lnTest');
  await page.waitForFunction(() => document.getElementById('lnTestOut').textContent.includes('事例ナレッジ'));
  t = await page.evaluate(() => document.getElementById('lnTestOut').textContent);
  check('接続テスト: ナレッジAPIキー未入力は仮ナレッジモードの案内', t.includes('判定アプリ: ✅') && t.includes('仮ナレッジモード'), t);
  await ingest();
  await page.click('#lnRun');
  await waitDone();
  s = await page.evaluate(() => ({
    curve: LN.curve.map(e => Math.round(e.tr)), reason: LN.stopReason, ledger: LN.ledger, report: LN.report,
    injected: LN.injected, dlCardsDisabled: document.getElementById('lnDlCards').disabled,
    ledgerHead: document.getElementById('lnLedger').textContent.slice(0, 40),
  }));
  check('E: 学習曲線 33%→67%→100%(ナレッジAPIを一切呼ばない)',
    JSON.stringify(s.curve) === JSON.stringify([33, 67, 100]) && state.docs.length === 0 && state.deletes === 0,
    JSON.stringify({curve: s.curve, docs: state.docs.length}));
  check('E: 目標到達で停止', s.reason.indexOf('🎯') === 0, s.reason);
  const okB = state.okQueries.filter(x => x.c === 'cB').map(x => x.q);
  const okC = state.okQueries.filter(x => x.c === 'cC').map(x => x.q);
  check('E: エポック1の「OK」には参考事例なし、2回目以降は「参考事例:」に【判定事例】が添えられる',
    okB[0] === 'OK' && okB[1].indexOf('OK\n\n参考事例:\n') === 0 && okB[1].includes('【判定事例】') && okB[1].includes('正解: 賃借料'),
    JSON.stringify(okB));
  check('E: Cは2回教えた後のカード(2回目の補足つき)が添えられて正解する',
    okC.length === 3 && okC[2].includes('(2回目)') && state.cards.cC === 2 && state.cards.cB === 1,
    JSON.stringify({okC: okC.map(q => q.slice(0, 60)), cards: state.cards}));
  const teachC = state.teaches.filter(x => x.c === 'cC');
  check('E: 再teachには誤答情報つき', teachC.length === 2 && teachC[1].q.includes('誤答したまま'), JSON.stringify(teachC));
  check('E: 仮ナレッジの台帳にカード本文(Cは差し替え2回・2回目の補足入り)',
    s.ledger['案件B_賃貸借'] && s.ledger['案件B_賃貸借'].card.indexOf('【判定事例】') === 0
    && s.ledger['案件C_リース'].count === 2 && s.ledger['案件C_リース'].card.includes('(2回目)')
    && s.ledgerHead.includes('仮ナレッジ'), JSON.stringify(s.ledger));
  check('E: 参考事例を添えた回数を数え、判定事例.txt の保存が有効', s.injected > 0 && !s.dlCardsDisabled, JSON.stringify(s.injected));
  check('E: レポートに仮ナレッジモード・反映手順・判定事例.txt の中身',
    s.report.includes('仮ナレッジモード') && s.report.includes('反映手順') && s.report.includes('### 案件B_賃貸借')
    && s.report.includes('文字の重なり'), s.report.slice(0, 300));
  const txt = await page.evaluate(async () => {
    const blobs = [];
    URL.createObjectURL = (b) => { blobs.push(b); return 'blob:x'; };
    HTMLAnchorElement.prototype.click = function(){};
    document.getElementById('lnDlCards').click();
    return await blobs[0].text();
  });
  check('E: 判定事例.txt は 1決裁=1ブロック(空行区切り)で全カードを含む',
    txt.indexOf('### 案件B_賃貸借\n【判定事例】') === 0 && txt.includes('\n\n### 案件C_リース\n【判定事例】') && txt.includes('(2回目)'),
    txt.slice(0, 200));
  // 仮ナレッジはブラウザに残る → 再読み込み後、最初のエポックから参考事例が効いて100%
  state.okQueries = [];
  await openAndFill('app-learn-nokey');
  await page.fill('#lnDsKey', '');
  await page.fill('#lnDsId', '');
  await ingest();
  s = await page.evaluate(() => ({n: Object.keys(LN.ledger).length}));
  check('E: 再読み込み後も仮ナレッジ(2枚)が復元される', s.n === 2, JSON.stringify(s));
  await page.click('#lnRun');
  await waitDone();
  s = await page.evaluate(() => ({curve: LN.curve.map(e => Math.round(e.tr))}));
  check('E: 仮ナレッジが残っていれば最初のエポックから100%', JSON.stringify(s.curve) === JSON.stringify([100])
    && state.okQueries.filter(x => x.q.includes('参考事例:')).length >= 2, JSON.stringify({curve: s.curve, n: state.okQueries.length}));
  await clearAllLedgers();

  console.log('--- シナリオF: ③の既定(環境変数 learned_cases 方式・ナレッジ不要)のアプリ ---');
  resetState();
  await openAndFill('app-learn-env');   // ナレッジAPIキーを入れたまま(apiモード)→ 環境変数方式のアプリは案内して中断
  await clearAllLedgers();
  await ingest();
  await page.click('#lnRun');
  await waitDone();
  s = await page.evaluate(() => ({prog: document.getElementById('lnProg').textContent, reason: LN.stopReason}));
  check('F: ナレッジAPIキー入りで回すと「環境変数方式のアプリ→キー欄を空欄に」の案内で中断',
    s.prog.includes('中断') && s.reason.includes('learned_cases') && s.reason.includes('空欄'), s.reason);
  check('F: ナレッジには何も保存・削除されない', state.docs.length === 0 && state.deletes === 0);
  resetState();
  await openAndFill('app-learn-env');
  await page.fill('#lnDsKey', '');
  await page.fill('#lnDsId', '');
  await clearAllLedgers();
  await ingest();
  await page.click('#lnRun');
  await waitDone();
  s = await page.evaluate(() => ({curve: LN.curve.map(e => Math.round(e.tr)), reason: LN.stopReason, report: LN.report, ledger: LN.ledger}));
  check('F: キー空欄(仮ナレッジモード)なら 33%→67%→100% で学習できる(ナレッジAPIは呼ばない)',
    JSON.stringify(s.curve) === JSON.stringify([33, 67, 100]) && s.reason.indexOf('🎯') === 0 && state.docs.length === 0,
    JSON.stringify(s.curve));
  check('F: 環境変数方式の回答からカード本文を取り出せている(Cは2回目の補足入り)',
    s.ledger['案件B_賃貸借'] && s.ledger['案件B_賃貸借'].card.indexOf('【判定事例】') === 0
    && s.ledger['案件C_リース'].card.includes('(2回目)'), JSON.stringify(s.ledger));
  check('F: レポートの反映手順に「環境変数 learned_cases に貼る」(上限の注意つき)',
    s.report.includes('`learned_cases`') && s.report.includes('MAX_VARIABLE_SIZE'), s.report.slice(0, 200));
  await clearAllLedgers();

  check('全操作を通してJSエラーなし', errors.length === 0, errors.join(' | '));
  await browser.close();
  srv.close();
  console.log('\nPASS ' + ok + ' / FAIL ' + ng);
  process.exit(ng ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
