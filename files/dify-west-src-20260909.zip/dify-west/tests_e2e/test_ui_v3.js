// 4形式チェックボックスUI(chat/tree/flat/pick)+追加科目+3形式の完全ダンプ書き出し
const { chromium } = require('playwright');
const fs = require('fs');

const ROOT = require('path').resolve(__dirname, '..');
const SCRATCH = process.env.SCRATCH || '.';
const TREE_CODED = fs.readFileSync(SCRATCH + '/tree_coded.md', 'utf8');
const TREE_PLAIN = fs.readFileSync(ROOT + '/分類ツリー.md', 'utf8');
const TREE_S7 = fs.readFileSync(ROOT + '/tools/tests/sample7.md', 'utf8');

let ok = 0, ng = 0;
function check(name, cond, detail) {
  if (cond) { ok++; console.log('  [PASS] ' + name); }
  else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); }
}

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto('file://' + ROOT + '/ツリーからDify.html');

  async function setStyles(chat, tree, flat, pick) {
    await page.evaluate(([c, t, f, p]) => {
      document.getElementById('styleChat').checked = c;
      document.getElementById('styleTree').checked = t;
      document.getElementById('styleFlat').checked = f;
      document.getElementById('stylePick').checked = p;
    }, [chat, tree, flat, pick]);
  }
  async function state() {
    return page.evaluate(() => ({
      outs: OUTPUTS.map(o => ({key: o.key, file: o.file, nodes: o.d.workflow.graph.nodes.length,
                               mode: o.d.app.mode})),
      canvasNodes: GRAPH ? GRAPH.nodes.length : 0,
      btns: ['dl', 'cp', 'dl2', 'cp2', 'dl3', 'cp3', 'dl4', 'cp4'].map(i => {
        const b = document.getElementById(i);
        return b.classList.contains('hide') ? null : b.textContent;
      }),
      summary: document.getElementById('summary').textContent,
      checks: document.getElementById('checks').innerText,
    }));
  }

  await page.evaluate(t => { document.getElementById('tree').value = t; }, TREE_CODED);

  console.log('--- 既定(チャットのみ)---');
  await page.click('#run');
  let s = await state();
  check('チャット19ノード・1出力', s.outs.length === 1 && s.outs[0].nodes === 19, JSON.stringify(s.outs));

  console.log('--- 各形式単独 ---');
  for (const [box, key, nodes] of [['styleTree', 'tree', 32], ['styleFlat', 'flat', 18], ['stylePick', 'pick', 17]]) {
    await setStyles(false, box === 'styleTree', box === 'styleFlat', box === 'stylePick');
    await page.click('#run');
    s = await state();
    check(key + ': ' + nodes + 'ノード・advanced-chat',
      s.outs.length === 1 && s.outs[0].key === key && s.outs[0].nodes === nodes && s.outs[0].mode === 'advanced-chat',
      JSON.stringify(s.outs));
  }

  console.log('--- 4形式まとめて ---');
  await setStyles(true, true, true, true);
  await page.click('#run');
  s = await state();
  check('4出力(chat/tree/flat/pick)', JSON.stringify(s.outs.map(o => o.key)) === '["chat","tree","flat","pick"]', JSON.stringify(s.outs));
  check('ノード数 19/32/18/17', JSON.stringify(s.outs.map(o => o.nodes)) === '[19,32,18,17]', JSON.stringify(s.outs.map(o => o.nodes)));
  check('全部advanced-chat(入力はチャットで統一)', s.outs.every(o => o.mode === 'advanced-chat'));
  check('ボタン4組・形式名ラベル', s.btns[0] === 'チャット形式を保存' && s.btns[2] === 'ツリー判定形式を保存'
    && s.btns[4] === 'コード2段選択形式を保存' && s.btns[6] === 'コード一発選択形式を保存', JSON.stringify(s.btns));
  const dlNames = await page.evaluate(() => {
    const captured = [];
    URL.createObjectURL = () => 'blob:x';
    HTMLAnchorElement.prototype.click = function(){ captured.push(this.download); };
    for (const i of ['dl', 'dl2', 'dl3', 'dl4']) document.getElementById(i).click();
    return captured;
  });
  check('保存名 chat/tree/flat/pick', JSON.stringify(dlNames) === JSON.stringify([
    'contract-account-classification-chat.yml', 'contract-account-classification-tree.yml',
    'contract-account-classification-flat.yml', 'contract-account-classification-pick.yml']), JSON.stringify(dlNames));
  check('図はチャット(19)', s.canvasNodes === 19, String(s.canvasNodes));

  console.log('--- コード無しツリー ---');
  await page.evaluate(t => { document.getElementById('tree').value = t; }, TREE_PLAIN);
  await page.click('#run');
  s = await state();
  check('chat+treeは出て、flat/pickは警告スキップ',
    JSON.stringify(s.outs.map(o => o.key)) === '["chat","tree"]'
    && s.checks.includes('コード2段選択形式:') && s.checks.includes('コード一発選択形式:')
    && s.checks.includes('[7桁]'), s.checks.slice(0, 250));

  console.log('--- 追加科目の埋め込み先 ---');
  await page.evaluate(t => { document.getElementById('tree').value = t; }, TREE_CODED);
  await page.fill('#extraAcc', '外貨/預金 [1100000140]: 外貨建て');
  await setStyles(true, true, true, true);
  await page.click('#run');
  const vals = await page.evaluate(() => OUTPUTS.map(o => {
    const ev = o.d.workflow.environment_variables.find(e => e.name === 'extra_accounts');
    return ev ? ev.value.length : null;
  }));
  check('extraはchat/flat/pickに入り、treeには無い',
    vals[0] > 0 && vals[1] === null && vals[2] > 0 && vals[3] > 0, JSON.stringify(vals));
  await setStyles(false, true, false, false);
  await page.click('#run');
  s = await state();
  check('tree単独+extraは注意を表示', s.checks.includes('extra_accounts が無いため入りません'), s.checks.slice(0, 250));
  await page.fill('#extraAcc', '');

  console.log('--- 追加科目チェックのJS結果書き出し(env_checkパリティ用)---');
  const probe = await page.evaluate((tree) => {
    const root = parseTree(tree, []);
    const lines = codeMapLines(root);
    const withCode = lines[lines.length - 1];
    const i = withCode.lastIndexOf(',');
    return { path: withCode.slice(0, i), leaf: withCode.slice(0, i).split('/').pop(), code: withCode.slice(i + 1) };
  }, TREE_S7);
  const CASES = [
    '', '\n# メモ\n   \n', '完全に新しい科目X [9999999990]: テスト用',
    probe.leaf + ' [9999999990]', probe.leaf, '新設親/' + probe.leaf + ' [9999999990]',
    probe.path + ' [' + probe.code + ']', '完全に新しい科目X [' + probe.code + ']',
    '新科目A [9999999990]\n新科目B [9999999990]', '新科目C [999999999]',
    '新科目D [9999999][990]', '新科目E [9999999]', '新科目F,9999999990', '[9999999990]',
    '- 新科目G [9999999990]', '新科目H\n新科目H', '新科目I [9999999990]\n新科目I [9999999990]',
    '新科目J [9999999990]', '完全に新しい科目X: 定義だけの行',
    probe.leaf + ' [9999999990]\n新設親/' + probe.leaf + ' [9999999991]\n' + probe.path + ',x\n新科目K',
  ];
  const results = await page.evaluate(([tree, cases]) => {
    const root = parseTree(tree, []);
    return cases.map(c => {
      const r = checkExtraAccounts(c, root);
      const out = r.warns.length
        ? '\n\n---\n⚠️ 後から追加した科目(環境変数 extra_accounts)に確認が必要な行があります:\n'
          + r.warns.map(w => '- ' + w).join('\n')
        : '';
      return { extra: c, out: out };
    });
  }, [TREE_S7, CASES]);
  fs.writeFileSync(SCRATCH + '/js_check_results.json', JSON.stringify(results, null, 1));
  check('20ケース書き出し', results.length === CASES.length);

  console.log('--- 3形式の完全ダンプ書き出し(Pythonパリティ用)---');
  for (const [fn, name] of [['generateTree', 'tree'], ['generateFlat', 'flat'], ['generatePick', 'pick']]) {
    const dump = await page.evaluate(([f, tree]) => {
      const d = window[f](tree, JSON.parse(EXTRAS_JSON), []);
      for (const n of d.workflow.graph.nodes) {
        if (n.data && n.data.type === 'llm' && n.data.model) {
          n.data.model.provider = 'langgenius/azure_openai/azure_openai';
          n.data.model.name = 'GPT-4o';
        }
      }
      return dumpYaml(d);
    }, [fn, TREE_CODED]);
    fs.writeFileSync(SCRATCH + '/js_' + name + '_dump.yml', dump);
    check(name + ' ダンプ書き出し', dump.length > 10000, String(dump.length));
  }

  check('全操作を通してJSエラーなし', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log('\nPASS ' + ok + ' / FAIL ' + ng);
  process.exit(ng ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
