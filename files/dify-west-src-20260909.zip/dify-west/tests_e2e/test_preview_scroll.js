// ①と②-2のプレビュー: 先頭200行を描き、下までスクロールすると続きが出る(全行まで)
const { chromium } = require('playwright');
const ROOT = require('path').resolve(__dirname, '..');
const FX = __dirname + '/fixtures/';
let ok = 0, ng = 0;
function check(name, cond, detail) {
  if (cond) { ok++; console.log('  [PASS] ' + name); }
  else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); }
}
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage({ viewport: { width: 1100, height: 900 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  const scrollDown = sel => page.evaluate(s => { const w = document.querySelector(s); w.scrollTop = w.scrollHeight; w.dispatchEvent(new Event('scroll')); }, sel);
  const rowsOf = sel => page.evaluate(s => document.querySelector(s + ' tbody').children.length, sel);

  console.log('--- ②-2 十桁の定義: Excelのプレビュー ---');
  await page.goto('file://' + ROOT + '/十桁定義.html'); await page.evaluate(() => KS.ready);
  await page.click('#sample');
  await page.setInputFiles('#xlFile', [FX + 'bigsst.xls']);   // 2001行
  await page.waitForFunction(() => document.querySelectorAll('.xlp').length === 1);
  let n = await rowsOf('.xlp .xlprev-wrap');
  let note = await page.evaluate(() => document.querySelector('.xlp .xlprev-note').textContent);
  check('②-2: 最初は200行を描き、注記に「200行目まで表示(全2001行)」', n === 200 && note.includes('200行目まで表示(全2001行)'), n + ' / ' + note);
  check('②-2: 表の箱がスクロールできる高さ(300px)で、見出し行が固定', await page.evaluate(() => { const w = document.querySelector('.xlp .xlprev-wrap'); return w.scrollHeight > w.clientHeight && getComputedStyle(document.querySelector('.xlp .xlprev thead th')).position === 'sticky'; }));
  await scrollDown('.xlp .xlprev-wrap');
  await page.waitForFunction(() => document.querySelector('.xlp .xlprev-wrap tbody').children.length === 400);
  n = await rowsOf('.xlp .xlprev-wrap');
  check('②-2: 下までスクロールすると次の200行が足される(400行)', n === 400, String(n));
  for(let i = 0; i < 12; i++){ await scrollDown('.xlp .xlprev-wrap'); await page.waitForTimeout(30); }
  await page.waitForFunction(() => document.querySelector('.xlp .xlprev-wrap tbody').children.length === 2001);
  note = await page.evaluate(() => document.querySelector('.xlp .xlprev-note').textContent);
  const last = await page.evaluate(() => document.querySelector('.xlp .xlprev-wrap tbody').lastElementChild.textContent);
  check('②-2: 最後までスクロールすると全2001行、注記は「全2001行を表示しています」', note === '全2001行を表示しています' && last.includes('5030001999'), note + ' / ' + last.slice(0, 60));
  check('②-2: コードの列と転記する列に色が付いたまま', await page.evaluate(() => !!document.querySelector('.xlp .xlprev td.k') && !!document.querySelector('.xlp .xlprev td.s')));
  await page.selectOption('.xlp .xlp-src', '1');
  await page.waitForFunction(() => document.querySelectorAll('.xlp').length === 1);
  n = await rowsOf('.xlp .xlprev-wrap');
  check('②-2: 列の指定を変えると描き直され、また200行から', n === 200 && await page.evaluate(() => document.querySelector('.xlp .xlprev tbody tr td.s').cellIndex === 2), String(n));
  await page.setInputFiles('#xlFile', [FX + 'various.xls']);   // 400文字超のセルがある
  await page.waitForFunction(() => document.querySelectorAll('.xlp').length === 2);
  const longCell = await page.evaluate(() => { const t = document.querySelector('.xlp[data-i="1"] .xlprev tbody tr:nth-child(3) td:nth-child(4)'); return {text: t.textContent, title: t.getAttribute('title'), clipped: t.scrollWidth > t.clientWidth + 1}; });
  check('②-2: 長いセルは全文をもち、列の幅で見た目だけ省略。全文はマウスを乗せると見える(title)', longCell.text.length > 300 && longCell.clipped && longCell.title && longCell.title.length > 300, JSON.stringify({len: longCell.text.length, clipped: longCell.clipped, title: !!longCell.title}));
  // 見出しの右端をドラッグして列の幅を広げる → はみ出しが減る(もっと見える)
  const before = await page.evaluate(() => { const t = document.querySelector('.xlp[data-i="1"] .xlprev tbody tr:nth-child(3) td:nth-child(4)'); return {w: t.clientWidth, over: t.scrollWidth - t.clientWidth}; });
  await page.evaluate(() => {
    const th = document.querySelector('.xlp[data-i="1"] .xlprev thead th:nth-child(4)'), rz = th.querySelector('.ks-rz');
    const r = rz.getBoundingClientRect(), x = r.left + 3, y = r.top + 5;
    rz.dispatchEvent(new MouseEvent('mousedown', {bubbles: true, clientX: x, clientY: y}));
    document.dispatchEvent(new MouseEvent('mousemove', {bubbles: true, clientX: x + 260, clientY: y}));
    document.dispatchEvent(new MouseEvent('mouseup', {bubbles: true, clientX: x + 260, clientY: y}));
  });
  const after = await page.evaluate(() => { const t = document.querySelector('.xlp[data-i="1"] .xlprev tbody tr:nth-child(3) td:nth-child(4)'); return {w: t.clientWidth, over: t.scrollWidth - t.clientWidth}; });
  check('②-2: 見出しの右端をドラッグすると列が広がり、見える範囲が増える', after.w > before.w + 200 && after.over < before.over, JSON.stringify([before, after]));

  console.log('--- ① Excelからツリー: 読み込んだ表とよく使う科目リスト ---');
  await page.goto('file://' + ROOT + '/Excelからツリー.html'); await page.evaluate(() => KS.ready);
  await page.setInputFiles('#file', [FX + 'bigsst.xls']);
  await page.waitForFunction(() => document.querySelector('#drop b').textContent === 'bigsst.xls');
  n = await rowsOf('#preview');
  note = await page.evaluate(() => document.getElementById('previewNote').textContent);
  check('①: 読み込んだ表は200行ずつ(注記つき)', n === 200 && note.includes('200行目まで表示(全2001行)'), n + ' / ' + note);
  await scrollDown('#preview');
  await page.waitForFunction(() => document.querySelector('#preview tbody').children.length === 400);
  check('①: スクロールで続きが出る(400行)', (await rowsOf('#preview')) === 400);
  await page.fill('#c1', 'C');
  check('①: 列を変えると色が付け直される(B列の色が消え、C列だけ)', await page.evaluate(() => document.querySelector('#preview thead th:nth-child(4)').className === 'hit' && document.querySelector('#preview thead th:nth-child(3)').className === '' && document.querySelector('#preview tbody tr td:nth-child(4)').className === 'hit' && document.querySelector('#preview tbody tr td:nth-child(3)').className === ''));
  await page.setInputFiles('#freqFile', [FX + 'freq.csv']);
  await page.waitForFunction(() => !document.getElementById('freqCond').classList.contains('hide'));
  const fq = await page.evaluate(() => ({rows: document.querySelector('#freqPreview tbody').children.length, note: document.getElementById('freqPreviewNote').textContent, hit: document.querySelectorAll('#freqPreview td.hit').length}));
  check('①: よく使う科目リストも同じ形(3行・全行表示・読み取った行に色)', fq.rows === 4 && fq.note === '全4行を表示しています' && fq.hit === 9, JSON.stringify(fq));
  check('JSエラーなし', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log('\nPASS ' + ok + ' / FAIL ' + ng);
  process.exit(ng ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
