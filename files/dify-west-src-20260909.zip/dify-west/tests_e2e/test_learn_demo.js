// ⑤「動画で見る: 自動学習の流れ / 仕組みの解説」のE2E
const { chromium } = require('playwright');
const ROOT = require('path').resolve(__dirname, '..');
let ok = 0, ng = 0;
function check(name, cond, detail) {
  if (cond) { ok++; console.log('  [PASS] ' + name); }
  else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); }
}
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto('file://' + ROOT + '/自動学習.html');

  let s = await page.evaluate(() => ({
    card: !!document.getElementById('dvCard'), i: DV.i, playing: DV.playing,
    idle: document.getElementById('dvScreen').textContent.includes('ボタン'),
    h2: [...document.querySelectorAll('h2')].map(h => h.textContent),
  }));
  check('動画カードがあり、カード番号が 1〜7 に振り直されている', s.card && s.i === -1 && !s.playing && s.idle
    && s.h2[2].startsWith('3. 動画で見る') && s.h2[3].startsWith('4. 接続設定') && s.h2[6].startsWith('7. 注意'), JSON.stringify(s.h2));

  await page.click('#dvPick1');
  s = await page.evaluate(() => ({i: DV.i, n: DV.steps.length, playing: DV.playing, name: document.getElementById('dvScriptName').textContent,
    cap: document.getElementById('dvCapT').textContent, scr: document.getElementById('dvScreen').innerHTML.length}));
  check('「自動学習の流れ」が始まる(20ステップ)', s.i === 0 && s.n === 20 && s.playing && s.name.includes('流れ') && s.cap.startsWith('1. ') && s.scr > 300, JSON.stringify(s));
  await page.click('#dvPick2');
  s = await page.evaluate(() => ({n: DV.steps.length, name: document.getElementById('dvScriptName').textContent}));
  check('「仕組みの解説」に切り替わる(8ステップ)', s.n === 8 && s.name.includes('仕組み'), JSON.stringify(s));

  const bad = await page.evaluate(() => {
    const out = [];
    [LEARN_DEMO_FLOW, LEARN_DEMO_WHY].forEach((sc, si) => {
      dvSetup(sc.steps, sc);
      for (let k = 0; k < sc.steps.length; k++) {
        dvShow(k);
        const scr = document.getElementById('dvScreen').innerHTML;
        if (scr.length < 200 || !document.getElementById('dvCapT').textContent.startsWith((k + 1) + '. ')
            || !document.getElementById('dvUrl').textContent.includes('https://')
            || document.querySelectorAll('#dvSteps li.dv-on').length !== 1) out.push(si + ':' + (k + 1));
      }
    });
    dvStop(); DV.playing = false;
    return out;
  });
  check('2本・全28ステップが描画できる', bad.length === 0, JSON.stringify(bad));

  s = await page.evaluate(() => {
    const o = {};
    dvSetup(LEARN_DEMO_FLOW.steps, LEARN_DEMO_FLOW);
    dvShow(8); o.curve1 = document.querySelectorAll('#dv-l-curvetbl tr').length - 1; o.detail = document.querySelectorAll('#dv-l-detailtbl tr').length - 1;
    o.marks1 = document.getElementById('dv-l-detailtbl').textContent;
    dvShow(14); o.ledger = document.getElementById('dv-l-ledgertbl').textContent;
    dvShow(15); o.curve3 = document.querySelectorAll('#dv-l-curvetbl tr').length - 1; o.prog3 = document.getElementById('dv-l-prog').textContent;
    dvShow(13); o.reteach = document.getElementById('dv-c-reteach').textContent;
    dvShow(10); o.kb = document.querySelectorAll('#dvScreen .dvy-table tr').length - 1;
    dvStop();
    return o;
  });
  check('流れ: エポック1の曲線1行・明細6件(×2件)', s.curve1 === 1 && s.detail === 6 && (s.marks1.match(/×/g) || []).length === 3, JSON.stringify(s));
  check('流れ: 台帳に差し替え済み、エポック3で🎯到達、再teachに誤答情報、ナレッジに2枚',
    s.ledger.includes('差し替え済み') && s.curve3 === 3 && s.prog3.includes('🎯') && s.reteach.includes('誤答したまま') && s.kb === 2, JSON.stringify(s));

  s = await page.evaluate(() => {
    dvSetup(LEARN_DEMO_WHY.steps, LEARN_DEMO_WHY);
    const o = {};
    dvShow(3); o.bars = document.querySelectorAll('#dv-chart .dvd-colbar').length;
    dvShow(4); o.card1 = !!document.getElementById('dv-card1') && !document.getElementById('dv-card2');
    dvShow(5); o.hold = document.getElementById('dvScreen').textContent.includes('教えない側');
    dvShow(6); o.stop = document.querySelectorAll('.dvd-row').length;
    dvStop();
    return o;
  });
  check('仕組み: 曲線グラフ・カード差し替え(初期は1枚)・ホールドアウト・止める条件3つ',
    s.bars >= 2 && s.card1 && s.hold && s.stop === 3, JSON.stringify(s));

  await page.evaluate(() => { dvSetup(LEARN_DEMO_FLOW.steps, LEARN_DEMO_FLOW); dvShow(1); });
  await page.waitForFunction(() => (document.getElementById('dv-l-url') || {textContent: ''}).textContent.startsWith('https://dify'), null, {timeout: 8000});
  check('打ち込みアニメが動く(URL)', true);

  // 画面の下に隠れた強調行まで、模擬画面が自動でスクロールする(台帳の案件004・エポック1の誤答2行)
  s = await page.evaluate(async () => {
    const scr = document.getElementById('dvScreen');
    const vis = id => { const r = document.getElementById(id).getBoundingClientRect(), sr = scr.getBoundingClientRect(); return r.top >= sr.top - 1 && r.bottom <= sr.bottom + 1; };
    const wait = ms => new Promise(r => setTimeout(r, ms));
    dvSetup(LEARN_DEMO_FLOW.steps, LEARN_DEMO_FLOW); DV.playing = false;
    dvShow(14); await wait(2500);
    const o = { st15: scr.scrollTop, led: vis('dv-l-ledgertbl-r1') };
    dvShow(8); await wait(3000);
    o.st9 = scr.scrollTop; o.curve = vis('dv-l-curvetbl-r0'); o.r2 = vis('dv-l-detailtbl-r1'); o.r4 = vis('dv-l-detailtbl-r3');
    // カーソルも到着後の位置に合う(強調行の上に乗っている)
    const c = document.getElementById('dvCursor').getBoundingClientRect(), row = document.getElementById('dv-l-curvetbl-r0').getBoundingClientRect();
    o.curOnRow = c.top >= row.top - 4 && c.top <= row.bottom + 4;
    dvShow(0); await wait(300); o.st1 = scr.scrollTop;
    return o;
  });
  check('模擬画面が強調行まで自動スクロール(台帳の案件004・誤答2行が見える・カーソル追従・次の場面で先頭に戻る)',
    s.st15 > 0 && s.led && s.st9 > 0 && s.curve && s.r2 && s.r4 && s.curOnRow && s.st1 === 0, JSON.stringify(s));

  await page.evaluate(() => { LEARN_DEMO_WHY.steps.forEach(st => { st.t = 60; }); dvSetup(LEARN_DEMO_WHY.steps, LEARN_DEMO_WHY); });
  await page.click('#dvRestart');
  await page.waitForFunction(() => DV.i === DV.steps.length - 1 && !DV.playing, null, {timeout: 20000});
  s = await page.evaluate(() => ({label: document.getElementById('dvPlay').textContent, bar: document.getElementById('dvBar').style.width}));
  check('自動再生で最後まで(もう一度・100%)', s.label.includes('もう一度') && s.bar === '100%', JSON.stringify(s));
  await page.click('#dvSteps li:nth-child(3)');
  s = await page.evaluate(() => ({i: DV.i, cnt: document.getElementById('dvCount').textContent}));
  check('一覧クリックで3へ', s.i === 2 && s.cnt === '3 / 8', JSON.stringify(s));
  await page.evaluate(() => { DV.playing = false; dvStop(); });

  check('全操作を通してJSエラーなし', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log('\nPASS ' + ok + ' / FAIL ' + ng);
  process.exit(ng ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
