#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""tree / flat / pick: ブラウザJS生成の完全ダンプと、Python生成器(公開版と同じ
slim extras 使用)の出力がバイト単位で一致することを照合する。"""
import importlib.util
import io
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ROOT, 'tools'))
import miniyaml  # noqa: E402
import generate_workflow as gw  # noqa: E402

spec = importlib.util.spec_from_file_location('bs', os.path.join(ROOT, 'tools', 'build_standalone.py'))
bs = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bs)

full = miniyaml.load(io.open(os.path.join(ROOT, 'tools', 'workflow_extras.yml'), encoding='utf-8').read())
extras = json.loads(json.dumps(bs.slim_extras(full), ensure_ascii=False))
tree = io.open(os.path.join(HERE, 'tree_coded.md'), encoding='utf-8').read()

CFG = {'mode': 'kb', 'base_url': 'https://parity.example.com/v1', 'dataset_key': 'dataset-parity-key',
       'dataset_id': 'ds-parity-1'}

ng = 0
jobs = []
for name, fn in (('tree', gw.generate_tree), ('flat', gw.generate_flat), ('pick', gw.generate_pick)):
    jobs.append((name, fn, False, None))
    jobs.append((name + '_learn', fn, True, None))          # 既定 = 環境変数方式(ナレッジ不要)
jobs.append(('pick_learn_kb', gw.generate_pick, True, {'mode': 'kb'}))   # 事例ナレッジ方式・設定なし
jobs.append(('pick_learn_cfg', gw.generate_pick, True, CFG))             # 事例ナレッジ方式・設定込み
for name, fn, learn, cfg in jobs:
    d = fn(tree, extras, learn, cfg)
    gw.set_llm_model(d, 'langgenius/azure_openai/azure_openai', 'GPT-4o')
    py = miniyaml.dump(d)
    js = io.open(os.path.join(HERE, 'js_%s_dump.yml' % name), encoding='utf-8').read()
    if py == js:
        print('[PASS] %s: JSとPythonの完全ダンプがバイト一致 (%d bytes)' % (name, len(py)))
        continue
    ng += 1
    print('[FAIL] %s: 不一致 (py %d / js %d bytes)' % (name, len(py), len(js)))
    pl, jl = py.split('\n'), js.split('\n')
    shown = 0
    for i in range(max(len(pl), len(jl))):
        a = pl[i] if i < len(pl) else '<EOF>'
        b = jl[i] if i < len(jl) else '<EOF>'
        if a != b:
            print('  line %d:\n    py: %r\n    js: %r' % (i + 1, a[:150], b[:150]))
            shown += 1
            if shown >= 6:
                break
sys.exit(1 if ng else 0)
