// ②-2: 1行目に更新日時などの前置きがあり、2行目が見出し、3行目からコードのExcel → 見出し行を正しく見分け、列の選択肢と転記の見出しがきれいになる
const { chromium } = require('playwright');
const ROOT = require('path').resolve(__dirname, '..');
const FX = __dirname + '/fixtures/';
let ok = 0, ng = 0;
function check(name, cond, detail) {
  if (cond) { ok++; console.log('  [PASS] ' + name); }
  else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); }
}
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage();
  const errors = [], dialogs = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('dialog', d => { dialogs.push(d.message()); if(d.message().includes('保存した内容')) d.accept(); else d.dismiss(); });
  await page.goto('file://' + ROOT + '/十桁定義.html');
  await page.evaluate(() => KS.ready);
  await page.click('#sample');
  const valOf = code => page.evaluate(c => { const it = ITEMS.find(x => x.parsed.code === c); return document.querySelector('[data-line="' + it.lineIdx + '"]').value; }, code);
  const panel = i => page.evaluate(k => {
    const el = document.querySelector('.xlp[data-i="' + k + '"]'), p = XL[k];
    return {key: p.key, src: p.src, hdrRow: p.hdrRow, hdrAuto: p.hdrAuto, dataRow: p.dataRow, label: p.label,
      keyOpts: [...el.querySelectorAll('.xlp-key option')].map(o => o.textContent), srcSel: el.querySelector('.xlp-src').value,
      hdrSel: el.querySelector('.xlp-hdrrow').value, hdrOpts: [...el.querySelectorAll('.xlp-hdrrow option')].map(o => o.textContent),
      head: el.querySelector('.xlp-head .note').textContent, stat: el.querySelector('.xlp-stat').textContent,
      rowStyles: [...el.querySelectorAll('.xlprev tbody tr')].map(tr => tr.getAttribute('style') || '')};
  }, i);

  console.log('--- 前置き1行 + 見出し行 + コード ---');
  await page.setInputFiles('#xlFile', [FX + 'preamble.xlsx']);
  await page.waitForFunction(() => document.querySelectorAll('.xlp').length === 1);
  let s = await panel(0);
  check('見出し行は2行目、コードは3行目から(1行目の前置きは無視)', s.hdrRow === 1 && s.dataRow === 2 && s.key === 0 && s.src === 2, JSON.stringify(s));
  check('列の選択肢は「A列」「B列」「C列」だけ(前置きや見出しの文字は混ざらない)', JSON.stringify(s.keyOpts) === JSON.stringify(['A列', 'B列', 'C列']), JSON.stringify(s.keyOpts));
  check('転記の見出しは「見出し行 × 転記する列」のセル(C列の見出し)から「説明」', s.label === '説明', s.label);
  check('「見出し行」の選択が2行目(自動)。選択肢は「なし」と各行(N行目)だけ。行数の横に「コードは3行目から」', s.hdrSel === '1' && s.hdrOpts[0] === 'なし(見出しを使わない)' && s.hdrOpts[2] === '2行目(自動)' && s.hdrOpts[1] === '1行目' && s.hdrOpts[3] === '3行目' && s.hdrOpts.length === 6 && s.head.includes('5行・コードは3行目から'), JSON.stringify([s.hdrSel, s.hdrOpts, s.head]));
  check('プレビューで前置き行は薄く、見出し行は太字', s.rowStyles[0].includes('opacity') && s.rowStyles[1].includes('font-weight') && s.rowStyles[2] === '', JSON.stringify(s.rowStyles));
  check('一致件数は3件(前置き行・見出し行はコードとして数えない)', s.stat.includes('一致 3件') && s.stat.includes('Excelにだけあるコード 0件'), s.stat);
  await page.click('#xlApply');
  const v1 = await valOf('5030012002'), v2 = await valOf('1010003001');
  check('転記が【説明】で入る', v1 === '【説明】取引先との飲食' && v2 === '【説明】日常の入出金に使う口座', JSON.stringify([v1, v2]));
  await page.selectOption('.xlp[data-i="0"] .xlp-hdrrow', '-1');
  await page.waitForFunction(() => XL[0].hdrRow === -1);
  s = await panel(0);
  check('「なし」を選ぶと見出しなし扱い(選択肢は「A列」だけ、見出しは既定の「解説」)', s.keyOpts[0] === 'A列' && s.label === '解説' && s.hdrSel === '-1', JSON.stringify([s.keyOpts, s.label, s.hdrSel]));
  await page.selectOption('.xlp[data-i="0"] .xlp-hdrrow', '0');
  await page.waitForFunction(() => XL[0].hdrRow === 0);
  s = await panel(0);
  check('自分で1行目(前置きの行)を選ぶとその行が見出しになる(手で選び直せる)', s.hdrRow === 0 && s.hdrSel === '0' && s.rowStyles[0].includes('font-weight'), JSON.stringify([s.hdrRow, s.hdrSel, s.rowStyles[0]]));
  await page.selectOption('.xlp[data-i="0"] .xlp-hdrrow', '1');
  await page.waitForFunction(() => XL[0].hdrRow === 1);
  s = await panel(0);
  check('2行目に戻すと元どおり(見出しは説明)', s.hdrRow === 1 && s.keyOpts[2] === 'C列' && s.label === '説明', JSON.stringify([s.hdrRow, s.keyOpts, s.label]));

  console.log('--- 前置き2行(2行目は空) + 見出し行 + コード ---');
  await page.setInputFiles('#xlFile', [FX + 'preamble2.xlsx']);
  await page.waitForFunction(() => document.querySelectorAll('.xlp').length === 2);
  s = await panel(1);
  check('空行をはさんでも、コードのすぐ上の3行目を見出し行にする', s.hdrRow === 2 && s.dataRow === 3 && s.label === '事例' && JSON.stringify(s.keyOpts) === JSON.stringify(['A列', 'B列', 'C列']), JSON.stringify(s));
  await page.click('#xlApply');
  const v3 = await valOf('5030012003');
  check('2つ目のExcelからも【事例】で転記', v3 === '【事例】贈答品・会費', v3);

  console.log('--- 見出し行とコードの間に空行があるファイル ---');
  await page.setInputFiles('#xlFile', [FX + 'gap.xlsx']);
  await page.waitForFunction(() => document.querySelectorAll('.xlp').length === 3);
  s = await panel(2);
  check('見出し行の直下が空行でも、その上の見出し行(2行目)を見つけ、見出しは「摘要説明」(解説に落ちない)',
    s.hdrRow === 1 && s.dataRow === 3 && s.src === 2 && s.label === '摘要説明' && s.hdrSel === '1', JSON.stringify([s.hdrRow, s.dataRow, s.src, s.label]));
  await page.click('#xlApply');
  const vgap = await valOf('5030012001');
  check('空行があっても【摘要説明】で転記される', vgap.includes('【摘要説明】従業員・取引先の慶弔に伴う支出'), vgap);

  console.log('--- 自動保存からの復元でも見出し行の情報が残る ---');
  await new Promise(r => setTimeout(r, 700));
  await page.reload(); await page.evaluate(() => KS.ready);
  s = await panel(0);
  check('再読込後も見出し行(2行目)・見出しが同じ', s.hdrRow === 1 && s.hdrSel === '1' && s.keyOpts[0] === 'A列' && s.label === '説明', JSON.stringify([s.hdrRow, s.hdrSel, s.label]));
  await page.click('#ksClear');
  await page.waitForFunction(() => XL.length === 0);
  check('JSエラー・alertなし', errors.length === 0 && dialogs.filter(d => !d.includes('保存した内容')).length === 0, errors.join(' | ') + dialogs.join(' | '));
  await browser.close();
  console.log('\nPASS ' + ok + ' / FAIL ' + ng);
  process.exit(ng ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
