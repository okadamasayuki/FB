#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""契約書判定の採点.ipynb のセルを、モックDifyに対して実際に実行して検証する
(LOCAL_DIR モード。複数ファイル=1決裁のケースを含む)。"""
import http.server
import io
import json
import os
import re
import sys
import tempfile
import threading

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ok = ng = 0


def check(name, cond, detail=''):
    global ok, ng
    if cond:
        ok += 1
        print('  [PASS] %s' % name)
    else:
        ng += 1
        print('  [FAIL] %s %s' % (name, detail))


ANSWERS2 = {
    'app-pick': {'c1': '| 相手勘定(科目) | 預金 |\n| 確定コード | 1010003001 |',
                 'c2': '| 相手勘定(科目) | 賃借料 |\n| 確定コード | 未確定 |'},
    'app-tree': {'c1': '| 相手勘定(科目) | 預金 |\n| 確定コード | 1010003001 |',
                 'c2': '| 相手勘定(科目) | 会議費 |\n| 確定コード | 9999999999 |'},
}
CONV_CASE = {}


class Mock(http.server.BaseHTTPRequestHandler):
    uploads = []

    def log_message(self, *a):
        pass

    def _json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        key = (self.headers.get('Authorization') or '').replace('Bearer ', '')
        n = int(self.headers.get('Content-Length') or 0)
        raw = self.rfile.read(n)
        if self.path.endswith('/files/upload'):
            m = re.search(rb'filename="([^"]+)"', raw)
            fname = m.group(1).decode('utf-8') if m else ''
            Mock.uploads.append(fname)
            case = 'c2' if '賃貸借' in fname else 'c1'
            return self._json(200, {'id': 'file-%s-%s-%d' % (case, key, len(Mock.uploads))})
        if self.path.endswith('/chat-messages'):
            req = json.loads(raw.decode('utf-8'))
            if req.get('files'):
                case = 'c1' if 'c1' in req['files'][0]['upload_file_id'] else 'c2'
                conv = 'conv-%s-%s' % (case, key)
                CONV_CASE[conv] = {'case': case, 'nfiles': len(req['files'])}
                return self._json(200, {'conversation_id': conv,
                                        'answer': '読み取りました。OKと返信してください。'})
            conv = req.get('conversation_id', '')
            case = CONV_CASE.get(conv, {}).get('case', 'c1')
            return self._json(200, {'conversation_id': conv, 'answer': ANSWERS2[key][case]})
        self._json(404, {'message': 'not found'})


srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Mock)
port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()

# ---- テスト用フォルダ(案件001は3ファイル=1決裁)
tmp = tempfile.mkdtemp(prefix='nbtest')
os.makedirs(os.path.join(tmp, '案件001_金銭消費貸借'))
for f in ('金銭消費貸借契約書.txt', '返済予定表.txt', '見積書.txt'):
    io.open(os.path.join(tmp, '案件001_金銭消費貸借', f), 'w', encoding='utf-8').write('本文 ' + f)
io.open(os.path.join(tmp, '案件001_金銭消費貸借', '正解.txt'), 'w', encoding='utf-8').write('預金 [1010003001]')
os.makedirs(os.path.join(tmp, '案件002_賃貸借'))
io.open(os.path.join(tmp, '案件002_賃貸借', '事務所賃貸借契約.txt'), 'w', encoding='utf-8').write('賃料 月額 …')
io.open(os.path.join(tmp, '案件002_賃貸借', '正解.txt'), 'w', encoding='utf-8').write('賃借料')

# ---- ノートブックのセルを実行(設定セル→本体セル→実行セル)
nb = json.load(io.open(os.path.join(ROOT, '契約書判定の採点.ipynb'), encoding='utf-8'))
srcs = [''.join(c['source']) for c in nb['cells']]
g = {'__name__': 'notebook'}
exec(srcs[2], g)  # 設定セル
g['BASE_URL'] = 'http://127.0.0.1:%d/v1' % port
g['KEYS'] = {'tree': 'app-tree', 'flat': '', 'pick': 'app-pick'}
g['STAGE_ZIP'] = ''
g['LOCAL_DIR'] = tmp
g['OUT_NAME'] = os.path.join(tmp, '採点結果.md')
exec(srcs[3], g)  # 本体セル(契約書判定の採点.py)
cwd = os.getcwd()
try:
    exec(srcs[4], g)  # 実行セル
finally:
    os.chdir(cwd)
srv.shutdown()

report = io.open(g['OUT_NAME'], encoding='utf-8').read()
check('レポート生成', '# 契約書判定の採点結果(3形式比較)' in report)
check('pick 100% / tree 50%',
      '| コード一発選択形式 | **100%** (2/2)' in report and '| ツリー判定形式 | **50%** (1/2)' in report,
      report[:600])
check('flat はキー未設定', '| コード2段選択形式 | (キー未設定) |' in report)
check('複数ファイル(3個)が1決裁としてアップロードされた',
      sum(1 for f in Mock.uploads if '金銭' in f or f in ('返済予定表.txt', '見積書.txt')) == 6,  # 2形式×3ファイル
      str(Mock.uploads))
check('1決裁の会話に3ファイル添付',
      any(v['nfiles'] == 3 for v in CONV_CASE.values()), str(CONV_CASE))
check('誤答一覧に tree の誤答', '形式: ツリー判定形式 / 案件: 案件002_賃貸借' in report)

print()
print('PASS %d / FAIL %d' % (ok, ng))
sys.exit(1 if ng else 0)
