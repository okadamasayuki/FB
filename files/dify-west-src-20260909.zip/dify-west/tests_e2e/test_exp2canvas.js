// 解説クリック→図の該当ノードをハイライトする逆方向ジャンプの実機検証
const { chromium } = require('playwright');
const fs = require('fs');
const ROOT = require('path').resolve(__dirname, '..');
const TREE_CODED = fs.readFileSync(process.env.SCRATCH + '/tree_coded.md', 'utf8');

let ok = 0, ng = 0;
function check(name, cond, detail) {
  if (cond) { ok++; console.log('  [PASS] ' + name); }
  else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); }
}

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto('file://' + ROOT + '/ツリーからDify.html');

  async function strokes() {
    return page.evaluate(() => {
      const out = {};
      for (const g of document.querySelectorAll('#canvas g[data-nid]')) {
        const r = g.querySelector('rect');
        out[g.getAttribute('data-nid')] = r.getAttribute('fill') + '|' + r.getAttribute('stroke') + '/' + r.getAttribute('stroke-width');
      }
      return out;
    });
  }
  const HL = s => s && s.startsWith('#ffd43b|#f08c00/3');   // 塗りつぶしハイライト(#11で枠線から変更)

  console.log('--- 生成前: 解説クリックは「DSLを作る」へ誘導 ---');
  await page.click('#exp-start');
  let hit = await page.evaluate(() => document.getElementById('run').classList.contains('exp-hit'));
  check('runボタンがハイライトされる', hit);

  console.log('--- flat形式で生成して解説→ノード ---');
  await page.evaluate(t => { document.getElementById('tree').value = t; }, TREE_CODED);
  await page.check('#styleFlat');
  await page.click('#run');
  await page.click('#exp-f-7');
  let s = await strokes();
  check('llm_code7 が塗りつぶしで強調される', HL(s['llm_code7']), s['llm_code7']);
  check('他のノードは通常の枠', s['llm_summary'].endsWith('#d0d5dd/1.5') && !s['llm_summary'].startsWith('#ffd43b'), s['llm_summary']);
  await page.waitForTimeout(1800);
  s = await strokes();
  check('時間が経ってもハイライトは維持される', HL(s['llm_code7']), s['llm_code7']);
  await page.click('#exp-f-code');
  s = await strokes();
  check('別の項目でハイライトが移る(code_final)', HL(s['code_final'])
    && s['llm_code7'].endsWith('#d0d5dd/1.5') && !s['llm_code7'].startsWith('#ffd43b'),
    s['code_final'] + ' / ' + s['llm_code7']);
  await page.click('#exp-start');
  s = await strokes();
  check('共通項目(開始)も対応', HL(s['start']), s['start']);
  const canvasVisible = await page.evaluate(() => !document.getElementById('canvasCard').classList.contains('hide'));
  check('図カードが表示されている', canvasVisible);

  console.log('--- tree形式: 判定ノード群がまとめて強調される ---');
  await page.check('#styleTree');
  await page.click('#exp-t-tree');
  s = await strokes();
  const highlighted = Object.entries(s).filter(([k, v]) => HL(v));
  check('カスケードの複数ノードが強調される(LLM+分岐)', highlighted.length >= 5
    && highlighted.every(([k]) => k.startsWith('llm-') || k.startsWith('if-else-')), JSON.stringify(highlighted.map(([k]) => k)));
  await page.click('#exp-t-code');
  s = await strokes();
  check('コード確定はtemplate_code', HL(s['template_code']), s['template_code']);

  console.log('--- 図のノードクリック→解説(従来方向)も生きている ---');
  const back = await page.evaluate(() => {
    const g = document.querySelector('#canvas g[data-nid="template_path"]');
    g.dispatchEvent(new MouseEvent('click', {bubbles: true}));
    return document.getElementById('exp-t-path').classList.contains('exp-hit');
  });
  check('ノードクリックで解説がハイライトされる', back);

  check('全操作を通してJSエラーなし', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log('\nPASS ' + ok + ' / FAIL ' + ng);
  process.exit(ng ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
