// 古い .xls(OLE2 + BIFF8/BIFF5/BIFF2)の読み込みを Node で直接検証する(ブラウザ不要)
const fs = require('fs'), vm = require('vm');
const src = fs.readFileSync(require('path').resolve(__dirname, '..', 'tools', 'sheet_reader.js'), 'utf8')
  + '\nglobalThis.__readXls = readXls; globalThis.__sniff = sheetSniff;';
vm.runInThisContext(src);
const FX = __dirname + '/fixtures/';
let ok = 0, ng = 0;
function check(name, cond, detail){ if(cond){ ok++; console.log('  [PASS] ' + name); } else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); } }
const ab = f => { const b = fs.readFileSync(FX + f); return b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength); };
const trimRow = r => { const a = r.slice(); while(a.length && a[a.length - 1] === '') a.pop(); return a; };
const norm = rows => { const out = rows.map(trimRow); while(out.length && !out[out.length - 1].length) out.pop(); return out; };
function firstDiff(got, want){
  for(let i = 0; i < Math.max(got.length, want.length); i++){
    const g = got[i] || [], w = want[i] || [];
    for(let j = 0; j < Math.max(g.length, w.length); j++) if(g[j] !== w[j]) return 'row ' + i + ' col ' + j + ': got ' + JSON.stringify(g[j]) + ' want ' + JSON.stringify(w[j]);
  }
  return 'rows ' + got.length + ' vs ' + want.length;
}
const exp = JSON.parse(fs.readFileSync(FX + 'xls_expected.json', 'utf8'));
for(const file of Object.keys(exp)){
  if(!fs.existsSync(FX + file)){ check(file + ': ファイルがある', false, 'missing'); continue; }
  const e = exp[file];
  let r;
  try{ r = __readXls(ab(file)); }catch(err){ check(file + ': 読める', false, String(err && err.stack || err)); continue; }
  check(file + ': シート名 ' + JSON.stringify(e.sheets), JSON.stringify(r.sheets) === JSON.stringify(e.sheets), JSON.stringify(r.sheets));
  if(e.samples){
    const rows = r.table[e.sheets[0]] || [];
    check(file + ': 行数 ' + e.rows, rows.length === e.rows, String(rows.length));
    for(const k of Object.keys(e.samples)) check(file + ': 行 ' + k, JSON.stringify(trimRow(rows[+k] || [])) === JSON.stringify(e.samples[k]), JSON.stringify(rows[+k]));
    continue;
  }
  for(const sh of e.sheets){
    const got = norm(r.table[sh] || []), want = norm(e.table[sh]);
    const same = JSON.stringify(got) === JSON.stringify(want);
    check(file + ' / ' + sh + ': 内容が一致(' + want.length + '行)', same, same ? '' : firstDiff(got, want));
  }
}
if(fs.existsSync(FX + 'master5.xls')){   // LibreOffice の Excel 5.0/95 出力(日本語はコードページ次第なので、構造とASCIIだけ確かめる)
  try{
    const r = __readXls(ab('master5.xls'));
    const rows = r.table[r.sheets[0]];
    check('master5.xls(LibreOffice の Excel 5.0/95): Book ストリームを読み、コード列が一致', r.sheets.length === 1 && rows[1][4] === '1010001001' && rows[9][4] === '5030009001' && rows[1][0] === '1',
      JSON.stringify([r.sheets, rows[1]]));
    check('master5.xls: 日本語がコードページどおり読める(文字化けなら LibreOffice 側の書き出し文字コードの問題)', rows[1][3] === '現金', JSON.stringify(rows[1][3]));
  }catch(err){ check('master5.xls: 読める', false, String(err)); }
}
console.log('--- 読めないファイルは理由を返す ---');
function expectErr(file, re){
  try{ __readXls(ab(file)); check(file + ': エラーになる', false, 'no error'); }
  catch(err){ check(file + ': ' + re, re.test(String(err.message)) && err.userFacing, String(err.message)); }
}
expectErr('encrypted.xls', /暗号化/);
expectErr('word.doc', /Word/);
expectErr('old.xls', /目次/);
check('sniff: 生の BIFF2 は biff', __sniff(new Uint8Array(ab('biff2.xls'))) === 'biff');
check('sniff: OLE は ole', __sniff(new Uint8Array(ab('biff5_small.xls'))) === 'ole');
console.log('\nPASS ' + ok + ' / FAIL ' + ng);
process.exit(ng ? 1 : 0);
