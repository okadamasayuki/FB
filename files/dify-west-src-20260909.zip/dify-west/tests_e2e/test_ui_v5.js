// 3形式統合後のUI: ラジオ3択+解説切り替え+パリティダンプの実機検証
const { chromium } = require('playwright');
const fs = require('fs');

const ROOT = require('path').resolve(__dirname, '..');
const SCRATCH = process.env.SCRATCH || '.';
const TREE_CODED = fs.readFileSync(SCRATCH + '/tree_coded.md', 'utf8');
const TREE_PLAIN = fs.readFileSync(ROOT + '/分類ツリー.md', 'utf8');

let ok = 0, ng = 0;
function check(name, cond, detail) {
  if (cond) { ok++; console.log('  [PASS] ' + name); }
  else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); }
}

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto('file://' + ROOT + '/ツリーからDify.html');

  async function state() {
    return page.evaluate(() => ({
      outs: OUTPUTS.map(o => ({key: o.key, file: o.file, nodes: o.d.workflow.graph.nodes.length, mode: o.d.app.mode,
                               name: o.d.app.name})),
      canvasNodes: GRAPH ? GRAPH.nodes.length : 0,
      radios: ['stylePick', 'styleTree', 'styleFlat'].map(i => document.getElementById(i).checked),
      dlLabel: document.getElementById('dl').textContent,
      visibleExp: [...document.querySelectorAll('.expOnly')].filter(e => !e.classList.contains('hide'))
        .map(e => [...e.classList].find(c => c.startsWith('exp-only-'))),
      checks: document.getElementById('checks').innerText,
    }));
  }

  console.log('--- ラジオ(3択)と解説の初期状態 ---');
  let s = await state();
  check('初期はコード一発選択のみ選択', JSON.stringify(s.radios) === '[true,false,false]', JSON.stringify(s.radios));
  check('初期の解説はpickのみ表示', s.visibleExp.every(c => c === 'exp-only-pick') && s.visibleExp.length >= 2, JSON.stringify(s.visibleExp));
  const chatLeft = await page.evaluate(() => document.body.innerHTML.includes('仕訳フロー形式') || !!document.getElementById('styleChat'));
  check('仕訳フロー形式の痕跡なし', !chatLeft);

  console.log('--- 形式を切り替えると解説が切り替わる ---');
  for (const [radio, cls] of [['#styleFlat', 'exp-only-flat'], ['#styleTree', 'exp-only-tree'],
                              ['#stylePick', 'exp-only-pick']]) {
    await page.check(radio);
    s = await state();
    check(radio + ' → 解説は ' + cls + ' だけ', s.visibleExp.length >= 2 && s.visibleExp.every(c => c === cls), JSON.stringify(s.visibleExp));
    check(radio + ' → ラジオは1つだけ選択', s.radios.filter(Boolean).length === 1, JSON.stringify(s.radios));
  }

  console.log('--- 生成は選択中の1形式だけ ---');
  await page.evaluate(t => { document.getElementById('tree').value = t; }, TREE_CODED);
  const FILES = {tree: 'contract-account-classification-tree.yml',
                 flat: 'contract-account-classification-flat.yml', pick: 'contract-account-classification-pick.yml'};
  for (const [radio, key, nodes] of [['#stylePick', 'pick', 20], ['#styleTree', 'tree', 37],
                                     ['#styleFlat', 'flat', 21]]) {
    await page.check(radio);
    await page.click('#run');
    s = await state();
    check(key + ': 1出力・' + nodes + 'ノード・図も同じ',
      s.outs.length === 1 && s.outs[0].key === key && s.outs[0].nodes === nodes && s.canvasNodes === nodes,
      JSON.stringify(s.outs) + ' canvas=' + s.canvasNodes);
    check(key + ': アプリ名は相手勘定判定', s.outs[0].name.indexOf('契約書 相手勘定判定(') === 0, s.outs[0].name);
    check(key + ': 保存ファイル名', s.outs[0].file === FILES[key], s.outs[0].file);
  }

  console.log('--- 生成後にラジオを切り替えると自動で作り直す ---');
  s = await state();
  check('直前はflat', s.outs[0].key === 'flat');
  await page.check('#stylePick');
  s = await state();
  check('切り替えだけでpickに作り直された(20ノード)', s.outs.length === 1 && s.outs[0].key === 'pick' && s.canvasNodes === 20, JSON.stringify(s.outs));
  check('解説もpickに切り替わっている', s.visibleExp.every(c => c === 'exp-only-pick'), JSON.stringify(s.visibleExp));

  console.log('--- 3形式をまとめて保存(zip)---');
  const zipInfo = await page.evaluate(async () => {
    const blobs = [];
    const origUrl = URL.createObjectURL, origClick = HTMLAnchorElement.prototype.click;
    URL.createObjectURL = (b) => { blobs.push(b); return 'blob:x'; };
    HTMLAnchorElement.prototype.click = function(){};
    const visible = getComputedStyle(document.getElementById('dlAll')).display !== 'none';
    document.getElementById('dlAll').click();
    URL.createObjectURL = origUrl; HTMLAnchorElement.prototype.click = origClick;
    const b64 = await new Promise(res => { const r = new FileReader(); r.onload = () => res(r.result.split(',')[1]); r.readAsDataURL(blobs[0]); });
    return {n: blobs.length, type: blobs[0].type, b64, visible, note: document.getElementById('dlAllNote').textContent, pickYaml: OUTPUTS[0].yaml};
  });
  fs.writeFileSync(SCRATCH + '/js_all_forms.zip', Buffer.from(zipInfo.b64, 'base64'));
  const zc = JSON.parse(require('child_process').execSync('python3 -c \'' +
    'import zipfile, json, sys\n' +
    'z = zipfile.ZipFile(sys.argv[1])\n' +
    'names = z.namelist()\n' +
    'print(json.dumps({"names": names, "bad": z.testzip(), "pick": z.read("contract-account-classification-pick.yml").decode("utf-8"), ' +
    '"sizes": [z.getinfo(n).file_size for n in names], "utf8": [bool(z.getinfo(n).flag_bits & 0x800) for n in names]}, ensure_ascii=False))\' ' +
    JSON.stringify(SCRATCH + '/js_all_forms.zip'), {encoding: 'utf8'}));
  check('zipボタンは結果が出ているとき表示され、1回の保存でzipが1つ(application/zip)', zipInfo.visible && zipInfo.n === 1 && zipInfo.type === 'application/zip', JSON.stringify([zipInfo.visible, zipInfo.n, zipInfo.type]));
  check('zipに3形式の .yml が入り、CRCも正しい(Pythonの zipfile で検証・ファイル名はUTF-8フラグ)',
    JSON.stringify(zc.names) === JSON.stringify(['contract-account-classification-pick.yml', 'contract-account-classification-tree.yml', 'contract-account-classification-flat.yml'])
    && zc.bad === null && zc.sizes.every(s => s > 10000) && zc.utf8.every(Boolean), JSON.stringify([zc.names, zc.bad, zc.sizes, zc.utf8]));
  check('zipの中のpickは画面で生成したDSLと同じ内容', zc.pick === zipInfo.pickYaml, zc.pick.length + ' vs ' + zipInfo.pickYaml.length);
  check('保存後の案内に「1ファイルずつ」', zipInfo.note.includes('3形式') && zipInfo.note.includes('1ファイルずつ'), zipInfo.note);

  console.log('--- expTarget が形式に追従 ---');
  const exps = await page.evaluate(() => {
    const out = {};
    out.journal = expTarget('llm_journal');
    out.jq = expTarget('if-else-q');
    out.jqa = expTarget('answer-q');
    out.pick = expTarget('llm_pick');
    out.pickAns = expTarget('answer-final');
    document.getElementById('styleFlat').checked = true;
    document.getElementById('stylePick').checked = false;
    out.flat7 = expTarget('llm_code7');
    out.flat10 = expTarget('llm_code10');
    out.flatAns = expTarget('answer-final');
    document.getElementById('styleTree').checked = true;
    document.getElementById('styleFlat').checked = false;
    out.treeCascade = expTarget('llm-sub-anything');
    out.treePath = expTarget('template_path');
    out.treeQ = expTarget('if-else-q-tree');
    out.treeResult = expTarget('code_result');
    out.treeJournal = expTarget('llm_journal');
    out.common = expTarget('llm_summary');
    document.getElementById('stylePick').checked = true;
    document.getElementById('styleTree').checked = false;
    return out;
  });
  check('expTarget: 共通前段(journal/更問い)',
    exps.journal === 'exp-journal' && exps.jq === 'exp-jq' && exps.jqa === 'exp-jq'
    && exps.treeJournal === 'exp-journal', JSON.stringify(exps));
  check('expTarget: 形式別',
    exps.pick === 'exp-p-pick' && exps.pickAns === 'exp-p-code'
    && exps.flat7 === 'exp-f-7' && exps.flat10 === 'exp-f-10' && exps.flatAns === 'exp-f-code'
    && exps.treeCascade === 'exp-t-tree' && exps.treePath === 'exp-t-path'
    && exps.treeQ === 'exp-t-q' && exps.treeResult === 'exp-t-result'
    && exps.common === 'exp-summary', JSON.stringify(exps));
  const expIds = await page.evaluate(() =>
    ['exp-f-7', 'exp-f-10', 'exp-f-code', 'exp-p-pick', 'exp-p-code',
     'exp-t-tree', 'exp-t-agg', 'exp-t-path', 'exp-t-code', 'exp-t-q', 'exp-t-result',
     'exp-journal', 'exp-jq',
     'exp-start', 'exp-extract', 'exp-vision', 'exp-summary', 'exp-confirm'].filter(i => !document.getElementById(i)));
  check('解説の全アンカーが存在', expIds.length === 0, JSON.stringify(expIds));
  const staleIds = await page.evaluate(() =>
    ['exp-c-flow', 'exp-c-q', 'exp-c-code', 'exp-f-out', 'exp-p-out', 'exp-t-out'].filter(i => document.getElementById(i)));
  check('旧アンカーが残っていない', staleIds.length === 0, JSON.stringify(staleIds));

  console.log('--- コード無しツリー+flat単独は明確なエラー ---');
  await page.evaluate(t => { document.getElementById('tree').value = t; }, TREE_PLAIN);
  await page.check('#styleFlat');
  await page.click('#run');
  s = await state();
  check('変換できませんでした+[7桁]', s.outs.length === 0 && s.checks.includes('変換できませんでした') && s.checks.includes('[7桁]'), s.checks.slice(0, 150));

  console.log('--- コード無しツリーでも tree は生成できる ---');
  await page.check('#styleTree');
  await page.click('#run');
  s = await state();
  check('treeは生成できる', s.outs.length === 1 && s.outs[0].key === 'tree', JSON.stringify(s.outs));

  console.log('--- 自己学習チェックで学習ノードが増える(既定: 環境変数方式・ナレッジ不要)---');
  await page.evaluate(t => { document.getElementById('tree').value = t; }, TREE_CODED);
  await page.check('#stylePick');
  await page.check('#learnCheck');
  await page.click('#run');
  s = await state();
  check('learn(env): pickが24ノード(+4: 参考事例の選択/条件分岐/カード作成/回答)', s.outs.length === 1 && s.outs[0].nodes === 24, JSON.stringify(s.outs));
  const envInfo = await page.evaluate(() => ({
    ids: OUTPUTS[0].d.workflow.graph.nodes.map(n => n.id),
    envs: OUTPUTS[0].d.workflow.environment_variables.map(e => e.name),
    desc: OUTPUTS[0].d.app.description,
    opening: OUTPUTS[0].d.workflow.features.opening_statement,
    exp: [expTarget('code_cases'), expTarget('answer-case')],
    warn: document.getElementById('checks').innerText,
    radios: [document.getElementById('learnEnv').checked, document.getElementById('learnKb').checked],
    kbBox: document.getElementById('learnKbBox').style.display,
    lcBox: document.getElementById('learnCfgBox').style.display,
  }));
  check('learn(env): 既定は「環境変数に貼る」が選択・設定欄は表示・ナレッジID等の欄は隠れる',
    envInfo.radios[0] && !envInfo.radios[1] && envInfo.lcBox === 'block' && envInfo.kbBox === 'none', JSON.stringify(envInfo.radios) + envInfo.kbBox);
  check('learn(env): 学習ノード4つ+環境変数 learned_cases だけ(ナレッジ検索・保存系のノードと環境変数なし)',
    ['code_cases', 'if-else-learn', 'llm_case', 'answer-case'].every(i => envInfo.ids.includes(i))
    && !['kr_cases', 'code_pagecases', 'learn_gate', 'http_save_case', 'answer-learned', 'answer-nolearn'].some(i => envInfo.ids.includes(i))
    && envInfo.envs.includes('learned_cases') && !envInfo.envs.some(e => ['dify_base_url', 'dataset_api_key', 'case_dataset_id'].includes(e)),
    JSON.stringify(envInfo.envs));
  check('learn(env): 説明と開始文に「ナレッジ・APIキー不要」「learned_cases」、図クリックは解説へ',
    envInfo.desc.includes('ナレッジ・APIキー不要') && envInfo.opening.includes('learned_cases')
    && envInfo.exp.every(x => x === 'exp-selflearn'), envInfo.desc.slice(0, 120));
  check('learn(env): 案内は「そのまま公開できる」「learned_cases に貼る」(ナレッジ選択の案内は出ない)',
    envInfo.warn.includes('learned_cases') && envInfo.warn.includes('ナレッジもAPIキーも不要') && !envInfo.warn.includes('類似事例の検索'),
    envInfo.warn.slice(0, 200));

  console.log('--- 事例の置き場を「Difyの事例ナレッジ」に切り替えると従来のナレッジ構成 ---');
  await page.check('#learnKb');
  s = await state();
  check('learn(kb): 切り替えで自動で作り直し・pickが30ノード(+10: 参考事例の取り出しノード込み)', s.outs.length === 1 && s.outs[0].nodes === 30, JSON.stringify(s.outs));
  const learnInfo = await page.evaluate(() => ({
    ids: OUTPUTS[0].d.workflow.graph.nodes.map(n => n.id),
    envs: OUTPUTS[0].d.workflow.environment_variables.map(e => e.name),
    desc: OUTPUTS[0].d.app.description,
    exp: expTarget('kr_cases'),
    warn: document.getElementById('checks').innerText,
  }));
  check('learn(kb): 学習ノード一式+環境変数3つ(learned_cases は無い)',
    ['kr_cases', 'if-else-learn', 'llm_case', 'http_save_case', 'answer-learned'].every(i => learnInfo.ids.includes(i))
    && !learnInfo.ids.includes('code_cases')
    && ['dify_base_url', 'dataset_api_key', 'case_dataset_id'].every(e => learnInfo.envs.includes(e))
    && !learnInfo.envs.includes('learned_cases'),
    JSON.stringify(learnInfo.envs));
  check('learn(kb): 説明に自己学習+図クリックは解説へ',
    learnInfo.desc.includes('自己学習') && learnInfo.exp === 'exp-selflearn', learnInfo.exp);
  check('learn(kb): ナレッジ設定の案内が出る(選ぶまで公開できない注意つき)',
    learnInfo.warn.includes('類似事例の検索') && learnInfo.warn.includes('公開'), learnInfo.warn.slice(0, 200));

  console.log('--- 設定込みDSL(ナレッジID・キーを書き込み)---');
  let lcBox = await page.evaluate(() => document.getElementById('learnKbBox').style.display);
  check('kb中は設定込み欄が表示', lcBox === 'block', lcBox);
  await page.fill('#lcDsId', ' ds-ui-1 ');
  await page.fill('#lcUrl', 'https://ui.example.com/v1');
  await page.fill('#lcKey', 'dataset-ui-key');
  await page.click('#run');
  const cfgInfo = await page.evaluate(() => {
    const d = OUTPUTS[0].d;
    const kr = d.workflow.graph.nodes.find(n => n.id === 'kr_cases');
    const ev = {};
    for (const e of d.workflow.environment_variables) ev[e.name] = e.value;
    return {ids: kr.data.dataset_ids, desc: kr.data.desc, ev,
            warn: document.getElementById('checks').innerText,
            yamlHasId: OUTPUTS[0].yaml.includes('ds-ui-1'),
            yamlHasKey: OUTPUTS[0].yaml.includes('dataset-ui-key')};
  });
  check('設定込み: dataset_ids/desc/環境変数に値が入る(trimも)',
    JSON.stringify(cfgInfo.ids) === '["ds-ui-1"]' && cfgInfo.desc.includes('設定済み')
    && cfgInfo.ev.case_dataset_id === 'ds-ui-1' && cfgInfo.ev.dify_base_url === 'https://ui.example.com/v1'
    && cfgInfo.ev.dataset_api_key === 'dataset-ui-key',
    JSON.stringify(cfgInfo.ids) + ' ' + JSON.stringify(cfgInfo.ev));
  check('設定込み: YAMLにも入る+「設定込み」とキー平文の注意',
    cfgInfo.yamlHasId && cfgInfo.yamlHasKey && cfgInfo.warn.includes('設定込み') && cfgInfo.warn.includes('平文'),
    cfgInfo.warn.slice(0, 250));
  await page.fill('#lcDsId', '');
  await page.fill('#lcUrl', '');
  await page.fill('#lcKey', '');
  await page.click('#run');
  const emptyInfo = await page.evaluate(() => {
    const kr = OUTPUTS[0].d.workflow.graph.nodes.find(n => n.id === 'kr_cases');
    return {ids: kr.data.dataset_ids, warn: document.getElementById('checks').innerText};
  });
  check('空欄に戻すと従来どおり(dataset_ids空・従来の案内)',
    emptyInfo.ids.length === 0 && emptyInfo.warn.includes('類似事例の検索'), JSON.stringify(emptyInfo));
  await page.check('#learnEnv');
  s = await state();
  check('環境変数方式に戻すと24ノードに作り直し・設定込み欄が隠れる', s.outs[0].nodes === 24
    && (await page.evaluate(() => document.getElementById('learnKbBox').style.display)) === 'none', JSON.stringify(s.outs));
  await page.uncheck('#learnCheck');
  s = await state();
  check('learn解除で自動で作り直し(20ノード)', s.outs[0].nodes === 20, JSON.stringify(s.outs));
  lcBox = await page.evaluate(() => document.getElementById('learnCfgBox').style.display);
  check('learn解除で設定欄が隠れる', lcBox === 'none', lcBox);

  console.log('--- パリティダンプ書き出し(tree/flat/pick × learnなし/あり(既定=env) + kb pick + 設定込みpick)---');
  const dumpOne = async (fn, fname, learn, cfg) => {
    const dump = await page.evaluate(([f, tree, ln, c]) => {
      const d = window[f](tree, JSON.parse(EXTRAS_JSON), [], ln, c);
      for (const n of d.workflow.graph.nodes) {
        if (n.data && n.data.type === 'llm' && n.data.model) {
          n.data.model.provider = 'langgenius/azure_openai/azure_openai';
          n.data.model.name = 'GPT-4o';
        }
      }
      return dumpYaml(d);
    }, [fn, TREE_CODED, learn, cfg]);
    fs.writeFileSync(SCRATCH + '/js_' + fname + '_dump.yml', dump);
    check(fname + ' ダンプ書き出し', dump.length > 10000, String(dump.length));
  };
  for (const [fn, name] of [['generateTree', 'tree'], ['generateFlat', 'flat'], ['generatePick', 'pick']]) {
    await dumpOne(fn, name, false, null);
    await dumpOne(fn, name + '_learn', true, null);
  }
  await dumpOne('generatePick', 'pick_learn_kb', true, {mode: 'kb'});
  await dumpOne('generatePick', 'pick_learn_cfg', true,
    {mode: 'kb', base_url: 'https://parity.example.com/v1', dataset_key: 'dataset-parity-key', dataset_id: 'ds-parity-1'});

  check('全操作を通してJSエラーなし', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log('\nPASS ' + ok + ' / FAIL ' + ng);
  process.exit(ng ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
