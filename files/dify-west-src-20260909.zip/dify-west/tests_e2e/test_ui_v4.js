// ラジオ単一選択UI+解説切り替え+3形式パリティダンプの実機検証
const { chromium } = require('playwright');
const fs = require('fs');

const ROOT = require('path').resolve(__dirname, '..');
const SCRATCH = process.env.SCRATCH || '.';
const TREE_CODED = fs.readFileSync(SCRATCH + '/tree_coded.md', 'utf8');
const TREE_PLAIN = fs.readFileSync(ROOT + '/分類ツリー.md', 'utf8');

let ok = 0, ng = 0;
function check(name, cond, detail) {
  if (cond) { ok++; console.log('  [PASS] ' + name); }
  else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); }
}

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto('file://' + ROOT + '/ツリーからDify.html');

  async function state() {
    return page.evaluate(() => ({
      outs: OUTPUTS.map(o => ({key: o.key, file: o.file, nodes: o.d.workflow.graph.nodes.length, mode: o.d.app.mode})),
      canvasNodes: GRAPH ? GRAPH.nodes.length : 0,
      radios: ['styleChat', 'styleTree', 'styleFlat', 'stylePick'].map(i => document.getElementById(i).checked),
      dlLabel: document.getElementById('dl').textContent,
      visibleExp: [...document.querySelectorAll('.expOnly')].filter(e => !e.classList.contains('hide'))
        .map(e => [...e.classList].find(c => c.startsWith('exp-only-'))),
      checks: document.getElementById('checks').innerText,
    }));
  }

  console.log('--- ラジオ(単一選択)と解説の初期状態 ---');
  let s = await state();
  check('初期はチャットのみ選択', JSON.stringify(s.radios) === '[true,false,false,false]', JSON.stringify(s.radios));
  check('初期の解説はチャット形式のみ表示', s.visibleExp.every(c => c === 'exp-only-chat') && s.visibleExp.length >= 2, JSON.stringify(s.visibleExp));

  console.log('--- 形式を切り替えると解説が切り替わる ---');
  for (const [radio, cls] of [['#styleFlat', 'exp-only-flat'], ['#stylePick', 'exp-only-pick'],
                              ['#styleTree', 'exp-only-tree'], ['#styleChat', 'exp-only-chat']]) {
    await page.check(radio);
    s = await state();
    check(radio + ' → 解説は ' + cls + ' だけ', s.visibleExp.length >= 2 && s.visibleExp.every(c => c === cls), JSON.stringify(s.visibleExp));
    check(radio + ' → ラジオは1つだけ選択', s.radios.filter(Boolean).length === 1, JSON.stringify(s.radios));
  }

  console.log('--- 生成は選択中の1形式だけ ---');
  await page.evaluate(t => { document.getElementById('tree').value = t; }, TREE_CODED);
  const FILES = {chat: 'contract-account-classification-flow.yml', tree: 'contract-account-classification-tree.yml',
                 flat: 'contract-account-classification-flat.yml', pick: 'contract-account-classification-pick.yml'};
  for (const [radio, key, nodes] of [['#styleChat', 'chat', 19], ['#styleTree', 'tree', 32],
                                     ['#styleFlat', 'flat', 18], ['#stylePick', 'pick', 17]]) {
    await page.check(radio);
    await page.click('#run');
    s = await state();
    check(key + ': 1出力・' + nodes + 'ノード・図も同じ',
      s.outs.length === 1 && s.outs[0].key === key && s.outs[0].nodes === nodes && s.canvasNodes === nodes,
      JSON.stringify(s.outs) + ' canvas=' + s.canvasNodes);
    check(key + ': 保存ボタンは通常ラベル', s.dlLabel === 'DSL(YAML)を保存', s.dlLabel);
    check(key + ': 保存ファイル名', s.outs[0].file === FILES[key], s.outs[0].file);
  }

  console.log('--- 生成後にラジオを切り替えると自動で作り直す ---');
  s = await state();
  check('直前はpick', s.outs[0].key === 'pick');
  await page.check('#styleTree');
  s = await state();
  check('切り替えだけでtreeに作り直された(32ノード)', s.outs.length === 1 && s.outs[0].key === 'tree' && s.canvasNodes === 32, JSON.stringify(s.outs));
  check('解説もtreeに切り替わっている', s.visibleExp.every(c => c === 'exp-only-tree'), JSON.stringify(s.visibleExp));

  console.log('--- expTarget が形式に追従 ---');
  const exps = await page.evaluate(() => {
    const out = {};
    document.getElementById('styleFlat').checked = true;
    document.getElementById('styleTree').checked = false;
    out.flat7 = expTarget('llm_code7');
    out.flatAns = expTarget('answer-final');
    document.getElementById('stylePick').checked = true;
    document.getElementById('styleFlat').checked = false;
    out.pick = expTarget('llm_pick');
    document.getElementById('styleTree').checked = true;
    document.getElementById('stylePick').checked = false;
    out.treeCascade = expTarget('llm-sub-anything');
    out.treePath = expTarget('template_path');
    document.getElementById('styleChat').checked = true;
    document.getElementById('styleTree').checked = false;
    out.chatFlow = expTarget('llm_flow');
    out.common = expTarget('llm_summary');
    return out;
  });
  check('expTargetの対応が正しい',
    exps.flat7 === 'exp-f-7' && exps.flatAns === 'exp-f-out' && exps.pick === 'exp-p-pick'
    && exps.treeCascade === 'exp-t-tree' && exps.treePath === 'exp-t-path'
    && exps.chatFlow === 'exp-c-flow' && exps.common === 'exp-summary', JSON.stringify(exps));
  const expIds = await page.evaluate(() =>
    ['exp-f-7', 'exp-f-10', 'exp-f-code', 'exp-f-out', 'exp-p-pick', 'exp-p-code', 'exp-p-out',
     'exp-t-tree', 'exp-t-agg', 'exp-t-path', 'exp-t-code', 'exp-t-q', 'exp-t-out',
     'exp-c-flow', 'exp-c-q', 'exp-c-code',
     'exp-start', 'exp-extract', 'exp-vision', 'exp-summary', 'exp-confirm'].filter(i => !document.getElementById(i)));
  check('解説の全アンカーが存在', expIds.length === 0, JSON.stringify(expIds));

  console.log('--- コード無しツリー+flat単独は明確なエラー ---');
  await page.evaluate(t => { document.getElementById('tree').value = t; }, TREE_PLAIN);
  await page.check('#styleFlat');
  await page.click('#run');
  s = await state();
  check('変換できませんでした+[7桁]', s.outs.length === 0 && s.checks.includes('変換できませんでした') && s.checks.includes('[7桁]'), s.checks.slice(0, 150));

  console.log('--- パリティダンプ書き出し(tree/flat/pick)---');
  for (const [fn, name] of [['generateChat', 'chat'], ['generateTree', 'tree'], ['generateFlat', 'flat'], ['generatePick', 'pick']]) {
    const dump = await page.evaluate(([f, tree]) => {
      const d = window[f](tree, JSON.parse(EXTRAS_JSON), []);
      for (const n of d.workflow.graph.nodes) {
        if (n.data && n.data.type === 'llm' && n.data.model) {
          n.data.model.provider = 'langgenius/azure_openai/azure_openai';
          n.data.model.name = 'GPT-4o';
        }
      }
      return dumpYaml(d);
    }, [fn, TREE_CODED]);
    fs.writeFileSync(SCRATCH + '/js_' + name + '_dump.yml', dump);
    check(name + ' ダンプ書き出し', dump.length > 10000, String(dump.length));
  }

  check('全操作を通してJSエラーなし', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log('\nPASS ' + ok + ' / FAIL ' + ng);
  process.exit(ng ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
