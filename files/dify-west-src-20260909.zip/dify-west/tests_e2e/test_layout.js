// ③の並び: 1.入力 → 2.図(左)+解説(右) → 3.結果(その下) → 動画カード(最下部)。「できたDSL」カードは無い
const { chromium } = require('playwright');
const ROOT = require('path').resolve(__dirname, '..');
let ok = 0, ng = 0;
function check(name, cond, detail) {
  if (cond) { ok++; console.log('  [PASS] ' + name); }
  else { ng++; console.log('  [FAIL] ' + name + ' ' + (detail || '')); }
}
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto('file://' + ROOT + '/ツリーからDify.html'); await page.evaluate(() => KS.ready);
  const rects = () => page.evaluate(() => {
    const r = id => { const el = document.getElementById(id); if(!el) return null; const b = el.getBoundingClientRect(); return {top: b.top + window.scrollY, bottom: b.bottom + window.scrollY, left: b.left, width: b.width, visible: b.width > 0 && b.height > 0}; };
    return {canvas: r('canvasCard'), explain: r('explainCard'), dv: r('dvCard'), result: r('resultCard'), yaml: r('yamlCard'), wrap: r('explainCard') && document.querySelector('.wrap').getBoundingClientRect().width};
  });
  let s = await rects();
  check('「できたDSL」カードは無い', s.yaml === null, JSON.stringify(s.yaml));
  check('生成前: 図は非表示、解説と動画カードは表示', !s.canvas.visible && s.explain.visible && s.dv.visible);
  check('動画カードが解説より下(最下部)にある', s.dv.top > s.explain.bottom - 1, JSON.stringify([s.explain.bottom, s.dv.top]));
  await page.click('#sample'); await page.click('#run');
  await page.waitForFunction(() => !document.getElementById('canvasCard').classList.contains('hide') && OUTPUTS.length === 1);
  s = await rects();
  check('生成後: 図(左)と解説(右)が横並び(上端がそろう)', s.canvas.visible && s.explain.visible && s.canvas.left + s.canvas.width <= s.explain.left + 1 && Math.abs(s.canvas.top - s.explain.top) < 5,
    JSON.stringify([s.canvas.left, s.canvas.width, s.explain.left, s.canvas.top, s.explain.top]));
  check('3.結果は「図+解説」の下、動画カードはさらに下', s.result.top >= Math.max(s.canvas.bottom, s.explain.bottom) - 1 && s.dv.top >= s.result.bottom - 1,
    JSON.stringify([s.canvas.bottom, s.explain.bottom, s.result.top, s.result.bottom, s.dv.top]));
  check('見出しの番号: 図が 2、結果が 3、解説は番号なし', await page.evaluate(() => document.querySelector('#canvasCard h2').textContent.indexOf('2. Dify') === 0 && document.querySelector('#resultCard h2').textContent.indexOf('3. 結果') === 0 && document.querySelector('#explainCard h2').textContent.indexOf('解説') === 0));
  check('図の注記は「横に並んだ解説」', await page.evaluate(() => document.querySelector('#canvasCard div.note').textContent.includes('横に並んだ解説')));
  check('DSLの保存・コピーは2.結果に残っている', await page.evaluate(() => !!document.getElementById('dl') && !!document.getElementById('cp') && OUTPUTS[0].yaml.length > 1000));
  // ノードクリック → 解説の該当箇所へ(下へ)スクロール
  const before = await page.evaluate(() => window.scrollY);
  await page.evaluate(() => { const g = document.querySelector('#canvas g[data-nid]'); g.dispatchEvent(new MouseEvent('click', {bubbles: true})); });
  await page.waitForTimeout(700);
  const hit = await page.evaluate(() => ({y: window.scrollY, hit: !!document.querySelector('.exp-hit')}));
  check('図のノードをクリックすると解説の該当箇所が強調される', hit.hit, JSON.stringify([before, hit]));
  await page.check('#learnCheck');   // 動画ボタンは自己学習の「Difyの事例ナレッジ」方式の設定欄の中にある
  await page.check('#learnKb');
  await page.click('#dvGo');
  await page.waitForTimeout(700);
  check('「動画で見る」ボタンで最下部の動画カードへ移動し再生が始まる', await page.evaluate(() => { const b = document.getElementById('dvCard').getBoundingClientRect(); return b.top < window.innerHeight && DV.i >= 0; }));
  check('JSエラーなし', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log('\nPASS ' + ok + ' / FAIL ' + ng);
  process.exit(ng ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
