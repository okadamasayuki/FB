// ③ページを実UIで駆動して、各形式のYAMLダンプを js_<key>_dump.yml に保存する
// (3形式 × 自己学習の有無(既定=環境変数方式)+ 事例ナレッジ方式の pick(設定なし/設定込み)= 計8本)
const {chromium} = require('playwright');
const fs = require('fs');
const path = require('path');

const HERE = __dirname;
const PAGE = 'file://' + require('path').resolve(__dirname, '..') + '/ツリーからDify.html';
const CFG = {id: 'ds-parity-1', url: 'https://parity.example.com/v1', key: 'dataset-parity-key'};

(async () => {
  const browser = await chromium.launch({executablePath: process.env.CHROMIUM_PATH || undefined});
  const page = await browser.newPage();
  const errors = [];
  global.errorsDump = () => errors.join(' | ') || '(none)';
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto(PAGE);

  const tree = fs.readFileSync(path.join(HERE, 'tree_coded.md'), 'utf8');
  await page.fill('#tree', tree);

  async function dump(name, box, key, learn, mode, cfg) {
    await page.evaluate(a => {
      for (const id of ['stylePick', 'styleTree', 'styleFlat']) {
        document.getElementById(id).checked = (id === a.box);
      }
      document.getElementById('learnCheck').checked = a.learn;
      document.getElementById('learnKb').checked = a.mode === 'kb';
      document.getElementById('learnEnv').checked = a.mode !== 'kb';
      document.getElementById('lcDsId').value = a.cfg ? a.cfg.id : '';
      document.getElementById('lcUrl').value = a.cfg ? a.cfg.url : '';
      document.getElementById('lcKey').value = a.cfg ? a.cfg.key : '';
      OUTPUTS = [];
    }, {box, learn, mode, cfg});
    await page.click('#run');
    try {
      await page.waitForFunction(() => OUTPUTS && OUTPUTS.length === 1, null, {timeout: 20000});
    } catch (e) {
      const checks = await page.evaluate(() => document.getElementById('checks').textContent);
      console.error('FAIL waiting for output of', name, '\nchecks:', checks, '\nerrors:', errorsDump());
      process.exit(1);
    }
    const got = await page.evaluate(() => ({key: OUTPUTS[0].key, yaml: OUTPUTS[0].yaml}));
    if (got.key !== key) { console.error('FAIL: 選択した形式と出力が違う', box, got.key); process.exit(1); }
    fs.writeFileSync(path.join(HERE, 'js_' + name + '_dump.yml'), got.yaml);
    console.log('dumped', name, got.yaml.length, 'bytes');
  }

  for (const [box, key] of [['stylePick', 'pick'], ['styleTree', 'tree'], ['styleFlat', 'flat']]) {
    await dump(key, box, key, false, 'env', null);
    await dump(key + '_learn', box, key, true, 'env', null);
  }
  await dump('pick_learn_kb', 'stylePick', 'pick', true, 'kb', null);
  await dump('pick_learn_cfg', 'stylePick', 'pick', true, 'kb', CFG);

  if (errors.length) { console.error('PAGE ERRORS:', errors); process.exit(1); }
  await browser.close();
  console.log('OK');
})();
