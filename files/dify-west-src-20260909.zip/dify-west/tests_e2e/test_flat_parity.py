#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""コード選択形式(flat): ブラウザJS生成の完全ダンプと、Python生成器の出力が
バイト単位で一致することを照合する。"""
import io
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ROOT, 'tools'))
import miniyaml  # noqa: E402
import generate_workflow as gw  # noqa: E402

extras = miniyaml.load(io.open(os.path.join(ROOT, 'tools', 'workflow_extras.yml'), encoding='utf-8').read())
tree = io.open(os.path.join(HERE, 'tree_coded.md'), encoding='utf-8').read()

d = gw.generate_flat(tree, extras)
gw.set_llm_model(d, 'langgenius/azure_openai/azure_openai', 'GPT-4o')
py = miniyaml.dump(d)
js = io.open(os.path.join(HERE, 'js_flat_dump.yml'), encoding='utf-8').read()

if py == js:
    print('[PASS] flat: JS生成とPython生成の完全ダンプがバイト一致 (%d bytes)' % len(py))
    sys.exit(0)

print('[FAIL] flat: ダンプが一致しません (py %d / js %d bytes)' % (len(py), len(js)))
pl, jl = py.split('\n'), js.split('\n')
shown = 0
for i in range(max(len(pl), len(jl))):
    a = pl[i] if i < len(pl) else '<EOF>'
    b = jl[i] if i < len(jl) else '<EOF>'
    if a != b:
        print('  line %d:' % (i + 1))
        print('    py: %r' % a[:160])
        print('    js: %r' % b[:160])
        shown += 1
        if shown >= 8:
            break
sys.exit(1)
