# 環境変数一覧(分類基準の定義)

契約書仕訳ワークフローの環境変数 **31個** の中身の一覧です。
Dify の「環境変数」画面でこの内容を編集すると、対応する分岐の判定基準をプロンプトを触らずに変更・追記できます。

> このファイルは YAML(`contract-account-classification.yml`)から自動生成した転記です。実際に効くのは Dify 上の環境変数の値なので、編集は Dify 側で行ってください。

1. [`rules_ca_cash`](#rules_ca_cash) — 流動資産 → 現預金・有価証券・貸付金 の小分類(llm-sub-cash)
2. [`rules_ca_receivable`](#rules_ca_receivable) — 流動資産 → 営業債権・その他の債権・貸倒引当金 の小分類(llm-sub-rcv)
3. [`rules_ca_prepaid`](#rules_ca_prepaid) — 流動資産 → 前払費用・未収収益 の小分類(llm-sub-pe)
4. [`rules_ca_other`](#rules_ca_other) — 流動資産 → その他の流動資産 の小分類(llm-sub-oca)
5. [`rules_fa_tangible`](#rules_fa_tangible) — 固定資産 → 有形固定資産 の小分類(llm-sub-fa-tangible)
6. [`rules_fa_dep_tangible`](#rules_fa_dep_tangible) — 固定資産 → 減価償却累計額(有形固定資産) の小分類(llm-sub-fa-dep-tangible)
7. [`rules_fa_invprop`](#rules_fa_invprop) — 固定資産 → 投資不動産 の小分類(llm-sub-fa-invprop)
8. [`rules_fa_intangible`](#rules_fa_intangible) — 固定資産 → 無形固定資産 の小分類(llm-sub-fa-intangible)
9. [`rules_fa_rou`](#rules_fa_rou) — 固定資産 → 使用権資産 の小分類(llm-sub-fa-rou)
10. [`rules_fa_dep_rou`](#rules_fa_dep_rou) — 固定資産 → 減価償却累計額(使用権資産) の小分類(llm-sub-fa-dep-rou)
11. [`rules_fa_impairment`](#rules_fa_impairment) — 固定資産 → 減損損失累計額 の小分類(llm-sub-fa-impairment)
12. [`rules_fa_securities`](#rules_fa_securities) — 固定資産 → 有価証券・その他投資 の小分類(llm-sub-fa-securities)
13. [`rules_fa_loans`](#rules_fa_loans) — 固定資産 → 長期貸付金 の小分類(llm-sub-fa-loans)
14. [`rules_fa_otherfin`](#rules_fa_otherfin) — 固定資産 → その他の金融非流動資産・その他 の小分類(llm-sub-fa-otherfin)
15. [`rules_fa_other`](#rules_fa_other) — 固定資産 → その他の非流動資産 の小分類(llm-sub-fa-other)
16. [`rules_fl_borrowing`](#rules_fl_borrowing) — 固定負債 → 長期借入債務 の小分類(llm-sub-fl-borrowing)
17. [`rules_fl_otherfin`](#rules_fl_otherfin) — 固定負債 → その他の金融負債(デリバティブ非流動負債) の小分類(llm-sub-fl-otherfin)
18. [`rules_fl_other`](#rules_fl_other) — 固定負債 → その他 の小分類(llm-sub-fl-other)
19. [`rules_fl_provisions`](#rules_fl_provisions) — 固定負債 → 引当金 の小分類(llm-sub-fl-provisions)
20. [`rules_fl_otherprov`](#rules_fl_otherprov) — 固定負債 → その他の引当金(非流動) の小分類(llm-sub-fl-otherprov)
21. [`code_map`](#code_map) — 経路→勘定科目コードの対応表(ツリーの[7桁][3桁]から自動生成)
22. [`rules_cl_borrowing`](#rules_cl_borrowing) — 流動負債 → 短期借入債務 の小分類(llm-sub-stb)
23. [`rules_cl_payable`](#rules_cl_payable) — 流動負債 → 営業債務・その他の債務 の小分類(llm-sub-pay)
24. [`rules_cl_personnel`](#rules_cl_personnel) — 流動負債 → 未払人件費 の小分類(llm-sub-upc)
25. [`rules_cl_tax`](#rules_cl_tax) — 流動負債 → 未払税金 の小分類(llm-sub-utx)
26. [`rules_cl_other`](#rules_cl_other) — 流動負債 → その他の流動負債 の小分類(llm-sub-ocl)
27. [`rules_oe_payroll`](#rules_oe_payroll) — 営業費用 → 人件費 の小分類(llm-sub-pc)
28. [`rules_oe_expense`](#rules_oe_expense) — 営業費用 → 経費 の小分類(llm-sub-ke)
29. [`rules_oe_entertainment`](#rules_oe_entertainment) — 営業費用 → 経費 → 交際費 の小分類(llm-sub-ent)
30. [`rules_oe_depreciation`](#rules_oe_depreciation) — 営業費用 → 減価償却・除却費 の小分類(llm-sub-dep)
31. [`rules_oe_publicdues`](#rules_oe_publicdues) — 営業費用 → 租税公課・公的使用料 の小分類(llm-sub-pub)

## `rules_ca_cash`

流動資産 → 現預金・有価証券・貸付金 の小分類(llm-sub-cash)

```
1. 現金・預金: 預金口座の開設・預入、当座勘定取引
2. 有価証券
3. 短期貸付金(3ヶ月以内)
4. 短期貸付金(3ヶ月超)
```

## `rules_ca_receivable`

流動資産 → 営業債権・その他の債権・貸倒引当金 の小分類(llm-sub-rcv)

```
1. 受取手形
2. 売掛金
3. 未収入金
4. 貸倒引当金
5. 債権(その他)
```

## `rules_ca_prepaid`

流動資産 → 前払費用・未収収益 の小分類(llm-sub-pe)

```
1. 前払費用: 保険料・保守料・家賃など、継続的な役務提供の対価の前払い
2. 前払利息
3. 未収利息
4. 未収収益: 継続的な役務提供の対価のうち、まだ受け取っていない収益
```

## `rules_ca_other`

流動資産 → その他の流動資産 の小分類(llm-sub-oca)

```
1. 立替金
2. 仮払金
3. その他流動資産(その他)
```

## `rules_fa_tangible`

固定資産 → 有形固定資産 の小分類(llm-sub-fa-tangible)

```
1. 土地
2. 建物
3. 構築物
4. 機械および装置
5. 車両および船舶
6. 工具器具備品
7. 建設仮勘定
8. 有形固定資産(その他)
```

## `rules_fa_dep_tangible`

固定資産 → 減価償却累計額(有形固定資産) の小分類(llm-sub-fa-dep-tangible)

```
1. 建物
2. 構築物
3. 機械および装置
4. 車両および船舶
5. 工具器具備品
6. 有形固定資産(その他)
```

## `rules_fa_invprop`

固定資産 → 投資不動産 の小分類(llm-sub-fa-invprop)

```
1. 投資不動産(有形)
2. 減価償却累計額(投資不動産)
```

## `rules_fa_intangible`

固定資産 → 無形固定資産 の小分類(llm-sub-fa-intangible)

```
1. 営業権
2. 契約関係固定資産
3. ソフトウェア
4. 知的財産権
5. その他無形固定資産
```

## `rules_fa_rou`

固定資産 → 使用権資産 の小分類(llm-sub-fa-rou)

```
1. 使用権資産(電気通信)
2. 使用権資産(建物)
3. 使用権資産(構築物)
4. 使用権資産(機械および装置)
5. 使用権資産(車両および船舶)
6. 使用権資産(工具器具備品)
7. 使用権資産(その他)
```

## `rules_fa_dep_rou`

固定資産 → 減価償却累計額(使用権資産) の小分類(llm-sub-fa-dep-rou)

```
1. 使用権資産減価償却累計額(電気通信)
2. 使用権資産減価償却累計額(建物)
3. 使用権資産減価償却累計額(構築物)
4. 使用権資産減価償却累計額(機械および装置)
5. 使用権資産減価償却累計額(車両および船舶)
6. 使用権資産減価償却累計額(工具器具備品)
7. 使用権資産減価償却累計額(その他)
```

## `rules_fa_impairment`

固定資産 → 減損損失累計額 の小分類(llm-sub-fa-impairment)

```
1. 有形固定資産
2. 使用権資産
```

## `rules_fa_securities`

固定資産 → 有価証券・その他投資 の小分類(llm-sub-fa-securities)

```
1. 関係会社株式・社債
2. その他関係会社有価証券
3. 関係会社出資金
4. 満期保有目的債券
5. その他有価証券
```

## `rules_fa_loans`

固定資産 → 長期貸付金 の小分類(llm-sub-fa-loans)

```
1. 長期貸付金
2. 関係会社長期貸付金
```

## `rules_fa_otherfin`

固定資産 → その他の金融非流動資産・その他 の小分類(llm-sub-fa-otherfin)

```
1. 差入敷金・保証金
2. 破産更生債権
3. 出資金
4. 貸倒引当金(固定)
5. その他の金融資産(デリバティブ非流動資産)
```

## `rules_fa_other`

固定資産 → その他の非流動資産 の小分類(llm-sub-fa-other)

```
1. 長期前払費用
2. その他の投資
3. 前払年金費用
```

## `rules_fl_borrowing`

固定負債 → 長期借入債務 の小分類(llm-sub-fl-borrowing)

```
1. 長期借入金
2. 社債
```

## `rules_fl_otherfin`

固定負債 → その他の金融負債(デリバティブ非流動負債) の小分類(llm-sub-fl-otherfin)

```
1. 金融負債(デリバティブ)
```

## `rules_fl_other`

固定負債 → その他 の小分類(llm-sub-fl-other)

```
1. リース債務(固定)
2. 長期預り金
```

## `rules_fl_provisions`

固定負債 → 引当金 の小分類(llm-sub-fl-provisions)

```
1. 環境対策引当金(固定)
```

## `rules_fl_otherprov`

固定負債 → その他の引当金(非流動) の小分類(llm-sub-fl-otherprov)

```
1. 株式給付引当金
2. その他
3. 受入敷金・保証金
4. 資産除去債務(固定)
5. その他の固定負債
```

## `code_map`

経路→勘定科目コードの対応表(ツリーの[7桁][3桁]から自動生成)

```

```

## `rules_cl_borrowing`

流動負債 → 短期借入債務 の小分類(llm-sub-stb)

```
1. 短期借入金: 返済期限1年以内の借入、当座借越
2. 1年内返済分長期借入債務
```

## `rules_cl_payable`

流動負債 → 営業債務・その他の債務 の小分類(llm-sub-pay)

```
1. 買掛金
2. 未払金
3. 債務(その他)
```

## `rules_cl_personnel`

流動負債 → 未払人件費 の小分類(llm-sub-upc)

```
1. 未払金(給与): 支給額が確定した給与・賃金の未払分
2. 未払費用(賞与): 賞与など期間対応で見積計上する未払人件費
```

## `rules_cl_tax`

流動負債 → 未払税金 の小分類(llm-sub-utx)

```
1. 未払事業所税
2. 未払法人税等
3. 未払税金(その他): 未払消費税等など上記以外の税金の未払分
```

## `rules_cl_other`

流動負債 → その他の流動負債 の小分類(llm-sub-ocl)

```
1. 預り金
2. 前受収益: 継続的な役務提供の対価の前受け
3. 仮受金
4. 引当金
5. その他の流動負債
```

## `rules_oe_payroll`

営業費用 → 人件費 の小分類(llm-sub-pc)

```
1. 給与: 従業員に支払う給与・賃金・賞与など、雇用契約に基づく労働の対価
2. 人件費その他: 役員報酬、退職金・退職慰労金、賞与引当金繰入など給与以外の人件費
```

## `rules_oe_expense`

営業費用 → 経費 の小分類(llm-sub-ke)

```
1. 端末仕入原価: 販売用の端末・機器・商品の仕入
2. 物品費: 事務用品・消耗品・備品の購入
3. 試験研究費: 研究開発に係る委託・共同研究・材料調達
4. 少額リース資産
5. 光熱水道料
6. 広告宣伝費: 広告出稿、宣伝物制作、キャンペーン、スポンサー契約
7. 代理店手数料
8. 工事請負費
9. 人材派遣料・派遣費
10. 他作業委託費: 業務の外部委託・アウトソーシング・保守運用委託
11. 通信設備使用料: 通信設備・回線の使用料、相互接続料、コロケーション利用料
12. 賃借料
13. 交際費
14. 会議費: 会議・打合せの会場利用等に係る費用
15. その他経費
```

## `rules_oe_entertainment`

営業費用 → 経費 → 交際費 の小分類(llm-sub-ent)

```
1. 慶弔費: 慶弔電報・花輪・祝金・香典など、社外の慶弔に伴い金品を支出するための費用
2. 社外飲食等: 社外の関係者との飲食・接待のための費用のうち、1人あたりの単価が1万円を超えるもの
3. 社外飲食等(少額交際費): 社外の関係者との飲食のうち、1人あたりの単価が1万円以下のもの
4. その他の贈答: 中元・歳暮等、金品を贈与するために必要な費用
5. その他: 上記以外で観光招待等明らかに接待・供応を目的とした費用、その他事業上必要な接待および交際のために要した費用
```

## `rules_oe_depreciation`

営業費用 → 減価償却・除却費 の小分類(llm-sub-dep)

```
1. 減価償却費
2. 除却費: 固定資産の除却・撤去・廃棄に伴う費用
```

## `rules_oe_publicdues`

営業費用 → 租税公課・公的使用料 の小分類(llm-sub-pub)

```
1. 道路占用料
2. 公園占用料
3. 河川占用料
4. その他の行政財産使用料: 上記以外の行政財産の使用許可に伴う使用料や租税公課
```
