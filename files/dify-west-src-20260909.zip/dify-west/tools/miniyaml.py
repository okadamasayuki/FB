# -*- coding: utf-8 -*-
"""PyYAML無し(Python標準ライブラリのみ)で動く、最小限のYAML書き出し/読み込み。

このリポジトリのツールが出力するブロック形式のYAMLだけを対象にした実装で、
YAML全仕様には対応しない(アンカー・タグ・折返しスカラー等は明示的にエラーにする)。
Difyが読める正しいYAMLを出力し、自分が出力したYAMLは必ず読み戻せる。
"""
import re

# ---------------------------------------------------------------- 書き出し

_NUM_RE = re.compile(r'^[-+]?(\d+\.?\d*([eE][-+]?\d+)?|\.\d+|0x[0-9a-fA-F]+|0o?[0-7]+)$')
_SEXAGESIMAL_RE = re.compile(r'^[-+]?\d[\d_]*(:[0-5]?\d)+')
_BOOLNULL = {'true', 'false', 'null', 'yes', 'no', 'on', 'off', '~', 'none'}
_FIRST_UNSAFE = set("-?:,[]{}#&*!|>'\"%@` \t")


def _plain_ok(s):
    if s == '' or s.lower() in _BOOLNULL or _NUM_RE.match(s) or _SEXAGESIMAL_RE.match(s):
        return False
    if s[0] in _FIRST_UNSAFE or s[-1] in ' \t:':
        return False
    if ': ' in s or ' #' in s or '\n' in s or '\t' in s or '\r' in s:
        return False
    if any(ord(c) < 0x20 for c in s):
        return False
    return True


def _dq(s):
    out = ['"']
    for c in s:
        if c == '\\':
            out.append('\\\\')
        elif c == '"':
            out.append('\\"')
        elif c == '\n':
            out.append('\\n')
        elif c == '\t':
            out.append('\\t')
        elif c == '\r':
            out.append('\\r')
        elif ord(c) < 0x20:
            out.append('\\x%02x' % ord(c))
        else:
            out.append(c)
    out.append('"')
    return ''.join(out)


def _scalar_inline(v):
    if v is None:
        return 'null'
    if v is True:
        return 'true'
    if v is False:
        return 'false'
    if isinstance(v, (int, float)):
        return repr(v)
    if isinstance(v, str):
        return v if _plain_ok(v) else _dq(v)
    raise TypeError('unsupported scalar: %r' % (v,))


def _literal_ok(s):
    if '\n' not in s or s.endswith('\n') or s.startswith((' ', '\n', '\t')) or '\r' in s:
        return False
    for ln in s.split('\n'):
        if ln != ln.rstrip() or any(ord(c) < 0x20 for c in ln):
            return False
    return True


def _emit(obj, ind, lines):
    pad = '  ' * ind
    if isinstance(obj, dict):
        for k, v in obj.items():
            if not isinstance(k, str):
                raise TypeError('dict keys must be str: %r' % (k,))
            key = _scalar_inline(k)
            if isinstance(v, dict):
                if v:
                    lines.append('%s%s:' % (pad, key))
                    _emit(v, ind + 1, lines)
                else:
                    lines.append('%s%s: {}' % (pad, key))
            elif isinstance(v, list):
                if v:
                    lines.append('%s%s:' % (pad, key))
                    _emit(v, ind + 1, lines)
                else:
                    lines.append('%s%s: []' % (pad, key))
            elif isinstance(v, str) and _literal_ok(v):
                lines.append('%s%s: |-' % (pad, key))
                for ln in v.split('\n'):
                    lines.append(('%s  %s' % (pad, ln)) if ln else '')
            else:
                lines.append('%s%s: %s' % (pad, key, _scalar_inline(v)))
    elif isinstance(obj, list):
        for it in obj:
            if isinstance(it, (dict, list)) and it:
                sub = []
                _emit(it, 0, sub)
                lines.append('%s- %s' % (pad, sub[0]))
                lines.extend((pad + '  ' + l) if l else '' for l in sub[1:])
            elif isinstance(it, dict):
                lines.append('%s- {}' % pad)
            elif isinstance(it, list):
                lines.append('%s- []' % pad)
            elif isinstance(it, str) and _literal_ok(it):
                lines.append('%s- |-' % pad)
                for ln in it.split('\n'):
                    lines.append(('%s  %s' % (pad, ln)) if ln else '')
            else:
                lines.append('%s- %s' % (pad, _scalar_inline(it)))
    else:
        lines.append(pad + _scalar_inline(obj))


def dump(obj):
    lines = []
    _emit(obj, 0, lines)
    return '\n'.join(lines) + '\n'


# ---------------------------------------------------------------- 読み込み

class YamlError(Exception):
    pass

_UNSUPPORTED = ('この形式のYAMLには対応していません(PyYAMLをインストールすれば読めます): ')


class _Parser(object):
    def __init__(self, text):
        self.lines = text.split('\n')
        self.i = 0

    def _peek(self):
        while self.i < len(self.lines):
            l = self.lines[self.i]
            st = l.strip()
            if st == '' or st.startswith('#') or st == '---':
                self.i += 1
                continue
            return len(l) - len(l.lstrip(' ')), st
        return None

    def parse(self):
        val = self._block(-1)
        if self._peek() is not None:
            raise YamlError('複数ドキュメント、またはインデント不整合があります(行 %d)' % (self.i + 1))
        return val

    def _block(self, parent_indent):
        p = self._peek()
        if p is None or p[0] <= parent_indent:
            return None
        indent, content = p
        if content == '-' or content.startswith('- '):
            return self._seq(indent)
        try:
            self._split_key(content)
        except YamlError:
            # キーの無い1行 = スカラー(シーケンス項目の中身など)
            self.i += 1
            return self._value(content, parent_indent)
        return self._map(indent)

    def _value_block(self, key_indent):
        """「key:」の値。シーケンスはキーと同じインデントで始まってもよい(PyYAMLの既定出力)"""
        p = self._peek()
        if p is None or p[0] < key_indent:
            return None
        if p[0] == key_indent:
            if p[1] == '-' or p[1].startswith('- '):
                return self._seq(key_indent)
            return None
        return self._block(key_indent)

    def _seq(self, indent):
        out = []
        while True:
            p = self._peek()
            if p is None or p[0] != indent or not (p[1] == '-' or p[1].startswith('- ')):
                break
            raw = self.lines[self.i]
            rest = raw[indent + 1:]
            if rest.strip() == '':
                self.i += 1
                out.append(self._block(indent))
            else:
                # 「- 」を空白に置き換えて、この行から始まる子ノードとして読む
                self.lines[self.i] = raw[:indent] + ' ' + rest
                out.append(self._block(indent))
        return out

    def _map(self, indent):
        out = {}
        while True:
            p = self._peek()
            if p is None or p[0] != indent or p[1] == '-' or p[1].startswith('- '):
                break
            content = p[1]
            key, rest = self._split_key(content)
            self.i += 1
            if rest == '':
                out[key] = self._value_block(indent)
            else:
                out[key] = self._value(rest, indent)
        if not out:
            raise YamlError('マッピングを読めません(行 %d 付近)' % (self.i + 1))
        return out

    def _split_key(self, content):
        if content.startswith('"'):
            m = re.match(r'^("(?:[^"\\]|\\.)*")\s*:(?:\s+(.*))?$', content)
            if not m:
                raise YamlError(_UNSUPPORTED + content)
            return self._value(m.group(1), 0), (m.group(2) or '').strip()
        if content.startswith("'"):
            m = re.match(r"^('(?:[^']|'')*')\s*:(?:\s+(.*))?$", content)
            if not m:
                raise YamlError(_UNSUPPORTED + content)
            return self._value(m.group(1), 0), (m.group(2) or '').strip()
        if content.endswith(':') and ': ' not in content:
            return content[:-1].strip(), ''
        idx = content.find(': ')
        if idx < 0:
            raise YamlError(_UNSUPPORTED + content)
        return content[:idx].strip(), content[idx + 2:].strip()

    def _value(self, s, parent_indent):
        if s in ('|', '|-', '|+'):
            return self._literal(s, parent_indent)
        if s and s[0] in '>&*!':
            raise YamlError(_UNSUPPORTED + s)
        if s.startswith('"'):
            if not re.match(r'^"(?:[^"\\]|\\.)*"$', s):
                raise YamlError(_UNSUPPORTED + s)
            return self._unescape(s[1:-1])
        if s.startswith("'"):
            if re.match(r"^'(?:[^']|'')*'$", s):
                return s[1:-1].replace("''", "'")
            return self._folded_single(s)
        if s == '[]':
            return []
        if s == '{}':
            return {}
        if s.startswith('[') or s.startswith('{'):
            return self._flow(s)
        if s.lower() in ('null', '~', 'none', ''):
            return None
        if s.lower() == 'true':
            return True
        if s.lower() == 'false':
            return False
        if re.match(r'^[-+]?\d+$', s):
            return int(s)
        if re.match(r'^[-+]?(\d+\.\d*|\.\d+)([eE][-+]?\d+)?$', s):
            return float(s)
        return s

    def _flow(self, s):
        # 単純なフロー形式([a, b, c] など。入れ子・引用符入りカンマは非対応)
        if s.startswith('[') and s.endswith(']'):
            inner = s[1:-1].strip()
            if inner == '':
                return []
            if '[' in inner or '{' in inner:
                raise YamlError(_UNSUPPORTED + s)
            return [self._value(x.strip(), 0) for x in inner.split(',')]
        raise YamlError(_UNSUPPORTED + s)

    def _scan_sq(self, line):
        """単一引用符スカラーの1行分を読む。(本文, 閉じたか) を返す"""
        out = []
        i = 0
        while i < len(line):
            c = line[i]
            if c == "'":
                if i + 1 < len(line) and line[i + 1] == "'":
                    out.append("'")
                    i += 2
                    continue
                if line[i + 1:].strip():
                    raise YamlError(_UNSUPPORTED + line)
                return ''.join(out), True
            out.append(c)
            i += 1
        return ''.join(out), False

    def _folded_single(self, s):
        """複数行に折り返された単一引用符スカラー(PyYAMLが改行入り文字列で出す形式)。
        折り返し = 空白1つ、空行n個 = 改行n個。"""
        result, done = self._scan_sq(s[1:])
        blanks = 0
        while not done:
            if self.i >= len(self.lines):
                raise YamlError('単一引用符が閉じていません')
            stripped = self.lines[self.i].strip()
            self.i += 1
            if stripped == '':
                blanks += 1
                continue
            seg, done = self._scan_sq(stripped)
            result += ('\n' * blanks) if blanks else ' '
            blanks = 0
            result += seg
        return result

    def _literal(self, header, parent_indent):
        body = []
        block_indent = None
        while self.i < len(self.lines):
            raw = self.lines[self.i]
            if raw.strip() == '':
                body.append('')
                self.i += 1
                continue
            ind = len(raw) - len(raw.lstrip(' '))
            if block_indent is None:
                if ind <= parent_indent:
                    break
                block_indent = ind
            if ind < block_indent:
                break
            body.append(raw[block_indent:])
            self.i += 1
        while body and body[-1] == '':
            body.pop()
        text = '\n'.join(body)
        if header == '|':
            text += '\n'
        return text

    def _unescape(self, s):
        out = []
        i = 0
        while i < len(s):
            c = s[i]
            if c != '\\':
                out.append(c)
                i += 1
                continue
            n = s[i + 1]
            if n == 'n':
                out.append('\n')
            elif n == 't':
                out.append('\t')
            elif n == 'r':
                out.append('\r')
            elif n == '"':
                out.append('"')
            elif n == '\\':
                out.append('\\')
            elif n == 'x':
                out.append(chr(int(s[i + 2:i + 4], 16)))
                i += 4
                continue
            elif n == 'u':
                out.append(chr(int(s[i + 2:i + 6], 16)))
                i += 6
                continue
            else:
                raise YamlError(_UNSUPPORTED + '\\' + n)
            i += 2
        return ''.join(out)


def load(text):
    return _Parser(text).parse()
