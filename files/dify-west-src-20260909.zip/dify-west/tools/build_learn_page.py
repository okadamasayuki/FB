#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""⑤「自動学習」ページを組み立てる。

  python3 tools/build_learn_page.py   → 自動学習.html

決裁フォルダを入れると「全件テスト → 誤答だけ教える → 再テスト」を繰り返して
正答率を上げていく、機械学習で標準のエポック学習ループのページ。
ランナーJSは tools/eval_common.js(④と共通のコア)と tools/learn_page_runner.js
(このページ固有)にあり、ビルド時にトークン置換でそのまま埋め込む
(エスケープ加工をしないので、JSは.jsファイルを直す)。
直したら、これを実行し直してから build_bundle.py を実行する。
「動画で見る」は tools/demo_player.css / demo_player.js(③④と共通のエンジン)と
tools/learn_demo_scripts.js(⑤の台本2本)を、同じくトークン置換で埋め込む。
"""
import io
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, '自動学習.html')

PAGE = '''<!doctype html>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>自動学習ループ(エポック学習で正答率を上げる)</title>
<style>
  :root{
    --bg:#f6f7f9; --fg:#1b1d20; --sub:#5b6169; --line:#d8dce1; --card:#ffffff;
    --accent:#2f6fed; --accent-fg:#ffffff; --code-bg:#f2f4f7;
    --ok:#1d7a4f; --ok-bg:#e8f6ee; --warn:#8a5a00; --warn-bg:#fff4dc;
  }
  *{box-sizing:border-box}
  body{margin:0;background:var(--bg);color:var(--fg);
       font-family:"Yu Gothic UI","Yu Gothic","Meiryo",system-ui,sans-serif;line-height:1.8}
  .wrap{max-width:1100px;margin:0 auto;padding:24px 16px 60px}
  h1{font-size:20px;margin:0 0 6px}
  h2{font-size:16px;margin:0 0 10px}
  h3{font-size:14px;margin:16px 0 6px}
  .lead{font-size:13px;color:var(--sub);margin:0 0 16px}
  .card{background:var(--card);border:1px solid var(--line);border-radius:10px;
        padding:16px;margin-bottom:16px}
  .btns{display:flex;gap:10px;flex-wrap:wrap;margin-top:10px}
  button{padding:9px 16px;border:1px solid var(--line);border-radius:6px;background:var(--card);
         color:var(--fg);font-family:inherit;font-size:13px;font-weight:600;cursor:pointer}
  button:hover{border-color:var(--accent)}
  button.primary{background:var(--accent);border-color:var(--accent);color:var(--accent-fg)}
  button:disabled{opacity:.5;cursor:default}
  code{background:var(--code-bg);border:1px solid var(--line);border-radius:4px;
       padding:1px 5px;font-family:Consolas,monospace;font-size:12px}
  pre{background:var(--code-bg);border:1px solid var(--line);border-radius:6px;padding:12px;
      overflow:auto;font-family:"BIZ UDGothic","MS Gothic",Consolas,monospace;font-size:12px;line-height:1.7}
  .note{font-size:12px;color:var(--sub);margin-top:8px}
  ul{font-size:14px;margin:0;padding-left:20px}
  ol{font-size:14px;margin:0;padding-left:22px}
  .warnbox{background:var(--warn-bg);border:1px solid #ead9ad;color:var(--warn);
           border-radius:6px;padding:10px 12px;font-size:13px;margin-top:10px}
  .okbox{background:var(--ok-bg);border:1px solid #bfe3cf;color:var(--ok);
         border-radius:6px;padding:10px 12px;font-size:13px;margin-top:10px}
  input[type="text"],input[type="password"]{border:1px solid var(--line);border-radius:6px;
         padding:6px 8px;font-family:Consolas,monospace;font-size:13px}
  input[type="number"]{border:1px solid var(--line);border-radius:6px;padding:4px;font-size:13px}
__DEMO_PLAYER_CSS__
</style>

<div class="wrap">
<h1>⑤ 自動学習 — 誤答を教えて正答率を上げるループ(エポック学習)</h1>
<p class="lead">
  ④と同じ決裁フォルダ(決裁書類+正解.txt)を入れて実行すると、
  <b>全決裁をテスト → 間違えた決裁にだけ正解を教える → また全決裁をテスト</b>…を自動で繰り返し、
  正答率の推移(例: 78%→85%→93%)を見ながら、目標に達したら止まります。
  機械学習で標準の「エポック学習」の回し方です。
  ③の既定(環境変数 <code>learned_cases</code> に貼る方式・ナレッジ不要)で作ったアプリは、教えたカードをこのブラウザの仮ナレッジに
  溜めて回す<b>仮ナレッジモード</b>(ナレッジAPIキー空欄)で動き、最後に 判定事例.txt をアプリの環境変数に貼ります。
  <b>このページ自体は通信しません。通信するのは「学習を実行」カードだけで、
  あなたが入力した自社DifyのURLにのみ通信します(それ以外の通信は行いません)。</b>
</p>

<div class="card">
  <h2>1. どう学習するのか(なぜ「1件ずつ粘る」ではなく「1周ずつ回す」のか)</h2>
  <ul>
    <li><b>学習の中身</b> — 間違えた決裁の判定と<b>同じ会話</b>に「正解: ◯◯」を自動で返信します。
      ③で「自己学習」にチェックを入れて作った判定アプリは、これを受けて<b>事例カード</b>
      (この契約の見分け方)を作って返します。<b>③の既定(環境変数に貼る方式)のアプリ</b>では、⑤がそのカードを
      このブラウザに溜め(仮ナレッジモード)、次の判定の「OK」に似たカード(最大4枚)を「参考事例:」として添えます。
      終了後に <code>判定事例.txt</code> にまとめ、アプリの環境変数 <code>learned_cases</code> に貼ると本番の判定でも参考にされます。
      <b>③で「Difyの事例ナレッジ」を選んだアプリ</b>(ナレッジAPIキーあり)では、アプリがカードを事例ナレッジに保存し、
      次のテストから似た契約の判定前に自動で検索されます</li>
    <li><b>1決裁=1カードの差し替え</b> — 同じ決裁をまた間違えたら、前回のカードを削除して、
      「前回は◯◯と誤答したままだった」という情報を添えて<b>作り直し</b>ます。
      カードがどんどん増えるのではなく、決裁ごとの1枚を磨いていきます(仮ナレッジモードではブラウザ側で差し替えます)</li>
    <li><b>なぜ1件に粘らないのか</b> — 間違えた1件が合うまでカードを直し続けると、
      その1件専用の説明になりやすく(<b>過学習</b>)、しかも他の決裁を壊しても気づけません。
      直ったかどうかは結局<b>全件で再テスト</b>しないと分からないので、機械学習では
      「全件を1周=1エポック」として<b>テスト→学習→テスト</b>を繰り返し、
      正答率が目標に達したら・改善が止まったら早めに止めるのが標準です(このページはその方式です)</li>
    <li><b>検証用の取り分け(ホールドアウト・任意)</b> — 同じ決裁で測った正答率は
      「教えたから当たる」数字も含みます。決裁の一部(推奨20%)を<b>教えない側</b>に取り分けると、
      「初見でも当たるか」を別に測れます</li>
    <li><b>自動でできる範囲</b> — 自動で更新するのは事例カードだけです。アプリのプロンプト
      (カードの作り方)や環境変数はAPIから書き換えられないため、カードで直りきらない誤答は
      「どの環境変数に何を追記するか」の提案としてレポートに出します</li>
  </ul>
</div>

<div class="card">
  <h2>2. 事前準備(③と④を先に)</h2>
  <ol>
    <li>③で<b>「自己学習」にチェック</b>を入れて判定アプリ(1形式でよい)を作り、Difyにインポートする
      (既定の「環境変数に貼る」方式なら<b>ナレッジもナレッジAPIキーも不要</b>で、インポートしてそのまま公開できます)</li>
    <li>アプリの「APIアクセス」で<b>APIキー(app-…)</b>を発行する</li>
    <li>まず④の「ブラウザで採点」で接続と読み取りが通ることを確認しておくとスムーズです</li>
  </ol>
  <div class="note"><b>③で「Difyの事例ナレッジ」を選んで作ったアプリの場合</b>: Difyで<b>事例ナレッジ</b>(空のナレッジ)を作り、
    アプリの<b>類似事例の検索ノードに紐付け</b>、環境変数 <code>dify_base_url</code>(…/v1)・<code>dataset_api_key</code>(dataset-…)・
    <code>case_dataset_id</code>(ナレッジのID)を設定します(手順は③の解説どおり。<b>空のナレッジの作り方〜IDとキーの取り方は③の「動画で見る」カード</b>で通しで確認できます。
    ③の「設定込みでDSLを作る」欄に入れて生成したアプリなら設定済みです)。
    このページには、Difyの<b>ナレッジAPIキー(dataset-…)</b>(「サービスAPI」→「APIキー」で発行。場所は版で違い、1.12以降はナレッジ一覧の右上、1.9〜1.11はナレッジを開いた左メニューの一番下、1.8以前は一覧左上の「API ACCESS」タブ)と<b>事例ナレッジのID</b>
    (ナレッジを開いたときのURLの <code>/datasets/</code> のあとの英数字)を入れます(カードの削除=差し替えと、保存の確認に使います)。
    ナレッジAPIキーが作れない(オーナー/管理者でない)場合は空欄のままで<b>仮ナレッジモード</b>になり、終了後に「判定事例.txt を保存」して
    ナレッジの画面から手でアップロードします(アップロードは編集者の権限でできます)。</div>
</div>

<div class="card" id="dvCard">
  <h2>3. 動画で見る(自動学習の流れ / 仕組みの解説)</h2>
  <p class="lead" style="margin:0 0 8px">
    ボタンを押すと、この場でこのページとDifyを模したアニメーションが流れます(音声なし)。
    「自動学習の流れ」は操作と同時に<b>裏側でDifyに何をしているか</b>(判定アプリへの自動返信・事例ナレッジのカード・差し替え)も交互に見せます(約2分)。
    「仕組みの解説」は、なぜ1周ずつ回すのか・検証用の取り分け・止める条件を図で説明します(約1分)。
    右のステップ一覧を押すと途中へ飛べます。動画ファイルの読み込みや通信はありません。
    ※ 画面は説明用のイメージです(実際のDifyの画面とは配色・配置が異なります)。
  </p>
  <div class="btns" style="margin:0 0 8px">
    <button class="primary" id="dvPick2">▶ 仕組みの解説(なぜ1周ずつ回すのか)</button>
    <button class="primary" id="dvPick1">▶ 自動学習の流れ(操作と裏側)</button>
  </div>
  <div class="dv-bar">
    <button id="dvPlay">▶ 再生</button>
    <button id="dvPrev">◀ 前へ</button>
    <button id="dvNext">次へ ▶</button>
    <button id="dvRestart">最初から</button>
    <label style="font-size:12px">速さ <select id="dvSpeed" style="border:1px solid var(--line);border-radius:6px;padding:3px 6px;font-family:inherit"><option value="0.7">ゆっくり</option><option value="1" selected>ふつう</option><option value="1.6">速く</option></select></label>
    <div class="dv-prog"><div id="dvBar"></div></div>
    <span id="dvCount" class="note" style="margin:0"></span>
    <b id="dvScriptName" style="font-size:12px"></b>
  </div>
  <div class="dv-wrap">
    <div class="dv-browser" id="dvBrowser">
      <div class="dv-chrome"><span class="dv-dot"></span><span class="dv-dot"></span><span class="dv-dot"></span><div class="dv-url" id="dvUrl">&nbsp;</div></div>
      <div class="dv-screen" id="dvScreen"><div class="dv-idle">上の2つのボタンから選ぶと始まります。</div></div>
      <div id="dvCursor" hidden><svg viewBox="0 0 24 24" width="22" height="22"><path d="M5 3l14 9-6 1.5L16 20l-3 1.3-3-6.5L5 19z" fill="#fff" stroke="#1b1d20" stroke-width="1.5" stroke-linejoin="round"/></svg></div>
      <div id="dvRipple"></div>
    </div>
    <ol class="dv-steps" id="dvSteps"></ol>
  </div>
  <div class="dv-cap" id="dvCap"><b id="dvCapT"></b><span id="dvCapB"></span></div>
</div>

<div class="card">
  <h2>4. 接続設定</h2>
  <div style="display:grid;grid-template-columns:auto 1fr;gap:6px 10px;align-items:center;font-size:13px;max-width:680px">
    <span>APIサーバー(…/v1)</span><input id="lnUrl" type="text" placeholder="https://dify.example.com/v1">
    <span></span><span style="font-size:11px;color:#666;line-height:1.4">アプリを開いて左メニュー「APIアクセス」の上に出る<b>「API サーバー」のURL</b>(ナレッジ一覧の「サービスAPI」カードの「サービスAPIエンドポイント」と同じ値)。ブラウザのアドレス欄のURL(…/app/…/workflow や …/datasets/…)ではありません。クラウド版は https://api.dify.ai/v1、自社サーバー版はふつう「いつも開いているDifyのアドレス + /v1」です。</span>
    <span>アプリの形式</span><span>
      <label><input type="radio" name="lnFmt" value="pick" checked> コード一発選択形式(推奨)</label>
      <label style="margin-left:10px"><input type="radio" name="lnFmt" value="tree"> ツリー判定形式</label>
      <label style="margin-left:10px"><input type="radio" name="lnFmt" value="flat"> コード2段選択形式</label>
    </span>
    <span>判定アプリのキー</span><input id="lnKey" type="text" placeholder="app-…(③で自己学習にチェックを入れたアプリ)">
    <span>ナレッジAPIキー</span><input id="lnDsKey" type="text" placeholder="dataset-…(③の既定=環境変数方式のアプリは空欄のまま。空欄なら仮ナレッジモード)">
    <span></span><span style="font-size:11px;color:#666;line-height:1.4"><b>③の既定(環境変数 learned_cases 方式)のアプリは空欄のまま</b>(仮ナレッジモード: アプリが返すカードをこのブラウザに溜め、判定時に参考事例として添え、最後に判定事例.txt にまとめて環境変数 learned_cases に貼ります)。 「Difyの事例ナレッジ」方式のアプリだけ、ナレッジAPIキーを入れます(作れない場合は空欄でもOK)。 場所はDifyの版で違います: <b>1.12以降</b>はナレッジ一覧の右上「サービスAPI」、<b>1.9〜1.11</b>はナレッジを開いた左メニューの一番下「サービスAPI」、<b>1.8以前</b>はナレッジ一覧の左上のタブ「API ACCESS」(「ナレッジ」の隣)。どれも見当たらなければ権限(ナレッジ管理者ロール)が原因なので、オーナー/管理者に発行を頼んでください。「新しいシークレットキーを作成」を押して「You don't have the permission to access the requested resource…」と出るのも同じ権限不足です(キーの作成はオーナー/管理者のみ。一覧を見るだけなら誰でも可)。版は右上のアカウントメニューの「About」で確認できます。 キーを作るとき範囲(スコープ)を聞かれたら<b>「特定のナレッジベース」で事例ナレッジだけ</b>を選ぶのがおすすめです(このページが触るのはそのナレッジだけ。社内の他のナレッジには届かないキーになります)。古い版のDifyは範囲が選べず、キー1本で全ナレッジの読み書き・削除ができるので、キーの保管に注意してください。</span>
    <span>事例ナレッジのID</span><input id="lnDsId" type="text" placeholder="URLの /datasets/ のあとの英数字">
  </div>
  <div class="btns" style="margin-top:8px">
    <button id="lnTest">接続テスト</button>
    <label style="font-size:12px;align-self:center"><input type="checkbox" id="lnSaveCfg"> URLとキーをこのブラウザに保存する</label>
  </div>
  <div id="lnTestOut" class="note"></div>
  <div class="note">APIキーがまだ無くても、URLだけ入れて「接続テスト」を押すと、
    CORSに引っかかるか(このページから自社Difyへ通信が届くか)の事前チェックだけできます。</div>
</div>

<div class="card">
  <h2>5. 決裁フォルダを入れる</h2>
  <div id="lnDrop" style="border:2px dashed #b6bdc6;border-radius:8px;padding:18px;text-align:center;cursor:pointer;background:#fbfcfe">
    <b>ここに「元データ」フォルダをドラッグ&amp;ドロップ</b><br>
    <span style="font-size:12px;color:#5b6169">またはクリックしてフォルダを選択。④と同じ構成
    (サブフォルダ=1決裁、中に決裁書類(複数可)+正解.txt)。ファイルはまだどこにも送られません(実行を押すまで)</span>
    <input type="file" id="lnDir" webkitdirectory multiple style="display:none">
  </div>
  <div id="lnSummary" class="note"></div>
</div>

<div class="card">
  <h2>6. 学習を実行</h2>
  <div style="font-size:13px">
    目標の正答率 <input id="lnTarget" type="number" min="1" max="100" value="100" style="width:56px"> % /
    最大 <input id="lnMaxEp" type="number" min="1" max="20" value="5" style="width:52px"> エポック /
    <input id="lnPatience" type="number" min="0" max="5" value="1" style="width:44px"> エポック改善なしで早期終了(0=使わない)
    <br>
    検証用の取り分け <input id="lnHoldout" type="number" min="0" max="50" value="0" style="width:52px"> %(推奨20。0=検証なし) /
    先頭から <input id="lnLimit" type="number" min="0" value="0" style="width:64px"> 決裁だけ(0=全件) /
    並列 <input id="lnPar" type="number" min="1" max="6" value="3" style="width:48px"> /
    タイムアウト <input id="lnTimeout" type="number" min="30" value="300" style="width:64px"> 秒
  </div>
  <div class="btns" style="margin-top:8px">
    <button class="primary" id="lnRun" disabled>学習を開始</button>
    <button id="lnStop" disabled>停止</button>
    <button id="lnDlMd" disabled>自動学習レポート.md を保存</button>
    <button id="lnDlCards" disabled>判定事例.txt を保存(仮ナレッジ)</button>
    <button id="lnClearCards" disabled>台帳・仮ナレッジを空にする</button>
  </div>
  <div id="lnProg" class="note"></div>
  <h3>学習曲線(エポックごとの正答率)</h3>
  <div id="lnCurve"></div>
  <h3>最新エポックの明細</h3>
  <div id="lnTableWrap" style="max-height:320px;overflow:auto"></div>
  <div id="lnLedger" style="margin-top:10px"></div>
  <pre id="lnReport" style="display:none;max-height:420px;margin-top:8px"></pre>
</div>

<div class="card">
  <h2>7. 注意(正直な断り書き)</h2>
  <ul>
    <li>時間の目安: 1決裁×1エポックでAPI呼び出し3回、誤答1件の学習でさらに3〜4回。
      <b>まず「先頭から2〜3決裁だけ」+最大2エポック</b>で試すのがおすすめです
      (100決裁×5エポックは数時間かかります)。実行中はタブを閉じない・PCをスリープさせないでください
      (「停止」→「再開」で続きから回せます。ページを再読み込みするとやり直しです)</li>
    <li>同じ決裁で測った学習正答率は「教えた後」の数字です。<b>初見の実力は検証用の取り分け(ホールドアウト)</b>で見てください</li>
    <li>カードの差し替えに使うナレッジのカード一覧・削除API(<code>GET/DELETE /datasets/…/documents</code>)は、
      この開発環境では実際のDifyに対して検証できていません。<b>エラーが出たらその文言のまま</b>教えてください
      (一覧/削除ができない場合も学習自体は続き、古いカードが残った旨をレポートに出します)</li>
    <li>学習の効果はLLMの挙動に依存します(保証ではありません)。上がらないときはレポートの
      「次の一手」(環境変数への追記)を試してください</li>
    <li><b>仮ナレッジモード</b>(ナレッジAPIキー空欄)の参考事例は、読み取り内容とカードの<b>文字の重なり</b>で選ぶ最大4枚です。
      ③の既定(環境変数 <code>learned_cases</code> 方式)のアプリも同じ選び方なので、<code>判定事例.txt</code> を貼れば本番でもほぼ同じ結果になります。
      Difyのナレッジ検索(意味の近さ)より粗いので、ナレッジ方式のアプリは <code>判定事例.txt</code> をナレッジにアップロードして本番の検索で測り直してください。
      仮ナレッジはこのブラウザに保存され、別のPC・ブラウザには引き継がれません</li>
    <li>カードの差し替えに使う台帳(決裁→カードID)は<b>このブラウザに保存</b>されます(ナレッジIDごと)。
      ページを再読み込みしても前回のカードを差し替えられますが、別のPC・ブラウザで続きを回すと
      前回のカードを見つけられず古いカードが残ります(その場合はナレッジの画面で手で削除してください)</li>
  </ul>
</div>
</div>

<script>
"use strict";
function $(id){ return document.getElementById(id); }
function esc(s){
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function save(text, name){
  var a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([text], {type: "application/octet-stream"}));
  a.download = name;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}
__COMMON_JS__
__LEARN_RUNNER_JS__
__DEMO_PLAYER_JS__
__LEARN_DEMO_JS__
</script>
'''


def read_js(name):
    """ページに埋め込むJSファイルを読む(そのままscriptブロックへ入るので中身を点検)。"""
    text = io.open(os.path.join(ROOT, 'tools', name), encoding='utf-8').read()
    assert '</script' not in text.lower(), name + ' に </script> は書けない'
    for tok in ('__COMMON_JS__', '__EVAL_RUNNER_JS__', '__LEARN_RUNNER_JS__',
                '__DEMO_PLAYER_CSS__', '__DEMO_PLAYER_JS__', '__LEARN_DEMO_JS__'):
        assert tok not in text, name + ' にトークン ' + tok + ' を含めない'
    return text.rstrip('\n')


def main():
    page = (PAGE.replace('__COMMON_JS__', read_js('eval_common.js'))
                .replace('__LEARN_RUNNER_JS__', read_js('learn_page_runner.js'))
                .replace('__DEMO_PLAYER_CSS__', read_js('demo_player.css'))
                .replace('__DEMO_PLAYER_JS__', read_js('demo_player.js'))
                .replace('__LEARN_DEMO_JS__', read_js('learn_demo_scripts.js')))
    assert '__' + 'COMMON_JS__' not in page and '__' + 'LEARN_RUNNER_JS__' not in page and '__' + 'LEARN_DEMO_JS__' not in page
    io.open(OUT, 'w', encoding='utf-8').write(page)
    sys.stderr.write('written %s (%d KB)\n' % (os.path.basename(OUT), len(page.encode('utf-8')) // 1024))


if __name__ == '__main__':
    main()
