// ============================================================ ④の台本(3本): 準備 / ブラウザで採点 / Dify版採点アプリ
// 共通エンジン(demo_player.js)の上で動く。build_eval_page.py がビルド時にトークン置換で埋め込む。
var EV_TOOL = "https://okadamasayuki.github.io/kanjo-tool/";
var EV_APPS = [{name: "契約書 相手勘定判定(一発選択)"}, {name: "契約書 相手勘定判定(ツリー)"}, {name: "契約書 相手勘定判定(2段選択)"}];
var EV_KEYS = {tree: "app-7Hq2mZ9kL4pX1rT8", flat: "app-Vc3nB6yW0sK9dJ5m", pick: "app-Q8fR2tY7uE1oP4aL"};

// ③(まとめ版)で3形式のDSLを作る画面
function scrTool3Gen(st){
  st = st || {};
  var r = function(k, label){ return '<label style="margin-right:10px">' + (st.fmt === k ? "●" : "○") + " " + label + "</label>"; };
  var h = '<div style="padding:14px 16px;background:#f6f7f9;height:100%;overflow:hidden">'
    + '<div class="dvy-h">③ ツリーからDify(まとめ版)</div>'
    + '<div style="background:#fff;border:1px solid var(--line);border-radius:10px;padding:10px;font-size:12px">'
    + '<div style="color:#666;margin-bottom:4px">分類ツリー(貼り付け済み)</div>'
    + '<div class="dvy-input" style="height:54px;overflow:hidden;color:#555">区分判定(1段目)\n    資産\n        流動資産\n            短期貸付金 [1010005]…</div>'
    + '<div style="margin-top:8px"><b>アプリの形式(1つ選ぶ)</b><br>' + r("pick", "コード一発選択形式(推奨)") + r("tree", "ツリー判定形式") + r("flat", "コード2段選択形式") + '</div>'
    + '<div style="margin-top:8px"><span class="dvy-btn" id="dv-run">DSLを作る</span></div></div>';
  if(st.done) h += '<div style="background:#fff;border:1px solid var(--line);border-radius:10px;padding:10px;font-size:12px;margin-top:8px"><b>2. 結果</b>'
    + '<div style="color:#0f6b3f">✅ ' + esc(st.done) + '</div>'
    + '<div style="margin-top:6px"><span class="dvy-btn ghost" id="dv-save">DSL(YAML)を保存</span> <span style="color:#666">→ ' + esc(st.file || "") + '</span></div></div>';
  return h + '</div>';
}
// ④カード2「ブラウザで採点」の画面
function scrEvalBrowser(st){
  st = st || {};
  var k = st.keys || {};
  var h = '<div style="padding:12px 16px;background:#f6f7f9;height:100%;overflow:hidden;font-size:12px">'
    + '<div class="dvy-h" style="margin-bottom:6px">④ 判定の採点 — 2. ブラウザで採点(フォルダを入れて実行)</div>'
    + '<div style="background:#fff;border:1px solid var(--line);border-radius:10px;padding:10px">'
    + '<div style="display:grid;grid-template-columns:120px 1fr;gap:3px 8px;align-items:center;max-width:520px">'
    + '<span>APIサーバー(…/v1)</span>' + dvInput("dv-b-url", st.url, "https://dify.example.com/v1", "min-height:24px")
    + '<span>ツリー判定のキー</span>' + dvInput("dv-b-k1", k.tree, "app-…(空なら採点しない)", "min-height:24px")
    + '<span>2段選択のキー</span>' + dvInput("dv-b-k2", k.flat, "app-…(空なら採点しない)", "min-height:24px")
    + '<span>一発選択のキー</span>' + dvInput("dv-b-k3", k.pick, "app-…(空なら採点しない)", "min-height:24px") + '</div>'
    + '<div style="margin-top:6px"><span class="dvy-btn ghost" id="dv-b-test">接続テスト</span> <span style="color:#666">☐ URLとキーをこのブラウザに保存する</span></div>'
    + (st.test ? '<div id="dv-b-testout" style="color:#0f6b3f;margin-top:4px">' + st.test + '</div>' : "")
    + '<div id="dv-b-drop" style="border:2px dashed #b6bdc6;border-radius:8px;padding:10px;text-align:center;margin-top:8px;background:#fbfcfe">'
    + '<b>ここに「元データ」フォルダをドラッグ&amp;ドロップ</b><br><span style="font-size:11px;color:#666">またはクリックしてフォルダを選択。サブフォルダ=1決裁</span></div>'
    + (st.summary ? '<div id="dv-b-summary" style="margin-top:6px">' + st.summary + '</div>' : "")
    + (st.opts ? '<div id="dv-b-opts" style="margin-top:6px">並列 <span class="dvy-chip">3</span> / 先頭から <span class="dvy-chip" id="dv-b-limit">' + esc(st.limit || "0") + '</span> 決裁だけ(0=全件) / タイムアウト <span class="dvy-chip">300</span> 秒</div>' : "")
    + '<div style="margin-top:8px"><span class="dvy-btn" id="dv-b-run">' + (st.runLabel || "採点を実行") + '</span> <span class="dvy-btn ghost">停止</span> <span class="dvy-btn ghost" id="dv-b-dl">採点結果.md を保存</span></div>'
    + (st.prog ? '<div id="dv-b-prog" style="color:#666;margin-top:6px">' + st.prog + '</div>' : "")
    + '</div>';
  if(st.rows){
    h += '<table class="dvy-table" style="margin-top:8px" id="dv-b-table"><tr><th>決裁</th><th>正解</th><th>ツリー判定形式</th><th>コード2段選択形式</th><th>コード一発選択形式</th></tr>'
      + st.rows.map(function(r){ return '<tr><td>' + r[0] + '</td><td>' + r[1] + '</td><td style="text-align:center">' + r[2] + '</td><td style="text-align:center">' + r[3] + '</td><td style="text-align:center">' + r[4] + '</td></tr>'; }).join("")
      + '</table>';
  }
  if(st.report) h += '<pre id="dv-b-report" style="margin-top:8px;background:#f2f4f7;border:1px solid var(--line);border-radius:6px;padding:8px;font-size:11px;line-height:1.5;white-space:pre-wrap">' + st.report + '</pre>';
  return h + '</div>';
}
// Dify版採点アプリ: 環境変数 / 実行画面 / 進捗 / 結果
function scrEvalEnv(st){
  st = st || {};
  var row = function(id, name, val, ph){ return '<tr><td style="font-family:Consolas,monospace">' + name + '</td><td>' + dvInput(id, val, ph, "min-height:24px") + '</td></tr>'; };
  return dvNav("スタジオ") + '<div style="height:32px;background:#fff;border-bottom:1px solid var(--line);display:flex;align-items:center;padding:0 12px;font-size:12px"><b>判定の採点</b><span style="color:#888;margin-left:8px">アプリ設定 → 環境変数</span></div>'
    + '<div class="dvy-body" style="height:calc(100% - 76px)">' + dvAppSide("orch") + '<div class="dvy-main"><div class="dvy-h">環境変数</div>'
    + '<table class="dvy-table"><tr><th>名前</th><th>値</th></tr>'
    + row("dv-env-url", "base_url", st.url, "https://…/v1") + row("dv-env-tree", "api_key_tree", st.tree, "app-…")
    + row("dv-env-flat", "api_key_flat", st.flat, "app-…(空なら比較から外す)") + row("dv-env-pick", "api_key_pick", st.pick, "app-…") + '</table>'
    + '<div style="margin-top:10px"><span class="dvy-btn" id="dv-env-save">保存</span></div></div></div>';
}
function scrEvalRun(st){
  st = st || {};
  return dvNav("スタジオ") + '<div style="height:32px;background:#fff;border-bottom:1px solid var(--line);display:flex;align-items:center;padding:0 12px;font-size:12px"><b>判定の採点</b><span style="color:#888;margin-left:8px">実行</span></div>'
    + '<div style="display:flex;height:calc(100% - 76px)"><div style="width:52%;padding:12px;border-right:1px solid var(--line);background:#fff;font-size:12px">'
    + '<div style="color:#666">契約書・決裁文書(最大100件)</div><div id="dv-files" style="min-height:34px;border:1px dashed var(--line);border-radius:8px;padding:4px">'
    + (st.files || []).map(function(f){ return '<span class="dvy-chip" style="margin:2px">📄 ' + esc(f) + '</span>'; }).join("") + '</div>'
    + '<div style="color:#666;margin-top:8px">正解表(1行=1決裁。添付した順)</div>' + dvInput("dv-ans", st.ans, "預金 [1010003001]\n賃借料 [5030001001] ×3\n…", "min-height:64px")
    + '<div style="margin-top:8px"><span class="dvy-btn" id="dv-exec">実行</span></div></div>'
    + '<div style="flex:1;padding:12px;font-size:12px;overflow:hidden" id="dv-out">' + (st.out || '<div style="color:#888">結果はここに表示されます</div>') + '</div></div>';
}
var EV_PROG = ['案件001 … 一発選択 ○ / ツリー判定 ○ / 2段選択 ○', '案件002 … 一発選択 ○ / ツリー判定 × / 2段選択 ?', '案件003 … 一発選択 ○ / ツリー判定 ○ / 2段選択 ×'];
function evOutProg(n){ return '<div style="font-family:Consolas,monospace;line-height:1.9">' + EV_PROG.slice(0, n).join("<br>") + (n < 3 ? "<br>…" : "") + '</div>'; }
var EV_REPORT1 = '<b>📊 3形式の正答率(3決裁)</b><table class="dvy-table" style="margin:6px 0"><tr><th>形式</th><th>正答率</th></tr>'
  + '<tr><td>コード一発選択形式</td><td><b>100%</b>(3/3)</td></tr><tr><td>ツリー判定形式</td><td><b>67%</b>(2/3)</td></tr><tr><td>コード2段選択形式</td><td><b>67%</b>(2/3)</td></tr></table>'
  + '<b id="dv-winner">いちばん正答率が高い形式: コード一発選択形式(100%)</b>';
var EV_REPORT2 = '<b>📋 1決裁ごとの結果</b><table class="dvy-table" style="margin-top:6px"><tr><th>#</th><th>決裁</th><th>正解</th><th>一発</th><th>ツリー</th><th>2段</th></tr>'
  + '<tr><td>1</td><td>案件001</td><td>預金 [1010003001]</td><td>○</td><td>○</td><td>○</td></tr>'
  + '<tr><td>2</td><td>案件002</td><td>賃借料 [5030001001]</td><td>○</td><td>×</td><td>?</td></tr>'
  + '<tr><td>3</td><td>案件003</td><td>支払手数料 [5030002001]</td><td>○</td><td>○</td><td>×</td></tr></table>'
  + '<div style="color:#666;margin-top:4px">?=質問で停止 E=エラー</div>';
var EV_REPORT3 = '<b>🎓 どこに何を書けば次から正解になるか</b><div style="margin-top:6px">原因の推定: 賃貸借の相手勘定を借入金と取り違え(ツリー判定形式)</div>'
  + '<div style="margin-top:4px">→ <code>accounting_policy</code> に追記:</div>' + dvInput("dv-advice", "事務所・設備を借りて対価を払う契約は「賃借料」に分類する", "", "margin-top:4px")
  + '<div style="margin-top:4px">→ <code>rules_*</code>(賃借料の細分)の該当行にも同じ条件を追記</div>';

// ---- 台本1: 準備(3形式のアプリを作ってAPIキーを発行)
var EVAL_DEMO_PREP = {name: "準備(3形式のアプリを作ってAPIキーを発行)",
  idle: "上の「▶ 再生」で始まります。<br>③で3形式のDSLを作る → Difyにインポート → 各アプリの「APIアクセス」でキー(app-…)を発行、までを通しで見られます。",
  steps: [
  {title: "③で形式を選んで「DSLを作る」→ 保存(3形式ぶん)",
   body: "まとめ版の③で、ツリーを貼って形式を1つ選び「DSLを作る」→「DSL(YAML)を保存」。形式を切り替えて3回繰り返すと、3形式のDSLファイルがそろいます。",
   url: EV_TOOL, t: 6200,
   render: function(){ return scrTool3Gen({fmt: "pick"}); },
   act: function(){ dvCurTo("dv-run", 400); dvClick(1300);
     dvLater(function(){ $("dvScreen").innerHTML = scrTool3Gen({fmt: "pick", done: "コード一発選択形式で生成しました(20ノード)", file: "contract-account-classification-pick.yml"}); dvCurTo("dv-save", 200); dvClick(900); }, 1800); }},
  {title: "Difyのスタジオで「アプリを作成」→「DSLファイルをインポート」",
   body: "3つのDSLファイルを1つずつインポートします。", url: DV_HOST + "/apps", t: 4600,
   render: function(){ return scrStudio({menu: true}); },
   act: function(){ dvCurTo("dv-import", 400); dvClick(1400); }},
  {title: "ファイルを選んで「インポート」(3回)",
   body: "", url: DV_HOST + "/apps", t: 4200,
   render: function(){ return scrStudio({importFile: "contract-account-classification-pick.yml", importNote: "(③で保存したファイル。tree / flat も同様に)"}); },
   act: function(){ dvCurTo("dv-importbtn", 400); dvClick(1400); }},
  {title: "3形式のアプリができました",
   body: "アプリ名は「契約書 相手勘定判定(形式名)」です。次はそれぞれのAPIキーを発行します。", url: DV_HOST + "/apps", t: 4200,
   render: function(){ return scrStudio({apps: [{name: EV_APPS[0].name, hl: true}, {name: EV_APPS[1].name, hl: true}, {name: EV_APPS[2].name, hl: true}]}); },
   act: function(){ dvCurTo("dv-app0", 500); }},
  {title: "アプリを開いて「APIアクセス」。APIサーバーのURLを控える",
   body: "…/v1 で終わるこのURLが、④の「APIサーバー」欄(Dify版なら環境変数 base_url)に入れる値です。3つのアプリで共通です。",
   url: DV_HOST + "/app/2b7e4c9a/develop", t: 5600,
   render: function(){ return scrApiAccess({kind: "app", appName: EV_APPS[0].name}); },
   act: function(){ dvHl("dv-apiurl", 300); dvCurTo("dv-apiurl", 500); }},
  {title: "「APIキー」→「新しいシークレットキーを作成」",
   body: "アプリ画面の右上にあります。", url: DV_HOST + "/app/2b7e4c9a/develop", t: 4800,
   render: function(){ return scrApiAccess({kind: "app", appName: EV_APPS[0].name, modal: true}); },
   act: function(){ dvCurTo("dv-newkey", 400); dvClick(1500); }},
  {title: "app- で始まるキーをコピー(dataset- とは別物)",
   body: "これが「一発選択のキー」です。ほかの2つのアプリでも同じ手順でキーを作り、3つを控えます。キーは他人に見せないでください。",
   url: DV_HOST + "/app/2b7e4c9a/develop", t: 5800,
   render: function(){ return scrApiAccess({kind: "app", appName: EV_APPS[0].name, modal: true, key: EV_KEYS.pick}); },
   act: function(){ dvHl("dv-keytext", 300); dvCurTo("dv-keytext", 500); dvClick(1400); }},
  {title: "準備完了。次は「ブラウザで採点」へ",
   body: "URL(…/v1)とキー3つがそろいました。④のカード2に入れて採点します(Dify版の採点アプリを使う場合は、同じ値を環境変数に入れます)。",
   url: DV_HOST + "/apps", t: 5000,
   render: function(){ return scrStudio({apps: [{name: EV_APPS[0].name}, {name: EV_APPS[1].name}, {name: EV_APPS[2].name}]}) + '<div class="dvy-toast">✅ 3形式のアプリ + APIキー ×3 + APIサーバーURL がそろいました</div>'; },
   act: function(){ dvCur(50, 60); }}
]};

// ---- 台本2: ブラウザで採点のようす
var EV_ROWS_DONE = [["案件001", "預金 [1010003001]", "○", "○", "○"], ["案件002", "賃借料 [5030001001]", "×", "?", "○"]];
var EV_REPORT_MD = "# 契約書判定の採点結果(3形式比較・ブラウザ版)\n\n## 📊 正答率(2決裁)\n| 形式 | 正答率 | 正解 | 不正解 | 質問で停止 | エラー |\n|---|---|---|---|---|---|\n| ツリー判定形式 | **50%** (1/2) | 1 | 1 | 0 | 0 |\n| コード2段選択形式 | **50%** (1/2) | 1 | 0 | 1 | 0 |\n| コード一発選択形式 | **100%** (2/2) | 2 | 0 | 0 | 0 |\n\n**いちばん正答率が高い形式: コード一発選択形式(100%)**\n\n## 🎓 どこに何を書けば次から正解になるか\n- 形式: ツリー判定形式 / 決裁: 案件002 / 正解: 賃借料 [5030001001]\n  アプリの回答(抜粋): 相手勘定(科目) 借入金 …";
var EVAL_DEMO_BROWSER = {name: "ブラウザで採点のようす",
  idle: "上の「▶ 再生」で始まります。<br>④のカード2にURLとキーを入れる → 接続テスト → 決裁フォルダを入れる → 試走 → 結果、までを通しで見られます。",
  steps: [
  {title: "④のカード2に、APIサーバーのURL(…/v1)を入れる",
   body: "準備で控えたURLです。このページ(GitHub Pages)から自社Difyへ直接通信するので、インストールも権限申請も要りません。",
   url: EV_TOOL, t: 5200,
   render: function(){ return scrEvalBrowser({}); },
   act: function(){ dvCurTo("dv-b-url", 300); dvType("dv-b-url", DV_HOST + "/v1", 800, 28); }},
  {title: "3形式のキーを貼る(空の形式はスキップされる)",
   body: "2形式だけ比べたいときは、使わない形式を空のままにします。", url: EV_TOOL, t: 7000,
   render: function(){ return scrEvalBrowser({url: DV_HOST + "/v1"}); },
   act: function(){ dvCurTo("dv-b-k1", 300); dvType("dv-b-k1", EV_KEYS.tree, 700, 30);
     dvCurTo("dv-b-k2", 2200); dvType("dv-b-k2", EV_KEYS.flat, 2500, 30);
     dvCurTo("dv-b-k3", 4000); dvType("dv-b-k3", EV_KEYS.pick, 4300, 30); }},
  {title: "「接続テスト」→ 3形式とも ✅",
   body: "キーが無くてもURLだけで押せば、CORS(通信が届くか)の事前チェックだけできます。「通信できません」なら画面の切り分け手順に従ってください。",
   url: EV_TOOL, t: 5200,
   render: function(){ return scrEvalBrowser({url: DV_HOST + "/v1", keys: EV_KEYS}); },
   act: function(){ dvCurTo("dv-b-test", 300); dvClick(1100);
     dvLater(function(){ $("dvScreen").innerHTML = scrEvalBrowser({url: DV_HOST + "/v1", keys: EV_KEYS, test: "ツリー判定形式: ✅ 接続OK<br>コード2段選択形式: ✅ 接続OK<br>コード一発選択形式: ✅ 接続OK"}); dvCurTo("dv-b-testout", 100); }, 1800); }},
  {title: "「元データ」フォルダをドラッグ&ドロップ",
   body: "サブフォルダ=1決裁(中に決裁書類(複数可)+正解.txt。正解.txt が無い決裁は採点せず判定結果だけ表示)。この時点ではまだどこにも送られません。",
   url: EV_TOOL, t: 5600,
   render: function(){ return scrEvalBrowser({url: DV_HOST + "/v1", keys: EV_KEYS, test: "ツリー判定形式: ✅ / コード2段選択形式: ✅ / コード一発選択形式: ✅"}); },
   act: function(){ dvHl("dv-b-drop", 300); dvCur(20, 80); dvCurTo("dv-b-drop", 900); dvClick(1600);
     dvLater(function(){ $("dvScreen").innerHTML = scrEvalBrowser({url: DV_HOST + "/v1", keys: EV_KEYS, test: "ツリー判定形式: ✅ / コード2段選択形式: ✅ / コード一発選択形式: ✅",
       summary: "<b>12決裁</b>(文書 31ファイル: .docx 9 / .pdf 14 / .xlsx 8)を読み取りました。まだ送信していません。", opts: true, limit: "0"}); dvHl("dv-b-summary", 100); }, 2300); }},
  {title: "まず「先頭から 2 決裁だけ」で試走",
   body: "読み取りと回答の形を確認してから本番に進むのがおすすめです(Excel・PowerPointの読み取りはDify側の対応次第)。",
   url: EV_TOOL, t: 4800,
   render: function(){ return scrEvalBrowser({url: DV_HOST + "/v1", keys: EV_KEYS, test: "ツリー判定形式: ✅ / コード2段選択形式: ✅ / コード一発選択形式: ✅",
       summary: "<b>12決裁</b>(文書 31ファイル)を読み取りました。まだ送信していません。", opts: true, limit: "0"}); },
   act: function(){ dvCurTo("dv-b-limit", 300); dvClick(1000); dvLater(function(){ var el = $("dv-b-limit"); if(el){ el.textContent = "2"; el.classList.add("dv-hl"); } }, 1400); }},
  {title: "「採点を実行」→ 表に○×が埋まっていく",
   body: "1決裁×1形式でAPI呼び出し3回(アップロード → 添付 → 「OK」)。並列3で回ります。「停止」→「再開」で続きから回せます。",
   url: EV_TOOL, t: 6600,
   render: function(){ return scrEvalBrowser({url: DV_HOST + "/v1", keys: EV_KEYS, test: "✅ ✅ ✅", summary: "<b>12決裁</b>を読み取りました。", opts: true, limit: "2",
       prog: "実行中… 0 / 6 完了", rows: [["案件001", "預金 [1010003001]", "…", "", ""], ["案件002", "賃借料 [5030001001]", "", "", ""]]}); },
   act: function(){ dvCurTo("dv-b-run", 300); dvClick(1000);
     dvLater(function(){ $("dvScreen").innerHTML = scrEvalBrowser({url: DV_HOST + "/v1", keys: EV_KEYS, test: "✅ ✅ ✅", summary: "<b>12決裁</b>を読み取りました。", opts: true, limit: "2",
       prog: "実行中… 3 / 6 完了(経過 0分48秒)", rows: [["案件001", "預金 [1010003001]", "○", "○", "○"], ["案件002", "賃借料 [5030001001]", "…", "…", "…"]]}); }, 2600);
     dvLater(function(){ $("dvScreen").innerHTML = scrEvalBrowser({url: DV_HOST + "/v1", keys: EV_KEYS, test: "✅ ✅ ✅", summary: "<b>12決裁</b>を読み取りました。", opts: true, limit: "2",
       prog: "完了: 6 / 6(1分31秒)。下に採点結果を表示しました。", rows: EV_ROWS_DONE}); dvHl("dv-b-table", 100); }, 4600); }},
  {title: "結果: 3形式の正答率と、いちばん高い形式",
   body: "○=正解 ×=不正解 ?=質問で停止 E=エラー。誤答は「どの環境変数に何を追記すれば次から正解になるか」つきで一覧になります。",
   url: EV_TOOL, t: 6400,
   render: function(){ return scrEvalBrowser({url: DV_HOST + "/v1", keys: EV_KEYS, test: "✅ ✅ ✅", summary: "<b>12決裁</b>を読み取りました。", opts: true, limit: "2",
       prog: "完了: 6 / 6(1分31秒)。", rows: EV_ROWS_DONE, report: esc(EV_REPORT_MD)}); },
   act: function(){ dvLater(function(){ var el = $("dv-b-report"); if(el) el.scrollIntoView({block: "nearest"}); }, 200); dvHl("dv-b-report", 400); dvCurTo("dv-b-report", 500); }},
  {title: "「採点結果.md を保存」→ 全件に戻して本番へ",
   body: "先頭から の数を 0 に戻して全件を回します(100決裁×3形式は並列3で1〜2時間。タブを閉じない・PCをスリープさせない)。結果のmdは共有・保存用です。",
   url: EV_TOOL, t: 5600,
   render: function(){ return scrEvalBrowser({url: DV_HOST + "/v1", keys: EV_KEYS, test: "✅ ✅ ✅", summary: "<b>12決裁</b>を読み取りました。", opts: true, limit: "2",
       prog: "完了: 6 / 6(1分31秒)。", rows: EV_ROWS_DONE}); },
   act: function(){ dvCurTo("dv-b-dl", 300); dvClick(1100); dvCurTo("dv-b-limit", 2300); dvClick(3000);
     dvLater(function(){ var el = $("dv-b-limit"); if(el){ el.textContent = "0"; el.classList.add("dv-hl"); } }, 3400); }}
]};

// ---- 台本3: Dify版採点アプリのようす
var EVAL_DEMO_DIFY = {name: "Dify版採点アプリのようす",
  idle: "上の「▶ 再生」で始まります。<br>④の採点アプリ(DSL)をDifyにインポート → 環境変数 → 実行画面でファイル添付+正解表 → 結果、までを通しで見られます。",
  steps: [
  {title: "④の「採点アプリ(DSL)を保存」→ Difyでインポート",
   body: "ブラウザで採点が使えない環境(CORSが解除できない等)向けの方法です。Difyの中で採点が回ります。",
   url: DV_HOST + "/apps", t: 5000,
   render: function(){ return scrStudio({apps: EV_APPS, importFile: "contract-account-eval.yml", importNote: "(④で保存した採点アプリ)"}); },
   act: function(){ dvCurTo("dv-importbtn", 500); dvClick(1500); }},
  {title: "採点アプリの環境変数に、URLとキー3つを入れる",
   body: "base_url は APIサーバー(…/v1)。api_key_tree / api_key_flat / api_key_pick は3形式のキー。空にした形式はスキップ(2形式だけの比較も可)。",
   url: DV_HOST + "/app/e1a2b3c4/configuration", t: 7400,
   render: function(){ return scrEvalEnv({}); },
   act: function(){ dvCurTo("dv-env-url", 300); dvType("dv-env-url", DV_HOST + "/v1", 700, 26);
     dvCurTo("dv-env-tree", 2100); dvType("dv-env-tree", EV_KEYS.tree, 2400, 30);
     dvCurTo("dv-env-flat", 3700); dvType("dv-env-flat", EV_KEYS.flat, 4000, 30);
     dvCurTo("dv-env-pick", 5300); dvType("dv-env-pick", EV_KEYS.pick, 5600, 30); }},
  {title: "「保存」",
   body: "", url: DV_HOST + "/app/e1a2b3c4/configuration", t: 3200,
   render: function(){ return scrEvalEnv({url: DV_HOST + "/v1", tree: EV_KEYS.tree, flat: EV_KEYS.flat, pick: EV_KEYS.pick}); },
   act: function(){ dvCurTo("dv-env-save", 300); dvClick(1000); }},
  {title: "実行画面: 決裁文書を添付し、正解表を貼る",
   body: "1行=1決裁で、添付した順に「科目名 [10桁コード]」。1決裁が複数ファイルなら行末に「×ファイル数」(例: 賃借料 [5030001001] ×3)。",
   url: DV_HOST + "/app/e1a2b3c4/run", t: 7000,
   render: function(){ return scrEvalRun({files: ["契約書01.pdf", "契約書02.pdf", "見積書02.xlsx", "議事録02.docx", "契約書03.pdf"]}); },
   act: function(){ dvHl("dv-files", 300); dvCurTo("dv-ans", 1200); dvType("dv-ans", "預金 [1010003001]\n賃借料 [5030001001] ×3\n支払手数料 [5030002001]", 1600, 45); }},
  {title: "「実行」→ 1件ずつ3形式を呼んで採点",
   body: "決裁ごとに3形式のアプリをAPIで呼びます(件数×形式ぶんの時間がかかります)。", url: DV_HOST + "/app/e1a2b3c4/run", t: 6600,
   render: function(){ return scrEvalRun({files: ["契約書01.pdf", "契約書02.pdf", "見積書02.xlsx", "議事録02.docx", "契約書03.pdf"], ans: "預金 [1010003001]\n賃借料 [5030001001] ×3\n支払手数料 [5030002001]"}); },
   act: function(){ dvCurTo("dv-exec", 300); dvClick(1000);
     dvPatch("dv-out", evOutProg(1), 1600); dvPatch("dv-out", evOutProg(2), 3000); dvPatch("dv-out", evOutProg(3), 4400); }},
  {title: "結果: 正答率の比較表と、いちばん高い形式",
   body: "", url: DV_HOST + "/app/e1a2b3c4/run", t: 5200,
   render: function(){ return scrEvalRun({files: ["契約書01.pdf", "契約書02.pdf", "見積書02.xlsx", "議事録02.docx", "契約書03.pdf"], ans: "預金 [1010003001]\n賃借料 [5030001001] ×3\n支払手数料 [5030002001]", out: EV_REPORT1}); },
   act: function(){ dvHl("dv-winner", 600); dvCurTo("dv-winner", 500); }},
  {title: "1決裁ごとの○×明細",
   body: "?=質問で停止、E=エラー。「質問: 」で止まった回は不正解扱いで集計されます。", url: DV_HOST + "/app/e1a2b3c4/run", t: 5000,
   render: function(){ return scrEvalRun({files: ["契約書01.pdf", "契約書02.pdf", "見積書02.xlsx", "議事録02.docx", "契約書03.pdf"], ans: "預金 [1010003001]\n賃借料 [5030001001] ×3\n支払手数料 [5030002001]", out: EV_REPORT2}); },
   act: function(){ dvCur(72, 50); }},
  {title: "学習アドバイス: どの環境変数に何を追記するか",
   body: "誤答から、コピペできる追記文が出ます。判定アプリの「アプリ設定 → 環境変数」に追記して、もう一度採点 → 正答率が上がったか確認します。",
   url: DV_HOST + "/app/e1a2b3c4/run", t: 6400,
   render: function(){ return scrEvalRun({files: ["契約書01.pdf", "契約書02.pdf", "見積書02.xlsx", "議事録02.docx", "契約書03.pdf"], ans: "預金 [1010003001]\n賃借料 [5030001001] ×3\n支払手数料 [5030002001]", out: EV_REPORT3}); },
   act: function(){ dvHl("dv-advice", 700); dvCurTo("dv-advice", 500); }}
]};

// ---- 台本の切り替えボタン
(function evalDemoInit(){
  var pick = function(id, sc){
    if(!$(id)) return;
    $(id).onclick = function(){
      dvSetup(sc.steps, sc);
      $("dvCard").scrollIntoView({behavior: "smooth", block: "start"});
      dvPlayFrom(0);
    };
  };
  pick("dvPick1", EVAL_DEMO_PREP);
  pick("dvPick2", EVAL_DEMO_BROWSER);
  pick("dvPick3", EVAL_DEMO_DIFY);
  dvSetup(EVAL_DEMO_PREP.steps, {name: "", idle: "上の3つのボタンから見たい場面を選ぶと始まります。<br>準備(アプリ作成とキー発行)→ ブラウザで採点 → (必要なら)Dify版採点アプリ の順がおすすめです。",
                                 capT: "見たい場面のボタンを押してください", capB: "右のステップ一覧から途中へ飛ぶこともできます。"});
})();
