#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""④「判定の採点」ページを組み立てる。

  python3 tools/build_eval_page.py   → 判定の採点.html

採点アプリ(contract-account-eval.yml)のダウンロード・使い方・解説・
オーケストレーション図を1ページにまとめたもの。DSLとスクリプト本体を
ページに埋め込むので、GitHub Pages からそのまま保存できる。
「ブラウザで採点」のJSは tools/eval_common.js(⑤と共通のコア)と
tools/eval_page_runner.js(このページ固有のUI)にあり、ビルド時に
トークン置換でそのまま埋め込む(エスケープ加工をしないので、JSは.jsファイルを直す)。
DSLやスクリプト・JSを直したら、これを実行し直してから build_bundle.py を実行する。
"""
import io
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import miniyaml  # noqa: E402

OUT = os.path.join(ROOT, '判定の採点.html')


def js(obj):
    """JSソースに埋め込める文字列リテラル(</script> 対策込み)。"""
    return (json.dumps(obj, ensure_ascii=False)
            .replace('</', '<\\/')
            .replace('\u2028', '\\u2028')
            .replace('\u2029', '\\u2029'))


def graph_data(d):
    """DSLから描画用の最小グラフ(ノード・エッジ)を取り出す。"""
    g = d['workflow']['graph']
    nodes = []
    for n in g['nodes']:
        nodes.append({
            'id': n['id'],
            'title': n['data'].get('title', ''),
            'type': n['data']['type'],
            'x': n['position']['x'], 'y': n['position']['y'],
            'w': n.get('width', 244), 'h': n.get('height', 98),
            'parent': n.get('parentId'),
        })
    edges = [{'s': e['source'], 't': e['target']} for e in g['edges']]
    return {'nodes': nodes, 'edges': edges}


PAGE = '''<!doctype html>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>判定の採点(3形式の正答率くらべ)</title>
<style>
  :root{
    --bg:#f6f7f9; --fg:#1b1d20; --sub:#5b6169; --line:#d8dce1; --card:#ffffff;
    --accent:#2f6fed; --accent-fg:#ffffff; --code-bg:#f2f4f7;
    --ok:#1d7a4f; --ok-bg:#e8f6ee; --warn:#8a5a00; --warn-bg:#fff4dc;
  }
  *{box-sizing:border-box}
  body{margin:0;background:var(--bg);color:var(--fg);
       font-family:"Yu Gothic UI","Yu Gothic","Meiryo",system-ui,sans-serif;line-height:1.8}
  .wrap{max-width:1100px;margin:0 auto;padding:24px 16px 60px}
  h1{font-size:20px;margin:0 0 6px}
  h2{font-size:16px;margin:0 0 10px}
  h3{font-size:14px;margin:16px 0 6px}
  .lead{font-size:13px;color:var(--sub);margin:0 0 16px}
  .card{background:var(--card);border:1px solid var(--line);border-radius:10px;
        padding:16px;margin-bottom:16px}
  .btns{display:flex;gap:10px;flex-wrap:wrap;margin-top:10px}
  button{padding:9px 16px;border:1px solid var(--line);border-radius:6px;background:var(--card);
         color:var(--fg);font-family:inherit;font-size:13px;font-weight:600;cursor:pointer}
  button:hover{border-color:var(--accent)}
  button.primary{background:var(--accent);border-color:var(--accent);color:var(--accent-fg)}
  code{background:var(--code-bg);border:1px solid var(--line);border-radius:4px;
       padding:1px 5px;font-family:Consolas,monospace;font-size:12px}
  pre{background:var(--code-bg);border:1px solid var(--line);border-radius:6px;padding:12px;
      overflow:auto;font-family:"BIZ UDGothic","MS Gothic",Consolas,monospace;font-size:12px;line-height:1.7}
  .note{font-size:12px;color:var(--sub);margin-top:8px}
  ul{font-size:14px;margin:0;padding-left:20px}
  ol{font-size:14px;margin:0;padding-left:22px}
  #canvas{border:1px solid var(--line);border-radius:8px;background:#fbfcfe;overflow:auto;max-height:70vh}
  #canvas svg{display:block}
  #canvas g[data-nid]{cursor:pointer}
  li[id^="exp-"]{cursor:pointer}
  li[id^="exp-"]:hover{background:#eef3ff;border-radius:6px}
  .exp-hit{background:#fff3d6;border-radius:6px;transition:background .4s}
  .warnbox{background:var(--warn-bg);border:1px solid #ead9ad;color:var(--warn);
           border-radius:6px;padding:10px 12px;font-size:13px;margin-top:10px}
__DEMO_PLAYER_CSS__
</style>

<div class="wrap">
<h1>④ 採点 — 3形式の正答率くらべと自己学習</h1>
<p class="lead">
  テストデータ(契約書と、正解=キャッシュ(現金・預金)の相手勘定となる勘定科目)で、③で作った<b>3形式の判定アプリをまとめて採点</b>し、
  どの形式が自社の契約でいちばん当たるかを比較します。誤答からは
  <b>「どこに何を追記すれば次から正解に近づくか」(学習の書き込み先)</b>も出力します。
  判定アプリ側には一切手を入れません(外からAPIで呼ぶだけです)。
  <b>このページ自体は通信しません。例外は下の「2. ブラウザで採点」だけで、
  あなたが入力した自社DifyのURLにのみ通信します(それ以外の通信は行いません)。</b>
</p>

<div class="card">
  <h2>1. ダウンロード</h2>
  <ul>
    <li><b>採点アプリ(Dify用DSL)</b> — Difyに「アプリを作成 → DSLファイルをインポート」で取り込む採点用ワークフロー</li>
    <li><b>Snowflakeノートブック版</b> — <b>.py を実行できない環境向け</b>。Snowflakeのノートブックに
      インポートして実行する採点(手順のセル入り。<b>件数の上限なし・スキャンPDFも可・1決裁=複数ファイル可</b>)</li>
    <li><b>共有フォルダ版スクリプト</b> — PCでPython 3が使えるなら、共有フォルダに置いた決裁+正解をまとめて採点するコマンド版
      (標準ライブラリだけで動作。中身はノートブック版と同一ロジック)</li>
  </ul>
  <div class="btns">
    <button class="primary" id="dlYaml">採点アプリ(DSL)を保存</button>
    <button id="cpYaml">DSLをコピー</button>
    <button class="primary" id="dlNb">Snowflakeノートブック版を保存</button>
    <button id="dlPy">共有フォルダ版スクリプトを保存</button>
  </div>
  <div class="note">
    保存名: <code>contract-account-eval.yml</code> / <code>契約書判定の採点.ipynb</code> / <code>契約書判定の採点.py</code>。
    どれも、③で作った判定アプリ(3形式)のAPIキーを使います(手順は下)。
  </div>
</div>

<div class="card">
  <h2>2. ブラウザで採点(フォルダを入れて実行)</h2>
  <p class="lead" style="margin:0 0 8px">
    決裁フォルダ一式をこのページに入れると、<b>ブラウザから自社DifyのAPIを直接呼んで採点</b>します。
    インストール・権限申請は不要で、<b>このカードの通信先は下に入力した自社DifyのURLだけ</b>です
    (URLとキーはこのページに埋め込まれておらず、保存も任意でこのブラウザ内のみ)。
    フォルダ階層をそのまま読むので、ファイル数の指定(×N)は要りません。
  </p>
  <div style="display:grid;grid-template-columns:auto 1fr;gap:6px 10px;align-items:center;font-size:13px;max-width:640px">
    <span>APIサーバー(…/v1)</span><input id="brUrl" type="text" placeholder="https://dify.example.com/v1" style="border:1px solid var(--line);border-radius:6px;padding:6px 8px;font-family:Consolas,monospace">
    <span></span><span style="font-size:11px;color:#666;line-height:1.4">アプリを開いて左メニュー「APIアクセス」の上に出る<b>「API サーバー」のURL</b>(ナレッジ一覧の「サービスAPI」カードの「サービスAPIエンドポイント」と同じ値)。ブラウザのアドレス欄のURL(…/app/…/workflow や …/datasets/…)ではありません。クラウド版は https://api.dify.ai/v1、自社サーバー版はふつう「いつも開いているDifyのアドレス + /v1」です。</span>
    <span>ツリー判定のキー</span><input id="brKeyTree" type="text" placeholder="app-…(空なら採点しない)" style="border:1px solid var(--line);border-radius:6px;padding:6px 8px;font-family:Consolas,monospace">
    <span>2段選択のキー</span><input id="brKeyFlat" type="text" placeholder="app-…(空なら採点しない)" style="border:1px solid var(--line);border-radius:6px;padding:6px 8px;font-family:Consolas,monospace">
    <span>一発選択のキー</span><input id="brKeyPick" type="text" placeholder="app-…(空なら採点しない)" style="border:1px solid var(--line);border-radius:6px;padding:6px 8px;font-family:Consolas,monospace">
  </div>
  <div class="btns" style="margin-top:8px">
    <button id="brTest">接続テスト</button>
    <label style="font-size:12px;align-self:center"><input type="checkbox" id="brSaveCfg"> URLとキーをこのブラウザに保存する</label>
  </div>
  <div id="brTestOut" class="note"></div>
  <div id="brDrop" style="border:2px dashed #b6bdc6;border-radius:8px;padding:18px;text-align:center;margin-top:10px;cursor:pointer;background:#fbfcfe">
    <b>ここに「元データ」フォルダをドラッグ&amp;ドロップ</b><br>
    <span style="font-size:12px;color:#5b6169">またはクリックしてフォルダを選択。サブフォルダ=1決裁(中に決裁書類(複数可。下位フォルダの分も含む)+正解.txt。
    正解.txt(1行目に「科目名 [10桁コード]」かコードだけ)が無い決裁は採点せず、各形式の判定結果(科目とコード)だけ表示します。
    「文書+同名.正解.txt」のペア方式も可)。ファイルはまだどこにも送られません(実行を押すまで)</span>
    <input type="file" id="brDir" webkitdirectory multiple style="display:none">
  </div>
  <div id="brSummary" class="note"></div>
  <div id="brOpts" style="display:none;font-size:13px;margin-top:6px">
    並列 <input id="brPar" type="number" min="1" max="6" value="3" style="width:52px;border:1px solid var(--line);border-radius:6px;padding:4px"> /
    先頭から <input id="brLimit" type="number" min="0" value="0" style="width:64px;border:1px solid var(--line);border-radius:6px;padding:4px"> 決裁だけ(0=全件) /
    タイムアウト <input id="brTimeout" type="number" min="30" value="300" style="width:64px;border:1px solid var(--line);border-radius:6px;padding:4px"> 秒
    <div id="brExts" style="margin-top:4px"></div>
  </div>
  <div class="btns" style="margin-top:8px">
    <button class="primary" id="brRun" disabled>採点を実行</button>
    <button id="brStop" disabled>停止</button>
    <button id="brDlMd" disabled>採点結果.md を保存</button>
  </div>
  <div id="brProg" class="note"></div>
  <div id="brTableWrap" style="max-height:320px;overflow:auto"></div>
  <pre id="brReport" style="display:none;max-height:420px;margin-top:8px"></pre>
  <div class="note">
    目安: 1決裁×1形式でAPI呼び出し3回(アップロード+2ターン)。100決裁×3形式は並列3で1〜2時間程度です。
    実行中は<b>このタブを閉じない・PCをスリープさせない</b>でください(「停止」→「再開」で続きから回せます。ページを再読み込みするとやり直しです)。<br>
    ・まず「先頭から2〜3決裁だけ」で試すのがおすすめです<br>
    ・ExcelやPowerPointの本文をどこまで読めるかは<b>Dify側の対応次第</b>です(特定の拡張子でエラーが続く場合は、上のチェックで外して再実行)<br>
    ・APIキーがまだ手元に無くても、URLだけ入れて「接続テスト」を押せば<b>CORSに引っかかるかの事前チェック</b>だけできます<br>
    ・接続テストで「通信できません」が出る場合は、Dify管理者に <code>WEB_API_CORS_ALLOW_ORIGINS</code>(既定 <code>*</code>)の設定確認を依頼してください(具体的な切り分け手順はテスト結果に表示されます)
  </div>
</div>

<div class="card">
  <h2>3. 使い方(Dify版)</h2>
  <ol>
    <li>③で作った3形式の判定アプリをDifyにインポートし、各アプリの<b>「APIアクセス」画面でAPIキー(app-…)を発行</b>する</li>
    <li>上の<b>採点アプリ(DSL)をインポート</b>し、アプリ設定 → 環境変数に
      <code>base_url</code>(DifyのAPIエンドポイント。例 <code>https://…/v1</code>。「APIアクセス」画面に表示されるURL)と
      <code>api_key_tree</code> / <code>api_key_flat</code> / <code>api_key_pick</code> を設定する
      (<b>空にした形式はスキップ</b>されるので、2形式だけの比較もできます)</li>
    <li>実行画面で<b>契約書・決裁文書のファイル</b>(決裁ごとに続けて添付)を添付し、<b>正解表</b>
      (1行=1決裁。添付した順に「科目名」または「科目名 [10桁コード]」。科目=その決裁のキャッシュの相手勘定。
      <b>1決裁が複数ファイルなら行末に「×ファイル数」</b>(例: <code>賃借料 [5030001001] ×3</code>)で束ねる)を貼って実行する</li>
    <li>出力: <b>正答率の比較表 → いちばん正答率が高い形式 → 1件ごとの○×明細 →
      学習アドバイス(どの環境変数に何を追記するか、コピペできる形)</b></li>
  </ol>
  <div class="warnbox">
    ・文書は<b>本文テキストを抽出して</b>各アプリへ渡すため、スキャンPDF・画像だけの文書は採点対象外です
    (結果に「読」と表示。<b>共有フォルダ版スクリプトなら本番と同じファイル添付で呼ぶため採点できます</b>)<br>
    ・「質問: 」で止まった回は<b>不正解扱い</b>で集計します(内訳に別掲)<br>
    ・3形式とも回答は「キャッシュの相手勘定1科目+確定コード」の同じ形なので、<b>採点基準は同一</b>です
    (正解のコード、コードが無ければ科目名が回答に含まれるか)<br>
    ・ファイル上限はDSL上100件ですが、<b>Dify側の設定上限(既定10件など)が優先</b>されます。
    件数が多い場合・100決裁は<b>Snowflakeノートブック版/スクリプト版</b>で回してください(上限なし)
  </div>
  <h3>Snowflakeノートブック版の使い方(.py が実行できない環境向け)</h3>
  <ol>
    <li>上の「Snowflakeノートブック版を保存」で <code>契約書判定の採点.ipynb</code> を保存し、
      Snowsightの <b>Notebooks → Import .ipynb file</b> で取り込む</li>
    <li><b>管理者に External Access Integration(Difyホストへの外部アクセス許可)を依頼</b>し、
      ノートブックの設定でONにする(依頼するSQL文の例はノートブックの先頭セルにあります)</li>
    <li>決裁一式のフォルダ(下の構成)を<b>ZIPにしてSnowflakeステージにアップロード</b>する
      (Snowflakeは共有フォルダを直接読めないため)</li>
    <li>ノートブックの<b>設定セル</b>に base_url・APIキー・ステージのZIPパスを書いて、上から実行する</li>
  </ol>
  <pre>決裁一式/
  ├─ 案件001/ … 契約書.pdf・見積書.xlsx など<b>複数ファイル可</b> + 正解.txt   ← 1行目に「科目名 [10桁コード]」(コードだけでも可)
  └─ 案件002/ … 決裁文書.docx + 正解.txt
      (「文書.pdf + 文書.正解.txt」のペア方式でもOK)</pre>
  <div class="note">1フォルダ=1決裁で、中のファイルはまとめて1つのチャットに添付されます。
    実際の使い方と同じ2ターン(ファイル添付→「OK」)で呼ぶので、スキャンPDFのAI読み取りまで本番同等。
    結果は <code>採点結果.md</code> に保存されます(ステージにも保存)。</div>
  <h3>共有フォルダ版(スクリプト)の使い方(PCでPythonが使える場合)</h3>
  <pre>python3 契約書判定の採点.py 対象フォルダ --base-url https://&lt;Difyホスト&gt;/v1 ^
    --key tree=app-yyyy --key flat=app-zzzz --key pick=app-wwww</pre>
  <div class="note">フォルダ構成はノートブック版と同じ(ZIPやステージは不要で、共有フォルダを直接指定できます)。</div>
</div>

<div class="card" id="dvCard">
  <h2>4. 動画で見る(準備 / ブラウザで採点 / Dify版採点アプリ)</h2>
  <p class="lead" style="margin:0 0 8px">
    見たい場面のボタンを押すと、この場でDifyとこのページを模したアニメーションが流れます(音声なし・各1分前後)。
    右のステップ一覧を押すと途中へ飛べます。動画ファイルの読み込みや通信はありません。
    ※ 画面は説明用のイメージです(実際のDifyの画面とは配色・配置が異なり、メニュー名も版によって多少変わります)。
  </p>
  <div class="btns" style="margin:0 0 8px">
    <button class="primary" id="dvPick1">▶ 準備(3形式のアプリを作ってAPIキーを発行)</button>
    <button class="primary" id="dvPick2">▶ ブラウザで採点のようす</button>
    <button class="primary" id="dvPick3">▶ Dify版採点アプリのようす</button>
  </div>
  <div class="dv-bar">
    <button id="dvPlay">▶ 再生</button>
    <button id="dvPrev">◀ 前へ</button>
    <button id="dvNext">次へ ▶</button>
    <button id="dvRestart">最初から</button>
    <label style="font-size:12px">速さ <select id="dvSpeed" style="border:1px solid var(--line);border-radius:6px;padding:3px 6px;font-family:inherit"><option value="0.7">ゆっくり</option><option value="1" selected>ふつう</option><option value="1.6">速く</option></select></label>
    <div class="dv-prog"><div id="dvBar"></div></div>
    <span id="dvCount" class="note" style="margin:0"></span>
    <b id="dvScriptName" style="font-size:12px"></b>
  </div>
  <div class="dv-wrap">
    <div class="dv-browser" id="dvBrowser">
      <div class="dv-chrome"><span class="dv-dot"></span><span class="dv-dot"></span><span class="dv-dot"></span><div class="dv-url" id="dvUrl">&nbsp;</div></div>
      <div class="dv-screen" id="dvScreen"><div class="dv-idle">上の3つのボタンから見たい場面を選ぶと始まります。</div></div>
      <div id="dvCursor" hidden><svg viewBox="0 0 24 24" width="22" height="22"><path d="M5 3l14 9-6 1.5L16 20l-3 1.3-3-6.5L5 19z" fill="#fff" stroke="#1b1d20" stroke-width="1.5" stroke-linejoin="round"/></svg></div>
      <div id="dvRipple"></div>
    </div>
    <ol class="dv-steps" id="dvSteps"></ol>
  </div>
  <div class="dv-cap" id="dvCap"><b id="dvCapT"></b><span id="dvCapB"></span></div>
</div>

<div class="card" id="canvasCard">
  <h2>5. Difyでの見え方(オーケストレーション)</h2>
  <div class="btns" style="margin:0 0 10px">
    <button id="zoomOut">縮小</button>
    <button id="zoomIn">拡大</button>
    <button id="zoomFit">全体を表示</button>
  </div>
  <div id="canvas"></div>
  <div class="note">この図はDSLに書かれたノードの座標をそのまま描いたものです。Difyに取り込むと同じ配置で表示されます。
    <b>ノードをクリックすると下の解説の該当箇所へ移動します。逆に、解説の項目をクリックすると
    図の該当ノード(複数のことも)が色塗りでハイライトされ、図がその位置までスクロールします。</b></div>
</div>

<div class="card">
  <h2>6. 解説: 採点アプリの中身</h2>
  <ul>
    <li id="exp-start"><b>開始</b> — 契約書・決済文書(最大10件)と正解表を受け取ります</li>
    <li id="exp-doc"><b>本文テキスト抽出</b> — 各文書から本文を取り出します(AIは使いません。
      文字が取れないスキャンPDF・画像はここで採点対象外になります)</li>
    <li id="exp-pack"><b>文書と正解の突き合わせ</b>(プログラムが担当) — 添付した順に正解表と組にして、
      1決裁=1行のデータにまとめます(正解表の行末「×N」でNファイルを1決裁に束ねる。数が合わないときは警告)</li>
    <li id="exp-iter"><b>1件ずつ3形式で判定</b>(繰り返し) — 文書ごとに中の処理を繰り返します:
      <b>判定依頼を作る</b>(本文をチャットAPIのリクエストに変換)→
      <b>3形式を順に呼ぶ</b>(HTTPリクエスト×3。APIキーが空の形式はスキップ)→
      <b>採点</b>(回答に正解コード(無ければ科目名)が含まれるかを機械チェック。
      「質問: 」なら質問停止、HTTPエラーならエラーとして記録)</li>
    <li id="exp-agg"><b>集計</b>(プログラムが担当) — 形式ごとの正答率・内訳(正解/不正解/質問/エラー)、
      いちばん高い形式、1件ごとの○×明細、誤答一覧を作ります</li>
    <li id="exp-advice"><b>学習アドバイス生成</b>(AIが担当) — 誤答一覧から、
      <b>どの環境変数に・どの行を追記すれば</b>次から正解に近づくかを、コピペできる形で書き出します</li>
    <li id="exp-report"><b>レポート結合 → 終了</b> — 採点結果と学習アドバイスを1つのレポートにして出力します</li>
  </ul>
  <h3>学習の書き込み先(誤答が出たらここに追記)</h3>
  <ul>
    <li><b>どの形式にも効く</b>: <code>accounting_policy</code> に
      「◯◯のような契約(見分けられる条件)は「正解科目」に分類する」を1行。
      相手勘定の取り違え(敷金・手数料など付随の行を選んだ等)も、ここに「◯◯契約の主目的は◯◯」の形で書く</li>
    <li><b>ツリー判定形式</b>: 正解科目が属する細分の <code>rules_*</code> の行に見分け方を追記</li>
    <li><b>コード2段選択形式</b>: <code>codes10_list</code> の該当行の定義に追記(7桁違いは <code>codes7_list</code>)</li>
    <li><b>コード一発選択形式</b>: <code>codes_list</code> の正解科目の行の定義に追記</li>
    <li><b>正解科目がどの候補一覧にも無い</b>: 分類ツリーに科目を足して③で各形式を再生成</li>
  </ul>
  <div class="note">すべてDifyの「アプリ設定 → 環境変数」の編集だけで済みます(再インポート不要・即反映)。
    追記したらもう一度採点を実行して、正答率が上がったか確認してください(LLMの判定なので効果は保証ではありません)。
    誤答に正解を教えて回るところまで自動化したい場合は、まとめ版の<b>「⑤ 自動学習」タブ</b>
    (テスト→誤答だけ学習→再テストを繰り返すエポック学習ループ)が使えます。</div>
</div>
</div>

<script>
"use strict";
var DSL_YAML = __YAML__;
var SCRIPT_PY = __SCRIPT__;
var NOTEBOOK = __NOTEBOOK__;
var GRAPH = __GRAPH__;

function $(id){ return document.getElementById(id); }

function save(text, name){
  var a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([text], {type: "application/octet-stream"}));
  a.download = name;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}
$("dlYaml").onclick = function(){ save(DSL_YAML, "contract-account-eval.yml"); };
$("dlPy").onclick = function(){ save(SCRIPT_PY, "契約書判定の採点.py"); };
$("dlNb").onclick = function(){ save(NOTEBOOK, "契約書判定の採点.ipynb"); };
__COMMON_JS__
__EVAL_RUNNER_JS__
$("cpYaml").onclick = function(e){
  var btn = e.target, ta = document.createElement("textarea");
  ta.value = DSL_YAML;
  document.body.appendChild(ta);
  ta.select();
  try{ document.execCommand("copy"); }catch(err){}
  document.body.removeChild(ta);
  btn.textContent = "コピーしました";
  setTimeout(function(){ btn.textContent = "DSLをコピー"; }, 1400);
};

// ---- オーケストレーション図(座標はDSLのまま。イテレーションは枠として描く)
var TYPE_COLOR = {start: "#e8f6ee", "document-extractor": "#e6f4f9", code: "#eef1f6",
                  iteration: "#f6f2fb", "iteration-start": "#ffffff", "http-request": "#fff2e2",
                  llm: "#efe9fb", "template-transform": "#e9f7f1", end: "#f3f4f6"};
var EXP = {start: "exp-start", "doc-extract": "exp-doc", pack: "exp-pack",
           iter: "exp-iter", "iter-start": "exp-iter", req: "exp-iter",
           http_tree: "exp-iter", http_flat: "exp-iter", http_pick: "exp-iter",
           grade: "exp-iter", agg: "exp-agg", advice: "exp-advice",
           "report-all": "exp-report", end: "exp-report"};
var ZOOM = 0;

function absPos(n, byId){
  if(!n.parent) return {x: n.x, y: n.y};
  var p = byId[n.parent];
  return {x: p.x + n.x, y: p.y + n.y};
}

function esc(s){
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function drawCanvas(fit){
  var byId = {};
  GRAPH.nodes.forEach(function(n){ byId[n.id] = n; });
  var maxX = 0, maxY = 0;
  GRAPH.nodes.forEach(function(n){
    var p = absPos(n, byId);
    maxX = Math.max(maxX, p.x + n.w);
    maxY = Math.max(maxY, p.y + n.h);
  });
  var W = maxX + 60, H = maxY + 60;
  if(fit || !ZOOM) ZOOM = Math.min(1, ($("canvas").clientWidth - 20) / W);
  var parts = [];
  GRAPH.edges.forEach(function(e){
    var s = byId[e.s], t = byId[e.t];
    if(!s || !t) return;
    var sp = absPos(s, byId), tp = absPos(t, byId);
    var x1 = sp.x + s.w, y1 = sp.y + s.h / 2, x2 = tp.x, y2 = tp.y + t.h / 2;
    var mx = (x1 + x2) / 2;
    parts.push('<path d="M' + x1 + ' ' + y1 + ' C' + mx + ' ' + y1 + ' ' + mx + ' ' + y2 +
               ' ' + x2 + ' ' + y2 + '" fill="none" stroke="#9aa4b2" stroke-width="1.6"/>');
  });
  // イテレーションの枠を先に、他ノードを後に描く
  var ordered = GRAPH.nodes.slice().sort(function(a, b){
    return (a.type === "iteration" ? -1 : 0) - (b.type === "iteration" ? -1 : 0);
  });
  ordered.forEach(function(n){
    var p = absPos(n, byId);
    var fill = TYPE_COLOR[n.type] || "#ffffff";
    if(n.type === "iteration-start"){
      parts.push('<g data-nid="' + n.id + '"><circle cx="' + (p.x + 22) + '" cy="' + (p.y + 22) +
                 '" r="14" fill="#ffffff" stroke="#d0d5dd" stroke-width="1.5"/>' +
                 '<text x="' + (p.x + 22) + '" y="' + (p.y + 27) + '" text-anchor="middle" font-size="12">▶</text></g>');
      return;
    }
    var dash = n.type === "iteration" ? ' stroke-dasharray="6 4"' : '';
    parts.push('<g data-nid="' + n.id + '">' +
      '<rect x="' + p.x + '" y="' + p.y + '" width="' + n.w + '" height="' + n.h +
      '" rx="8" fill="' + fill + '" stroke="#d0d5dd" stroke-width="1.5"' + dash + '/>' +
      '<text x="' + (p.x + 12) + '" y="' + (p.y + 24) + '" font-size="13" font-weight="bold" fill="#1b1d20">' +
      esc(n.title || n.id) + '</text>' +
      '<text x="' + (p.x + 12) + '" y="' + (p.y + 42) + '" font-size="11" fill="#5b6169">' + esc(n.type) + '</text></g>');
  });
  $("canvas").innerHTML = '<svg width="' + (W * ZOOM) + '" height="' + (H * ZOOM) +
    '" viewBox="0 0 ' + W + ' ' + H + '" xmlns="http://www.w3.org/2000/svg">' + parts.join("") + '</svg>';
  $("canvas").querySelectorAll("g[data-nid]").forEach(function(g){
    g.addEventListener("click", function(){ jumpToExp(g.getAttribute("data-nid")); });
  });
}

// ノードのハイライト。縮小表示でも一目で分かるよう、枠線ではなく塗りつぶしで示す
function markNode(shape, on){
  if(!shape.hasAttribute("data-fill0")) shape.setAttribute("data-fill0", shape.getAttribute("fill") || "#ffffff");
  if(on){
    shape.setAttribute("fill", "#ffd43b");
    shape.setAttribute("stroke", "#f08c00");
    shape.setAttribute("stroke-width", "3");
  }else{
    shape.setAttribute("fill", shape.getAttribute("data-fill0"));
    shape.setAttribute("stroke", "#d0d5dd");
    shape.setAttribute("stroke-width", "1.5");
  }
}

var HIT_TIMER = null;
function jumpToExp(nid){
  $("canvas").querySelectorAll("g[data-nid] rect, g[data-nid] circle").forEach(function(r){ markNode(r, false); });
  var g = $("canvas").querySelector('g[data-nid="' + nid + '"]');
  if(g) markNode(g.querySelector("rect, circle"), true);
  var exp = $(EXP[nid] || "exp-start");
  if(!exp) return;
  exp.scrollIntoView({behavior: "smooth", block: "center"});
  document.querySelectorAll(".exp-hit").forEach(function(el){ el.classList.remove("exp-hit"); });
  exp.classList.add("exp-hit");
  if(HIT_TIMER) clearTimeout(HIT_TIMER);
  HIT_TIMER = setTimeout(function(){ exp.classList.remove("exp-hit"); }, 2200);
}

$("zoomIn").onclick = function(){ ZOOM = Math.min(2, ZOOM * 1.25); drawCanvas(false); };
$("zoomOut").onclick = function(){ ZOOM = Math.max(0.05, ZOOM / 1.25); drawCanvas(false); };
$("zoomFit").onclick = function(){ drawCanvas(true); };
drawCanvas(true);

// ---- 解説クリック → 図の該当ノードをハイライト(逆方向ジャンプ)
var EXP_NODES = {};
Object.keys(EXP).forEach(function(nid){ (EXP_NODES[EXP[nid]] = EXP_NODES[EXP[nid]] || []).push(nid); });
document.querySelectorAll('li[id^="exp-"]').forEach(function(li){
  li.addEventListener("click", function(){ jumpToCanvas(li.id); });
});
function jumpToCanvas(expId){
  var ids = EXP_NODES[expId] || [];
  if(!ids.length) return;
  $("canvas").querySelectorAll("g[data-nid] rect, g[data-nid] circle").forEach(function(r){ markNode(r, false); });
  var byId = {};
  GRAPH.nodes.forEach(function(n){ byId[n.id] = n; });
  var minX = Infinity, minY = Infinity;
  ids.forEach(function(nid){
    var g = $("canvas").querySelector('g[data-nid="' + nid + '"]');
    if(g) markNode(g.querySelector("rect, circle"), true);
    var n = byId[nid];
    if(n){
      var pp = absPos(n, byId);
      minX = Math.min(minX, pp.x);
      minY = Math.min(minY, pp.y);
    }
  });
  $("canvasCard").scrollIntoView({behavior: "smooth", block: "start"});
  var cv = $("canvas");
  cv.scrollLeft = Math.max(0, minX * ZOOM - 60);
  cv.scrollTop = Math.max(0, minY * ZOOM - 40);
}

// ---- 動画プレーヤー(共通エンジン tools/demo_player.js と ④の台本 tools/eval_demo_scripts.js を埋め込み)
__DEMO_PLAYER_JS__
__EVAL_DEMO_JS__
</script>
'''


def read_js(name):
    """ページに埋め込むJSファイルを読む(そのままscriptブロックへ入るので中身を点検)。"""
    text = io.open(os.path.join(ROOT, 'tools', name), encoding='utf-8').read()
    assert '</script' not in text.lower(), name + ' に </script> は書けない'
    for tok in ('__COMMON_JS__', '__EVAL_RUNNER_JS__', '__LEARN_RUNNER_JS__',
                '__DEMO_PLAYER_CSS__', '__DEMO_PLAYER_JS__', '__EVAL_DEMO_JS__'):
        assert tok not in text, name + ' にトークン ' + tok + ' を含めない'
    return text.rstrip('\n')


def main():
    yaml_text = io.open(os.path.join(ROOT, 'contract-account-eval.yml'), encoding='utf-8').read()
    script_text = io.open(os.path.join(ROOT, '契約書判定の採点.py'), encoding='utf-8').read()
    nb_text = io.open(os.path.join(ROOT, '契約書判定の採点.ipynb'), encoding='utf-8').read()
    d = miniyaml.load(yaml_text)
    page = (PAGE.replace('__YAML__', js(yaml_text))
                .replace('__SCRIPT__', js(script_text))
                .replace('__NOTEBOOK__', js(nb_text))
                .replace('__GRAPH__', js(graph_data(d)))
                .replace('__COMMON_JS__', read_js('eval_common.js'))
                .replace('__EVAL_RUNNER_JS__', read_js('eval_page_runner.js'))
                .replace('__DEMO_PLAYER_CSS__', read_js('demo_player.css'))
                .replace('__DEMO_PLAYER_JS__', read_js('demo_player.js'))
                .replace('__EVAL_DEMO_JS__', read_js('eval_demo_scripts.js')))
    io.open(OUT, 'w', encoding='utf-8').write(page)
    sys.stderr.write('written %s (%d KB)\n' % (os.path.basename(OUT), len(page.encode('utf-8')) // 1024))


if __name__ == '__main__':
    main()
