// ============================================================ 採点コア(共通)
// ④「ブラウザで採点」と⑤「自動学習ループ」で共用するコア。
// ビルド時に build_eval_page.py / build_learn_page.py がトークン置換で
// ページへそのまま埋め込む(このファイル自体は配布物に含まれない)。
// 通信するのは evFetch / evUpload / evChat / evRunOne だけで、通信先は
// 呼び出し側が渡した base(ユーザーが入力した自社DifyのURL)のみ。
// 手順・採点基準は 契約書判定の採点.py と同一
// (アップロード→1ターン目(ファイル添付)→「OK」→回答を照合)。
var EV_DOC_EXTS = [".pdf", ".txt", ".md", ".markdown", ".docx", ".xlsx", ".xls", ".pptx", ".ppt", ".csv",
                   ".png", ".jpg", ".jpeg", ".webp", ".gif"];
var EV_IMG_EXTS = [".png", ".jpg", ".jpeg", ".webp", ".gif"];

function evExt(name){
  var i = name.lastIndexOf(".");
  return i >= 0 ? name.slice(i).toLowerCase() : "";
}
function evIsAnswer(name){
  return name.toLowerCase().slice(-4) === ".txt" && name.indexOf("正解") >= 0;
}
function evNk(s){ return (s || "").normalize("NFKC"); }

// 正解.txt の最初の行(「#」のコメント行と空行は飛ばす)から科目名とコードを読む。
// 「賃借料 [5030001001]」「賃借料」「5030001001」「賃借料 5030001001」「正解: 賃借料 [5030001001] ×3」のどれでもよい。
// 採点はコードがあればコード(7桁でも可=10桁コードの先頭一致)、無ければ科目名の部分一致
function evParseAnswer(text){
  var lines = (text || "").replace(/^﻿/, "").split("\n");
  for(var i = 0; i < lines.length; i++){
    var line = evNk(lines[i]).trim();
    if(line.slice(0, 2) === "- ") line = line.slice(2).trim();
    if(!line || line[0] === "#") continue;
    line = line.replace(/^正解\s*[:：]\s*/, "").replace(/\s*[×xX]\s*[0-9]+\s*$/, "");
    var m = line.match(/\[([0-9]{7,10})\]/);
    var code = m ? m[1] : "";
    var rest = line.replace(/\[[0-9]{7,10}\]/g, "");
    if(!code){
      var m2 = rest.match(/(?:^|[\s:：,、])([0-9]{7,10})(?=$|[\s,、)])/);
      if(m2){ code = m2[1]; rest = rest.replace(m2[1], ""); }
    }
    var name = rest.replace(/^[\s:：,、\-]+|[\s:：,、\-]+$/g, "").trim();
    return {name: name, code: code};
  }
  return {name: "", code: ""};
}

// 同じ階層にある「文書 + 同名.正解.txt」のペアを決裁にする(ペア方式)。files: [{name: その階層内の名前, file}]
function evPairs(files, excl, labelPrefix){
  var cases = [];
  files.filter(function(it){ return evIsAnswer(it.name); }).forEach(function(it){
    var stem = it.name.replace(/\.?正解\.txt$/i, "");
    var docs = files.filter(function(f){
      if(f.name === it.name) return false;
      var base = f.name.slice(0, f.name.length - evExt(f.name).length);
      return base === stem && EV_DOC_EXTS.indexOf(evExt(f.name)) >= 0 && !excl[evExt(f.name)];
    }).map(function(f){ return {name: f.name, file: f.file}; });
    if(docs.length) cases.push({label: (labelPrefix || "") + stem, docs: docs, ansFile: it.file});
  });
  return cases;
}

// items: [{rel: "案件001/契約書.pdf", file: File}] から決裁一覧を検出する
//  - 第1階層のフォルダ=1決裁。中のファイルは下位フォルダの分も含めて全部その決裁の書類。
//    正解.txt(ファイル名に「正解」を含む .txt)は任意で、無ければ採点せず判定結果だけ出す。
//    フォルダ直下が「文書+同名.正解.txt」のペア2組以上ならペア方式として1ペア=1決裁
//  - トップ直下の「文書+同名.正解.txt」ペアも決裁にする
// 戻り値: [{label, docs: [{name, file}], ansFile: File または null}]
function evDetect(items, excl){
  excl = excl || {};
  var groups = {}, top = [];
  items.forEach(function(it){
    var i = it.rel.indexOf("/");
    if(i < 0){ top.push({name: it.rel, file: it.file}); return; }
    var dir = it.rel.slice(0, i), name = it.rel.slice(i + 1);
    (groups[dir] = groups[dir] || []).push({name: name, file: it.file});
  });
  var base = function(c){ return c.name.split("/").pop(); };
  var cases = [];
  Object.keys(groups).sort().forEach(function(label){
    var children = groups[label];
    var pairs = evPairs(children.filter(function(c){ return c.name.indexOf("/") < 0; }), excl, label + "/");
    if(pairs.length >= 2){ cases = cases.concat(pairs); return; }
    var ans = children.filter(function(c){ return evIsAnswer(base(c)); })
      .sort(function(a, b){ return (a.name.split("/").length - b.name.split("/").length) || (a.name < b.name ? -1 : 1); });
    var docs = children.filter(function(c){
      return !evIsAnswer(base(c)) && EV_DOC_EXTS.indexOf(evExt(base(c))) >= 0 && !excl[evExt(base(c))];
    }).sort(function(a, b){ return a.name < b.name ? -1 : 1; })
      .map(function(c){ return {name: c.name, file: c.file}; });
    if(docs.length) cases.push({label: label, docs: docs, ansFile: ans.length ? ans[0].file : null});
  });
  cases = cases.concat(evPairs(top, excl, ""));
  cases.sort(function(a, b){ return a.label < b.label ? -1 : 1; });
  return cases;
}

// トップが「1つのフォルダ」だけのとき、その中身の様子を返す(ラッパーフォルダかどうかの判断用)。
// 戻り値 null(トップが1フォルダではない)または {root, directDocs: 直下の書類数, nSub: 書類入りサブフォルダ数, pairs: 直下のペア数}
function evRootStats(items){
  var tops = {}, direct = [], subWithDocs = {};
  items.forEach(function(it){
    var segs = it.rel.split("/");
    tops[segs[0]] = tops[segs[0]] || (segs.length > 1 ? "dir" : "file");
    var name = segs[segs.length - 1];
    if(segs.length === 2) direct.push({name: name, file: it.file});
    if(segs.length >= 3 && !evIsAnswer(name) && EV_DOC_EXTS.indexOf(evExt(name)) >= 0) subWithDocs[segs[1]] = 1;
  });
  var names = Object.keys(tops);
  if(names.length !== 1 || tops[names[0]] !== "dir") return null;
  return {root: names[0],
          directDocs: direct.filter(function(f){ return !evIsAnswer(f.name) && EV_DOC_EXTS.indexOf(evExt(f.name)) >= 0; }).length,
          nSub: Object.keys(subWithDocs).length,
          pairs: evPairs(direct, {}, "").length};
}

// ラッパーフォルダ(例:「元データ」1枚)を自動で降りて決裁を検出し、各決裁の正解.txt を読み込む。
// 降りる条件: トップが1つのフォルダだけで、その直下に書類が無く書類入りのサブフォルダがある(または直下がペア方式2組以上)。
// 直下にもサブフォルダにも書類がある場合はどちらとも取れるので、opts.rootAsCase(true=そのフォルダ全体を1決裁)で
// 指定できる。未指定なら、書類入りサブフォルダが2つ以上あればサブフォルダ=決裁、1つならフォルダ全体=1決裁(下位は添付)。
// 戻り値 {items: 降りた後の一覧, cases: 決裁一覧, ambiguous: 判断が分かれた階層の情報または null}
async function evBuildCases(items, excl, opts){
  opts = opts || {};
  var amb = null;
  for(var depth = 0; depth < 4; depth++){
    var st = evRootStats(items);
    if(!st) break;
    var wrapper;
    if(st.directDocs && st.nSub >= 1){
      amb = {root: st.root, directDocs: st.directDocs, nSub: st.nSub};
      wrapper = (typeof opts.rootAsCase === "boolean") ? !opts.rootAsCase : st.nSub >= 2;
    }else{
      wrapper = st.nSub >= 1 || st.pairs >= 2;
    }
    if(!wrapper) break;
    var pre = st.root + "/";
    items = items.map(function(it){ return {rel: it.rel.slice(pre.length), file: it.file}; });
    if(amb) break;
  }
  var raw = evDetect(items, excl);
  for(var i = 0; i < raw.length; i++){
    raw[i].has_answer = !!raw[i].ansFile;
    var a = raw[i].ansFile ? evParseAnswer(await raw[i].ansFile.text()) : {name: "", code: ""};
    raw[i].expect_name = a.name;
    raw[i].expect_code = a.code;
  }
  return {items: items, cases: raw, ambiguous: amb};
}

// ---- フォルダの読み取り(D&D の DataTransferItem.webkitGetAsEntry を再帰走査)
function evWalkEntry(entry, prefix, out){
  return new Promise(function(resolve){
    if(entry.isFile){
      entry.file(function(f){ out.push({rel: prefix + entry.name, file: f}); resolve(); }, function(){ resolve(); });
    }else if(entry.isDirectory){
      var reader = entry.createReader();
      var all = [];
      (function readMore(){
        reader.readEntries(function(es){
          if(!es.length){
            Promise.all(all.map(function(e){ return evWalkEntry(e, prefix + entry.name + "/", out); })).then(resolve);
            return;
          }
          all = all.concat(es);
          readMore();
        }, function(){ resolve(); });
      })();
    }else{
      resolve();
    }
  });
}

// ---- 通信(タイムアウト+中断可能な fetch。aborters は呼び出し側の中断登録先)
function evFetch(url, opts, timeoutSec, aborters){
  var ctl = new AbortController();
  if(aborters) aborters.push(ctl);
  var timer = setTimeout(function(){ ctl.abort(); }, (timeoutSec || 300) * 1000);
  opts.signal = ctl.signal;
  return fetch(url, opts).finally(function(){
    clearTimeout(timer);
    if(aborters){
      var i = aborters.indexOf(ctl);
      if(i >= 0) aborters.splice(i, 1);
    }
  });
}

// 1ファイルをアップロードしてファイルIDを得る。戻り値 {id} または {err}
async function evUpload(base, key, doc, timeoutSec, aborters){
  var fd = new FormData();
  fd.append("user", "eval-runner");
  fd.append("file", doc.file, doc.name.split("/").pop());   // 下位フォルダの分もファイル名だけで送る
  var r = await evFetch(base + "/files/upload",
    {method: "POST", headers: {Authorization: "Bearer " + key}, body: fd}, timeoutSec, aborters);
  if(!r.ok) return {err: "HTTP " + r.status + ": " + (await r.text()).slice(0, 200)};
  return {id: (await r.json()).id};
}

// チャットAPIを1回呼ぶ(body に query / files / conversation_id を渡す)。
// 戻り値 {answer, conv} または {err}
async function evChat(base, key, body, timeoutSec, aborters){
  var payload = Object.assign(
    {inputs: {}, response_mode: "blocking", user: "eval-runner", auto_generate_name: false}, body);
  var r = await evFetch(base + "/chat-messages",
    {method: "POST", headers: {"Content-Type": "application/json", Authorization: "Bearer " + key},
     body: JSON.stringify(payload)}, timeoutSec, aborters);
  if(!r.ok) return {err: "HTTP " + r.status + ": " + (await r.text()).slice(0, 200)};
  var d = await r.json();
  return {answer: d.answer || "", conv: d.conversation_id || ""};
}

// 1決裁×1アプリを実行: 全ファイルをアップロード→1ターン目(添付)→「OK」→回答。
// 戻り値 {answer, conv, err}(conv は続きのターン(⑤の「正解:」返信)に使える)。
// opts: {aborters: 中断登録先, stopped: 停止済みかを返す関数,
//        okFor: 1ターン目の回答を受け取り2ターン目の本文を返す関数(省略時は "OK"。⑤の仮ナレッジモードが参考事例を添える)}
// HTTPエラーは即返し、通信例外だけ2秒おいて1回リトライ(契約書判定の採点.py と同じ)。
async function evRunOne(base, key, docs, timeoutSec, opts){
  opts = opts || {};
  for(var attempt = 0; attempt < 2; attempt++){
    try{
      var files = [];
      for(var i = 0; i < docs.length; i++){
        var up = await evUpload(base, key, docs[i], timeoutSec, opts.aborters);
        if(up.err) return {answer: "", conv: "", err: up.err};
        files.push({type: EV_IMG_EXTS.indexOf(evExt(docs[i].name)) >= 0 ? "image" : "document",
                    transfer_method: "local_file", upload_file_id: up.id});
      }
      var r1 = await evChat(base, key, {query: ".", files: files}, timeoutSec, opts.aborters);
      if(r1.err) return {answer: "", conv: "", err: r1.err};
      var okText = opts.okFor ? (opts.okFor(r1.answer) || "OK") : "OK";
      var r2 = await evChat(base, key, {query: okText, conversation_id: r1.conv}, timeoutSec, opts.aborters);
      if(r2.err) return {answer: "", conv: "", err: r2.err};
      return {answer: r2.answer, conv: r1.conv, err: null};
    }catch(e){
      if(opts.stopped && opts.stopped()) return {answer: "", conv: "", err: "stopped"};
      if(attempt === 0){ await new Promise(function(res){ setTimeout(res, 2000); }); continue; }
      return {answer: "", conv: "", err: "error: " + ((e && e.message) || e)};
    }
  }
}

// 回答の表から、アプリが答えた「科目名 [コード]」を取り出す(無ければ "")
function evPick(answer){
  var a = evNk(answer);
  var n = /相手勘定\(科目\)\s*\|\s*([^|\n]+)/.exec(a), c = /確定コード\s*\|\s*([^|\n]+)/.exec(a);
  var name = n ? n[1].trim() : "", code = c ? c[1].trim() : "";
  return name + (code ? " [" + code + "]" : "");
}

// 採点: 回答に正解コード(無ければ科目名)が含まれるか。戻り値 [状態, 回答抜粋, アプリの答え(科目 [コード])]
// 状態: ok=正解 ng=不正解 ask=質問で停止 error=エラー none=正解なし(判定結果だけ)
function evGrade(answer, err, expectName, expectCode){
  if(err) return ["error", err, ""];
  var a = evNk(answer);
  var got = a.slice(0, 400).split(/\s+/).join(" ").trim();
  if(a.indexOf("質問:") >= 0) return ["ask", got, ""];
  var pick = evPick(a);
  if(!expectCode && !expectName) return ["none", got, pick];
  var hit = expectCode ? a.indexOf(expectCode) >= 0 : a.indexOf(evNk(expectName).trim()) >= 0;
  return [hit ? "ok" : "ng", got, pick];
}

// ---- 接続テストの補助(④⑤共通)
// このページのオリジン(Dify管理者にCORS許可を依頼するときに伝える値)
function evOrigin(){
  var o = "";
  try{ o = location.origin || ""; }catch(e){}
  return (o && o.indexOf("http") === 0) ? o
    : "このページを開いているサイトのURL(ファイルとして開いている場合は null)";
}

// 「通信できません」だったときの切り分け案内
function evCorsHint(base){
  var mixed = "";
  try{
    if(location.protocol === "https:" && base.indexOf("http://") === 0){
      mixed = "。なお、このページはhttpsで開かれているため、http:// のDifyへは(CORS以前に)ブラウザが接続を止めます"
        + " — その場合はDifyのhttps化を管理者に相談してください";
    }
  }catch(e){}
  return "🔎 切り分け: アドレスバーに " + base + "/info を直接打って開いてください。"
    + "何かJSON(エラー文でも可)が表示されるなら原因はCORSです — Dify管理者に"
    + " WEB_API_CORS_ALLOW_ORIGINS(既定 *)へ " + evOrigin() + " の追加を依頼してください。"
    + "ページ自体が開けないなら、URLの誤りか社内ネットワークの問題です" + mixed + "。";
}

// キー無しでURLの疎通(CORSに引っかかるか)だけを確かめる。戻り値は表示用メッセージ。
// 401などのHTTPエラーでも「返事が届いた」ならCORSは通っている。
async function evProbeUrl(base, aborters){
  try{
    var r = await evFetch(base + "/info", {}, 30, aborters);
    return "✅ サーバーに届きました(HTTP " + r.status + ")— CORSは通っています(このページからの呼び出しがDify側で許可されています)。"
      + (r.status === 404 ? "ただし404なので、URLの末尾が /v1 かを確認してください。" : "")
      + "あとはAPIキー(app-…)を入力して、もう一度接続テストを押してください。";
  }catch(e){
    return "❌ 通信できません。" + evCorsHint(base);
  }
}
