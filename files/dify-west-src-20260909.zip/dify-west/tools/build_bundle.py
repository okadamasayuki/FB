#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""6つのHTMLツール(①・②・②-2・③・④・⑤)を、1つのHTMLにまとめる。

  python3 tools/build_bundle.py

各ツールは iframe(srcdoc)の中で動かすので、元のHTMLには一切手を入れない。
IDや変数名がぶつからないため、ツール側を直したらこれを実行し直すだけでよい。
"""
import io
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, '勘定科目分類ツール.html')

TOOLS = [
    ('① Excelからツリー', 'Excelからツリー.html',
     '勘定科目マスタ(Excel)を読み込んで、判定用の「分類ツリー」を作ります。'),
    ('② 検査(AIに投げて適用)', 'ツリー検査.html',
     '科目の並びが正しいかをAIに確認させ、返ってきた指示をこの画面が機械的に適用します。'),
    ('②-2 10桁の定義', '十桁定義.html',
     '1つの7桁に複数の10桁がぶら下がるところに、会社独自の書き分け(定義)を書きます。③でAIの判定基準になります。'),
    ('③ ツリーからDify', 'ツリーからDify.html',
     '分類ツリーから、Dify に取り込むアプリ定義(YAML)を作ります。どの形式も仕訳の流れを整理してキャッシュの相手勘定1科目を判定します。コードの決め方は3つ(コード一発選択/ツリー判定/コード2段選択)から1つ選べます。'),
    ('④ 採点(正答率くらべ)', '判定の採点.html',
     '決裁フォルダをドラッグ&ドロップして、ブラウザから自社DifyのAPIを直接呼んで③の3形式を採点・比較できます(通信先は入力した自社DifyのURLのみ)。Dify用DSL・Snowflakeノートブック版・スクリプト版のダウンロードと解説も。'),
    ('⑤ 自動学習(正答率を上げる)', '自動学習.html',
     '「全決裁をテスト→誤答にだけ正解を教える→再テスト」を自動で繰り返すエポック学習。正答率の推移を見ながら目標で止まります(③の自己学習チェック入りアプリが必要。通信先は入力した自社DifyのURLのみ)。'),
]

PAGE = '''<title>勘定科目 分類ツール</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  :root{
    --bg:#f6f7f9; --fg:#1b1d20; --sub:#5b6169; --line:#d8dce1; --card:#ffffff;
    --accent:#2f6fed; --accent-fg:#ffffff; --code-bg:#f2f4f7;
  }
  *{box-sizing:border-box}
  html,body{height:100%%}
  body{margin:0;background:var(--bg);color:var(--fg);display:flex;flex-direction:column;
       font-family:"Yu Gothic UI","Yu Gothic","Meiryo",system-ui,sans-serif;line-height:1.7}
  header{background:var(--card);border-bottom:1px solid var(--line);padding:10px 16px 0;flex:0 0 auto}
  header h1{font-size:16px;margin:0 0 2px;font-weight:600}
  header p{margin:0 0 8px;font-size:12px;color:var(--sub)}
  nav{display:flex;gap:4px;flex-wrap:wrap}
  nav button{padding:7px 14px;border:1px solid var(--line);border-bottom:none;
             border-radius:7px 7px 0 0;background:#eef0f3;color:var(--sub);
             font-size:13px;font-family:inherit;cursor:pointer;margin-bottom:-1px}
  nav button:hover{background:#e4e7ec}
  nav button.on{background:var(--card);color:var(--fg);font-weight:600;
                border-bottom:1px solid var(--card)}
  .step{font-size:12px;color:var(--sub);padding:6px 16px;background:var(--card);
        border-bottom:1px solid var(--line);flex:0 0 auto}
  main{flex:1 1 auto;position:relative;overflow:hidden}
  iframe{position:absolute;inset:0;width:100%%;height:100%%;border:0;background:var(--bg)}
  .hide{display:none}
  header{position:relative}
  .hdr-btns{position:absolute;right:16px;top:12px;display:flex;gap:6px}
  .about-btn{padding:6px 12px;border:1px solid var(--line);
             border-radius:6px;background:var(--card);color:var(--fg);font-family:inherit;
             font-size:12px;cursor:pointer}
  .about-btn:hover{border-color:var(--accent)}
  .about{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:50;
         display:flex;align-items:center;justify-content:center;padding:24px}
  .about.hide{display:none}   /* .hide より後に来るので、必ず打ち消せるようにする */
  .about-inner{background:var(--card);border:1px solid var(--line);border-radius:10px;
               max-width:820px;width:100%%;max-height:86vh;display:flex;flex-direction:column;
               padding:16px}
  .about-inner h2{font-size:15px;margin:0 0 4px}
  .about-inner .lead{font-size:12px;color:var(--sub);margin:0 0 12px}
  .about-inner .btns{display:flex;gap:8px;margin-bottom:12px}
  .about-inner button{padding:8px 16px;border-radius:6px;font-family:inherit;
                      font-size:13px;font-weight:600;cursor:pointer}
  .about-inner .primary{border:1px solid var(--accent);background:var(--accent);color:var(--accent-fg)}
  .about-inner .plain{border:1px solid var(--line);background:var(--card);color:var(--fg)}
  .about-inner pre{background:var(--code-bg);border:1px solid var(--line);border-radius:6px;
                   padding:12px;overflow:auto;font-family:"BIZ UDGothic","MS Gothic","Consolas",monospace;
                   font-size:12px;line-height:1.7;margin:0;white-space:pre-wrap}
</style>

<header>
  <h1>勘定科目 分類ツール</h1>
  <p>契約書から勘定科目を判定するAIの「設計図」を①→②→③の順に作り、④で正答率を測り、⑤で誤答を自動で教えて育てます。
  <b>読み込んだファイルはこのパソコンの中だけで処理されます</b>(通信は、④の「ブラウザで採点」と⑤の「自動学習」で
  あなたが入力した自社DifyのURLに送るときだけ。それ以外にこのページは一切通信しません)。
  入力内容や読み込んだファイルは<b>このブラウザの中にだけ</b>自動保存され、ページを開き直しても残ります
  (各タブの上でOFF・消去できます。右上の「保存した内容をすべて消す」で最初の状態に戻せます)。</p>
  <nav id="nav"></nav>
  <div class="hdr-btns">
    <button class="about-btn" id="clearAllBtn" title="このブラウザに保存した①〜⑤の入力・ファイル・設定をすべて消して、最初の状態に戻します">保存した内容をすべて消す</button>
    <button class="about-btn" id="aboutBtn">この仕組みの説明</button>
  </div>
</header>
<div class="about hide" id="aboutPanel">
  <div class="about-inner">
    <h2>この仕組みの説明(そのまま渡せます)</h2>
    <p class="lead">このページのツールが何をしているかを、2〜3分で読める長さにまとめたものです。</p>
    <div class="btns">
      <button class="primary" id="aboutCopy">説明文をコピーする</button>
      <button class="plain" id="aboutClose">閉じる</button>
    </div>
    <pre id="aboutText"></pre>
  </div>
</div>
<div class="step" id="step"></div>
<main id="main"></main>

<script>
"use strict";
%s
var TOOLS = %s;
var ABOUT_TEXT = %s;
var nav = document.getElementById("nav");
var main = document.getElementById("main");
var step = document.getElementById("step");
var panes = [], cur = -1;

var TAB_KEY = "kanjoTab";   // 最後に開いていたタブ(このブラウザ内のみ。更新しても同じタブを開く)
var booting = true;         // 復元で開くとき(初回)は書き込まない。ユーザーがタブを押したときだけ覚える
function select(i){
  if(cur === i) return;
  cur = i;
  if(!booting){ try{ localStorage.setItem(TAB_KEY, String(i)); }catch(e){} }
  for(var k = 0; k < panes.length; k++){
    if(panes[k]) panes[k].classList.toggle("hide", k !== i);
    nav.children[k].classList.toggle("on", k === i);
  }
  if(!panes[i]){
    var t = TOOLS[i];
    var f = document.createElement("iframe");
    f.setAttribute("title", t.name);
    f.setAttribute("allow", "fullscreen");   // ③の図の全画面表示に必要
    panes[i] = f;
    main.appendChild(f);
    f.srcdoc = t.html;
    for(var k2 = 0; k2 < panes.length; k2++) if(panes[k2]) panes[k2].classList.toggle("hide", k2 !== i);
  }
  step.textContent = TOOLS[i].hint;
}

for(var i = 0; i < TOOLS.length; i++){
  panes.push(null);
  var b = document.createElement("button");
  b.textContent = TOOLS[i].name;
  b.onclick = (function(n){ return function(){ select(n); }; })(i);
  nav.appendChild(b);
}
// 前回開いていたタブを復元する(無ければ①)。更新(Ctrl+R)でも同じタブが開く
var startTab = 0;
try{ var saved = parseInt(localStorage.getItem(TAB_KEY), 10); if(saved >= 0 && saved < TOOLS.length) startTab = saved; }catch(e){}
select(startTab);
booting = false;

// ---- 上司・関係者への説明文(表示とワンクリックコピー)
var aboutPanel = document.getElementById("aboutPanel");
document.getElementById("aboutText").textContent = ABOUT_TEXT;
document.getElementById("aboutBtn").onclick = function(){ aboutPanel.classList.remove("hide"); };
document.getElementById("aboutClose").onclick = function(){ aboutPanel.classList.add("hide"); };
aboutPanel.onclick = function(e){ if(e.target === aboutPanel) aboutPanel.classList.add("hide"); };
document.getElementById("aboutCopy").onclick = function(){
  var btn = this;
  var ta = document.createElement("textarea");
  ta.value = ABOUT_TEXT;
  document.body.appendChild(ta);
  ta.select();
  try{ document.execCommand("copy"); }catch(e){}
  document.body.removeChild(ta);
  btn.textContent = "コピーしました";
  setTimeout(function(){ btn.textContent = "説明文をコピーする"; }, 1400);
};

// ---- 保存した内容をすべて消す(このブラウザ内のデータだけ。①〜③の自動保存・③の任意保存・④⑤の接続設定・⑤の仮ナレッジ)
document.getElementById("clearAllBtn").onclick = function(){
  if(!confirm("このブラウザに保存した内容をすべて消して、最初の状態に戻します(①〜③の入力とファイル、③で任意保存したナレッジID・URL・キー、④⑤の接続設定、⑤の仮ナレッジ)。よろしいですか?")) return;
  KS.clearAll().then(function(){ location.reload(); }, function(){ location.reload(); });
};
</script>
'''


ABOUT_TEXT = """【契約書から勘定科目を判定する仕組み(3ステップのツール)】

■ 何のためのものか
契約書を読んで、仕訳や勘定科目コード(10桁。上7桁が全社共通、下3桁が会社別)を
出すAIアプリをDify上に作ります。このページのツールは、そのアプリの「設計図」を
作り、検査するためのものです。

■ 全体の流れ(① → ② → ③)

① Excel → 分類ツリー
   勘定科目マスタ(Excel)を読み込み、区分1/区分2/明細の階層から
   判定用の「分類ツリー」を自動生成します。勘定科目コードもツリーに埋め込むので、
   コードはAIに推測させず、機械的に確定できます。

② ツリーの検査(AIは判断だけ、編集は機械)
   科目が正しい親の下に置かれているかを、AIに1科目ずつ確認させます。
   AIに出させるのは「昇格(1階層上げる)」の指示リストだけで、
   ツリーの書き換えはこのプログラムが機械的に行います。
   → AIの書き間違いでコードや科目が消えることが、原理的に起きません。
   適用後はコードの全数照合(欠け・増え0件、コードと科目名の対応)を毎回自動で行います。
   ②-2では、名前だけでは書き分けられない下3桁(会社独自のルール)の定義を書き足せます。

③ ツリー → Dify DSL
   完成したツリーから、Difyにそのまま取り込めるアプリ定義(YAML)を生成します。
   どの形式も、入力は「チャットに契約書を添付」で共通(読み取り内容の認識確認と、
   情報不足時の更問いつき)。まずAIが契約の一般的な仕訳の流れ(3〜5行)を整理して
   キャッシュ(現金・預金)の相手勘定となる勘定科目を1つ特定し、その科目の
   勘定科目コードを確定します。コードの決め方だけが3つから選べます:
   ・コード一発選択形式(推奨) … 全コード候補を横並びで提示して1回で選びます
   ・ツリー判定形式 … 相手勘定を分類ツリーで1段ずつ下りて位置づけます
   ・コード2段選択形式 … 7桁コードを横並びで1つ選び、紐付く10桁を書き分けの定義で絞り込みます
   どの形式も、勘定科目コードはAIに書かせず対応表から機械的に確定し、
   回答は「相手勘定・確定コード・判定経路・理由・根拠の仕訳」の表です。
   「自己学習を入れる」チェックを付けると、チャットで「正解: ◯◯」と返信したとき
   判定事例カードを返し、次回から似た契約の判定前に過去の事例を参考にする構成になります。
   既定の「環境変数に貼る」方式はナレッジもAPIキーも不要で、インポートしてそのまま公開できます
   (⑤がまとめた 判定事例.txt をアプリの環境変数 learned_cases に貼るだけ)。
   「Difyの事例ナレッジ」方式を選ぶと、ナレッジに自動保存・検索する構成になります
   (ナレッジのIDやキーを入れて、設定済みの状態でインポートできる「設定込みDSL」にもできます)。
   Difyでの見え方(オーケストレーション図)もその場で確認できます。

④ 採点(任意)
   テストデータ(決裁フォルダ: 1フォルダ=1決裁で複数ファイル+正解の相手勘定)で
   3形式の判定アプリをAPIで呼び出して正答率を比較し、誤答から「どの設定に何を追記
   すれば次から正解に近づくか」(自己学習の書き込み先)を出力します。
   いちばん手軽なのは「ブラウザで採点」: 決裁フォルダ一式をドラッグ&ドロップすると、
   ブラウザが自社DifyのAPIを直接呼んで採点します(このときだけ、入力した自社Difyの
   URLに通信します。それ以外にこのツールは通信しません)。
   ほかにDifyアプリ版、.py を実行できない環境向けのSnowflakeノートブック版、
   PCスクリプト版もダウンロードできます。
   結果を設定に追記していくことで、判定を会社の実務に寄せていけます。

⑤ 自動学習(任意)
   ④と同じ決裁フォルダで「全件テスト → 間違えた決裁にだけ正解を教える →
   また全件テスト」を自動で繰り返します(機械学習で標準のエポック学習)。
   正解を教えると、③の自己学習付きアプリが判定事例カードを作り(既定の環境変数方式では
   ⑤がブラウザに溜めて次の判定に添え、最後に 判定事例.txt にまとめてアプリの環境変数に貼る。
   ナレッジ方式では事例ナレッジに保存)、同じ決裁をまた間違えたら古いカードを差し替えて
   誤答情報つきで作り直します(1決裁=1カード)。正答率の推移(例: 78%→85%→93%)を見ながら、
   目標到達・改善停止で自動的に止まります(過学習の防止)。
   決裁の一部を「検証用」に取り分けて、教えていない初見の正答率も測れます。

■ なぜツリー(分類の階層)を整備するのか
どの形式でも、選択肢・経路・コードの対応はすべて分類ツリーから作られます。
特に段階判定(ツリー判定形式)は選択肢を絞りながら下りていくため、浅い段の誤りが
致命的で、「科目が正しい親の下にあるか」を検査する②が要になります。
横並びで選ぶ形式でも、候補の経路と定義はツリー由来なので、②の検査が精度に効きます。

■ 実行環境とセキュリティ
・ブラウザで開くだけの1ファイルHTMLです(インストール不要・管理者権限不要)
・①〜③の処理はすべてブラウザの中だけで行われ、読み込んだファイルはどこにも送信されません
  (ネットワークを切断した状態でも動きます)
・通信するのは④の「ブラウザで採点」と⑤の「自動学習」を実行するときだけで、
  送信先はあなたが入力した自社DifyのURLのみです(それ以外への通信はありません)
・入力した内容や読み込んだファイルは、ページを開き直しても続きから使えるように
  このブラウザの中(ブラウザ標準の保存領域)にだけ自動保存されます。外部やサーバーには送りません。
  各タブの上でOFFにでき、「このページの保存内容を消す」/右上の「保存した内容をすべて消す」で消せます

■ 現状
仕組みは完成しています。実際の勘定科目コードを入れれば、そのまま動きます。
"""


def js(obj):
    """JSのソースに埋め込める文字列リテラルにする。
    "</script>" がそのまま入るとHTMLのパースがそこで切れてしまうので、必ず "<\\/" に逃がす。"""
    return (json.dumps(obj, ensure_ascii=False)
            .replace('</', '<\\/')
            .replace('\u2028', '\\u2028')
            .replace('\u2029', '\\u2029'))


def main():
    items = []
    for name, fn, hint in TOOLS:
        path = os.path.join(ROOT, fn)
        html = io.open(path, encoding='utf-8').read()
        items.append({'name': name, 'hint': hint, 'html': html})
    store_js = io.open(os.path.join(ROOT, 'tools', 'state_store.js'), encoding='utf-8').read().rstrip('\n')
    assert '</script' not in store_js.lower(), 'state_store.js に </script> は書けない'
    page = PAGE % (store_js, js(items), js(ABOUT_TEXT))
    io.open(OUT, 'w', encoding='utf-8').write(page)
    sys.stderr.write('written %s (%d KB)\n' % (os.path.basename(OUT), len(page.encode('utf-8')) // 1024))


if __name__ == '__main__':
    main()
