// docs/orchestration.html のキャンバスを docs/orchestration-canvas.png / .pdf に書き出す。
// 前提: `npm i playwright`(ブラウザは PLAYWRIGHT_BROWSERS_PATH のChromiumを利用)と日本語フォント。
// docs/orchestration.html 自体は `python3 tools/render_canvas.py` でDSLから再生成する。
const path = require('path');
const { chromium } = require('playwright');

(async () => {
  const root = path.dirname(__dirname);
  const src = path.join(root, 'docs', 'orchestration.html');

  let browser;
  try { browser = await chromium.launch(); }
  catch (e) { browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' }); }
  const page = await browser.newPage({ viewport: { width: 1200, height: 800 }, deviceScaleFactor: 2 });
  await page.goto('file://' + src);
  const dims = await page.evaluate(() => {
    const svg = document.querySelector('svg.canvas');
    return { w: Number(svg.getAttribute('width')), h: Number(svg.getAttribute('height')) };
  });
  await page.setViewportSize({ width: dims.w + 100, height: dims.h + 100 });
  await page.waitForTimeout(300);
  const png = path.join(root, 'docs', 'orchestration-canvas.png');
  await page.locator('svg.canvas').screenshot({ path: png });
  console.log('written', png, dims.w + 'x' + dims.h);
  const pdf = path.join(root, 'docs', 'orchestration-canvas.pdf');
  await page.pdf({ path: pdf, width: (dims.w + 40) + 'px', height: (dims.h + 40) + 'px', printBackground: true });
  console.log('written', pdf);
  await browser.close();
})().catch((e) => { console.error(e); process.exit(1); });
