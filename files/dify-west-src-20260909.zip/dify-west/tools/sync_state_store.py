#!/usr/bin/env python3
"""tools/state_store.js(入力内容とファイルをこのブラウザの中にだけ自動保存する共通部品)を
①Excelからツリー / ②ツリー検査 / ②-2十桁定義 / ③ツリーからDify のマーカー間に埋め込む。

  python3 tools/sync_state_store.py

直すときは tools/state_store.js を直してこのスクリプトを実行する(HTML側は直接編集しない)。
まとめ版(tools/build_bundle.py)は同じファイルを親ページにも埋め込む(右上の「保存した内容をすべて消す」用)。
"""
import io
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BEGIN = '// STATE_STORE_BEGIN(tools/state_store.js を tools/sync_state_store.py で埋め込む。ここは直接編集しない)'
END = '// STATE_STORE_END'
TARGETS = ['Excelからツリー.html', 'ツリー検査.html', '十桁定義.html', 'ツリーからDify.html']


def main():
    js = io.open(os.path.join(ROOT, 'tools', 'state_store.js'), encoding='utf-8').read().rstrip('\n')
    assert '</script' not in js.lower(), 'state_store.js に </script> は書けない'
    for name in TARGETS:
        path = os.path.join(ROOT, name)
        html = io.open(path, encoding='utf-8').read()
        a = html.index(BEGIN) + len(BEGIN)
        b = html.index(END, a)
        html = html[:a] + '\n' + js + '\n' + html[b:]
        io.open(path, 'w', encoding='utf-8').write(html)
        sys.stderr.write('synced %s (%d KB)\n' % (name, len(html.encode('utf-8')) // 1024))


if __name__ == '__main__':
    main()
