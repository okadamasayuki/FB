#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ツリーからDify.html に tools/workflow_extras.yml の内容を埋め込む。

HTML本体は手で編集し、このスクリプトは <<EXTRAS>> 〜 <</EXTRAS>> の間だけを差し替える。
  python3 tools/build_html.py
"""
import io
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import miniyaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HTML = os.path.join(ROOT, 'ツリーからDify.html')
HEAD = '// <<EXTRAS>>\n'
TAIL = '// <</EXTRAS>>'


def slim_extras(extras):
    """HTML/単体版に埋め込む素材だけを取り出す。
    生成時に必ず上書きされる項目(app.description・全体集約の変数一覧)は、
    現行ツリーの規模や小区分の内訳が読み取れてしまうので空にしてから埋め込む。"""
    import copy
    slim = {'app': copy.deepcopy(extras['app']),
            'features': copy.deepcopy(extras['features']),
            'conversation_variables': extras.get('conversation_variables', []),
            'scaffold_nodes': copy.deepcopy(extras['scaffold_nodes']),
            'chat': copy.deepcopy(extras['chat']),
            'flat': copy.deepcopy(extras['flat']),
            'pick': copy.deepcopy(extras['pick'])}
    slim['app']['description'] = ''
    for n in slim['scaffold_nodes'] + slim['chat']['scaffold_nodes']:
        if n.get('id') == 'aggregator':
            n['data']['variables'] = []
    return slim


def main():
    extras = miniyaml.load(io.open(os.path.join(ROOT, 'tools', 'workflow_extras.yml'),
                                   encoding='utf-8').read())
    slim = slim_extras(extras)
    blob = json.dumps(slim, ensure_ascii=False, separators=(',', ':'))
    src = io.open(HTML, encoding='utf-8').read()
    i = src.index(HEAD) + len(HEAD)
    j = src.index(TAIL)
    line = 'const EXTRAS_JSON = %s;\n' % json.dumps(blob, ensure_ascii=False)
    out = src[:i] + line + src[j:]
    io.open(HTML, 'w', encoding='utf-8').write(out)
    sys.stderr.write('embedded %d KB of extras into %s\n' % (len(line) // 1024, os.path.basename(HTML)))


if __name__ == '__main__':
    main()
