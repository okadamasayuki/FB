#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ツリー検査.html に ツリー検査.md(AI用の手順書)を埋め込む。

  python3 tools/build_check.py

「AIに貼るプロンプトをコピー」が手順書+ツリーを1回で作れるようにするため。
手順書を直したらこれを実行し、続けて build_bundle.py を実行する。
"""
import io
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HTML = os.path.join(ROOT, 'ツリー検査.html')
HEAD = '// <<GUIDE>>\n'
TAIL = '// <</GUIDE>>'


def js(obj):
    return (json.dumps(obj, ensure_ascii=False)
            .replace('</', '<\\/').replace('\u2028', '\\u2028').replace('\u2029', '\\u2029'))


def main():
    guide = io.open(os.path.join(ROOT, 'ツリー検査.md'), encoding='utf-8').read()
    # AI向け部分だけを埋め込む(末尾の「利用者向け」節は不要)
    cut = guide.find('## 使い方の全体像(利用者向け)')
    if cut > 0:
        guide = guide[:guide.rfind('---', 0, cut)].rstrip() + '\n'
    src = io.open(HTML, encoding='utf-8').read()
    i = src.index(HEAD) + len(HEAD)
    j = src.index(TAIL)
    out = src[:i] + 'const GUIDE_TEXT = %s;\n' % js(guide) + src[j:]
    io.open(HTML, 'w', encoding='utf-8').write(out)
    sys.stderr.write('embedded %d chars of guide into ツリー検査.html\n' % len(guide))


if __name__ == '__main__':
    main()
