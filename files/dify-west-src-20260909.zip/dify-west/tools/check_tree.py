#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""分類ツリー.md の適正検査を支援するツール(Dify・YAMLとは完全に独立)。

浅い段の誤分類は下流で取り返せないため、「各ラベルが正しい親の配下にあるか」を
検査・修正するための機械部分を担う。意味の判定はClaude(tools/tree_review_guide.md の
基準に従う)が行い、本ツールはカードの列挙・昇格の機械適用・検証だけを行う。

  python3 tools/check_tree.py cards  [-t ツリー.md] [-o カード出力.md]
      判定カード(段ごとの選択肢一覧)を深い階層から順に列挙する
  python3 tools/check_tree.py apply  -m moves.json [-t ツリー.md] -o 修正案.md
      moves(昇格・★再指定)を機械適用した修正案を別ファイルに書き出し、diffを表示する
      ※ 元のツリーは書き換えない。昇格しても既存の似た項目とは統合しない
  python3 tools/check_tree.py verify [-t ツリー.md]
      構造検証(generate_workflow と同じパーサ+★・重複チェック)
  python3 tools/check_tree.py prompts [-t ツリー.md] [-o 出力先ディレクトリ] [--per N]
      チャットAIにそのまま貼れる「判定依頼」ファイルを分割生成する(社内チャット版パイロット用)
  python3 tools/check_tree.py collect -i 回答ファイルまたはディレクトリ -o moves.json
      チャットAIの回答(PROMOTE:/STAR: 行)を拾って moves.json に変換する

moves.json の形式:
  {"moves": [
    {"op": "promote", "path": ["流動資産", "現預金・有価証券・貸付金", "現金・預金", "デリバティブ資産"]},
    {"op": "set_star", "path": ["流動資産", "現預金・有価証券・貸付金", "現金・預金"], "label": "預金"}
  ]}
  - promote: path の最後のラベルを1階層上(元の親の直後)へ移動する。移動時に ★ は外れる
  - set_star: path の段の子のうち label だけに ★ を付ける(他の子の ★ は外す)
"""
import argparse
import difflib
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from generate_workflow import ROOT_LABEL, parse_tree  # 構造検証に利用

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_TREE = os.path.join(ROOT, '分類ツリー.md')

LINE_RE = re.compile(r'^((?:│   |    )*)(?:├─|└─) (.+)$')


# ---------------------------------------------------------------- パースと再構成

class TNode(object):
    def __init__(self):
        self.label = ''
        self.leaf = False
        self.star = False
        self.lock = False
        self.note = None       # ★の直後の括弧注記(例: 分類不能)
        self.definition = None
        self.code = None       # [7桁] または [3桁] の勘定科目コード
        self.ann = ''          # 「 …… 細分判定へ ✏ rules_x」等の注記(そのまま保持)
        self.children = []
        self.parent = None

    @property
    def is_branch(self):
        return bool(self.children)

    def path(self):
        out, n = [], self
        while n.parent is not None:
            out.append(n.label)
            n = n.parent
        return out[::-1]


def parse_content(content):
    n = TNode()
    n.leaf = content.startswith('◆ ')
    if n.leaf:
        content = content[2:]
    i = content.find(' …')
    if i >= 0:
        content, n.ann = content[:i], content[i:]
    if ': ' in content:
        content, n.definition = content.split(': ', 1)
    m = re.search(r' \[(\d+)\]', content)
    if m:
        n.code = m.group(1)
        content = content.replace(m.group(0), '', 1)
    if '🔒' in content:
        n.lock = True
        content = content.replace('🔒', '')
    j = content.find('★')
    if j >= 0:
        n.star = True
        after = content[j + 1:].strip()
        if after:
            n.note = after.strip('()')
        content = content[:j]
    n.label = content.strip()
    return n


def content_of(n):
    s = ('◆ ' if n.leaf else '') + n.label
    marks = ('★' if n.star else '') + ('🔒' if n.lock else '')
    if marks:
        s += ' ' + marks
        if n.star and n.note:
            s += '(%s)' % n.note
    if n.code is not None:
        s += ' [%s]' % n.code
    if n.definition is not None:
        s += ': ' + n.definition
    return s + n.ann


def load(path):
    """ファイル全文と、ツリーのコードブロックをパースした木を返す"""
    text = open(path, encoding='utf-8').read()
    blocks = text.split('```')
    ti = next((i for i, b in enumerate(blocks) if ROOT_LABEL + '(1段目)' in b), None)
    if ti is None:
        raise SystemExit('ツリーのコードブロックが見つかりません: %s' % path)
    root = TNode()
    root.label = ROOT_LABEL
    stack = [root]
    for raw in blocks[ti].split('\n'):
        raw = raw.rstrip()
        if not raw or raw.startswith(ROOT_LABEL):
            continue
        m = LINE_RE.match(raw)
        if not m:
            raise SystemExit('ツリーの行を解釈できません: %r' % raw)
        depth = len(m.group(1)) // 4
        node = parse_content(m.group(2))
        node.parent = stack[depth]
        stack[depth].children.append(node)
        del stack[depth + 1:]
        stack.append(node)
    return text, blocks, ti, root


def render(root):
    lines = ['', ROOT_LABEL + '(1段目)']

    def walk(n, prefix):
        for i, c in enumerate(n.children):
            last = i == len(n.children) - 1
            lines.append(prefix + ('└─ ' if last else '├─ ') + content_of(c))
            walk(c, prefix + ('    ' if last else '│   '))
    walk(root, '')
    return '\n'.join(lines) + '\n'


# ---------------------------------------------------------------- cards

def collect_stages(root):
    out = []

    def walk(n, depth):
        if n.children:
            out.append((depth, n))
        for c in n.children:
            walk(c, depth + 1)
    walk(root, 0)
    order = {id(n): i for i, (_, n) in enumerate(out)}
    return sorted(out, key=lambda t: (-t[0], order[id(t[1])]))


def card_text(st, depth):
    """判定カード1枚分の行"""
    path = st.path()
    out = ['## カード: %s(深さ%d)' % (' / '.join(path) or ROOT_LABEL, depth)]
    if st.definition:
        out.append('- この段の定義: %s' % st.definition)
    env = re.search(r'✏ (rules_[A-Za-z0-9_]+)', st.ann)
    if env:
        out.append('- 分類基準は環境変数 `%s`(下記の定義がそのまま入る)' % env.group(1))
    out.append('- 選択肢:')
    for i, c in enumerate(st.children, 1):
        marks = ('★' if c.star else '') + ('🔒' if c.lock else '')
        out.append('  %d. %s%s%s%s%s' % (
            i, '◆ ' if c.leaf else '', c.label,
            ' ' + marks if marks else '',
            ' — %s' % c.definition if c.definition else '',
            '' if c.leaf else '(配下に細分あり)'))
    if st.parent is not None:
        sib = [c.label for c in st.parent.children]
        out.append('- 昇格した場合の並び先(1階層上の選択肢): %s' % '、'.join(sib))
    return out


def cmd_cards(args):
    _, _, _, root = load(args.tree)
    stages = collect_stages(root)
    out = ['# 判定カード(深い階層から順)', '',
           '各カードについて tools/tree_review_guide.md の基準で判定する。', '']
    for depth, st in stages:
        out.extend(card_text(st, depth))
        out.append('')
    text = '\n'.join(out)
    if args.output:
        open(args.output, 'w', encoding='utf-8').write(text)
        print('written %s(%d cards)' % (args.output, len(stages)))
    else:
        print(text)


# ---------------------------------------------------------------- apply

def find(root, path):
    n = root
    for label in path:
        nxt = next((c for c in n.children if c.label == label), None)
        if nxt is None:
            raise SystemExit('パスが見つかりません: %s(「%s」が %s の配下に無い)'
                             % (' / '.join(path), label, n.label))
        n = nxt
    return n


def cmd_apply(args):
    text, blocks, ti, root = load(args.tree)
    moves = json.load(open(args.moves, encoding='utf-8'))['moves']
    warnings = []
    for mv in moves:
        if mv['op'] == 'promote':
            node = find(root, mv['path'])
            parent = node.parent
            if parent is None or parent.parent is None:
                raise SystemExit('これ以上昇格できません(すでに1段目): %s' % node.label)
            grand = parent.parent
            parent.children.remove(node)
            if not parent.children:
                raise SystemExit('昇格すると「%s」の配下が空になります。この段の扱い(葉に変える等)は手動で決めてください'
                                 % parent.label)
            if node.star:
                node.star = False
                node.note = None
                warnings.append('⚠ 「%s」は昇格により ★ を外しました。元の段「%s」に set_star が必要です'
                                % (node.label, parent.label))
            for sib in grand.children:
                if sib.label == node.label:
                    warnings.append('⚠ 昇格先に同名の「%s」が既にあります(方針どおり統合せず両方残しています。'
                                    '名前の変更を検討してください)' % node.label)
            node.parent = grand
            grand.children.insert(grand.children.index(parent) + 1, node)
        elif mv['op'] == 'set_star':
            stage = find(root, mv['path'])
            if not any(c.label == mv['label'] for c in stage.children):
                raise SystemExit('set_star: 「%s」の配下に「%s」がありません' % (stage.label, mv['label']))
            for c in stage.children:
                c.star = c.label == mv['label']
                if not c.star:
                    c.note = None
        else:
            raise SystemExit('不明な op: %r' % mv['op'])

    old_block = blocks[ti]
    new_blocks = list(blocks)
    new_blocks[ti] = render(root)
    new_text = '```'.join(new_blocks)
    open(args.output, 'w', encoding='utf-8').write(new_text)

    diff = '\n'.join(difflib.unified_diff(old_block.split('\n'), new_blocks[ti].split('\n'),
                                          '変更前', '修正案', lineterm=''))
    print(diff or '(変更なし)')
    for w in warnings:
        print(w)
    # 構造検証
    try:
        parse_tree(new_text)
        print('検証OK: 修正案は構造的に正しく、自動生成に使えます → %s' % args.output)
    except SystemExit as e:
        print('検証NG: %s' % e)
        print('(★の再指定などの moves を追加して apply し直してください)')
        raise


RULES = """あなたは日本の企業会計に精通した経理・会計の専門家です。
契約書を段階的に分類するための「分類ツリー」が正しく組まれているかを検査してください。

このツリーは上の段から順に選択肢を1つ選んで下りていく構造で、**浅い段で誤ると下流では絶対に正解できません**。
そのため「各選択肢が、その親の意味範囲に本当に含まれるか」がもっとも重要です。

判定は、日本の企業会計の一般知識と、カードに書かれた定義文だけを根拠にしてください。

【各カードで見ること】
1. 所属判定(重大): 選択肢が親の意味範囲に含まれないなら「1階層上へ昇格」を指示する
2. 兄弟間の紛れ(中): 同じ段の選択肢同士で意味が重複・境界が曖昧なペアがあれば指摘する(移動はしない)
3. 定義の曖昧さ(軽): 判定を誤りやすい書き方があれば指摘する

【厳守】
- 移動を指示してよいのは「1階層上への昇格」だけです。別の分岐への付け替えは指摘に留めてください
- 昇格先に似た項目や同名の項目があっても、**統合してはいけません**(別項目として並べます)
- 確信が持てないものは動かさず、指摘に留めてください
- ★ は「その段で判定が紛れた時の受け皿」です。★の付いた選択肢を昇格させる場合は、
  その段の別の選択肢に★を付け替える指示(STAR行)を必ず添えてください

【回答の書き方】(この形式の行だけを機械が読み取ります。説明文は自由に書いて構いません)
  PROMOTE: 親 / 子 / 孫 / 昇格させたいラベル      ← 1階層上へ移動する
  STAR: 親 / 子 / 孫 -> 新しい★のラベル           ← その段の★を付け替える
  NOTE: 指摘の内容                                 ← 移動しない指摘(記録用)
問題がなければ「OK」とだけ書いてください。
"""


def cmd_prompts(args):
    _, _, _, root = load(args.tree)
    stages = collect_stages(root)
    outdir = args.output or os.path.join(os.path.dirname(os.path.abspath(args.tree)), 'judge_prompts')
    if not os.path.isdir(outdir):
        os.makedirs(outdir)
    per = max(1, args.per)
    chunks = [stages[i:i + per] for i in range(0, len(stages), per)]
    written = []
    for k, chunk in enumerate(chunks, 1):
        body = [RULES.strip(), '',
                '=== 判定カード(%d/%d)===' % (k, len(chunks)), '']
        for depth, st in chunk:
            body.extend(card_text(st, depth))
            body.append('')
        path = os.path.join(outdir, 'judge_%02d.md' % k)
        with open(path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(body))
        written.append(path)
    print('%d ファイルを書き出しました(全%dカード / 1ファイル%dカード)' % (len(written), len(stages), per))
    for w in written:
        print('  ' + w)
    print('')
    print('使い方: 各ファイルの中身をそのまま社内チャットAIに貼り付け、返ってきた回答をテキストで保存 →')
    print('  python3 tools/check_tree.py collect -i <回答を保存したディレクトリ> -o moves.json')
    print('  python3 tools/check_tree.py apply -m moves.json -o 分類ツリー_修正案.md')


MOVE_RE = re.compile(r'^\s*(PROMOTE|STAR|NOTE)\s*[::]\s*(.+?)\s*$')


def cmd_collect(args):
    files = []
    if os.path.isdir(args.input):
        for name in sorted(os.listdir(args.input)):
            if name.lower().endswith(('.txt', '.md')):
                files.append(os.path.join(args.input, name))
    else:
        files.append(args.input)
    if not files:
        raise SystemExit('回答ファイルが見つかりません: %s' % args.input)

    moves, notes = [], []
    for path in files:
        for line in open(path, encoding='utf-8'):
            m = MOVE_RE.match(line.rstrip('\n'))
            if not m:
                continue
            kind, body = m.group(1), m.group(2)
            body = body.strip('`').strip()
            if kind == 'NOTE':
                notes.append(body)
            elif kind == 'PROMOTE':
                path_parts = [x.strip() for x in body.split('/') if x.strip()]
                if len(path_parts) < 2:
                    raise SystemExit('PROMOTE の書式が不正です(親からのパスを / で区切ってください): %s' % body)
                moves.append({'op': 'promote', 'path': path_parts})
            else:  # STAR
                if '->' not in body and '→' not in body:
                    raise SystemExit('STAR の書式が不正です(パス -> ラベル): %s' % body)
                sep = '->' if '->' in body else '→'
                left, label = body.split(sep, 1)
                path_parts = [x.strip() for x in left.split('/') if x.strip()]
                moves.append({'op': 'set_star', 'path': path_parts, 'label': label.strip()})
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump({'moves': moves}, f, ensure_ascii=False, indent=1)
        f.write('\n')
    print('moves %d件を %s に書き出しました(昇格%d / ★付け替え%d)'
          % (len(moves), args.output,
             sum(1 for m in moves if m['op'] == 'promote'),
             sum(1 for m in moves if m['op'] == 'set_star')))
    if notes:
        print('')
        print('適用しない指摘(NOTE)%d件:' % len(notes))
        for n in notes:
            print('  ・' + n)
    if not moves:
        print('(昇格の指示はありませんでした。ツリーの配置は問題なしという判定です)')


# ---------------------------------------------------------------- verify

def cmd_verify(args):
    text, _, _, root = load(args.tree)
    parse_tree(text)  # 構造エラーなら SystemExit
    # 同一段の完全同名チェック(統合しない方針のため、エラーではなく警告)
    for _, st in collect_stages(root):
        seen = {}
        for c in st.children:
            seen.setdefault(c.label, 0)
            seen[c.label] += 1
        for label, cnt in seen.items():
            if cnt > 1:
                print('⚠ 「%s」の配下に同名の「%s」が%d個あります(判定が曖昧になるため名前の変更を推奨)'
                      % (st.label, label, cnt))
    print('検証OK: %s' % args.tree)


def main():
    ap = argparse.ArgumentParser(description='分類ツリーの検査支援(カード列挙・昇格適用・検証)')
    sub = ap.add_subparsers(dest='cmd', required=True)
    p = sub.add_parser('cards', help='判定カードを深い階層から列挙')
    p.add_argument('-t', '--tree', default=DEFAULT_TREE)
    p.add_argument('-o', '--output')
    p.set_defaults(func=cmd_cards)
    p = sub.add_parser('apply', help='movesを適用した修正案を別ファイルに出力')
    p.add_argument('-m', '--moves', required=True)
    p.add_argument('-t', '--tree', default=DEFAULT_TREE)
    p.add_argument('-o', '--output', required=True)
    p.set_defaults(func=cmd_apply)
    p = sub.add_parser('verify', help='構造検証')
    p.add_argument('-t', '--tree', default=DEFAULT_TREE)
    p.set_defaults(func=cmd_verify)
    p = sub.add_parser('prompts', help='チャットAIに貼れる判定依頼ファイルを分割生成')
    p.add_argument('-t', '--tree', default=DEFAULT_TREE)
    p.add_argument('-o', '--output', help='出力先ディレクトリ(既定: ツリーと同じ場所の judge_prompts/)')
    p.add_argument('--per', type=int, default=5, help='1ファイルあたりのカード数(既定5)')
    p.set_defaults(func=cmd_prompts)
    p = sub.add_parser('collect', help='チャットAIの回答から moves.json を作る')
    p.add_argument('-i', '--input', required=True, help='回答を保存したファイル、またはディレクトリ')
    p.add_argument('-o', '--output', required=True)
    p.set_defaults(func=cmd_collect)
    args = ap.parse_args()
    args.func(args)


if __name__ == '__main__':
    main()
