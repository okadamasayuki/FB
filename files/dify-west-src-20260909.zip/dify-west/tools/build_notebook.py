#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Snowflakeノートブック版の採点 `契約書判定の採点.ipynb` を組み立てる。

  python3 tools/build_notebook.py

採点ロジックは `契約書判定の採点.py` をそのまま1セルに埋め込む(二重管理しない)。
.py を実行できない環境(Snowflakeノートブック等)向けに、手順のMarkdownセルと
設定セル・実行セルを付けた .ipynb にする。ロジックを直すときは .py 側を直して、
このスクリプトで作り直すこと。
"""
import io
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, '契約書判定の採点.ipynb')

MD_INTRO = '''# 契約書判定の採点(Snowflakeノートブック版)

契約書・決裁文書と正解(キャッシュの相手勘定となる勘定科目)を突き合わせて、
**3形式の判定アプリ(ツリー判定/コード2段選択/コード一発選択)の正答率を比較**するノートブックです。
`.py` を実行できない環境向けに、`契約書判定の採点.py` と同じロジックをセルに埋め込んであります。
**件数の上限はありません**(100決裁でも回ります。1決裁×1形式あたりAPI呼び出し3回ぶんの時間がかかります)。

## 使い方(上から順にセルを実行するだけ)

1. この下の **【準備】** を済ませる(最初の1回だけ)
2. **【設定】セル**の値を書き換える
3. すべてのセルを上から順に実行する → 最後に採点結果(Markdown)が表示され、`採点結果.md` に保存されます

---

## 【準備】最初の1回だけやること

### ① 判定アプリのAPIキーを発行する

- ③で作った判定アプリ(3形式)をDifyにインポートし、各アプリの**「APIアクセス」画面でAPIキー(`app-…`)を発行**します
- 同じ画面に表示される**APIサーバーのURL(`https://…/v1`)**も控えます(下の設定セルの `BASE_URL`)
- キーを入れた形式だけが採点されます(1形式だけでもOK)

### ② Snowflakeから社外(Difyのホスト)への通信許可(管理者に依頼)

Snowflakeのノートブックは、**そのままでは外部のURLにアクセスできません**。
管理者に **External Access Integration(外部アクセス統合)** の作成を依頼し、
このノートブックの設定(右上 ⋮ → Notebook settings → External access)で**その統合をONに**してください。

依頼文の例(`<Difyのホスト名>` は `https://` を除いたホスト名):

```sql
CREATE OR REPLACE NETWORK RULE dify_api_rule
  MODE = EGRESS TYPE = HOST_PORT
  VALUE_LIST = ('<Difyのホスト名>:443');

CREATE OR REPLACE EXTERNAL ACCESS INTEGRATION dify_api_integration
  ALLOWED_NETWORK_RULES = (dify_api_rule)
  ENABLED = TRUE;

GRANT USAGE ON INTEGRATION dify_api_integration TO ROLE <ノートブックを実行するロール>;
```

※ これが無いと、実行時に「接続できません」系のエラーになります。

### ③ 採点する決裁ファイルをSnowflakeに置く

Snowflakeは**共有フォルダを直接読めない**ため、決裁一式を**ZIPにしてステージにアップロード**します。

- フォルダの置き方(共有フォルダ版と同じ):

```
決裁一式/
  ├─ 案件001/ … 契約書.pdf・見積書.xlsx など複数ファイル可 + 正解.txt
  └─ 案件002/ … 決裁文書.docx + 正解.txt
```

- `正解.txt` の1行目に「科目名」または「科目名 [10桁コード]」(2行目以降はメモ扱い)
- この「決裁一式」フォルダを**ZIP**にし、Snowsight(Data → ステージ → Upload)か `PUT` コマンドでステージへ:

```sql
CREATE STAGE IF NOT EXISTS saiten_stage;
-- Snowsightの画面から 決裁一式.zip をアップロード(または PUT file://… @saiten_stage)
```

- 下の設定セルの `STAGE_ZIP` に `@saiten_stage/決裁一式.zip` のように書きます
- (Snowflake以外のJupyterで動かす場合は、`LOCAL_DIR` にフォルダパスを書けばステージ不要です)
'''

MD_CONFIG = '''## 【設定】ここだけ書き換えてください

- **`BASE_URL`** … DifyのAPIエンドポイント(例 `https://dify.example.com/v1`)
- **`KEYS`** … 形式ごとのAPIキー(`app-…`)。**空のままの形式はスキップ**されます
- **`STAGE_ZIP`** … ステージに置いたZIPのパス(例 `@saiten_stage/決裁一式.zip`)。
  Jupyter等でローカルフォルダを直接読む場合は `STAGE_ZIP` を空にして **`LOCAL_DIR`** にパスを書く
- `LIMIT` … 先頭から何決裁だけ採点するか(0=全件)。まず 2〜3 件で動作確認するのがおすすめ'''

CONFIG_CELL = '''# ====== 設定(ここだけ書き換える)======

BASE_URL = "https://dify.example.com/v1"   # DifyのAPIエンドポイント(…/v1)

KEYS = {
    "tree": "",   # ツリー判定形式のAPIキー(app-…)。使わない形式は空のまま
    "flat": "",   # コード2段選択形式のAPIキー(app-…)
    "pick": "",   # コード一発選択形式のAPIキー(app-…)
}

STAGE_ZIP = "@saiten_stage/決裁一式.zip"   # ステージ上のZIP(Snowflakeで実行する場合)
LOCAL_DIR = ""                             # ローカルフォルダを直接読む場合はこちら(STAGE_ZIPは空に)

LIMIT = 0        # 先頭から何決裁だけ採点するか(0=全件)
TIMEOUT = 300    # API1回あたりの待ち秒数
OUT_NAME = "採点結果.md"
'''

RUN_CELL = '''# ====== 実行(このセルは書き換え不要)======
import io as _io
import os as _os
import zipfile as _zipfile

# 1) 採点対象フォルダを用意(ステージのZIPを展開 or ローカルフォルダ)
if STAGE_ZIP.strip():
    _dl = "/tmp/saiten_dl"
    _ex = "/tmp/saiten_data"
    _os.makedirs(_dl, exist_ok=True)
    from snowflake.snowpark.context import get_active_session
    _session = get_active_session()
    _session.file.get(STAGE_ZIP.strip(), _dl)
    _zips = [f for f in _os.listdir(_dl) if f.lower().endswith(".zip")]
    if not _zips:
        raise SystemExit("■ ステージからZIPを取得できませんでした: %s" % STAGE_ZIP)
    if _os.path.exists(_ex):
        import shutil as _shutil
        _shutil.rmtree(_ex)
    with _zipfile.ZipFile(_os.path.join(_dl, _zips[0])) as _z:
        _z.extractall(_ex)
    # ZIP直下が1フォルダだけなら、その中を対象にする
    _entries = [e for e in _os.listdir(_ex) if not e.startswith("__MACOSX")]
    FOLDER = _os.path.join(_ex, _entries[0]) if len(_entries) == 1 and _os.path.isdir(_os.path.join(_ex, _entries[0])) else _ex
elif LOCAL_DIR.strip():
    FOLDER = LOCAL_DIR.strip()
else:
    raise SystemExit("■ STAGE_ZIP か LOCAL_DIR のどちらかを設定してください")

print("■ 採点対象フォルダ:", FOLDER)

# 2) 採点(上のセルで定義した関数をそのまま使う)
_base = BASE_URL.rstrip("/")
_keys = {k: (KEYS.get(k) or "").strip() for k, _ in FORMATS}
if not _base or not any(_keys.values()):
    raise SystemExit("■ BASE_URL と KEYS(1つ以上)を設定してください")

cases = collect_cases(FOLDER)
if not cases:
    raise SystemExit("■ 採点対象が見つかりません。サブフォルダに 文書+正解.txt を置いてください: %s" % FOLDER)
if LIMIT:
    cases = cases[:LIMIT]
used = [(k, l) for k, l in FORMATS if _keys[k]]
print("■ %d決裁 × %d形式(%s)を採点します(1決裁×1形式あたりAPI呼び出し3回)"
      % (len(cases), len(used), "・".join(l for _, l in used)))

results = []
for _i, _c in enumerate(cases):
    _row = {}
    for _k, _label in FORMATS:
        if not _keys[_k]:
            _row[_k] = ("skip", "")
            continue
        _answer, _err = run_one(_base, _keys[_k], _c["docs"], TIMEOUT)
        _row[_k] = grade(_answer, _err, _c["expect_name"], _c["expect_code"])
        print("  [%d/%d] %s / %s → %s" % (_i + 1, len(cases), _c["label"], _label, MARK[_row[_k][0]]))
    results.append(_row)

report = build_report(cases, _keys, results)
with _io.open(OUT_NAME, "w", encoding="utf-8") as _f:
    _f.write(report)
print("■ 保存しました:", OUT_NAME)

# 3) 結果を表示(+ステージ利用時はステージにも保存)
if STAGE_ZIP.strip():
    try:
        _stage = STAGE_ZIP.strip().rsplit("/", 1)[0]
        _session.file.put(OUT_NAME, _stage, auto_compress=False, overwrite=True)
        print("■ ステージにも保存しました:", _stage + "/" + OUT_NAME)
    except Exception as _e:
        print("(ステージへの保存はスキップ:", _e, ")")

try:
    from IPython.display import Markdown, display
    display(Markdown(report))
except Exception:
    print(report)
'''

MD_TAIL = '''## 結果の見方と、次にやること

- **正答率の比較表** … いちばん高い形式が、自社の決裁でいちばん当たる形式です
- **誤答一覧** … そのまま判定アプリのチャットに貼って
  「この誤答をなくすには、どの環境変数にどんな行を追記すべきか。コピペできる形で提案して」と続けると、追記文を作ってくれます
- **学習の書き込み先**(すべてDifyの「アプリ設定 → 環境変数」。再インポート不要・即反映)
  - どの形式にも効く: `accounting_policy` に「◯◯のような契約は「正解科目」に分類する」を1行
  - ツリー判定: `rules_*` の該当行 / コード2段選択: `codes10_list`(7桁違いは `codes7_list`)/ コード一発選択: `codes_list`
  - 正解科目がどの候補一覧にも無い: 分類ツリーに科目を足して③で再生成
- 追記したら、**もう一度このノートブックを実行**して正答率が上がったか確認してください(効果は保証ではありません)

## うまく動かないとき

- **「接続できません」「Network is unreachable」系** … External Access Integration が未設定/ノートブックでONになっていません(上の【準備】②)
- **「ステージからZIPを取得できません」** … `STAGE_ZIP` のパス(`@ステージ名/ファイル名.zip`)を確認。Snowsightのステージ画面でファイルがあるか確認
- **HTTP 401/403** … APIキー(`app-…`)の貼り間違い。**ナレッジのキー(dataset-…)ではなくアプリのキー**です
- **スキャンPDFの読み取り** … 実際の使い方と同じ「ファイル添付→OK」の2ターンで呼ぶため、AIモデルが対応していればスキャンPDFも採点できます
'''


def cell(kind, src):
    c = {'cell_type': kind, 'metadata': {}, 'source': src.splitlines(keepends=True)}
    if kind == 'code':
        c['execution_count'] = None
        c['outputs'] = []
    return c


def main():
    scorer = io.open(os.path.join(ROOT, '契約書判定の採点.py'), encoding='utf-8').read()
    # ノートブックのセルでは __name__ == '__main__' になるため、CLI実行の入口は取り除く
    guard = "if __name__ == '__main__':\n    main()\n"
    if guard not in scorer:
        raise SystemExit('契約書判定の採点.py の __main__ ガードが見つかりません(形が変わったら追従してください)')
    scorer = scorer.replace(guard, '')
    scorer_cell = ('# ====== 採点プログラム本体(書き換え不要。契約書判定の採点.py と同一)======\n'
                   '# ※ このセルは tools/build_notebook.py が自動で埋め込んでいます\n\n' + scorer.rstrip('\n') + '\n')
    nb = {
        'cells': [
            cell('markdown', MD_INTRO),
            cell('markdown', MD_CONFIG),
            cell('code', CONFIG_CELL),
            cell('code', scorer_cell),
            cell('code', RUN_CELL),
            cell('markdown', MD_TAIL),
        ],
        'metadata': {
            'kernelspec': {'display_name': 'Python 3', 'language': 'python', 'name': 'python3'},
            'language_info': {'name': 'python', 'version': '3.9'},
        },
        'nbformat': 4,
        'nbformat_minor': 5,
    }
    io.open(OUT, 'w', encoding='utf-8').write(json.dumps(nb, ensure_ascii=False, indent=1))
    print('written %s (%.0f KB)' % (os.path.basename(OUT), os.path.getsize(OUT) / 1024.0))


if __name__ == '__main__':
    main()
