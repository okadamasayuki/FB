// ============================================================ ⑤の台本(2本): 自動学習の流れ(操作と裏側) / 仕組みの解説
// 共通エンジン(demo_player.js)の上で動く。build_learn_page.py がビルド時にトークン置換で埋め込む。
var LD_TOOL = "https://okadamasayuki.github.io/kanjo-tool/";
var LD_KEY = "app-Q8fR2tY7uE1oP4aL";
var LD_DSKEY = "dataset-Kx9mQ2vL8pR4tW7yB1nC3dF6";
var LD_DSID = "3f2a9c1e-7b4d-4e2a-9c1f-0a8b7d6e5f43";
// 例として6決裁(学習5件 + 検証1件=末尾の案件006)
var LD_CASES = [["案件001_金銭消費貸借", "預金 [1010003001]"], ["案件002_事務所賃貸借", "賃借料 [5030001001]"],
                ["案件003_保守委託", "支払手数料 [5030002001]"], ["案件004_設備リース", "リース料 [5030009001]"],
                ["案件005_業務委託", "外注費 [5030003001]"], ["案件006_駐車場賃貸借", "賃借料 [5030001001]"]];

// ---- ⑤ページの画面もどき(見せたいカードだけ濃く表示)
function ldCard(title, inner, on, id){
  return '<div' + (id ? ' id="' + id + '"' : "") + ' style="background:#fff;border:1px solid var(--line);border-radius:10px;padding:8px 10px;margin-bottom:6px'
    + (on ? "" : ";opacity:.5") + '"><b>' + title + '</b>' + (inner ? '<div style="margin-top:4px">' + inner + '</div>' : "") + '</div>';
}
function ldTable(head, rows, id){
  return '<table class="dvy-table" style="margin-top:4px"' + (id ? ' id="' + id + '"' : "") + '><tr>' + head.map(function(h){ return "<th>" + h + "</th>"; }).join("") + "</tr>"
    + rows.map(function(r, i){ return '<tr id="' + (id || "t") + '-r' + i + '">' + r.map(function(c){ return "<td>" + c + "</td>"; }).join("") + "</tr>"; }).join("") + "</table>";
}
function ldBar(pct, color){
  return '<div style="height:7px;border-radius:3px;background:#e4e7ec;margin-top:3px;width:150px"><div style="height:7px;border-radius:3px;background:' + (color || "var(--accent)") + ';width:' + pct + '%"></div></div>';
}
// curve: [{ep, tr, va, miss}]
function ldCurve(curve){
  return ldTable(["エポック", "学習正答率", "検証正答率", "誤答(学習対象)"], curve.map(function(e){
    return [e.ep, "<b>" + e.tr + "%</b>" + ldBar(e.tr), e.va === null ? "-" : e.va + "%", e.miss];
  }), "dv-l-curvetbl");
}
// marks: {label: "○"/"×"/"…"/""}, taught: {label: n}
function ldDetail(marks, taught){
  marks = marks || {}; taught = taught || {};
  return ldTable(["#", "決裁", "区分", "正解", "結果", "教えた回数"], LD_CASES.map(function(c, i){
    var kind = i === 5 ? '<span class="dvd-tag va">検証</span>' : '<span class="dvd-tag">学習</span>';
    return [i + 1, c[0], kind, c[1], '<b>' + (marks[c[0]] || "") + "</b>", taught[c[0]] || 0];
  }), "dv-l-detailtbl");
}
function ldLedger(rows){ return ldTable(["決裁", "教えた回数", "カードID"], rows, "dv-l-ledgertbl"); }

function scrLearn(st){
  st = st || {};
  var view = st.view || "conn";
  var h = '<div style="padding:10px 14px;background:#f6f7f9;min-height:100%;box-sizing:border-box;font-size:12px">'
    + '<div class="dvy-h" style="margin-bottom:6px">⑤ 自動学習 — 誤答を教えて正答率を上げるループ(このページ)</div>';
  if(view === "conn"){
    h += ldCard("4. 接続設定",
      '<div style="display:grid;grid-template-columns:120px 1fr;gap:3px 8px;align-items:center;max-width:540px">'
      + '<span>APIサーバー(…/v1)</span>' + dvInput("dv-l-url", st.url, "https://dify.example.com/v1", "min-height:24px")
      + '<span>アプリの形式</span><span>● コード一発選択形式 ○ ツリー判定形式 ○ コード2段選択形式</span>'
      + '<span>判定アプリのキー</span>' + dvInput("dv-l-key", st.key, "app-…(③で自己学習にチェックを入れたアプリ)", "min-height:24px")
      + '<span>ナレッジAPIキー</span>' + dvInput("dv-l-dskey", st.dskey, "dataset-…(カードの差し替えに使用)", "min-height:24px")
      + '<span>事例ナレッジのID</span>' + dvInput("dv-l-dsid", st.dsid, "URLの /datasets/ のあとの英数字", "min-height:24px") + '</div>'
      + '<div style="margin-top:6px"><span class="dvy-btn ghost" id="dv-l-test">接続テスト</span> <span style="color:#666">☐ URLとキーをこのブラウザに保存する</span></div>'
      + '<div id="dv-l-testout" style="color:#0f6b3f;margin-top:4px;min-height:18px">' + (st.test || "") + '</div>', true)
      + ldCard("5. 決裁フォルダを入れる", "", false) + ldCard("6. 学習を実行", "", false);
  }else if(view === "folder"){
    h += ldCard("4. 接続設定", '<span style="color:#0f6b3f">判定アプリ: ✅ 接続OK / 事例ナレッジ: ✅ 接続OK</span>', false)
      + ldCard("5. 決裁フォルダを入れる",
        '<div id="dv-l-drop" style="border:2px dashed #b6bdc6;border-radius:8px;padding:12px;text-align:center;background:#fbfcfe"><b>ここに「元データ」フォルダをドラッグ&amp;ドロップ</b><br>'
        + '<span style="font-size:11px;color:#666">④と同じ構成(サブフォルダ=1決裁、中に決裁書類(複数可)+正解.txt)。ファイルはまだどこにも送られません</span></div>'
        + '<div id="dv-l-summary" style="margin-top:6px;min-height:18px">' + (st.summary || "") + '</div>', true)
      + ldCard("6. 学習を実行", "", false);
  }else{
    h += ldCard("6. 学習を実行",
      '<div id="dv-l-opts">目標の正答率 <span class="dvy-chip" id="dv-l-target">' + (st.target || "100") + '</span> % / 最大 <span class="dvy-chip" id="dv-l-maxep">' + (st.maxep || "5") + '</span> エポック / '
      + '<span class="dvy-chip" id="dv-l-pat">' + (st.pat || "1") + '</span> エポック改善なしで早期終了<br>'
      + '検証用の取り分け <span class="dvy-chip" id="dv-l-hold">' + (st.hold || "20") + '</span> % / 先頭から <span class="dvy-chip" id="dv-l-limit">' + (st.limit || "0") + '</span> 決裁だけ(0=全件) / 並列 <span class="dvy-chip">3</span></div>'
      + '<div style="margin-top:6px"><span class="dvy-btn" id="dv-l-run">' + (st.runLabel || "学習を開始") + '</span> <span class="dvy-btn ghost">停止</span> <span class="dvy-btn ghost" id="dv-l-dl">自動学習レポート.md を保存</span></div>'
      + '<div id="dv-l-prog" style="color:#666;margin-top:4px;min-height:18px">' + (st.prog || "") + '</div>', true);
    if(st.curve) h += '<div style="background:#fff;border:1px solid var(--line);border-radius:10px;padding:8px 10px;margin-bottom:6px" id="dv-l-curve"><b>学習曲線(エポックごとの正答率)</b>' + ldCurve(st.curve) + '</div>';
    if(st.marks) h += '<div style="background:#fff;border:1px solid var(--line);border-radius:10px;padding:8px 10px;margin-bottom:6px" id="dv-l-detail"><b>最新エポックの明細</b>' + ldDetail(st.marks, st.taught) + '</div>';
    if(st.ledger) h += '<div style="background:#fff;border:1px solid var(--line);border-radius:10px;padding:8px 10px;margin-bottom:6px" id="dv-l-ledger"><b>事例カードの台帳(1決裁=1カード)</b>' + ldLedger(st.ledger) + '</div>';
    if(st.report) h += '<pre id="dv-l-report" style="background:#f2f4f7;border:1px solid var(--line);border-radius:6px;padding:8px;font-size:11px;line-height:1.5;white-space:pre-wrap;margin:0">' + esc(st.report) + '</pre>';
  }
  return h + '</div>';
}
// 裏側: ⑤が自動で呼んでいる判定アプリの会話
function scrLearnChat(title, msgs){
  return dvNav("スタジオ") + '<div style="height:30px;background:#fff;border-bottom:1px solid var(--line);display:flex;align-items:center;padding:0 12px;font-size:12px"><b>契約書 相手勘定判定(一発選択)</b><span style="color:#888;margin-left:8px">' + title + '</span></div>'
    + '<div class="dvy-chat" style="height:calc(100% - 74px);overflow:hidden">'
    + msgs.map(function(m){ return '<div class="dvy-msg' + (m.me ? " me" : "") + '"' + (m.id ? ' id="' + m.id + '"' : "") + '>' + m.html + '</div>'; }).join("") + '</div>';
}
var LD_MSG_ATTACH = {me: true, html: '📎 賃貸借契約書.pdf / 見積書.xlsx <span style="color:#666">(⑤が添付。本文は「.」だけ)</span>'};
var LD_MSG_READ = {html: '読み取りました。<b>🎯 一言でいうと</b>: 事務所を借りて毎月賃料を払う契約です。…(認識確認)<br><span style="color:#666">OK と返信してください。</span>'};
var LD_MSG_OK = {me: true, html: 'OK <span style="color:#666">(⑤が自動返信)</span>'};
var LD_MSG_WRONG = {id: "dv-c-wrong", html: '<b>相手勘定(科目)</b>: 借入金 / <b>確定コード</b>: 2010001001<br><span style="color:#666">判定経路・理由・根拠の仕訳 …</span>'};
var LD_MSG_TEACH = {me: true, id: "dv-c-teach", html: '正解: 賃借料 [5030001001] <span style="color:#666">(⑤が自動返信)</span>'};
var LD_MSG_SAVED = {id: "dv-c-saved", html: '✅ 正解を事例ナレッジに保存しました(HTTP 200)。次回から、似た契約の判定前に自動で検索して参考にします。<br>'
  + '<span style="color:#666">【判定事例】契約の種類: 事務所賃貸借契約 / 当社の立場: 借主 / 間違えやすい判定: 借入金 / 正解: 賃借料 [5030001001] / 決め手: 物件を借りて毎月賃料を払う → 賃借料</span>'};
var LD_MSG_RETEACH = {me: true, id: "dv-c-reteach", html: '正解: リース料 [5030009001]<br><span style="color:#444">(前回のカードでは「賃借料」と誤答したままでした。次は必ずこの正解を選べるよう、この契約を見分ける決め手を具体的に書き直してください)</span>'};
var LD_MSG_RESAVED = {id: "dv-c-resaved", html: '✅ 正解を事例ナレッジに保存しました(HTTP 200)。<br><span style="color:#666">【判定事例】契約の種類: 設備リース契約 / 間違えやすい判定: 賃借料(賃貸借と混同) / 正解: リース料 / 決め手: <b>リース会社との契約で、リース期間・リース料の定めがある → リース料(賃貸借の賃料ではない)</b></span>'};

// ---- 図解用の画面
function scrFlow(hl, note){
  function box(id, t, sub, on){ return '<div class="dvd-box' + (on ? " on" : "") + '" id="' + id + '">' + t + '<small>' + sub + '</small></div>'; }
  function arrow(t, sub){ return '<div class="dvd-arrow">' + t + '<small>' + sub + '</small></div>'; }
  return '<div class="dvd-wrap"><b style="font-size:14px">⑤が動かしているもの(3つ)</b>'
    + '<div class="dvd-flow">' + box("dv-f-page", "⑤ 自動学習ページ", "決裁フォルダを持っている(このページ)", hl === 0)
    + arrow("⇄", "決裁を添付して判定<br>誤答に「正解: ◯◯」") + box("dv-f-app", "判定アプリ(Dify)", "③で「自己学習」入りで作ったもの", hl === 1)
    + arrow("⇄", "似た事例を検索<br>カードを保存") + box("dv-f-kb", "事例ナレッジ", "判定事例カードの保管庫(Difyのナレッジ)", hl === 2) + '</div>'
    + '<div style="text-align:center;color:#666;font-size:12px">⑤ → 事例ナレッジ: カードの一覧と削除も直接行う(1決裁=1カードの差し替えのため)</div>'
    + '<div class="dvy-empty" style="margin-top:14px;text-align:left;color:#333">' + note + '</div></div>';
}
function scrLoop(on){
  function box(t, sub, k){ return '<div class="dvd-box' + (on === k ? " on" : "") + '" style="min-width:170px">' + t + '<small>' + sub + '</small></div>'; }
  return '<div class="dvd-wrap"><b style="font-size:14px">1周(=1エポック)でやること</b>'
    + '<div class="dvd-flow">' + box("① 全決裁をテスト", "④のブラウザ採点と同じ手順で判定", 0) + '<div class="dvd-arrow">→</div>'
    + box("② 誤答だけに正解を教える", "同じ会話に「正解: ◯◯」→ カード保存", 1) + '<div class="dvd-arrow">→</div>'
    + box("③ また全決裁をテスト", "教えていない決裁も含めて測り直す", 2) + '</div>'
    + '<div style="text-align:center;font-size:13px;margin-top:6px">↺ 目標の正答率に届くか、改善が止まるまで繰り返す(既定は最大5周)</div>'
    + '<div class="dvy-empty" style="margin-top:12px;text-align:left;color:#333">1周ごとに「学習正答率」と「検証正答率」を記録するので、伸びていく様子(例: 60% → 80% → 100%)が学習曲線として見えます。'
    + '正答率が上がったかどうかを毎周ちゃんと測る、というのが機械学習の標準的な回し方です。</div></div>';
}
function scrCompare(){
  return '<div class="dvd-wrap"><b style="font-size:14px">なぜ「間違えた1件を合うまで直し続ける」やり方にしないのか</b>'
    + '<div class="dvd-two"><div class="dvd-ng"><h4>✖ 1件に粘る方式</h4><ul>'
    + '<li>その1件専用の説明になりやすい(<b>過学習</b>=手元の例に合わせ込みすぎ)</li>'
    + '<li>直している間に<b>他の決裁を壊しても気づけない</b></li>'
    + '<li>「直ったか」は結局、全件でもう一度測らないと分からない</li></ul></div>'
    + '<div class="dvd-ok"><h4>◯ 全件を1周ずつ回す方式(⑤)</h4><ul>'
    + '<li>誤答には<b>1周に1回だけ</b>教えて次へ進む</li>'
    + '<li>周の終わりに<b>全件で正答率を測る</b>ので、悪化にも気づける</li>'
    + '<li>目標到達・改善なしで<b>早めに止める</b>(機械学習の標準)</li></ul></div></div>'
    + '<div class="dvy-empty" style="margin-top:12px;text-align:left;color:#333">同じ1件を何度も教え込むより、全体を見ながら少しずつ育てるほうが、初めて見る契約にも効く「本物の学習」になります。</div></div>';
}
// points: [{ep, tr, va}] / 高さは%そのまま
function scrCurveChart(points, note){
  var cols = points.map(function(p){
    return '<div class="dvd-col"><div class="bars">'
      + '<div class="dvd-colbar" style="height:' + p.tr + '%"><b>' + p.tr + '%</b></div>'
      + (p.va === null ? "" : '<div class="dvd-colbar va" style="height:' + Math.max(p.va, 1) + '%"><b>' + p.va + '%</b></div>')
      + '</div><div class="lbl">エポック' + p.ep + '</div></div>';
  }).join("");
  return '<div class="dvd-wrap"><b style="font-size:14px">学習曲線(エポックごとの正答率)</b>'
    + '<div class="dvd-chart" id="dv-chart"><div class="dvd-target" style="bottom:100%">目標 100%</div>' + cols + '</div>'
    + '<div class="dvd-legend"><i style="background:#155eef"></i>学習正答率(教えた決裁で測った数字) <i style="background:#0f6b3f"></i>検証正答率(教えていない決裁=初見の実力)</div>'
    + '<div class="dvy-empty" style="margin-top:10px;text-align:left;color:#333">' + note + '</div></div>';
}
function scrCardReplace(stage){
  var v1 = '<div class="dvd-card' + (stage >= 2 ? " old" : "") + '" id="dv-card1"><b>【判定事例】</b>(1回目)<br>契約の種類: 設備リース契約<br>正解: リース料 [5030009001]<br>決め手: 設備を借りて月額を払う契約 → リース料</div>';
  var v2 = '<div class="dvd-card" id="dv-card2" style="border-color:#0f6b3f;background:#f0faf4"><b>【判定事例】</b>(作り直し)<br>契約の種類: 設備リース契約<br><b>間違えやすい判定: 賃借料(賃貸借と混同)</b><br>正解: リース料 [5030009001]<br>決め手: <b>リース会社との契約で、リース期間・リース料の定めがある → リース料(賃貸借の賃料ではない)</b></div>';
  return '<div class="dvd-wrap"><b style="font-size:14px">同じ決裁をまた間違えたら: 1決裁=1カードの差し替え</b>'
    + '<div style="display:flex;align-items:center;gap:12px;justify-content:center;margin-top:14px">' + v1
    + (stage >= 2 ? '<div class="dvd-arrow">→<small>削除して<br>作り直し</small></div>' + v2 : "") + '</div>'
    + '<div class="dvy-empty" style="margin-top:12px;text-align:left;color:#333">'
    + (stage >= 2
       ? '⑤は「前回のカードでは賃借料と誤答したままだった」という情報を添えて正解を送り直します。アプリは<b>見分けの決め手を書き直した</b>カードを作り、⑤は前のカードをナレッジAPIで削除しておくので、カードは増えずに磨かれていきます。'
       : '1回目のカードの決め手が弱いと、次のエポックでも同じ決裁を間違えることがあります(例: 賃貸借と混同して「賃借料」)。') + '</div></div>';
}
function scrHoldout(){
  var tags = LD_CASES.map(function(c, i){ return '<span class="dvd-tag' + (i === 5 ? " va" : "") + '">' + c[0].split("_")[0] + (i === 5 ? "(検証)" : "") + '</span>'; }).join("");
  return '<div class="dvd-wrap"><b style="font-size:14px">検証用の取り分け(ホールドアウト)</b>'
    + '<div style="margin-top:10px;text-align:center">' + tags + '</div>'
    + '<div class="dvd-two"><div><h4>学習(教える側)</h4>間違えたら「正解: ◯◯」を教えて、カードを作ります。<br>ここで測った正答率は<b>「教えた後」の数字</b>です(上がって当然)。</div>'
    + '<div class="dvd-ok"><h4>検証(教えない側)</h4>一覧の末尾から取り分け、<b>一度も正解を教えません</b>。<br>ここが上がれば、カードが<b>初めて見る契約にも効いている</b>=本物の学習です。</div></div>'
    + '<div class="dvy-empty" style="margin-top:10px;text-align:left;color:#333">同じ決裁で100%になっても「教えたから当たる」だけかもしれません。推奨は20%を検証に回すこと(機械学習の標準的な作法です)。決裁が多いほど、この物差しは正確になります。</div></div>';
}
function scrStop(){
  function row(ic, t, sub, id){ return '<div class="dvd-row" id="' + id + '"><div class="ic">' + ic + '</div><div><b>' + t + '</b><br><span style="color:#555">' + sub + '</span></div></div>'; }
  return '<div class="dvd-wrap"><b style="font-size:14px">自動で止まる条件(どれか1つで終了)</b>'
    + row("🎯", "目標の正答率に到達(既定 100%)", "学習正答率が目標に届いたら、それ以上は教えません", "dv-s1")
    + row("⏹", "改善が止まった(既定: 1エポック改善なしで早期終了)", "前の周より上がらなければ止める=手元の決裁に合わせ込みすぎる<b>過学習</b>を防ぐ", "dv-s2")
    + row("🔁", "最大エポックに到達(既定 5周)", "時間とAPI呼び出しの上限。100決裁×5周は数時間かかるので、まず2〜3決裁で試走", "dv-s3")
    + '</div>';
}
function scrScope(){
  return '<div class="dvd-wrap"><b style="font-size:14px">自動でできる範囲と、人がやること</b>'
    + '<div class="dvd-two"><div class="dvd-ok"><h4>⑤が自動でやる</h4><ul><li>全決裁のテストと正答率の計測(学習/検証)</li><li>誤答への「正解: ◯◯」返信 → 事例カードの作成</li><li>同じ決裁の再誤答 → カードの削除と作り直し</li><li>学習曲線・明細・台帳・レポート(.md)</li></ul></div>'
    + '<div><h4>人がやる(APIでは書き換えられない)</h4><ul><li>アプリの環境変数への追記(<code>accounting_policy</code> / <code>rules_*</code> / <code>codes_list</code>)</li><li>分類ツリーの修正 → ③で作り直し</li><li>検証正答率を見て「本物か」を判断</li></ul></div></div>'
    + '<div class="dvy-empty" style="margin-top:10px;text-align:left;color:#333">カードで直りきらない誤答は、レポートの「📌 まだ間違える決裁(次の一手)」に、どの環境変数へ何を書けばよいかの提案として出ます。そこから先は手動です。</div></div>';
}

// ---- 台本1: 自動学習の流れ(操作と裏側)
var LD_M1 = {"案件001_金銭消費貸借": "○", "案件002_事務所賃貸借": "×", "案件003_保守委託": "○", "案件004_設備リース": "×", "案件005_業務委託": "○", "案件006_駐車場賃貸借": "×"};
var LD_M2 = {"案件001_金銭消費貸借": "○", "案件002_事務所賃貸借": "○", "案件003_保守委託": "○", "案件004_設備リース": "×", "案件005_業務委託": "○", "案件006_駐車場賃貸借": "○"};
var LD_M3 = {"案件001_金銭消費貸借": "○", "案件002_事務所賃貸借": "○", "案件003_保守委託": "○", "案件004_設備リース": "○", "案件005_業務委託": "○", "案件006_駐車場賃貸借": "○"};
var LD_T1 = {"案件002_事務所賃貸借": 1, "案件004_設備リース": 1};
var LD_T2 = {"案件002_事務所賃貸借": 1, "案件004_設備リース": 2};
var LD_C1 = [{ep: 1, tr: 60, va: 0, miss: 2}];
var LD_C2 = [{ep: 1, tr: 60, va: 0, miss: 2}, {ep: 2, tr: 80, va: 100, miss: 1}];
var LD_C3 = [{ep: 1, tr: 60, va: 0, miss: 2}, {ep: 2, tr: 80, va: 100, miss: 1}, {ep: 3, tr: 100, va: 100, miss: 0}];
var LD_LEDGER1 = [["案件002_事務所賃貸借", "1", "doc-1"], ["案件004_設備リース", "1", "doc-2"]];
var LD_LEDGER2 = [["案件002_事務所賃貸借", "1", "doc-1"], ["案件004_設備リース", "2(差し替え済み)", "doc-3"]];
var LD_REPORT = "# 自動学習レポート(エポック学習・ブラウザ版)\n- アプリ形式: コード一発選択形式(③の「自己学習」チェック入り)\n- 決裁: 学習 5件 + 検証 1件(検証は一覧の末尾からの取り分けで、学習には使いません)\n- 停止条件: 目標 100% / 最大 5エポック / 1エポック改善なしで早期終了\n\n## 📈 学習曲線\n| エポック | 学習正答率 | 検証正答率 | 誤答 | 教えた決裁 |\n|---|---|---|---|---|\n| 1 | **60%** | 0% | 2 | 2 |\n| 2 | **80%** | 100% | 1 | 1 |\n| 3 | **100%** | 100% | 0 | 0 |\n\n**停止理由: 🎯 目標の正答率(100%)に到達しました**\n\n## 🗂 事例カードの台帳 … / ## 📌 まだ間違える決裁(次の一手) … / ## ⚠️ この数字の読み方(正直な注意) …";
var LD_MSGS_JUDGE = [LD_MSG_ATTACH, LD_MSG_READ, LD_MSG_OK, LD_MSG_WRONG];
var LD_MSGS_TEACH = [LD_MSG_OK, LD_MSG_WRONG, LD_MSG_TEACH, LD_MSG_SAVED];
var LD_MSGS_RETEACH = [{me: true, html: 'OK <span style="color:#666">(⑤が自動返信・エポック2)</span>'}, {html: '<b>相手勘定(科目)</b>: 賃借料 / <b>確定コード</b>: 5030001001 <span style="color:#b42318">(まだ誤答。正解はリース料)</span>'}, LD_MSG_RETEACH, LD_MSG_RESAVED];

var LEARN_DEMO_FLOW = {name: "自動学習の流れ(操作と裏側)",
  idle: "上の「▶ 再生」で始まります。<br>接続設定 → フォルダを入れる → 学習を開始 → エポックが進むごとに「裏側でDifyに何をしているか」も交互に見せます(約2分)。",
  steps: [
  {title: "前提: ③で「自己学習」入りのアプリと、事例ナレッジ",
   body: "⑤が動かすのは、③で「自己学習を入れる」にチェックして作った判定アプリ(1形式でよい)と、そのアプリが使う事例ナレッジです。作り方は③の動画で通しで見られます。③の既定(環境変数 learned_cases 方式)で作ったアプリならナレッジは不要で、この動画のナレッジ側の場面は仮ナレッジ(⑤のブラウザ内)に置き換わります。",
   url: LD_TOOL, t: 6200,
   render: function(){ return scrFlow(-1, "この動画では例として<b>6決裁</b>(学習5件+検証1件)を使います。実際は100決裁でも流れは同じです。"); },
   act: function(){ dvCur(50, 30); dvHl("dv-f-app", 600); dvHl("dv-f-kb", 1500); }},
  {title: "⑤の接続設定: URL・形式・判定アプリのキー",
   body: "④の接続設定と同じURL。形式は1つ(3形式を同時に学習させることはしません)。キーは③で自己学習にチェックを入れて作ったアプリのものです。",
   url: LD_TOOL, t: 6600,
   render: function(){ return scrLearn({view: "conn"}); },
   act: function(){ dvCurTo("dv-l-url", 300); dvType("dv-l-url", DV_HOST + "/v1", 700, 26); dvCurTo("dv-l-key", 2600); dvType("dv-l-key", LD_KEY, 2900, 30); }},
  {title: "ナレッジAPIキーと事例ナレッジのID(カードの差し替えに使う)",
   body: "⑤は同じ決裁をまた間違えたとき、前回のカードを消して作り直します。その削除と「保存できたか」の確認に、ナレッジ側の鍵(dataset-…)と住所(ID)が要ります。③の設定込み欄に入れたのと同じ値です。鍵が作れない場合や、③の既定(環境変数方式)のアプリでは、この2つを空欄にすると、カードをブラウザに溜める仮ナレッジモードになります(最後に 判定事例.txt を環境変数 learned_cases に貼ります)。",
   url: LD_TOOL, t: 7200,
   render: function(){ return scrLearn({view: "conn", url: DV_HOST + "/v1", key: LD_KEY}); },
   act: function(){ dvCurTo("dv-l-dskey", 300); dvType("dv-l-dskey", LD_DSKEY, 700, 28); dvCurTo("dv-l-dsid", 2800); dvType("dv-l-dsid", LD_DSID, 3100, 22); }},
  {title: "「接続テスト」→ 判定アプリ ✅ / 事例ナレッジ ✅",
   body: "アプリだけでなく、ナレッジ側(カードの一覧と削除に使う)にも届くかを確かめます。ナレッジAPIキーが未入力なら「仮ナレッジモード」と表示されます。",
   url: LD_TOOL, t: 5000,
   render: function(){ return scrLearn({view: "conn", url: DV_HOST + "/v1", key: LD_KEY, dskey: LD_DSKEY, dsid: LD_DSID}); },
   act: function(){ dvCurTo("dv-l-test", 300); dvClick(1000); dvPatch("dv-l-testout", "判定アプリ: ✅ 接続OK<br>事例ナレッジ: ✅ 接続OK(カードの一覧と削除に使えます)", 1700); }},
  {title: "決裁フォルダをドラッグ&ドロップ(④と同じ構成)",
   body: "サブフォルダ=1決裁(中に決裁書類+正解.txt)。この時点ではまだどこにも送られません。",
   url: LD_TOOL, t: 5600,
   render: function(){ return scrLearn({view: "folder"}); },
   act: function(){ dvHl("dv-l-drop", 300); dvCur(20, 80); dvCurTo("dv-l-drop", 900); dvClick(1600);
     dvPatch("dv-l-summary", "<b>6決裁</b>(文書 14ファイル)を読み取りました。まだ送信していません。「学習を開始」で開始します。", 2300); dvHl("dv-l-summary", 2400); }},
  {title: "学習の設定: 目標100%・最大5エポック・改善なし1・検証20%",
   body: "検証20% → 一覧の末尾の1決裁(案件006)が「教えない側」に取り分けられ、初見の実力を測る物差しになります。最初は「先頭から2〜3決裁だけ」で試走するのがおすすめです。",
   url: LD_TOOL, t: 7000,
   render: function(){ return scrLearn({view: "run"}); },
   act: function(){ dvCurTo("dv-l-target", 300); dvHl("dv-l-target", 600); dvCurTo("dv-l-maxep", 1500); dvHl("dv-l-maxep", 1800);
     dvCurTo("dv-l-pat", 2700); dvHl("dv-l-pat", 3000); dvCurTo("dv-l-hold", 3900); dvHl("dv-l-hold", 4200); }},
  {title: "「学習を開始」→ エポック1: 全決裁をテスト",
   body: "1決裁ずつ判定アプリを呼び、正解と突き合わせます(④のブラウザ採点と同じ採点基準)。検証の案件006も測ります。",
   url: LD_TOOL, t: 7400,
   render: function(){ return scrLearn({view: "run", prog: "", marks: {}}); },
   act: function(){ dvCurTo("dv-l-run", 300); dvClick(1000);
     dvPatch("dv-l-prog", "エポック1/5: テスト中… 0 / 6 決裁", 1300);
     dvPatch("dv-l-detail", "<b>最新エポックの明細</b>" + ldDetail({"案件001_金銭消費貸借": "…", "案件002_事務所賃貸借": "…", "案件003_保守委託": "…"}), 1400);
     dvPatch("dv-l-prog", "エポック1/5: テスト中… 3 / 6 決裁", 3200);
     dvPatch("dv-l-detail", "<b>最新エポックの明細</b>" + ldDetail({"案件001_金銭消費貸借": "○", "案件002_事務所賃貸借": "×", "案件003_保守委託": "○", "案件004_設備リース": "…", "案件005_業務委託": "…", "案件006_駐車場賃貸借": "…"}), 3300);
     dvPatch("dv-l-prog", "エポック1/5: テスト中… 6 / 6 決裁", 5200);
     dvPatch("dv-l-detail", "<b>最新エポックの明細</b>" + ldDetail(LD_M1), 5300); }},
  {title: "裏側: 1決裁ずつ、判定アプリをAPIで呼んでいる",
   body: "④のブラウザ採点と同じ手順(添付 → 「OK」 → 回答)。案件002は「借入金」と誤答しました(正解は賃借料)。この会話は次の「教える」ステップでそのまま使います。",
   url: DV_HOST + "/chat/2b7e4c9a", t: 6400,
   render: function(){ return scrLearnChat("案件002 の判定(⑤が自動で呼んでいる会話)", LD_MSGS_JUDGE); },
   act: function(){ dvCur(60, 70); dvHl("dv-c-wrong", 900); }},
  {title: "エポック1の結果: 学習 60% / 検証 0% → 目標未達なので学習へ",
   body: "学習5件のうち3件正解(60%)。誤答は案件002と案件004の2件。検証の案件006も誤答ですが、検証には教えません。",
   url: LD_TOOL, t: 6600,
   render: function(){ return scrLearn({view: "run", prog: "エポック1/5: テスト完了 → 誤答 2件に学習します", curve: LD_C1, marks: LD_M1}); },
   act: function(){ dvHl("dv-l-curvetbl-r0", 500); dvCurTo("dv-l-curvetbl-r0", 400); dvHl("dv-l-detailtbl-r1", 1600); dvHl("dv-l-detailtbl-r3", 1900); }},
  {title: "裏側: 誤答の決裁の同じ会話に「正解: ◯◯」を自動返信",
   body: "判定に使った会話の続きに「正解: 賃借料 [5030001001]」を送ると、アプリが会話の内容から判定事例カード(契約の種類・間違えやすい判定・決め手)を1枚作り、事例ナレッジに保存します。1件ずつ順番に行います。仮ナレッジモードではアプリはカードを返すだけで、⑤がブラウザに溜めます。",
   url: DV_HOST + "/chat/2b7e4c9a", t: 7400,
   render: function(){ return scrLearnChat("案件002 に正解を教える(同じ会話の続き)", LD_MSGS_TEACH); },
   act: function(){ dvCur(70, 55); dvHl("dv-c-teach", 700); dvHl("dv-c-saved", 2200); }},
  {title: "裏側: 事例ナレッジにカードが2枚できた(台帳に記録)",
   body: "⑤は保存前後のカード一覧の差分で「いま増えた1枚」を特定し、決裁→カードIDの台帳に記録します(後で差し替えるため)。仮ナレッジモードではナレッジは増えず、次の判定の「OK」に似たカードを「参考事例:」として添え、最後に判定事例.txt を手でアップロードします。",
   url: DV_HOST + "/datasets/" + LD_DSID + "/documents", t: 5800,
   render: function(){ return scrKbDocs("判定事例", ["判定事例: 事務所賃貸借契約", "判定事例: 設備リース契約"]); },
   act: function(){ dvHl("dv-row0", 500); dvHl("dv-row1", 1100); dvCur(50, 50); }},
  {title: "エポック2: 全決裁をもう一度テスト(教えていない決裁も)",
   body: "今度は判定の前に、事例ナレッジから似たカードが検索されて参考にされます。",
   url: LD_TOOL, t: 6400,
   render: function(){ return scrLearn({view: "run", prog: "エポック2/5: テスト中… 0 / 6 決裁", curve: LD_C1, marks: {}, taught: LD_T1}); },
   act: function(){ dvPatch("dv-l-prog", "エポック2/5: テスト中… 3 / 6 決裁", 1800);
     dvPatch("dv-l-detail", "<b>最新エポックの明細</b>" + ldDetail({"案件001_金銭消費貸借": "○", "案件002_事務所賃貸借": "○", "案件003_保守委託": "○", "案件004_設備リース": "…", "案件005_業務委託": "…", "案件006_駐車場賃貸借": "…"}, LD_T1), 1900);
     dvPatch("dv-l-prog", "エポック2/5: テスト中… 6 / 6 決裁", 4200);
     dvPatch("dv-l-detail", "<b>最新エポックの明細</b>" + ldDetail(LD_M2, LD_T1), 4300); }},
  {title: "エポック2の結果: 学習 80% / 検証 100%。案件004はまだ誤答",
   body: "案件002は直りました。検証の案件006も(教えていないのに)正解 → カードが初見の判定にも効いた証拠です。案件004はまだ誤答なので、もう一度教えます。",
   url: LD_TOOL, t: 7000,
   render: function(){ return scrLearn({view: "run", prog: "エポック2/5: テスト完了 → 誤答 1件に学習します", curve: LD_C2, marks: LD_M2, taught: LD_T1}); },
   act: function(){ dvHl("dv-l-curvetbl-r1", 500); dvCurTo("dv-l-curvetbl-r1", 400); dvHl("dv-l-detailtbl-r5", 1800); dvHl("dv-l-detailtbl-r3", 3000); }},
  {title: "裏側: 案件004は前回のカードを削除し、誤答情報を添えて作り直し",
   body: "同じ決裁のカードを増やさず、1決裁=1カードを保ちます。「前回は賃借料と誤答したままだった」という情報を添えるので、見分けの決め手が書き直されます。",
   url: DV_HOST + "/chat/2b7e4c9a", t: 8000,
   render: function(){ return scrLearnChat("案件004 にもう一度教える(前回のカードは削除済み)", LD_MSGS_RETEACH); },
   act: function(){ dvCur(70, 55); dvHl("dv-c-reteach", 700); dvHl("dv-c-resaved", 2600); }},
  {title: "台帳: 案件004は「2回(差し替え済み)」。カードは増えていない",
   body: "台帳(決裁→カードID・教えた回数)はこのブラウザに保存されるので、ページを再読み込みしても前回のカードを差し替えられます。",
   url: LD_TOOL, t: 5800,
   render: function(){ return scrLearn({view: "run", prog: "エポック2/5: 学習完了 → エポック3へ", curve: LD_C2, ledger: LD_LEDGER2}); },
   act: function(){ dvHl("dv-l-ledgertbl-r1", 600); dvCurTo("dv-l-ledgertbl-r1", 500); }},
  {title: "エポック3の結果: 学習 100% → 🎯 目標到達で停止",
   body: "全決裁が正解になり、目標の正答率に届いたので自動で止まります。",
   url: LD_TOOL, t: 6400,
   render: function(){ return scrLearn({view: "run", runLabel: "もう一度 最初から学習", prog: "終了: 🎯 目標の正答率(100%)に到達しました(学習正答率 100%)", curve: LD_C3, marks: LD_M3, taught: LD_T2}); },
   act: function(){ dvHl("dv-l-prog", 400); dvHl("dv-l-curvetbl-r2", 1200); dvCurTo("dv-l-curvetbl-r2", 1000); }},
  {title: "止まる条件は3つ(目標到達・改善なし・最大エポック)",
   body: "目標に届かなくても、前の周より上がらなければ早めに止めます。手元の決裁に合わせ込みすぎる(過学習)のを防ぐ、機械学習で標準のやり方です。",
   url: LD_TOOL, t: 6600,
   render: function(){ return scrStop(); },
   act: function(){ dvCur(30, 30); dvHl("dv-s1", 500); dvHl("dv-s2", 1700); dvHl("dv-s3", 2900); }},
  {title: "「自動学習レポート.md を保存」",
   body: "学習曲線・停止理由・明細・台帳・まだ間違える決裁と「次の一手」(環境変数への追記の提案)・正直な注意が1つのファイルになります。",
   url: LD_TOOL, t: 6200,
   render: function(){ return scrLearn({view: "run", runLabel: "もう一度 最初から学習", prog: "終了: 🎯 目標の正答率(100%)に到達しました", report: LD_REPORT}); },
   act: function(){ dvCurTo("dv-l-dl", 300); dvClick(1100); dvHl("dv-l-report", 1500); }},
  {title: "途中で止めても続きから(停止 → 再開)",
   body: "「停止」で実行中の呼び出しを打ち切り、「再開」で続きから回せます(ページを再読み込みするとやり直しですが、台帳は残ります)。実行中はタブを閉じない・PCをスリープさせないでください。",
   url: LD_TOOL, t: 5400,
   render: function(){ return scrLearn({view: "run", runLabel: "再開(エポック2の続き)", prog: "停止しました(エポック2・テストの途中)。「再開」で続きから回せます。", curve: LD_C1, marks: {"案件001_金銭消費貸借": "○", "案件002_事務所賃貸借": "○"}, taught: LD_T1}); },
   act: function(){ dvHl("dv-l-run", 500); dvCurTo("dv-l-run", 400); }},
  {title: "読み方: 学習正答率は「教えた後」の数字。初見の実力は検証正答率で",
   body: "同じ決裁で測った学習正答率は、教えたぶん上がって当然です。検証(教えていない決裁)の正答率が上がっていれば学習は本物。決裁を足して回すほど育ちます。",
   url: LD_TOOL, t: 7000,
   render: function(){ return scrCurveChart([{ep: 1, tr: 60, va: 0}, {ep: 2, tr: 80, va: 100}, {ep: 3, tr: 100, va: 100}],
     "この例では検証1件なので0%か100%しかありませんが、決裁が増えるほど検証正答率はなだらかな数字になり、信頼できる物差しになります。仕上がりは④の採点で改めて測ることもできます。"); },
   act: function(){ dvCur(40, 40); }}
]};

// ---- 台本2: 仕組みの解説(なぜそうするのか)
var LEARN_DEMO_WHY = {name: "仕組みの解説(なぜ1周ずつ回すのか)",
  idle: "上の「▶ 再生」で始まります。<br>何を学習するのか → 1周の中身 → なぜ1件に粘らないのか → 学習曲線 → カードの差し替え → 検証用の取り分け → 止める条件 → 自動でできる範囲、の順に図で説明します(約1分)。",
  steps: [
  {title: "何を学習するのか: 事例カードが保管庫に溜まる",
   body: "学習の中身は「この契約はこう見分けて、相手勘定はこれ」という判定事例カードです。カードは事例ナレッジ(保管庫)に溜まり、次の判定の前に似たカードが検索されて参考にされます。",
   url: LD_TOOL, t: 7000,
   render: function(){ return scrFlow(2, "アプリのプロンプトや環境変数を書き換えるのではなく、<b>保管庫にカードを足していく</b>のが自己学習です。だからアプリを作り替えても学習は消えません。"); },
   act: function(){ dvCur(50, 30); dvHl("dv-f-kb", 600); }},
  {title: "1周=1エポック: テスト → 誤答だけ教える → 再テスト",
   body: "全件をテストしてから、間違えた決裁にだけ1回ずつ教え、もう一度全件をテストする。この1周を「エポック」と呼びます。",
   url: LD_TOOL, t: 7000,
   render: function(){ return scrLoop(-1); },
   act: function(){ dvCur(50, 30); dvLater(function(){ $("dvScreen").innerHTML = scrLoop(0); }, 900); dvLater(function(){ $("dvScreen").innerHTML = scrLoop(1); }, 2600); dvLater(function(){ $("dvScreen").innerHTML = scrLoop(2); }, 4300); }},
  {title: "なぜ「1件が合うまで直し続ける」やり方にしないのか",
   body: "1件に粘ると、その1件専用の説明になりやすく(過学習)、他の決裁を壊しても気づけません。全件を1周ずつ回して毎回測るのが標準です。",
   url: LD_TOOL, t: 8000,
   render: function(){ return scrCompare(); },
   act: function(){ dvCur(28, 45); dvLater(function(){ dvCur(72, 45); }, 3600); }},
  {title: "学習曲線: エポックごとに正答率が伸びる",
   body: "青が学習正答率、緑が検証正答率。目標(点線)に届くか、伸びが止まったら終了します。",
   url: LD_TOOL, t: 7400,
   render: function(){ return scrCurveChart([{ep: 1, tr: 60, va: 0}], "例: 60% → 80% → 100%。3周目で目標に到達して停止。"); },
   act: function(){ dvCur(40, 40);
     dvLater(function(){ $("dvScreen").innerHTML = scrCurveChart([{ep: 1, tr: 60, va: 0}, {ep: 2, tr: 80, va: 100}], "例: 60% → 80% → 100%。3周目で目標に到達して停止。"); }, 2000);
     dvLater(function(){ $("dvScreen").innerHTML = scrCurveChart([{ep: 1, tr: 60, va: 0}, {ep: 2, tr: 80, va: 100}, {ep: 3, tr: 100, va: 100}], "例: 60% → 80% → 100%。3周目で目標に到達して停止。"); }, 4000); }},
  {title: "同じ決裁をまた間違えたら: 1決裁=1カードの差し替え",
   body: "カードを増やすのではなく、前回のカードを削除して「前回◯◯と誤答したままだった」情報つきで作り直します。決裁ごとの1枚を磨いていくイメージです。",
   url: LD_TOOL, t: 8000,
   render: function(){ return scrCardReplace(1); },
   act: function(){ dvCur(50, 40); dvLater(function(){ $("dvScreen").innerHTML = scrCardReplace(2); dvHl("dv-card2", 100); }, 2600); }},
  {title: "検証用の取り分け(ホールドアウト): 教えない決裁で初見の実力を測る",
   body: "同じ決裁で100%になっても「教えたから当たる」だけかもしれません。一部(推奨20%)は一度も教えずに測るのが、機械学習の標準の作法です。",
   url: LD_TOOL, t: 8000,
   render: function(){ return scrHoldout(); },
   act: function(){ dvCur(50, 25); dvLater(function(){ dvCur(74, 60); }, 3000); }},
  {title: "止める条件と、過学習の防止",
   body: "目標到達・改善なし・最大エポックのどれかで止まります。「改善なしで止める」は、手元の決裁に合わせ込みすぎるのを防ぐためです。",
   url: LD_TOOL, t: 6600,
   render: function(){ return scrStop(); },
   act: function(){ dvCur(30, 30); dvHl("dv-s1", 500); dvHl("dv-s2", 1700); dvHl("dv-s3", 2900); }},
  {title: "自動でできる範囲と、人がやること",
   body: "自動で更新するのは事例カードだけ。アプリのプロンプトや環境変数はAPIから書き換えられないので、カードで直りきらない誤答はレポートの「次の一手」を見て手で追記します。ナレッジAPIキーが無いときは、判定事例.txt をナレッジに手で入れるのも人の作業です。",
   url: LD_TOOL, t: 7400,
   render: function(){ return scrScope(); },
   act: function(){ dvCur(28, 45); dvLater(function(){ dvCur(72, 45); }, 3400); }}
]};

// ---- 台本の切り替えボタン
(function learnDemoInit(){
  var pick = function(id, sc){
    if(!$(id)) return;
    $(id).onclick = function(){
      dvSetup(sc.steps, sc);
      $("dvCard").scrollIntoView({behavior: "smooth", block: "start"});
      dvPlayFrom(0);
    };
  };
  pick("dvPick1", LEARN_DEMO_FLOW);
  pick("dvPick2", LEARN_DEMO_WHY);
  dvSetup(LEARN_DEMO_FLOW.steps, {name: "", idle: "上の2つのボタンから選ぶと始まります。<br>初めての方は「仕組みの解説」→「自動学習の流れ」の順がおすすめです。",
                                  capT: "見たい内容のボタンを押してください", capB: "右のステップ一覧から途中へ飛ぶこともできます。"});
})();
