#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""採点用ワークフロー(3形式の正答率比較)の DSL を組み立てる。

  python3 tools/build_eval.py   → contract-account-eval.yml

別アプリとしてDifyにインポートし、環境変数に base_url と各判定アプリのAPIキーを
設定して使う。契約書・決裁文書のファイル一式+正解表(1行=1決裁。複数ファイルの
決裁は行末に「×ファイル数」)を入れると、3形式の判定アプリを
HTTPリクエストノードで1決裁ずつ呼び出し、正答率の比較と「どこに何を追記すれば
次から正解になるか」(自己学習アドバイス)を出力する。

判定アプリ側には一切手を入れない(このアプリが外からAPIで呼ぶだけ)。
文書はこのアプリ内でテキスト抽出し、チャット本文として渡す(ファイルの
再アップロードはDifyのバージョン差があるため使わない)。そのため
スキャンPDF・画像だけの文書は採点できない(結果に「本文なし」と出る)。
"""
import io
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import miniyaml  # noqa: E402

OUT = os.path.join(ROOT, 'contract-account-eval.yml')

MODEL = {'completion_params': {'temperature': 0.1}, 'mode': 'chat',
         'name': 'GPT-4o', 'provider': 'langgenius/azure_openai/azure_openai'}

FORMATS = [
    ('tree', 'ツリー判定形式'),
    ('flat', 'コード2段選択形式'),
    ('pick', 'コード一発選択形式'),
]

ITER = 'iter'


# ---------------------------------------------------------------- 部品
def node(nid, data, x, y, width=244, height=98, in_iter=False, ntype='custom'):
    d = dict(data)
    d.setdefault('desc', '')
    d.setdefault('selected', False)
    if in_iter:
        d['isInIteration'] = True
        d['iteration_id'] = ITER
    n = {'data': d, 'height': height, 'id': nid,
         'position': {'x': x, 'y': y}, 'positionAbsolute': {'x': x, 'y': y},
         'selected': False, 'sourcePosition': 'right', 'targetPosition': 'left',
         'type': ntype, 'width': width}
    if in_iter:
        n['parentId'] = ITER
        n['extent'] = 'parent'
        n['zIndex'] = 1001
    return n


def edge(src, dst, src_type, dst_type, in_iter=False):
    e = {'data': {'isInIteration': in_iter, 'sourceType': src_type, 'targetType': dst_type},
         'id': '%s-source-%s-target' % (src, dst),
         'source': src, 'sourceHandle': 'source',
         'target': dst, 'targetHandle': 'target',
         'type': 'custom', 'zIndex': 1002 if in_iter else 0}
    if in_iter:
        e['data']['iteration_id'] = ITER
    return e


# ---------------------------------------------------------------- コードノードの中身
PACK_CODE = r'''
def main(texts: list, answers: str) -> dict:
    # 添付文書(抽出済み本文)と正解表を「添付した順」に突き合わせ、1決裁=1JSONにまとめる。
    # 正解表は1行=1決裁:「科目名」「科目名 [10桁コード]」/先頭に「決裁名: 」を書いてもよい(表示用)。
    # 1決裁が複数ファイルのときは行末に「×N」(そのファイル数だけ順に束ねる。例: 賃借料 [5030001001] ×3)。
    import json
    import re
    import unicodedata

    def nk(s):
        return unicodedata.normalize('NFKC', (s or '')).strip()

    rows = []
    for line in (answers or '').split('\n'):
        line = nk(line)
        if line.startswith('- '):
            line = line[2:].strip()
        if not line or line.startswith('#'):
            continue
        label = ''
        body = line
        if ': ' in line and '[' not in line.split(': ', 1)[0]:
            label, body = line.split(': ', 1)
        nfiles = 1
        m = re.search(r'[×x*]\s*([0-9]+)\s*$', body)
        if m:
            nfiles = max(1, int(m.group(1)))
            body = body[:m.start()].strip()
        m = re.search(r'\[([0-9]{7,10})\]', body)
        code = m.group(1) if m else ''
        name = nk(re.sub(r'\[[0-9]{7,10}\]', '', body))
        rows.append({'label': nk(label), 'name': name, 'code': code, 'nfiles': nfiles})

    warns = []
    need = sum(r['nfiles'] for r in rows)
    if need != len(texts):
        warns.append('正解表の合計ファイル数 %d / 添付文書 %d件 で数が合いません'
                     '(添付した順に束ねます。1決裁が複数ファイルのときは行末に「×ファイル数」)。'
                     % (need, len(texts)))
    items = []
    pos = 0
    no = 0
    while pos < len(texts) or no < len(rows):
        row = rows[no] if no < len(rows) else {'label': '', 'name': '', 'code': '', 'nfiles': 1}
        chunk = [(t or '').strip() for t in texts[pos:pos + row['nfiles']]]
        pos += row['nfiles']
        no += 1
        if len(chunk) > 1:
            t = '\n\n'.join('【ファイル%d】\n%s' % (i + 1, c) for i, c in enumerate(chunk))
        else:
            t = chunk[0] if chunk else ''
        head = ' '.join(t[:60].split()) or '(本文なし: スキャンPDF・画像は採点できません)'
        if len(chunk) > 1:
            head = '%dファイル: %s' % (len(chunk), head)
        items.append(json.dumps({
            'no': no,
            'label': row['label'] or ('決裁%d' % no),
            'head': head,
            'text': t[:50000],
            'expect_name': row['name'],
            'expect_code': row['code'],
        }, ensure_ascii=False))
    return {'items': items, 'warn': '\n'.join(warns)}
'''.strip() + '\n'

REQ_CODE = r'''
def main(item: str) -> dict:
    # 1件分の判定依頼(チャットAPIのリクエストボディ)を作る。3形式とも同じ本文を送る。
    import json
    d = json.loads(item)
    if not d.get('text'):
        return {'body': ''}
    query = ('次の契約書(決済文書)の本文を読んで、キャッシュ(現金・預金)の相手勘定となる勘定科目を判定してください。\n'
             '<契約書本文>\n%s\n</契約書本文>' % d['text'])
    return {'body': json.dumps({'inputs': {}, 'query': query, 'response_mode': 'blocking',
                                'user': 'eval-runner', 'auto_generate_name': False},
                               ensure_ascii=False)}
'''.strip() + '\n'

GRADE_CODE = r'''
def main(item: str, b1: str, s1: float, k1: str, b2: str, s2: float, k2: str,
         b3: str, s3: float, k3: str) -> dict:
    # 1件分の3形式の回答を正解と突き合わせる。
    #   ok=正解 / ng=不正解 / ask=質問で停止 / error=呼び出し失敗 / skip=APIキー未設定
    #   notext=本文が取れず未実行 / noans=正解表なし
    # 正解判定は機械的な包含チェック: コードがあればコード、無ければ科目名が回答に含まれるか。
    import json
    import unicodedata

    def nk(s):
        return unicodedata.normalize('NFKC', (s or ''))

    d = json.loads(item)
    out = {'no': d['no'], 'label': d['label'], 'head': d['head'],
           'expect_name': d['expect_name'], 'expect_code': d['expect_code']}
    for key, body, status, apikey in (('tree', b1, s1, k1), ('flat', b2, s2, k2),
                                      ('pick', b3, s3, k3)):
        if not (apikey or '').strip():
            out[key] = {'outcome': 'skip', 'got': ''}
            continue
        if not d.get('expect_name') and not d.get('expect_code'):
            out[key] = {'outcome': 'noans', 'got': ''}
            continue
        if d.get('text') == '' or d.get('head', '').startswith('(本文なし'):
            out[key] = {'outcome': 'notext', 'got': ''}
            continue
        try:
            status_i = int(status)
        except Exception:
            status_i = 0
        if status_i != 200:
            out[key] = {'outcome': 'error', 'got': 'HTTP %s: %s' % (status_i, nk(body)[:160])}
            continue
        try:
            ans = json.loads(body).get('answer', '')
        except Exception:
            ans = nk(body)
        ans_n = nk(ans)
        got = ' '.join(ans_n[:400].split())
        if '質問:' in ans_n:
            out[key] = {'outcome': 'ask', 'got': got}
            continue
        if d['expect_code']:
            hit = d['expect_code'] in ans_n
        else:
            hit = nk(d['expect_name']) in ans_n
        out[key] = {'outcome': 'ok' if hit else 'ng', 'got': got}
    return {'result': json.dumps(out, ensure_ascii=False)}
'''.strip() + '\n'

AGG_CODE = r'''
def main(results: list, warn: str) -> dict:
    # 全件の採点結果を集計し、正答率の比較表・明細・誤答一覧(学習アドバイス用)を作る。
    import json
    rows = [json.loads(r) for r in results]
    formats = [('tree', 'ツリー判定形式'), ('flat', 'コード2段選択形式'),
               ('pick', 'コード一発選択形式')]
    mark = {'ok': '○', 'ng': '×', 'ask': '?', 'error': 'E', 'skip': '-', 'notext': '読', 'noans': '正'}

    stats = {}
    for key, label in formats:
        c = {'ok': 0, 'ng': 0, 'ask': 0, 'error': 0, 'skip': 0, 'notext': 0, 'noans': 0}
        for r in rows:
            c[r[key]['outcome']] = c.get(r[key]['outcome'], 0) + 1
        graded = c['ok'] + c['ng'] + c['ask'] + c['error']
        rate = (100.0 * c['ok'] / graded) if graded else None
        stats[key] = {'label': label, 'c': c, 'graded': graded, 'rate': rate}

    lines = ['## 📊 3形式の正答率(%d件)' % len(rows), '',
             '| 形式 | 正答率 | 正解 | 不正解 | 質問で停止 | エラー |', '|---|---|---|---|---|---|']
    for key, label in formats:
        s = stats[key]
        if not s['graded']:
            lines.append('| %s | (未設定/採点なし) | - | - | - | - |' % label)
            continue
        lines.append('| %s | **%.0f%%** (%d/%d) | %d | %d | %d | %d |'
                     % (label, s['rate'], s['c']['ok'], s['graded'],
                        s['c']['ok'], s['c']['ng'], s['c']['ask'], s['c']['error']))
    best = [(s['rate'], s['label']) for s in stats.values() if s['rate'] is not None]
    if best:
        top = max(r for r, _ in best)
        names = '、'.join(l for r, l in best if r == top)
        lines += ['', '**いちばん正答率が高い形式: %s(%.0f%%)**' % (names, top)]
        lines += ['', '※ 3形式とも回答は「キャッシュの相手勘定1科目+確定コード」の同じ形なので、'
                      '採点基準も同一です(正解のコード、コードが無ければ科目名が回答に含まれるか)。']
    lines += ['', '## 📋 1件ごとの結果(○=正解 ×=不正解 ?=質問で停止 E=エラー -=キー未設定 読=本文抽出不可 正=正解表なし)', '',
              '| # | 文書 | 正解 | ' + ' | '.join(l for _, l in formats) + ' |',
              '|---|---|---|' + '---|' * len(formats)]
    for r in rows:
        expect = r['expect_name'] + ((' [%s]' % r['expect_code']) if r['expect_code'] else '')
        lines.append('| %d | %s(%s…) | %s | ' % (r['no'], r['label'], r['head'][:24], expect or '(なし)')
                     + ' | '.join(mark.get(r[k]['outcome'], '?') for k, _ in formats) + ' |')
    if warn:
        lines += ['', '⚠️ ' + warn.replace('\n', ' / ')]

    misses = []
    for r in rows:
        for key, label in formats:
            o = r[key]
            if o['outcome'] not in ('ng', 'ask'):
                continue
            expect = r['expect_name'] + ((' [%s]' % r['expect_code']) if r['expect_code'] else '')
            misses.append('- 形式: %s / 文書%d(%s)/ 冒頭: %s\n  正解: %s\n  アプリの回答(抜粋): %s'
                          % (label, r['no'], r['label'], r['head'][:40], expect,
                             ('(質問で停止)' if o['outcome'] == 'ask' else '') + o['got'][:300]))
    return {'report': '\n'.join(lines),
            'misses': '\n'.join(misses) if misses else '(誤答なし)'}
'''.strip() + '\n'

ADVICE_SYSTEM = '''あなたは、契約書からキャッシュ(現金・預金)の相手勘定を判定するDifyアプリ(3形式)を運用する担当者の支援者です。
渡される誤答一覧をもとに、「Difyのどの設定に・どの行を追記すれば」次回から正解に近づくかを、そのままコピペできる形で出力してください。

# 各形式の学習の書き込み先(すべてDifyのアプリ設定 → 環境変数。編集は即反映・再インポート不要)
- どの形式にも効く: `accounting_policy`(会社の会計方針・判定ルール。自由記述)
  → 「◯◯のような契約(見分けられる条件)は「正解科目」に分類する」の形で1行追記。
  相手勘定の取り違え(主目的の行の選び間違い。敷金や手数料を選んだ等)もここに
  「◯◯契約の主目的は◯◯(付随する◯◯は選ばない)」の形で書く
- ツリー判定形式: 正解科目が属する細分の `rules_*`(分類基準。1行=「ラベル名: 定義」)の該当行に、見分ける条件を書き足す
- コード2段選択形式: `codes10_list`(7桁→10桁の書き分け定義)の該当行に条件を書き足す。7桁の選び間違いなら `codes7_list`
- コード一発選択形式: `codes_list`(全候補一覧)の正解科目の行の定義に条件を書き足す

# 出力ルール
- 誤答をグループ化し、グループごとに「原因の推定(1行)」→「書き込み先と追記する行(コピペできる形)」を書く
- 複数形式に効かせたい内容は `accounting_policy` を第一候補にする
- 追記行は上記の書式に合わせる(存在しない変数名・書式を発明しない)
- 条件は契約の特徴(契約の種類・当事者の立場・期間・支払条件など)で書き、固有名詞に依存させない
- 正解科目がどの候補一覧にも無い場合は、環境変数への追記ではなく「分類ツリーに科目を足して③で再生成する」ことを案内する
- 最後に必ず「追記したら、もう一度この採点を実行して正答率が上がったか確認してください(効果は保証ではありません)」と添える
- 誤答一覧が「(誤答なし)」の場合は「誤答がないため、追記は不要です。」とだけ出力する'''

REPORT_TEMPLATE = ('{{ report }}\n\n'
                   '## 🎓 どこに何を書けば次から正解になるか(自己学習アドバイス)\n\n'
                   '{{ advice }}')


# ---------------------------------------------------------------- 組み立て
def build():
    env = [
        {'description': '会社のDify APIのエンドポイント(例: https://dify.example.com/v1)。'
                        '各判定アプリの「APIアクセス」画面に表示されるAPIサーバーのURL。',
         'id': 'env-eval-base-url', 'name': 'base_url', 'value': '', 'value_type': 'string'},
    ]
    for key, label in FORMATS:
        env.append({'description': '%sの判定アプリのAPIキー(app-…)。そのアプリの「APIアクセス」画面で発行。'
                                   '空のままならこの形式はスキップ(採点対象外)。' % label,
                    'id': 'env-eval-key-%s' % key, 'name': 'api_key_%s' % key,
                    'value': '', 'value_type': 'string'})

    nodes = []
    edges = []
    X = lambda i: 80 + 304 * i  # noqa: E731

    nodes.append(node('start', {
        'title': '開始',
        'desc': '契約書・決裁文書のファイル一式と、その正解表を入れます(複数ファイルで1決裁の場合は正解表の行末に「×ファイル数」)。',
        'type': 'start',
        'variables': [
            {'allowed_file_extensions': [], 'allowed_file_types': ['document'],
             'allowed_file_upload_methods': ['local_file', 'remote_url'],
             'label': '契約書・決裁文書のファイル(決裁ごとに続けて添付。最大100件 ※Dify側の上限が優先)',
             'max_length': 100,
             'options': [], 'required': True, 'type': 'file-list', 'variable': 'docs'},
            {'label': '正解表(1行=1決裁。添付した順に「科目名」または「科目名 [10桁コード]」。'
                      '複数ファイルの決裁は行末に「×ファイル数」、先頭に「決裁名: 」を書いてもよい)',
             'max_length': 4000, 'options': [], 'required': True,
             'type': 'paragraph', 'variable': 'answers'},
        ]}, X(0), 190, height=116))

    nodes.append(node('doc-extract', {
        'title': '本文テキスト抽出',
        'desc': '各文書から本文を取り出します(スキャンPDF・画像は文字が取れないため採点対象外になります)。',
        'type': 'document-extractor', 'is_array_file': True,
        'variable_selector': ['start', 'docs']}, X(1), 190, height=92))
    edges.append(edge('start', 'doc-extract', 'start', 'document-extractor'))

    nodes.append(node('pack', {
        'title': '文書と正解の突き合わせ',
        'desc': '添付した順に正解表と組にします(1決裁=1行。「×N」の行はNファイルを1決裁に束ねる)。',
        'type': 'code', 'code_language': 'python3', 'code': PACK_CODE,
        'outputs': {'items': {'children': None, 'type': 'array[string]'},
                    'warn': {'children': None, 'type': 'string'}},
        'variables': [
            {'value_selector': ['doc-extract', 'text'], 'variable': 'texts'},
            {'value_selector': ['start', 'answers'], 'variable': 'answers'},
        ]}, X(2), 190, height=92))
    edges.append(edge('doc-extract', 'pack', 'document-extractor', 'code'))

    # ---- イテレーション(1件ずつ3形式を呼ぶ)
    ITER_W, ITER_H = 5 * 304 + 140, 330
    nodes.append(node(ITER, {
        'title': '1決裁ずつ3形式で判定',
        'desc': '各決裁(1〜複数ファイル)について、3つの判定アプリをAPIで順に呼び出し、回答を正解と突き合わせます。',
        'type': 'iteration',
        'iterator_selector': ['pack', 'items'],
        'output_selector': ['grade', 'result'],
        'output_type': 'array[string]',
        'is_parallel': False, 'parallel_nums': 10,
        'error_handle_mode': 'terminated',
        'start_node_id': 'iter-start'}, X(3), 150, width=ITER_W, height=ITER_H))
    edges.append(edge('pack', ITER, 'code', 'iteration'))

    ix = lambda i: 70 + 304 * i  # noqa: E731
    n = node('iter-start', {'title': '', 'type': 'iteration-start'},
             24, 130, width=44, height=44, in_iter=True, ntype='custom-iteration-start')
    n['zIndex'] = 1002
    nodes.append(n)

    nodes.append(node('req', {
        'title': '判定依頼を作る',
        'desc': '本文をチャットAPIのリクエスト(3形式共通)にします。',
        'type': 'code', 'code_language': 'python3', 'code': REQ_CODE,
        'outputs': {'body': {'children': None, 'type': 'string'}},
        'variables': [{'value_selector': [ITER, 'item'], 'variable': 'item'}]},
        ix(0) + 60, 110, height=92, in_iter=True))
    edges.append(edge('iter-start', 'req', 'iteration-start', 'code', in_iter=True))

    prev = 'req'
    for i, (key, label) in enumerate(FORMATS):
        nid = 'http_%s' % key
        nodes.append(node(nid, {
            'title': '%sを呼ぶ' % label,
            'desc': '判定アプリ(%s)のチャットAPIを呼び出します。' % label,
            'type': 'http-request', 'method': 'post',
            'url': '{{#env.base_url#}}/chat-messages',
            'authorization': {'config': None, 'type': 'no-auth'},
            'headers': 'Content-Type: application/json\nAuthorization: Bearer {{#env.api_key_%s#}}' % key,
            'params': '',
            'body': {'data': [{'id': 'key-value-body-%s' % key, 'key': '', 'type': 'text',
                               'value': '{{#req.body#}}'}], 'type': 'json'},
            'timeout': {'max_connect_timeout': 30, 'max_read_timeout': 300, 'max_write_timeout': 30},
            'retry_config': {'max_retries': 1, 'retry_enabled': True, 'retry_interval': 2000},
            'variables': []}, ix(1 + i) + 60, 110, height=92, in_iter=True))
        edges.append(edge(prev, nid, 'code' if prev == 'req' else 'http-request', 'http-request', in_iter=True))
        prev = nid

    grade_vars = [{'value_selector': [ITER, 'item'], 'variable': 'item'}]
    for i, (key, _) in enumerate(FORMATS):
        grade_vars += [
            {'value_selector': ['http_%s' % key, 'body'], 'variable': 'b%d' % (i + 1)},
            {'value_selector': ['http_%s' % key, 'status_code'], 'variable': 's%d' % (i + 1)},
            {'value_selector': ['env', 'api_key_%s' % key], 'variable': 'k%d' % (i + 1)},
        ]
    nodes.append(node('grade', {
        'title': '採点',
        'desc': '3形式の回答を正解と機械的に突き合わせます(コード優先の包含チェック)。',
        'type': 'code', 'code_language': 'python3', 'code': GRADE_CODE,
        'outputs': {'result': {'children': None, 'type': 'string'}},
        'variables': grade_vars}, ix(4) + 60, 110, height=92, in_iter=True))
    edges.append(edge(prev, 'grade', 'http-request', 'code', in_iter=True))

    # ---- 集計〜レポート
    x4 = X(3) + (ITER_W - 244) // 304 + 4  # イテレーションの右から再開
    xs = X(3) + ITER_W + 60
    nodes.append(node('agg', {
        'title': '集計',
        'desc': '正答率の比較表・1件ごとの明細・誤答一覧を作ります。',
        'type': 'code', 'code_language': 'python3', 'code': AGG_CODE,
        'outputs': {'report': {'children': None, 'type': 'string'},
                    'misses': {'children': None, 'type': 'string'}},
        'variables': [
            {'value_selector': [ITER, 'output'], 'variable': 'results'},
            {'value_selector': ['pack', 'warn'], 'variable': 'warn'},
        ]}, xs, 190, height=92))
    edges.append(edge(ITER, 'agg', 'iteration', 'code'))

    nodes.append(node('advice', {
        'title': '学習アドバイス生成',
        'desc': '誤答一覧から、どの環境変数に何を追記すれば次から正解に近づくかを、コピペできる形で書き出します。',
        'type': 'llm',
        'context': {'enabled': False, 'variable_selector': []},
        'model': dict(MODEL),
        'prompt_template': [
            {'id': 'system-prompt-advice', 'role': 'system', 'text': ADVICE_SYSTEM},
            {'id': 'user-prompt-advice', 'role': 'user',
             'text': '誤答一覧:\n{{#agg.misses#}}'},
        ],
        'variables': [],
        'vision': {'configs': {'detail': 'high', 'variable_selector': []}, 'enabled': False},
    }, xs + 304, 190))
    edges.append(edge('agg', 'advice', 'code', 'llm'))

    nodes.append(node('report-all', {
        'title': 'レポート結合',
        'desc': '',
        'type': 'template-transform',
        'template': REPORT_TEMPLATE,
        'variables': [
            {'value_selector': ['agg', 'report'], 'variable': 'report'},
            {'value_selector': ['advice', 'text'], 'variable': 'advice'},
        ]}, xs + 304 * 2, 190, height=92))
    edges.append(edge('advice', 'report-all', 'llm', 'template-transform'))

    nodes.append(node('end', {
        'title': '終了',
        'desc': '正答率の比較と学習アドバイスを出力します。',
        'type': 'end',
        'outputs': [{'value_selector': ['report-all', 'output'], 'variable': 'report'}]},
        xs + 304 * 3, 190, height=90))
    edges.append(edge('report-all', 'end', 'template-transform', 'end'))

    app = {
        'description': '3つの判定アプリ(ツリー判定/コード2段選択/コード一発選択)をAPIで呼び出し、'
                       '正解表(キャッシュの相手勘定)と突き合わせて正答率を比較する採点用ワークフロー。誤答からは「どの環境変数に何を追記すれば'
                       '次から正解に近づくか」も出力する。使い方: (1)3つの判定アプリをDifyに取り込み、各アプリの'
                       '「APIアクセス」でAPIキーを発行 (2)このアプリの環境変数 base_url(…/v1)と api_key_* を設定 '
                       '(3)実行時に契約書・決裁文書のファイルと正解表(1行=1決裁「科目名 [コード]」。'
                       '複数ファイルの決裁は行末に「×ファイル数」)を入力。'
                       '文書は本文テキストを抽出して各アプリへチャットとして渡すため、スキャンPDF・画像だけの文書は'
                       '採点対象外。件数が多い場合は数十決裁ずつに分けて実行(まとめて回すならリポジトリの'
                       '採点スクリプト/ノートブック版)。このDSLは tools/build_eval.py で自動生成したもの。',
        'icon': '📊', 'icon_background': '#E4FBCC', 'mode': 'workflow',
        'name': '契約書判定の採点(3形式比較)', 'use_icon_as_answer_icon': False,
    }
    features = {
        'file_upload': {
            'allowed_file_extensions': ['.PDF', '.TXT', '.MD', '.MARKDOWN', '.DOCX',
                                        '.XLSX', '.XLS', '.PPTX', '.PPT', '.CSV'],
            'allowed_file_types': ['document'],
            'allowed_file_upload_methods': ['local_file', 'remote_url'],
            'enabled': True,
            'image': {'detail': 'high', 'enabled': False, 'number_limits': 10,
                      'transfer_methods': ['local_file', 'remote_url']},
            'number_limits': 10},
        'opening_statement': '',
        'retriever_resource': {'enabled': True},
        'sensitive_word_avoidance': {'enabled': False},
        'speech_to_text': {'enabled': False},
        'suggested_questions': [],
        'suggested_questions_after_answer': {'enabled': False},
        'text_to_speech': {'enabled': False, 'language': '', 'voice': ''},
    }
    return {
        'app': app,
        'kind': 'app',
        'version': '0.1.5',
        'workflow': {
            'conversation_variables': [],
            'environment_variables': env,
            'features': features,
            'graph': {'edges': edges, 'nodes': nodes,
                      'viewport': {'x': 0, 'y': 0, 'zoom': 0.7}},
        },
    }


def lint(d):
    """エッジ・参照の食い違いを機械チェックする(インポート前の自己検査)。"""
    g = d['workflow']['graph']
    ids = {n['id'] for n in g['nodes']}
    outs = {}
    for n in g['nodes']:
        data = n['data']
        o = set()
        t = data['type']
        if t == 'code':
            o = set(data['outputs'])
        elif t == 'llm':
            o = {'text'}
        elif t in ('template-transform',):
            o = {'output'}
        elif t == 'document-extractor':
            o = {'text'}
        elif t == 'http-request':
            o = {'body', 'status_code', 'headers', 'files'}
        elif t == 'iteration':
            o = {'output', 'item', 'index'}
        elif t == 'start':
            o = {v['variable'] for v in data['variables']}
        outs[n['id']] = o
    envs = {'api_key_%s' % k for k, _ in FORMATS} | {'base_url'}
    errors = []
    for e in g['edges']:
        for k in ('source', 'target'):
            if e[k] not in ids:
                errors.append('edge %s: %s が存在しません' % (e['id'], e[k]))
    def check_sel(sel, where):
        if not sel:
            return
        src, var = sel[0], sel[1]
        if src == 'env':
            if var not in envs:
                errors.append('%s: env.%s が未定義' % (where, var))
        elif src not in ids:
            errors.append('%s: ノード %s が存在しません' % (where, src))
        elif outs.get(src) and var not in outs[src]:
            errors.append('%s: %s に出力 %s がありません' % (where, src, var))
    for n in g['nodes']:
        data = n['data']
        for v in data.get('variables', []) if isinstance(data.get('variables'), list) else []:
            if isinstance(v, dict) and 'value_selector' in v:
                check_sel(v['value_selector'], '%s.%s' % (n['id'], v.get('variable')))
        for o in data.get('outputs', []) if data['type'] == 'end' else []:
            check_sel(o['value_selector'], '%s(end)' % n['id'])
        if data['type'] == 'iteration':
            check_sel(data['iterator_selector'], '%s(iterator)' % n['id'])
            check_sel(data['output_selector'], '%s(output)' % n['id'])
    return errors


def main():
    d = build()
    errors = lint(d)
    if errors:
        for e in errors:
            sys.stderr.write('LINT: %s\n' % e)
        sys.exit(1)
    text = miniyaml.dump(d)
    assert miniyaml.load(text)['app']['mode'] == 'workflow'
    io.open(OUT, 'w', encoding='utf-8').write(text)
    g = d['workflow']['graph']
    sys.stderr.write('written %s (%d nodes / %d edges / %d env vars)\n'
                     % (os.path.basename(OUT), len(g['nodes']), len(g['edges']),
                        len(d['workflow']['environment_variables'])))


if __name__ == '__main__':
    main()
