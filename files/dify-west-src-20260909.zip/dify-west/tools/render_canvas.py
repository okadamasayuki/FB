#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""DSL(YAML)からオーケストレーション図(自己完結HTML/SVG)を描画する。

  python3 tools/render_canvas.py                          # DSL → docs/orchestration.html
  python3 tools/render_canvas.py -y 別の.yml -o 出力.html --title "変更前"

ノード座標・エッジはYAMLの中身をそのまま使うので、生成し直せば常にDSLと同期する。
エッジはDify同様に「右ポート→左ポート」の水平ベジェで描く。
"""
import argparse
import html
import os

import miniyaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

COLORS = {
    'start': ('#12b76a', '開始'),
    'document-extractor': ('#667085', 'テキスト抽出'),
    'llm': ('#2970ff', 'LLM'),
    'if-else': ('#f79009', '条件分岐'),
    'variable-aggregator': ('#7a5af8', '変数集約'),
    'template-transform': ('#0e9384', 'テンプレート'),
    'assigner': ('#667085', '変数保存'),
    'code': ('#fb6514', 'コード実行'),
    'answer': ('#f04438', '回答'),
    'end': ('#f04438', '終了'),
}


def load_graph(path):
    d = miniyaml.load(open(path, encoding='utf-8').read())
    g = d['workflow']['graph']
    return g['nodes'], g['edges']


def src_port(node, handle):
    x = node['position']['x'] + node.get('width', 244)
    y0 = node['position']['y']
    h = node.get('height', 116)
    if node['data']['type'] == 'if-else':
        cases = node['data']['cases']
        slots = len(cases) + 1
        if handle == 'false':
            idx = len(cases)
        else:
            idx = next(i for i, c in enumerate(cases) if c['case_id'] == handle)
        return x, y0 + h * (idx + 1) / (slots + 1)
    return x, y0 + h / 2


def tgt_port(node):
    return node['position']['x'], node['position']['y'] + node.get('height', 116) / 2


def edge_path(p0, p1):
    dx = max(50, (p1[0] - p0[0]) * 0.5)
    return (p0[0], p0[1], p0[0] + dx, p0[1], p1[0] - dx, p1[1], p1[0], p1[1])



def render(nodes, edges, title=''):
    by_id = {n['id']: n for n in nodes}
    w = max(n['position']['x'] + n.get('width', 244) for n in nodes) + 100
    h = max(n['position']['y'] + n.get('height', 116) for n in nodes) + 100
    parts = []
    parts.append('<svg class="canvas" width="%d" height="%d" viewBox="0 0 %d %d" '
                 'xmlns="http://www.w3.org/2000/svg">' % (w, h, w, h))
    parts.append('<rect width="%d" height="%d" fill="#f7f8fa"/>' % (w, h))
    for e in edges:
        p0 = src_port(by_id[e['source']], e['sourceHandle'])
        p1 = tgt_port(by_id[e['target']])
        c = edge_path(p0, p1)
        parts.append('<path d="M %.0f %.0f C %.0f %.0f, %.0f %.0f, %.0f %.0f" '
                     'fill="none" stroke="rgba(52,64,84,0.5)" stroke-width="1.6"/>' % c)
        parts.append('<circle cx="%.0f" cy="%.0f" r="3" fill="#344054"/>' % (p1[0], p1[1]))
    for n in nodes:
        x, y = n['position']['x'], n['position']['y']
        wd, ht = n.get('width', 244), n.get('height', 116)
        color, typename = COLORS.get(n['data']['type'], ('#667085', n['data']['type']))
        parts.append('<g>')
        parts.append('<rect x="%d" y="%d" width="%d" height="%d" rx="10" fill="#ffffff" '
                     'stroke="#d0d5dd" stroke-width="1.5"/>' % (x, y, wd, ht))
        parts.append('<rect x="%d" y="%d" width="6" height="%d" rx="3" fill="%s"/>' % (x, y, ht, color))
        parts.append('<text x="%d" y="%d" font-size="15" font-weight="bold" fill="#101828" '
                     'font-family="sans-serif">%s</text>'
                     % (x + 16, y + 28, html.escape(n['data'].get('title', n['id']))))
        parts.append('<text x="%d" y="%d" font-size="12" fill="%s" font-family="sans-serif">%s</text>'
                     % (x + 16, y + 50, color, html.escape(typename)))
        if n['data']['type'] == 'if-else':
            cases = n['data']['cases']
            for i, cse in enumerate(cases + [None]):
                px, py = src_port(n, 'false' if cse is None else cse['case_id'])
                label = 'ELSE' if cse is None else cse['conditions'][0]['value']
                parts.append('<circle cx="%.0f" cy="%.0f" r="3.5" fill="#f79009"/>' % (px, py))
                parts.append('<text x="%.0f" y="%.0f" font-size="10" fill="#98a2b3" text-anchor="end" '
                             'font-family="sans-serif">%s</text>' % (px - 8, py + 3, html.escape(label)))
        parts.append('</g>')
    parts.append('</svg>')
    head = ''
    if title:
        head = '<div style="font: bold 26px sans-serif; padding: 18px 24px 6px; color:#101828;">%s</div>' % html.escape(title)
    return ('<div style="background:#f7f8fa">%s<div class="canvas-frame" style="overflow:auto">%s</div></div>'
            % (head, ''.join(parts)))


def main():
    ap = argparse.ArgumentParser(description='DSLからオーケストレーション図HTMLを描画')
    ap.add_argument('-y', '--yml', default=os.path.join(ROOT, 'contract-account-classification.yml'))
    ap.add_argument('-o', '--output', default=os.path.join(ROOT, 'docs', 'orchestration.html'))
    ap.add_argument('--title', default='')
    args = ap.parse_args()
    nodes, edges = load_graph(args.yml)
    with open(args.output, 'w', encoding='utf-8') as f:
        f.write(render(nodes, edges, args.title))
    print('written %s (%d nodes / %d edges)' % (args.output, len(nodes), len(edges)))


if __name__ == '__main__':
    main()
