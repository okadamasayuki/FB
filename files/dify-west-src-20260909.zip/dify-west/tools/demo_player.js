// ============================================================ 動画プレーヤー(ページ内アニメーションの共通エンジン)
// ③(ツリーからDify)・④(判定の採点)・⑤(自動学習)で共用。通信・動画ファイルなし。
// 台本の各ステップは {title, body, url, hl, t, render, act}:
//   render() が画面(HTML)を丸ごと返し、act() がカーソル移動・クリック・打ち込みの演出を予約する。
//   毎回描き直すので、ステップ一覧から途中へ飛べる。
// 使い方: dvSetup(steps, {name, idle, capT, capB}) で台本を入れ、dvPlayFrom(0) で再生。
// ページには dvCard / dvUrl / dvScreen / dvCursor / dvRipple / dvSteps / dvCapT / dvCapB /
// dvBar / dvCount / dvPlay / dvPrev / dvNext / dvRestart / dvSpeed(任意で dvScriptName)が必要。
var DV = {steps: [], i: -1, playing: false, timer: null, later: [], typers: [], opts: {}, scrollGoal: null};

function dvSpeed(){ return parseFloat($("dvSpeed").value) || 1; }
function dvLater(fn, ms){
  var at = DV.i, steps = DV.steps;
  var t = setTimeout(function(){ if(DV.i === at && DV.steps === steps) fn(); }, (ms || 0) / dvSpeed());
  DV.later.push(t);
}
function dvStop(){
  if(DV.timer) clearTimeout(DV.timer);
  DV.timer = null;
  DV.later.forEach(clearTimeout); DV.later = [];
  DV.typers.forEach(clearInterval); DV.typers = [];
}
function dvCur(xPct, yPct){ var c = $("dvCursor"); c.style.left = xPct + "%"; c.style.top = yPct + "%"; }
function dvCurTo(id, ms){
  dvLater(function(){
    var el = $(id), box = $("dvBrowser"), s = $("dvScreen");
    if(!el || !box) return;
    var inScreen = !!(s && s.contains(el));
    if(inScreen) dvReveal([el]);
    var r = el.getBoundingClientRect(), b = box.getBoundingClientRect();
    // 画面がなめらかにスクロール中なら、到着後の位置に合わせる
    var adj = (inScreen && DV.scrollGoal != null) ? (DV.scrollGoal - s.scrollTop) : 0;
    var c = $("dvCursor");
    c.style.left = (r.left - b.left + r.width * 0.55 - 3) + "px";
    c.style.top = (r.top - b.top - adj + r.height * 0.6 - 2) + "px";
  }, ms);
}
function dvClick(ms){
  dvLater(function(){
    var c = $("dvCursor"), r = $("dvRipple");
    r.style.left = "calc(" + c.style.left + " + 3px)";
    r.style.top = "calc(" + c.style.top + " + 2px)";
    r.classList.remove("go"); void r.offsetWidth; r.classList.add("go");
  }, ms);
}
function dvHl(id, ms){
  dvLater(function(){
    var el = $(id); if(!el) return;
    el.classList.add("dv-hl");
    // 光らせた要素が画面の下に隠れていたら、見えるところまでスクロールする(新しいものを最後に)
    var s = $("dvScreen"), all = [];
    if(s) all = Array.prototype.slice.call(s.querySelectorAll(".dv-hl")).filter(function(e){ return e !== el; });
    all.push(el);
    dvReveal(all);
  }, ms);
}
// 画面(dvScreen)の中で要素が見えるよう、必要なぶんだけ縦にスクロールする。
// 複数なら全部が収まる位置、収まらなければ最後の要素を優先。overflow:hidden でもJSからは動かせる。
function dvReveal(els){
  var s = $("dvScreen"); if(!s) return;
  els = els.filter(function(e){ return e && s.contains(e); });
  if(!els.length) return;
  var sr = s.getBoundingClientRect(), cur = s.scrollTop, h = s.clientHeight, pad = 20;
  var goal = DV.scrollGoal == null ? cur : DV.scrollGoal;
  function span(list){
    var top = Infinity, bottom = -Infinity;
    list.forEach(function(e){
      var r = e.getBoundingClientRect();
      top = Math.min(top, r.top - sr.top + cur);
      bottom = Math.max(bottom, r.bottom - sr.top + cur);
    });
    return {top: top, bottom: bottom};
  }
  var sp = span(els);
  if(sp.bottom - sp.top > h - 2 * pad) sp = span([els[els.length - 1]]);
  var want = goal;
  if(sp.bottom - sp.top > h - 2 * pad) want = sp.top - pad;
  else if(sp.top < goal + pad) want = sp.top - pad;
  else if(sp.bottom > goal + h - pad) want = sp.bottom - h + pad;
  want = Math.max(0, Math.min(s.scrollHeight - h, Math.round(want)));
  if(Math.abs(want - goal) < 2) return;
  DV.scrollGoal = want;
  dvCurShift(want - goal);
  if(s.scrollTo) s.scrollTo({top: want, behavior: "smooth"}); else s.scrollTop = want;
}
// 画面がスクロールしたぶんカーソルもずらし、指していたものを指し続ける(画面の外には出さない)
function dvCurShift(delta){
  var c = $("dvCursor"), box = $("dvBrowser"), s = $("dvScreen");
  if(!c || !box || !s || c.hidden || !delta) return;
  var t = c.style.top || "0", top;
  if(t.slice(-1) === "%") top = parseFloat(t) / 100 * box.offsetHeight; else top = parseFloat(t) || 0;
  var br = box.getBoundingClientRect(), sr = s.getBoundingClientRect();
  var lo = sr.top - br.top + 6, hi = sr.bottom - br.top - 14;
  c.style.top = Math.max(lo, Math.min(hi, top - delta)) + "px";
}
function dvType(id, text, ms, iv){
  dvLater(function(){
    var el = $(id); if(!el) return;
    el.textContent = "";
    var k = 0;
    var t = setInterval(function(){
      if(!document.body.contains(el) || k >= text.length){ clearInterval(t); return; }
      el.textContent += text[k++];
    }, (iv || 40) / dvSpeed());
    DV.typers.push(t);
  }, ms);
}
// 画面の一部だけを描き直す(id の要素の innerHTML を差し替え)
function dvPatch(id, html, ms){ dvLater(function(){ var el = $(id); if(el) el.innerHTML = html; }, ms); }
function dvUrlSet(url, hl, tip){
  var h = esc(url || "");
  if(hl) h = h.replace(esc(hl), '<mark class="dv-mark" id="dv-urlmark">' + esc(hl) + '</mark>');
  if(tip) h += '<span class="dv-urltip">' + esc(tip) + '</span>';
  $("dvUrl").innerHTML = h || "&nbsp;";
}

// ---- 再生エンジン
function dvSyncBtn(){
  var b = $("dvPlay");
  if(DV.playing) b.textContent = "⏸ 一時停止";
  else if(DV.i >= DV.steps.length - 1 && DV.steps.length) b.textContent = "▶ もう一度";
  else b.textContent = DV.i < 0 ? "▶ 再生" : "▶ 続きを再生";
}
function dvShow(i){
  dvStop();
  if(!DV.steps.length) return;
  i = Math.max(0, Math.min(DV.steps.length - 1, i));
  DV.i = i;
  var st = DV.steps[i];
  $("dvScreen").innerHTML = st.render();
  $("dvScreen").scrollTop = 0; DV.scrollGoal = null;
  dvUrlSet(st.url, st.hl, null);
  $("dvCapT").textContent = (i + 1) + ". " + st.title;
  $("dvCapB").textContent = st.body || "";
  var lis = $("dvSteps").children;
  for(var k = 0; k < lis.length; k++) lis[k].classList.toggle("dv-on", k === i);
  if(lis[i] && lis[i].scrollIntoView) lis[i].scrollIntoView({block: "nearest"});
  $("dvBar").style.width = Math.round(100 * (i + 1) / DV.steps.length) + "%";
  $("dvCount").textContent = (i + 1) + " / " + DV.steps.length;
  $("dvCursor").hidden = false;
  if(st.act) st.act();
  if(DV.playing){
    DV.timer = setTimeout(function(){
      if(DV.i + 1 < DV.steps.length) dvShow(DV.i + 1);
      else { DV.playing = false; dvSyncBtn(); }
    }, (st.t || 4000) / dvSpeed());
  }
  dvSyncBtn();
}
function dvPlayFrom(i){ DV.playing = true; dvShow(i); }
// 台本を差し替える(一覧・画面・キャプションを初期状態に)
function dvSetup(steps, opts){
  dvStop();
  opts = opts || {};
  DV.steps = steps; DV.i = -1; DV.playing = false; DV.opts = opts;
  $("dvSteps").innerHTML = steps.map(function(s, k){
    return '<li><span class="n">' + (k + 1) + '</span><span>' + esc(s.title) + '</span></li>';
  }).join("");
  var lis = $("dvSteps").children;
  for(var k = 0; k < lis.length; k++){
    (function(idx){ lis[idx].onclick = function(){ dvShow(idx); }; })(k);
  }
  $("dvScreen").innerHTML = '<div class="dv-idle">' + (opts.idle || "上の「▶ 再生」で始まります。") + '</div>';
  $("dvScreen").scrollTop = 0; DV.scrollGoal = null;
  dvUrlSet("", null, null);
  $("dvCapT").textContent = opts.capT || "ステップ一覧(右)から始めたい場面を選ぶこともできます";
  $("dvCapB").textContent = opts.capB || "";
  $("dvBar").style.width = "0";
  $("dvCount").textContent = "";
  $("dvCursor").hidden = true;
  if($("dvScriptName")) $("dvScriptName").textContent = opts.name ? "▶ " + opts.name : "";
  dvSyncBtn();
}
(function dvInit(){
  if(!$("dvPlay")) return;
  $("dvPlay").onclick = function(){
    if(DV.playing){ DV.playing = false; dvStop(); dvSyncBtn(); return; }
    if(DV.i < 0 || DV.i >= DV.steps.length - 1) dvPlayFrom(0);
    else dvPlayFrom(DV.i);
  };
  $("dvPrev").onclick = function(){ dvShow(Math.max(0, DV.i - 1)); };
  $("dvNext").onclick = function(){ dvShow(Math.min(DV.steps.length - 1, DV.i < 0 ? 0 : DV.i + 1)); };
  $("dvRestart").onclick = function(){ dvPlayFrom(0); };
})();

// ---- Difyの画面もどき(説明用のイメージ。③④の台本で共用する部品)
var DV_HOST = "https://dify.example.com";
function dvNav(active){
  return '<div class="dvy-nav"><div class="dvy-logo">D</div>'
    + ["探索", "スタジオ", "ナレッジ", "ツール"].map(function(t){
        var id = t === "ナレッジ" ? ' id="dv-tab-kb"' : (t === "スタジオ" ? ' id="dv-tab-studio"' : "");
        return '<span class="dvy-tab' + (t === active ? " on" : "") + '"' + id + '>' + t + '</span>';
      }).join("")
    + '<span style="margin-left:auto;width:26px;height:26px;border-radius:50%;background:#d8dce1"></span></div>';
}
// ナレッジの中の左メニュー。下の「API アクセス」はそのナレッジをAPIで使えるかのON/OFF(キーはここには無い)
function dvDocSide(){
  return '<div class="dvy-side"><div class="on">📄 ドキュメント</div><div>🔍 検索テスト</div><div>⚙ 設定</div>'
    + '<div style="height:150px"></div>'
    + '<div style="font-size:11px;border:1px solid var(--line);border-radius:8px;padding:4px 8px;color:#555">🔌 API アクセス <span style="color:#0f6b3f;float:right">●</span></div></div>';
}
function dvAppSide(active){
  return '<div class="dvy-side"><div class="' + (active === "orch" ? "on" : "") + '" id="dv-side-orch">🧩 オーケストレート</div>'
    + '<div class="' + (active === "api" ? "on" : "") + '" id="dv-side-appapi">🔑 APIアクセス</div><div>📜 ログ</div></div>';
}
function dvModal(inner, width){
  return '<div class="dvy-modal"><div class="dvy-dialog"' + (width ? ' style="width:' + width + 'px"' : "") + '>' + inner + '</div></div>';
}
function dvInput(id, val, ph, style){
  return '<div class="dvy-input" id="' + id + '"' + (style ? ' style="' + style + '"' : "") + '>'
    + (val ? esc(val) : '<span style="color:#aaa">' + esc(ph || "") + '</span>') + '</div>';
}
// スタジオ(アプリ一覧)。opts: {apps: [{name, kind, hl}], menu, importFile}
function scrStudio(opts){
  opts = opts || {};
  var apps = opts.apps || [];
  var h = dvNav("スタジオ") + '<div class="dvy-body"><div class="dvy-main"><div class="dvy-h">スタジオ</div><div class="dvy-cards">'
    + '<div class="dvy-card add" id="dv-newapp">+ アプリを作成</div>'
    + apps.map(function(a, i){
        return '<div class="dvy-card' + (a.hl ? " dv-hl" : "") + '" id="dv-app' + i + '">' + (a.icon || "📑") + " " + esc(a.name)
          + '<br><span style="color:#888">' + esc(a.kind || "チャットフロー") + '</span></div>';
      }).join("") + '</div>';
  if(opts.menu) h += '<div style="position:absolute;left:16px;top:74px;background:#fff;border:1px solid var(--line);border-radius:10px;'
    + 'box-shadow:0 6px 20px rgba(0,0,0,.15);padding:6px;width:230px;font-size:12px">'
    + '<div style="padding:6px 10px">✏ 最初から作成</div><div style="padding:6px 10px">🧩 テンプレートから作成</div>'
    + '<div style="padding:6px 10px;background:#eef3ff;border-radius:6px" id="dv-import">📥 DSLファイルをインポート</div></div>';
  h += '</div></div>';
  if(opts.importFile) h += dvModal('<b>DSLファイルをインポート</b>'
    + '<div class="dvy-drop" style="margin:10px 0;padding:14px">📄 ' + esc(opts.importFile) + '<br><span style="font-size:11px">' + esc(opts.importNote || "") + '</span></div>'
    + '<div style="text-align:right"><span class="dvy-btn ghost">キャンセル</span> <span class="dvy-btn" id="dv-importbtn">インポート</span></div>');
  return h;
}
// ナレッジ一覧。右上に「外部ナレッジベース連携 API」と「サービスAPI」(ナレッジ用APIキーはここ)。
// opts: {card: 「サービスAPI」のカードを開いた状態, modal: APIキー一覧を開いた状態, key: 作成済みのキー}
function scrKbList(items, opts){
  opts = opts || {};
  var h = dvNav("ナレッジ") + '<div class="dvy-body"><div class="dvy-main">'
    + '<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px"><div class="dvy-h" style="margin:0">ナレッジ</div>'
    + '<span style="margin-left:auto;font-size:11px;color:#777">🔗 外部ナレッジベース連携 API</span>'
    + '<span class="dvy-btn ghost" id="dv-svcapi" style="font-size:11px;padding:2px 8px"><span style="color:#0f6b3f">●</span> サービスAPI</span></div>'
    + '<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;font-size:11px;color:#777"><span>🏷 すべてのタグ</span>'
    + '<span class="dvy-input" style="width:150px;padding:2px 8px;color:#aaa">🔍 検索</span></div>'
    + '<div class="dvy-cards"><div class="dvy-card add" id="dv-kbcreate">+ ナレッジを作成</div>'
    + items.map(function(n){ return '<div class="dvy-card">📚 ' + esc(n) + '<br><span style="color:#888">0 ドキュメント</span></div>'; }).join("")
    + '</div>';
  if(opts.card) h += '<div id="dv-apicard" style="position:absolute;right:16px;top:40px;width:330px;background:#fff;border:1px solid var(--line);border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,.16);font-size:12px;z-index:2">'
    + '<div style="padding:12px 14px"><div style="display:flex;align-items:center;gap:8px;margin-bottom:8px"><span style="display:inline-block;width:20px;height:20px;border-radius:6px;background:#155eef"></span><b>バックエンドサービスAPI</b>'
    + '<span style="margin-left:auto;color:#0f6b3f;font-size:11px">● サービス中</span></div>'
    + '<div style="font-size:11px;color:#666;margin-bottom:2px">サービスAPIエンドポイント</div>'
    + '<div style="display:flex;align-items:center;gap:6px">' + dvInput("dv-apiurl", DV_HOST + "/v1", "", "flex:1") + '<span>📋</span></div></div>'
    + '<div style="border-top:1px solid var(--line);padding:8px 10px;display:flex;gap:6px"><span class="dvy-btn ghost" id="dv-apikeybtn" style="font-size:11px;padding:3px 8px">🔑 APIキー</span>'
    + '<span class="dvy-btn ghost" style="font-size:11px;padding:3px 8px">📖 APIリファレンス</span></div></div>';
  h += '</div></div>';
  if(opts.modal) h += dvApiKeyModal(opts.key, true);
  return h;
}
// APIキーの一覧ダイアログ(アプリ用・ナレッジ用で共用)。key があれば作成済みの1件を表示
function dvApiKeyModal(key, showScope){
  return dvModal('<b>API キー</b>'
    + '<div style="font-size:11px;color:#666;margin:6px 0 10px">API の悪用を防ぐために、API キーを保護してください。</div>'
    + (key
       ? '<table class="dvy-table"><tr><th>シークレットキー</th>' + (showScope ? '<th>スコープ</th>' : '') + '<th>作成日時</th><th></th></tr>'
         + '<tr><td><span id="dv-keytext" style="font-family:Consolas,monospace">' + esc(key) + '</span></td>' + (showScope ? '<td>特定のナレッジベース(判定事例)</td>' : '') + '<td>今日</td><td>📋</td></tr></table>'
       : '<div class="dvy-empty" style="padding:14px">キーはまだありません</div>')
    + '<div style="margin-top:10px"><span class="dvy-btn" id="dv-newkey">+ 新しいシークレットキーを作成</span></div>', 620);
}
function scrKbCreate(modal, name){
  var h = dvNav("ナレッジ") + '<div class="dvy-body"><div class="dvy-main">'
    + '<div style="font-size:12px;color:#666;margin-bottom:10px"><b style="color:#155eef">① データソースの選択</b> → ② テキストの前処理とクリーニング → ③ 実行して完了</div>'
    + '<div style="display:flex;gap:14px;font-size:12px;margin-bottom:8px"><b style="border-bottom:2px solid #155eef">テキストファイルからインポート</b>'
    + '<span style="color:#777">Notionから同期</span><span style="color:#777">ウェブサイトから同期</span></div>'
    + '<div class="dvy-drop">📄 ファイルをドラッグ&amp;ドロップ、または <span class="dvy-link">参照</span><br><span style="font-size:11px">TXT・PDF・DOCX などに対応</span></div>'
    + '<div style="margin-top:14px"><span class="dvy-link" id="dv-emptylink">空のナレッジベースを作成したいです</span></div>'
    + '</div></div>';
  if(modal) h += dvModal('<b>空のナレッジベースを作成</b>'
    + '<div style="font-size:12px;color:#666;margin:6px 0 10px">空のナレッジベースを作成します。ドキュメントはあとから追加できます(このアプリでは「正解: ◯◯」の返信で自動的に増えます)。</div>'
    + '<div style="font-size:12px;margin-bottom:4px">ナレッジ名</div>' + dvInput("dv-kbname", name, "")
    + '<div style="text-align:right;margin-top:12px"><span class="dvy-btn ghost">キャンセル</span> <span class="dvy-btn" id="dv-kbok">作成</span></div>');
  return h;
}
function scrKbDocs(name, rows){
  return dvNav("ナレッジ") + '<div class="dvy-body">' + dvDocSide() + '<div class="dvy-main">'
    + '<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px"><div class="dvy-h" style="margin:0">📚 ' + esc(name) + '</div>'
    + '<span class="dvy-btn ghost" style="margin-left:auto">+ ファイルを追加</span></div>'
    + (rows.length
       ? '<table class="dvy-table"><tr><th>#</th><th>名前</th><th>文字数</th><th>状態</th></tr>'
         + rows.map(function(r, i){ return '<tr><td>' + (i + 1) + '</td><td id="dv-row' + i + '">' + esc(r) + '</td><td>412</td><td style="color:#0f6b3f">● 利用可能</td></tr>'; }).join("")
         + '</table>'
       : '<div class="dvy-empty">ドキュメントがまだありません<br><span style="font-size:11px">(空で正常です。アプリに「正解: ◯◯」と返信すると、ここに判定事例カードが増えていきます)</span></div>')
    + '</div></div>';
}
// アプリの「APIアクセス」画面(④で使用)。opts: {appName, modal, key}
function scrApiAccess(opts){
  opts = opts || {};
  var h = dvNav("スタジオ") + '<div style="height:32px;background:#fff;border-bottom:1px solid var(--line);display:flex;align-items:center;padding:0 12px;font-size:12px"><b>' + esc(opts.appName || "アプリ") + '</b></div>'
    + '<div class="dvy-body" style="height:calc(100% - 76px)">' + dvAppSide("api") + '<div class="dvy-main">'
    + '<div style="display:flex;align-items:center;margin-bottom:10px"><div class="dvy-h" style="margin:0">APIアクセス</div>'
    + '<span class="dvy-btn" style="margin-left:auto" id="dv-apikeybtn">🔑 APIキー</span></div>'
    + '<div style="font-size:12px;color:#666">APIサーバー</div>'
    + dvInput("dv-apiurl", DV_HOST + "/v1", "", "max-width:360px;margin-bottom:12px")
    + '<div style="font-size:12px;color:#666">このアプリのAPI: ' + (opts.key ? 'シークレットキー 1 件' : 'シークレットキーはまだありません') + '</div>'
    + '</div></div>';
  if(opts.modal) h += dvApiKeyModal(opts.key, false);
  return h;
}
// ナレッジ一覧+サービスAPIカード(+キー一覧)。③の台本用(DV_KEY は台本側で定義)
function scrApi(modal, created){ return scrKbList(["判定事例"], {card: true, modal: modal, key: created ? DV_KEY : ""}); }
// チャット画面。msgs: [{me, id, html}]
function scrChat(msgs){
  return dvNav("スタジオ") + '<div class="dvy-chat" style="height:calc(100% - 44px);overflow:hidden">'
    + msgs.map(function(m){ return '<div class="dvy-msg' + (m.me ? " me" : "") + '"' + (m.id ? ' id="' + m.id + '"' : "") + '>' + m.html + '</div>'; }).join("")
    + '</div>';
}
