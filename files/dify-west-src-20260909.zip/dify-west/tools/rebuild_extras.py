#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""現行のDSL(contract-account-classification.yml)から tools/workflow_extras.yml を復元する。

workflow_extras.yml(自動生成でツリーに載らない素材: 出力例・更問い質問例・固定定義・ID・座標)を
紛失した場合や、DifyからエクスポートしたDSLしか手元に無い場合に使う。

  python3 tools/rebuild_extras.py                # YAML → tools/workflow_extras.yml
  python3 tools/rebuild_extras.py -y 別の.yml -o 出力先.yml

ステージ(細分判定ノード)は、プロンプト内の「前段の判定で…に該当」の文と
エッジ構造からYAMLだけで自動判別する(ノードIDのハードコード無し)。
"""
import argparse
import os
import re

import miniyaml

try:
    import yaml  # あれば任意形式のYAMLも読める(無くても本リポジトリのファイルは読める)
except ImportError:
    yaml = None


def _load(path):
    text = open(path, encoding='utf-8').read()
    if yaml is not None:
        return yaml.safe_load(text)
    return miniyaml.load(text)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROOT_LABEL = '区分判定'

# スキャフォールド(ツリー非依存)ノードのID。tools/generate_workflow.py が常にこのIDで出力する
SCAFFOLD = ['start', 'doc-extractor', 'llm-summary', 'if-else-confirm', 'template-confirm',
            'aggregator', 'if-else-q', 'llm-journal', 'aggregator-out', 'end']


def block(text, start_marker, end_markers):
    lines = text.split('\n')
    out, on = [], False
    for ln in lines:
        if on and any(ln.startswith(m) for m in end_markers):
            break
        if on:
            out.append(ln)
        if ln.startswith(start_marker):
            on = True
    return out


def main():
    ap = argparse.ArgumentParser(description='DSLから workflow_extras.yml を復元')
    ap.add_argument('-y', '--yml', default=os.path.join(ROOT, 'contract-account-classification.yml'))
    ap.add_argument('-o', '--output', default=os.path.join(ROOT, 'tools', 'workflow_extras.yml'))
    args = ap.parse_args()

    d = _load(args.yml)
    nodes = {n['id']: n for n in d['workflow']['graph']['nodes']}
    edges = d['workflow']['graph']['edges']

    missing = [i for i in SCAFFOLD if i not in nodes]
    if missing:
        raise SystemExit('スキャフォールドノードが見つかりません: %s' % missing)

    # ルートの区分判定LLM = 認識確認ゲートの false 側
    root_llm = next(e['target'] for e in edges
                    if e['source'] == 'if-else-confirm' and e['sourceHandle'] == 'false')

    # ステージLLM: スキャフォールド以外の llm ノード
    stage_llms = [n for n in nodes.values()
                  if n['data']['type'] == 'llm' and n['id'] not in SCAFFOLD]
    # 各LLMの自分の if-else(llm → if-else エッジ)
    own_ifelse = {e['source']: e['target'] for e in edges
                  if nodes[e['target']]['data']['type'] == 'if-else'
                  and nodes[e['source']]['data']['type'] == 'llm'
                  and e['target'] not in SCAFFOLD}
    # 親if-elseのケース: (if-else, case_id) → target llm
    case_target = {}
    for e in edges:
        if e['sourceHandle'].startswith('case-') and e['source'] not in SCAFFOLD:
            case_target[(e['source'], e['sourceHandle'])] = e['target']

    stages = {}
    for n in stage_llms:
        lid = n['id']
        sysp = n['data']['prompt_template'][0]['text']
        userp = n['data']['prompt_template'][1]['text']
        if lid == root_llm:
            label = ROOT_LABEL
        else:
            m = (re.search(r'前段の判定で.+?のうち「(.+?)」に該当', sysp)
                 or re.search(r'前段の判定で勘定科目区分「(.+?)」に該当', sysp))
            if not m:
                raise SystemExit('ノード %s のプロンプトからステージ名を判別できません' % lid)
            label = m.group(1)
        st = {
            'id': lid,
            'title': n['data']['title'],
            'desc': n['data']['desc'],
            'position': [n['position']['x'], n['position']['y']],
            'user_intro': userp.split('\n')[0],
        }
        ex = block(sysp, '【出力例】', ['【'])
        ex = [l for l in ex if l.strip()]
        if ex:
            st['examples'] = ex
        q = [l.strip() for l in block(sysp, '- このノードでの質問の例:', ['【']) if l.strip()]
        if q:
            st['question'] = q
        m = re.search(r'前段の判定で(.+?)のうち「', sysp)
        if m:
            st['parent_phrase'] = m.group(1)
        # 追加の出力ルール行(共通行・fallback行以外)
        extra = []
        for ln in block(sysp, '【出力ルール】', ['【']):
            if not ln.strip():
                continue
            if ln.startswith('- 出力はラベル1つのみ') or ln.startswith('- 出力してよいラベルは'):
                continue
            if ln.startswith('  ') and label == ROOT_LABEL:
                continue  # ラベル列挙行
            if ln.startswith('- 判定材料はあるが'):
                continue
            extra.append(ln)
        if extra:
            st['extra_rules'] = extra
        # プロンプト内固定の定義(N. ラベル(例: ...))
        if '{{#env.' not in sysp:
            defs = {}
            for ln in sysp.split('\n'):
                m = re.match(r'^\d+\. (.+?)(?:\(例: (.+)\))?$', ln)
                if m:
                    defs[m.group(1)] = m.group(2) or ''
            if defs:
                st['defs'] = defs
        # 親if-elseのケース
        for (src, handle), tgt in case_target.items():
            if tgt == lid:
                case = next(c for c in nodes[src]['data']['cases'] if c['case_id'] == handle)
                st['case_id'] = case['case_id']
                st['cond_id'] = case['conditions'][0]['id']
                st['case_value'] = case['conditions'][0]['value']
        if lid in own_ifelse:
            i = nodes[own_ifelse[lid]]
            st['ifelse'] = {
                'id': i['id'],
                'title': i['data']['title'],
                'desc': i['data']['desc'],
                'position': [i['position']['x'], i['position']['y']],
                'height': i['height'],
            }
        if label in stages:
            raise SystemExit('ステージ名が重複しています: %s' % label)
        stages[label] = st

    extras = {
        'app': d['app'],
        'features': d['workflow']['features'],
        'conversation_variables': d['workflow'].get('conversation_variables', []),
        'env_ids': {v['name']: {k: v[k] for k in v if k not in ('name', 'value', 'description')}
                    for v in d['workflow']['environment_variables']},
        'env_descriptions': {v['name']: v.get('description', '')
                             for v in d['workflow']['environment_variables']},
        'scaffold_nodes': [nodes[i] for i in SCAFFOLD],
        'stages': stages,
    }
    with open(args.output, 'w', encoding='utf-8') as f:
        f.write(miniyaml.dump(extras))
    print('written %s(%d stages)' % (args.output, len(stages)))


if __name__ == '__main__':
    main()
