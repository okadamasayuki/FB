// ============================================================ 自動学習ループ(⑤ページ固有のUI)
// コア(evXxx / EV_*)は eval_common.js にあり、ビルド時に一緒に埋め込まれる。
// 通信先は lnUrl に入力された自社DifyのURLのみ。
//
// 回し方は機械学習で標準の「エポック学習」:
//   1エポック = 全決裁をテスト → 誤答の決裁にだけ同じ会話で「正解: ◯◯」を返信
//   (アプリの自己学習が事例カードを保存。2回目からは古いカードを削除して
//    誤答情報を添えて作り直し=1決裁1カードの差し替え)→ 次のエポックで再テスト。
//   目標正答率に到達・改善が止まった・最大エポック、のどれかで停止する。
//
// ナレッジAPIキーの有無で2つのモード:
//   api モード(キーあり)  : ③で「Difyの事例ナレッジ」を選んで作ったアプリ向け。アプリがナレッジに保存し、
//     ⑤はナレッジAPIで古いカードを削除して差し替える
//   browser モード(キーなし): ③の既定(環境変数 learned_cases 方式)のアプリ向け(ナレッジ方式でキーが無い場合も同じ)。
//     アプリが返したカードを⑤がこのブラウザの「仮ナレッジ」に溜め、
//     次のエポックの判定では似たカード(最大4枚)を「OK」の返信に「参考事例:」として添える。
//     最後に 判定事例.txt にまとめ、アプリの環境変数 learned_cases に貼る(ナレッジ方式のアプリはナレッジへ手でアップロード)。
var LN_FMT_NAMES = {tree: "ツリー判定形式", flat: "コード2段選択形式", pick: "コード一発選択形式"};
var LN_MARK = {ok: "○", ng: "×", ask: "?", error: "E"};
var LN = {
  items: [], cases: [],            // 取り込んだフォルダと決裁一覧
  train: [], val: [], all: [],     // 学習用と検証用(ホールドアウト)の分割
  epoch: 0, phase: "",             // 進行中のエポックと段階("test" / "teach")
  results: {}, taught: {},         // このエポックのテスト結果(idx→…)と教えた決裁
  missIdx: [],                     // このエポックで学習対象になった誤答のidx
  curve: [],                       // 学習曲線: {ep, tr, va, miss, err, taught}
  ledger: {},                      // カード台帳: 決裁ラベル→{docId, count, wrong, card}(card は仮ナレッジ用の本文)
  injected: 0,                     // 仮ナレッジモードで参考事例を添えた回数
  warns: [], noDs: false,          // 警告と「ナレッジAPIが使えない」フラグ
  noAnsCount: 0,                   // 正解.txt が無くて除外した決裁の数
  finished: false, fatal: "", stopReason: "",
  running: false, stopFlag: false, aborters: []
};

function lnNum(id, def){
  var v = parseInt($(id).value, 10);
  return isNaN(v) ? def : v;
}
function lnMsg(t){ $("lnProg").textContent = t; }

// ---- カード台帳の保存(このブラウザ内・ナレッジIDごと。仮ナレッジモードはURL+アプリキーの要約ごと)。
// 決裁→カードID(またはカード本文)を残しておくと、ページを再読み込みしても前回のカードを差し替えできる
function lnHash(str){
  var h = 5381;
  for(var i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
  return (h >>> 0).toString(16);
}
function lnLedgerNs(cfg){ return cfg.dsId ? cfg.dsId : ("app:" + lnHash(cfg.base + "|" + cfg.key)); }
function lnLedgerKey(dsId){ return "kanjoLearnLedger:" + dsId; }
function lnLedgerLoad(dsId){
  if(!dsId) return;
  try{
    var saved = JSON.parse(localStorage.getItem(lnLedgerKey(dsId)) || "null");
    if(saved) Object.keys(saved).forEach(function(lb){ if(!LN.ledger[lb]) LN.ledger[lb] = saved[lb]; });
  }catch(e){}
}
function lnLedgerSave(dsId){
  if(!dsId) return;
  try{ localStorage.setItem(lnLedgerKey(dsId), JSON.stringify(LN.ledger)); }catch(e){}
}

function lnCfg(){
  var fmtEl = document.querySelector('input[name="lnFmt"]:checked');
  return {
    base: $("lnUrl").value.trim().replace(/\/+$/, ""),
    key: $("lnKey").value.trim(),
    dsKey: $("lnDsKey").value.trim(),
    dsId: $("lnDsId").value.trim(),
    mode: $("lnDsKey").value.trim() ? "api" : "browser",
    fmt: fmtEl ? fmtEl.value : "pick",
    target: Math.max(1, Math.min(100, lnNum("lnTarget", 100))),
    maxEp: Math.max(1, Math.min(20, lnNum("lnMaxEp", 5))),
    patience: Math.max(0, Math.min(5, lnNum("lnPatience", 1))),
    holdout: Math.max(0, Math.min(50, lnNum("lnHoldout", 0))),
    timeoutSec: lnNum("lnTimeout", 300),
    par: Math.max(1, Math.min(6, lnNum("lnPar", 3)))
  };
}

// ---- フォルダ取り込み(検出と正解の読み込みは④と同じコア)
async function lnIngest(items){
  var r = await evBuildCases(items, {});
  LN.items = r.items;
  // ⑤は正解を教えるので、正解.txt の無い決裁は除外する(判定結果だけ見たいときは④の「ブラウザで採点」)
  LN.noAnsCount = r.cases.filter(function(c){ return !c.has_answer; }).length;
  LN.cases = r.cases.filter(function(c){ return c.has_answer; });
  // 進行状態はリセット(台帳はDify側に残っているカードと対応するため保持する)
  LN.train = []; LN.val = []; LN.all = [];
  LN.epoch = 0; LN.phase = ""; LN.results = {}; LN.taught = {}; LN.missIdx = [];
  LN.curve = []; LN.warns = []; LN.finished = false; LN.fatal = ""; LN.stopReason = "";
  lnRenderSummary();
  $("lnTableWrap").innerHTML = "";
  $("lnCurve").innerHTML = "";
  $("lnRun").disabled = !LN.cases.length;
  $("lnRun").textContent = "学習を開始";
  $("lnDlMd").disabled = true;
  $("lnReport").style.display = "none";
  lnMsg("");
  lnLedgerLoad(lnLedgerNs(lnCfg()));
  lnRenderLedger();
}

function lnRenderSummary(){
  var noAnsNote = LN.noAnsCount
    ? ' <span style="color:#b42318">正解.txt が無い決裁 ' + LN.noAnsCount + "件は除外しました(⑤は正解を教えるので正解.txt が必要です。"
      + "判定結果だけ見たいときは④の「ブラウザで採点」へ)。</span>" : "";
  if(!LN.cases.length){
    $("lnSummary").innerHTML = '<div class="warnbox">決裁が見つかりません。サブフォルダ(=1決裁)の中に決裁書類と、'
      + 'ファイル名に「正解」を含む .txt(例: 正解.txt。1行目に「科目名 [10桁コード]」かコード)を置いてください。' + noAnsNote + "</div>";
    return;
  }
  var nDocs = 0, badAns = 0;
  LN.cases.forEach(function(c){
    nDocs += c.docs.length;
    if(!c.expect_code && !c.expect_name) badAns++;
  });
  $("lnSummary").innerHTML = "<b>" + LN.cases.length + "決裁</b>(文書 " + nDocs + "ファイル)を読み取りました。"
    + (badAns ? '<span style="color:#b42318"> 正解.txt はあるが読めない決裁が' + badAns + '件あります(1行目に「科目名 [10桁コード]」かコード)。</span>' : "")
    + noAnsNote
    + " まだ送信していません。「学習を開始」で開始します。";
}

// 学習用と検証用の分割(検証=末尾からの取り分け。学習には使わず、初見の正答率を測る)
function lnSplit(cfg){
  var lim = lnNum("lnLimit", 0);
  var cases = lim > 0 ? LN.cases.slice(0, lim) : LN.cases.slice();
  var nVal = Math.max(0, Math.min(cases.length - 1, Math.round(cases.length * cfg.holdout / 100)));
  LN.val = nVal > 0 ? cases.slice(cases.length - nVal) : [];
  LN.train = cases.slice(0, cases.length - nVal);
  LN.all = LN.train.concat(LN.val);
}

// ---- ナレッジ(データセット)API: カード一覧とカード削除
async function lnListDocIds(cfg){
  var ids = [];
  for(var page = 1; page <= 50; page++){
    var r;
    try{
      r = await evFetch(cfg.base + "/datasets/" + encodeURIComponent(cfg.dsId)
                        + "/documents?page=" + page + "&limit=100",
                        {headers: {Authorization: "Bearer " + cfg.dsKey}}, 60, LN.aborters);
    }catch(e){
      return {err: "通信できません(" + ((e && e.message) || e) + ")"};
    }
    if(!r.ok) return {err: "HTTP " + r.status};
    var d = await r.json();
    (d.data || []).forEach(function(x){ ids.push(x.id); });
    if(!d.has_more) break;
  }
  return {ids: ids};
}

async function lnDeleteDoc(cfg, docId){
  var r;
  try{
    r = await evFetch(cfg.base + "/datasets/" + encodeURIComponent(cfg.dsId)
                      + "/documents/" + encodeURIComponent(docId),
                      {method: "DELETE", headers: {Authorization: "Bearer " + cfg.dsKey}}, 60, LN.aborters);
  }catch(e){
    return {err: "通信できません(" + ((e && e.message) || e) + ")"};
  }
  if(!r.ok && r.status !== 404) return {err: "HTTP " + r.status};
  return {};
}

function lnWarnDs(detail){
  if(LN.noDs) return;
  LN.noDs = true;
  LN.warns.push("ナレッジAPIでのカード一覧/削除ができませんでした(" + detail + ")。"
    + "学習は続けますが古いカードが残るため、ナレッジの画面で「判定事例: 〈決裁名〉」の古い方を手で削除してください。");
}

// アプリの回答から「何と誤答したか」(相手勘定の科目名)を取り出す
function lnWrongName(answer){
  var m = evNk(answer || "").match(/相手勘定\(科目\)\s*\|\s*([^|\n]+)/);
  return m ? m[1].trim() : "違う科目";
}

// 回答から【判定事例】カードの本文を取り出す(無ければ "")
function lnExtractCard(answer){
  var a = String(answer || "");
  var i = a.indexOf("【判定事例】");
  if(i < 0) return "";
  var body = a.slice(i);
  var cut = body.indexOf("\n---");
  if(cut >= 0) body = body.slice(0, cut);
  return body.trim();
}

// ---- 1決裁に正解を教える(カードの差し替え)
async function lnTeachOne(cfg, i){
  var c = LN.all[i];
  var res = LN.results[i];
  var led = LN.ledger[c.label] || {docId: "", count: 0};
  var api = cfg.mode === "api";
  // 1) 2回目以降は、前回作ったカードを先に削除(=差し替え)。仮ナレッジモードはブラウザ側で差し替えるので不要
  if(api && !LN.noDs && led.docId){
    var del = await lnDeleteDoc(cfg, led.docId);
    if(del.err) lnWarnDs("削除 " + del.err);
  }
  // 2) 保存前のカード一覧(保存後との差分で新カードのIDを追跡する)
  var before = null;
  if(api && !LN.noDs){
    var b = await lnListDocIds(cfg);
    if(b.err) lnWarnDs("一覧 " + b.err);
    else before = b.ids;
  }
  // 3) 判定と同じ会話に「正解: ◯◯」を返信(アプリの自己学習がカードを保存する)
  var wrong = lnWrongName(res.answer);
  var q = "正解: " + c.expect_name + (c.expect_code ? " [" + c.expect_code + "]" : "");
  if(led.count > 0){
    q += "\n(前回のカードでは「" + wrong + "」と誤答したままでした。次は必ずこの正解を選べるよう、"
       + "この契約を見分ける決め手を具体的に書き直してください)";
  }
  var t;
  try{
    t = await evChat(cfg.base, cfg.key, {query: q, conversation_id: res.conv}, cfg.timeoutSec, LN.aborters);
  }catch(e){
    t = {err: "error: " + ((e && e.message) || e)};
  }
  if(t.err){
    if(LN.stopFlag) return {stopped: true};
    return {teachErr: t.err};
  }
  var ans = t.answer || "";
  var card = lnExtractCard(ans);
  var saved = ans.indexOf("事例ナレッジに保存しました") >= 0;
  var unsaved = ans.indexOf("事例ナレッジには保存していません") >= 0 || ans.indexOf("保存先が未設定") >= 0;
  // 環境変数方式のアプリ(③の既定)は保存せずカードを返すだけ
  var cardOnly = !saved && !unsaved && ans.indexOf("判定事例カードを作りました") >= 0;
  if(!saved && !unsaved && !cardOnly){
    LN.fatal = "「正解: …」への返事が学習の応答になっていません。③で「自己学習」にチェックを入れて"
      + "作った判定アプリのAPIキーか確認してください。回答(抜粋): " + ans.slice(0, 200);
    return {fatal: true};
  }
  if(api && unsaved){
    LN.fatal = "アプリが「保存先が未設定」と返しました。判定アプリの環境変数 dify_base_url(…/v1)・"
      + "dataset_api_key(dataset-…)・case_dataset_id(事例ナレッジのID)を設定してください"
      + "(③の「設定込みでDSLを作る」欄に入れて作り直し、再インポートするのが早道です)。"
      + "ナレッジAPIキーを使わない場合は、このページの「ナレッジAPIキー」を空欄にすると仮ナレッジモードになります。";
    return {fatal: true};
  }
  if(api && cardOnly){
    LN.fatal = "この判定アプリは事例をナレッジに保存しない「環境変数 learned_cases」方式(③の既定)です。"
      + "このページの「ナレッジAPIキー」と「事例ナレッジのID」を空欄にして(仮ナレッジモード)回してください。"
      + "学習した事例は最後に「判定事例.txt を保存」し、アプリの環境変数 learned_cases に貼ります。";
    return {fatal: true};
  }
  if(api && saved){
    var m = ans.match(/HTTP\s*([0-9]{3})/);
    if(m && m[1].slice(0, 1) !== "2"){
      LN.fatal = "事例の保存APIが HTTP " + m[1] + " を返しました。判定アプリの環境変数 "
        + "dify_base_url / dataset_api_key / case_dataset_id を確認してください。";
      return {fatal: true};
    }
  }
  if(!api && !card){
    LN.fatal = "アプリの返事に【判定事例】カードが入っていません。古い生成器で作ったアプリの可能性があります。"
      + "③で作り直して(キー未設定でもカードを返す版)再インポートしてください。回答(抜粋): " + ans.slice(0, 200);
    return {fatal: true};
  }
  // 4) 保存後の一覧との差分から、新しいカードのIDを台帳へ(apiモードのみ)
  var docId = "";
  if(api && !LN.noDs && before){
    var a = await lnListDocIds(cfg);
    if(a.err) lnWarnDs("一覧 " + a.err);
    else{
      var seen = {};
      before.forEach(function(id){ seen[id] = 1; });
      var news = a.ids.filter(function(id){ return !seen[id]; });
      if(news.length) docId = news[0];
    }
  }
  LN.ledger[c.label] = {docId: docId, count: led.count + 1, wrong: wrong, card: card};
  lnLedgerSave(lnLedgerNs(cfg));
  return {};
}

// ---- 仮ナレッジ(ブラウザ側): 文字の重なり(2文字組)で似たカードを選び、「OK」に添える
function lnGrams(str){
  var t = evNk(String(str || "")).replace(/[\s|\[\]【】()()「」:：、。・,.\/\-*#]+/g, "");
  var g = {};
  for(var i = 0; i + 1 < t.length; i++) g[t.slice(i, i + 2)] = 1;
  return g;
}
function lnSim(ga, gb){
  var inter = 0, na = 0, nb = 0, k;
  for(k in ga){ na++; if(gb[k]) inter++; }
  for(k in gb) nb++;
  return (na && nb) ? inter / Math.sqrt(na * nb) : 0;
}
function lnPickCards(summaryText, limit){
  var q = lnGrams(summaryText);
  var scored = [];
  Object.keys(LN.ledger).forEach(function(lb){
    var e = LN.ledger[lb];
    if(!e || !e.card) return;
    scored.push({label: lb, card: e.card, s: lnSim(q, lnGrams(e.card))});
  });
  scored.sort(function(a, b){ return b.s - a.s; });
  return scored.filter(function(x){ return x.s > 0; }).slice(0, limit || 4);
}
function lnOkText(firstAnswer){
  var picks = lnPickCards(firstAnswer, 4);
  if(!picks.length) return "OK";
  LN.injected += picks.length;
  return "OK\n\n参考事例:\n" + picks.map(function(x){ return x.card; }).join("\n\n");
}
// 仮ナレッジの中身を、Difyのナレッジにアップロードするテキストにする(1決裁=1ブロック。空行区切りで1カード=1チャンク)
function lnCardsText(){
  var labels = Object.keys(LN.ledger).filter(function(lb){ return LN.ledger[lb] && LN.ledger[lb].card; }).sort();
  return labels.map(function(lb){ return "### " + lb + "\n" + LN.ledger[lb].card; }).join("\n\n") + (labels.length ? "\n" : "");
}
function lnCardCount(){
  return Object.keys(LN.ledger).filter(function(lb){ return LN.ledger[lb] && LN.ledger[lb].card; }).length;
}

// ---- 1エポックぶんのテスト(④と同じ並列ワーカー。結果が残っているidxはスキップ=再開)
async function lnTestEpoch(cfg){
  lnRenderDetail();
  var queue = [];
  LN.all.forEach(function(_, i){ if(!LN.results[i]) queue.push(i); });
  var idx = 0;
  function prog(){
    var done = Object.keys(LN.results).length;
    lnMsg("エポック" + LN.epoch + "/" + cfg.maxEp + ": テスト中… " + done + " / " + LN.all.length + " 決裁"
      + (LN.stopFlag ? " — 停止中(実行中の呼び出しを打ち切っています)" : ""));
  }
  prog();
  async function worker(){
    while(!LN.stopFlag && idx < queue.length){
      var i = queue[idx++];
      var c = LN.all[i];
      var cell = $("ln-cell-" + i);
      if(cell) cell.textContent = "…";
      var r = await evRunOne(cfg.base, cfg.key, c.docs, cfg.timeoutSec,
                             {aborters: LN.aborters, stopped: function(){ return LN.stopFlag; },
                              okFor: cfg.mode === "browser" ? lnOkText : null});
      if(LN.stopFlag && r.err === "stopped"){ if(cell) cell.textContent = ""; break; }
      var g = evGrade(r.answer, r.err, c.expect_name, c.expect_code);
      LN.results[i] = {st: g[0], got: g[1], answer: r.answer, conv: r.conv};
      if(cell) cell.textContent = LN_MARK[g[0]] || "";
      prog();
    }
  }
  var ws = [];
  for(var w = 0; w < cfg.par; w++) ws.push(worker());
  await Promise.all(ws);
  lnRenderDetail();
}

function lnAcc(from, to){
  var ok = 0;
  for(var i = from; i < to; i++){
    var r = LN.results[i];
    if(r && r.st === "ok") ok++;
  }
  return to > from ? 100.0 * ok / (to - from) : 0;
}

// テスト後の集計と停止判定。停止するなら理由(文字列)、続けるなら null を返す
function lnEvalEpoch(cfg){
  var tr = lnAcc(0, LN.train.length);
  var va = LN.val.length ? lnAcc(LN.train.length, LN.all.length) : null;
  var missIdx = [];
  for(var i = 0; i < LN.train.length; i++){
    var r = LN.results[i];
    if(r && (r.st === "ng" || r.st === "ask") && r.conv) missIdx.push(i);
  }
  var errs = 0;
  for(var j = 0; j < LN.all.length; j++){
    if(LN.results[j] && LN.results[j].st === "error") errs++;
  }
  LN.missIdx = missIdx;
  LN.curve.push({ep: LN.epoch, tr: tr, va: va, miss: missIdx.length, err: errs, taught: 0});
  lnRenderCurve();
  lnRenderReport(cfg);
  if(tr >= cfg.target){
    return "🎯 目標の正答率(" + cfg.target + "%)に到達しました(学習正答率 " + Math.round(tr) + "%)";
  }
  if(LN.epoch >= cfg.maxEp) return "最大エポック(" + cfg.maxEp + ")に到達しました";
  if(cfg.patience > 0 && LN.curve.length >= cfg.patience + 1){
    var noImp = 0;
    for(var k = LN.curve.length - 1; k >= 1; k--){
      var best = 0;
      for(var p = 0; p < k; p++) best = Math.max(best, LN.curve[p].tr);
      if(LN.curve[k].tr <= best) noImp++;
      else break;
    }
    if(noImp >= cfg.patience){
      return "学習正答率が" + cfg.patience + "エポック続けて改善しなかったため早期終了しました(過学習防止)";
    }
  }
  if(!missIdx.length) return "学習できる誤答がありません(残りの不正解はエラーのみ)";
  return null;
}

// 誤答の決裁に1件ずつ正解を教える(順番に。教えた決裁は再開時にスキップ)
async function lnTeachEpoch(cfg){
  var list = LN.missIdx;
  for(var k = 0; k < list.length; k++){
    if(LN.stopFlag || LN.fatal) return;
    var i = list[k];
    var c = LN.all[i];
    if(LN.taught[c.label]) continue;
    lnMsg("エポック" + LN.epoch + "/" + cfg.maxEp + ": 学習中… " + (k + 1) + " / " + list.length
      + "(" + c.label + " に正解を教えています)");
    var r = await lnTeachOne(cfg, i);
    if(r.fatal || r.stopped) return;
    LN.taught[c.label] = true;
    if(r.teachErr){
      LN.warns.push("エポック" + LN.epoch + ": " + c.label + " への学習が失敗しました(" + r.teachErr + ")");
    }else{
      LN.curve[LN.curve.length - 1].taught++;
    }
    lnRenderLedger();
  }
}

// ---- メインループ: テスト → 集計・停止判定 → 学習 → 次のエポック
async function lnRunAll(){
  var cfg = lnCfg();
  if(!cfg.base){ lnMsg("APIサーバー(…/v1)を入力してください。"); return; }
  if(!cfg.key){ lnMsg("判定アプリのAPIキー(自己学習チェック入り)を入力してください。"); return; }
  if(cfg.mode === "api" && !cfg.dsId){
    lnMsg("事例ナレッジのIDを入力してください(ナレッジAPIキーを使うときは、カードの差し替えと追跡に必要です)。"
      + "ナレッジAPIキーを空欄にすると、キー不要の仮ナレッジモードになります。");
    return;
  }
  if(!LN.cases.length){ lnMsg("先に決裁フォルダを入れてください。"); return; }
  lnSaveCfg();
  if(!LN.epoch || LN.finished){
    // 新規スタート(前回の結果はクリア。台帳はカードの差し替えに使うため保持)
    lnSplit(cfg);
    lnLedgerLoad(lnLedgerNs(cfg));
    LN.injected = 0;
    LN.epoch = 1;
    LN.phase = "test";
    LN.results = {}; LN.taught = {}; LN.missIdx = [];
    LN.curve = []; LN.warns = []; LN.noDs = false;
    LN.finished = false; LN.fatal = ""; LN.stopReason = "";
    $("lnCurve").innerHTML = "";
    $("lnReport").style.display = "none";
    $("lnDlMd").disabled = true;
  }
  LN.running = true;
  LN.stopFlag = false;
  $("lnRun").disabled = true;
  $("lnRun").textContent = "学習を実行中…";
  $("lnStop").disabled = false;
  while(!LN.stopFlag && !LN.fatal){
    if(LN.phase === "test"){
      await lnTestEpoch(cfg);
      if(LN.stopFlag) break;
      var reason = lnEvalEpoch(cfg);
      if(reason){ lnFinish(cfg, reason); return; }
      LN.phase = "teach";
      LN.taught = {};
    }
    if(LN.phase === "teach"){
      await lnTeachEpoch(cfg);
      if(LN.stopFlag || LN.fatal) break;
      LN.epoch++;
      LN.results = {};
      LN.phase = "test";
    }
  }
  if(LN.fatal){ lnFinish(cfg, "⛔ 中断: " + LN.fatal); return; }
  // 手動停止
  LN.running = false;
  $("lnStop").disabled = true;
  $("lnRun").disabled = false;
  $("lnRun").textContent = "再開(エポック" + LN.epoch + "の続き)";
  $("lnDlMd").disabled = !LN.curve.length;
  lnMsg("停止しました(エポック" + LN.epoch + "・" + (LN.phase === "test" ? "テスト" : "学習") + "の途中)。"
    + "「再開」で続きから回せます(ページを再読み込みするとやり直しです)。");
}

function lnFinish(cfg, reason){
  LN.running = false;
  LN.finished = true;
  LN.stopReason = reason;
  $("lnStop").disabled = true;
  $("lnRun").disabled = false;
  $("lnRun").textContent = "もう一度 最初から学習";
  $("lnDlMd").disabled = false;
  if($("lnDlCards")) $("lnDlCards").disabled = !lnCardCount();
  lnRenderCurve();
  lnRenderLedger();
  lnRenderReport(cfg);
  $("lnReport").style.display = "block";
  lnMsg("終了: " + reason);
}

// ---- 表示: 学習曲線・明細・台帳・レポート
function lnPct(v){ return v === null ? "-" : Math.round(v) + "%"; }

function lnRenderCurve(){
  if(!LN.curve.length){ $("lnCurve").innerHTML = ""; return; }
  var h = '<table style="border-collapse:collapse;font-size:12px;width:100%"><tr>'
    + '<th style="border:1px solid var(--line);padding:3px 6px">エポック</th>'
    + '<th style="border:1px solid var(--line);padding:3px 6px;text-align:left;min-width:180px">学習正答率</th>'
    + '<th style="border:1px solid var(--line);padding:3px 6px">検証正答率</th>'
    + '<th style="border:1px solid var(--line);padding:3px 6px">誤答(学習対象)</th>'
    + '<th style="border:1px solid var(--line);padding:3px 6px">エラー</th></tr>';
  LN.curve.forEach(function(e){
    h += '<tr><td style="border:1px solid var(--line);padding:3px 6px;text-align:center">' + e.ep + "</td>"
      + '<td style="border:1px solid var(--line);padding:3px 6px"><b>' + lnPct(e.tr) + "</b>"
      + '<div style="height:7px;border-radius:3px;background:#e4e7ec;margin-top:3px">'
      + '<div style="height:7px;border-radius:3px;background:var(--accent);width:' + Math.round(e.tr) + '%"></div></div></td>'
      + '<td style="border:1px solid var(--line);padding:3px 6px;text-align:center">' + lnPct(e.va) + "</td>"
      + '<td style="border:1px solid var(--line);padding:3px 6px;text-align:center">' + e.miss + "</td>"
      + '<td style="border:1px solid var(--line);padding:3px 6px;text-align:center">' + e.err + "</td></tr>";
  });
  $("lnCurve").innerHTML = h + "</table>";
}

function lnRenderDetail(){
  if(!LN.all.length){ $("lnTableWrap").innerHTML = ""; return; }
  var h = '<table style="border-collapse:collapse;font-size:12px;width:100%"><tr>'
    + '<th style="border:1px solid var(--line);padding:3px 6px">#</th>'
    + '<th style="border:1px solid var(--line);padding:3px 6px;text-align:left">決裁</th>'
    + '<th style="border:1px solid var(--line);padding:3px 6px;text-align:left">正解</th>'
    + '<th style="border:1px solid var(--line);padding:3px 6px">区分</th>'
    + '<th style="border:1px solid var(--line);padding:3px 6px">結果</th>'
    + '<th style="border:1px solid var(--line);padding:3px 6px">教えた回数</th></tr>';
  LN.all.forEach(function(c, i){
    var expect = c.expect_name + (c.expect_code ? " [" + c.expect_code + "]" : "");
    var r = LN.results[i];
    var led = LN.ledger[c.label];
    h += '<tr><td style="border:1px solid var(--line);padding:3px 6px;text-align:center">' + (i + 1) + "</td>"
      + '<td style="border:1px solid var(--line);padding:3px 6px">' + esc(c.label) + "</td>"
      + '<td style="border:1px solid var(--line);padding:3px 6px">' + esc(expect || "(なし)") + "</td>"
      + '<td style="border:1px solid var(--line);padding:3px 6px;text-align:center">'
      + (i >= LN.train.length ? "検証" : "学習") + "</td>"
      + '<td id="ln-cell-' + i + '" style="border:1px solid var(--line);padding:3px 6px;text-align:center">'
      + (r ? LN_MARK[r.st] : "") + "</td>"
      + '<td style="border:1px solid var(--line);padding:3px 6px;text-align:center">'
      + (led ? led.count : 0) + "</td></tr>";
  });
  $("lnTableWrap").innerHTML = h + "</table>";
}

function lnRenderLedger(){
  var labels = Object.keys(LN.ledger).sort();
  if($("lnDlCards")) $("lnDlCards").disabled = !lnCardCount();
  if($("lnClearCards")) $("lnClearCards").disabled = !labels.length;
  if(!labels.length){ $("lnLedger").innerHTML = ""; return; }
  var browser = lnCfg().mode === "browser";
  var h = '<b style="font-size:13px">' + (browser ? "仮ナレッジ(このブラウザに保存・1決裁=1カード)" : "事例カードの台帳(1決裁=1カード)") + "</b>"
    + '<table style="border-collapse:collapse;font-size:12px;width:100%;margin-top:4px"><tr>'
    + '<th style="border:1px solid var(--line);padding:3px 6px;text-align:left">決裁</th>'
    + '<th style="border:1px solid var(--line);padding:3px 6px">教えた回数</th>'
    + '<th style="border:1px solid var(--line);padding:3px 6px;text-align:left">' + (browser ? "カード(先頭)" : "カードID") + "</th></tr>";
  labels.forEach(function(lb){
    var e = LN.ledger[lb];
    var third = browser ? (e.card ? e.card.replace(/\s+/g, " ").slice(0, 70) + "…" : "(カードなし)") : (e.docId || "(追跡できず)");
    h += '<tr><td style="border:1px solid var(--line);padding:3px 6px">' + esc(lb) + "</td>"
      + '<td style="border:1px solid var(--line);padding:3px 6px;text-align:center">' + e.count
      + (e.count > 1 ? "(差し替え済み)" : "") + "</td>"
      + '<td style="border:1px solid var(--line);padding:3px 6px' + (browser ? "" : ";font-family:Consolas,monospace") + '">'
      + esc(third) + "</td></tr>";
  });
  $("lnLedger").innerHTML = h + "</table>";
}

function lnRenderReport(cfg){
  LN.report = lnBuildReport(cfg);
  $("lnReport").textContent = LN.report;
  $("lnReport").style.display = "block";
}

function lnBuildReport(cfg){
  var lines = ["# 自動学習レポート(エポック学習・ブラウザ版)", ""];
  lines.push("- アプリ形式: " + (LN_FMT_NAMES[cfg.fmt] || cfg.fmt) + "(③の「自己学習」チェック入り)");
  lines.push("- 決裁: 学習 " + LN.train.length + "件 + 検証 " + LN.val.length
    + "件(検証は一覧の末尾からの取り分けで、学習には使いません)");
  lines.push("- 停止条件: 目標 " + cfg.target + "% / 最大 " + cfg.maxEp + "エポック / "
    + (cfg.patience > 0 ? cfg.patience + "エポック改善なしで早期終了" : "改善なし停止は使わない"));
  lines.push("- ナレッジ: " + (cfg.mode === "api"
    ? "ナレッジAPIでカードを自動保存・差し替え"
    : "ナレッジAPIキーなし(仮ナレッジモード: カードはこのブラウザに保存し、判定のたびに似たカード最大4枚を「参考事例:」として添付。添付回数 " + LN.injected + ")"));
  lines.push("", "## 📈 学習曲線(エポック=全決裁を1周)", "",
             "| エポック | 学習正答率 | 検証正答率 | 誤答(学習対象) | エラー | 教えた決裁 |",
             "|---|---|---|---|---|---|");
  LN.curve.forEach(function(e){
    lines.push("| " + e.ep + " | **" + lnPct(e.tr) + "** | " + lnPct(e.va) + " | "
      + e.miss + " | " + e.err + " | " + e.taught + " |");
  });
  if(LN.stopReason) lines.push("", "**停止理由: " + LN.stopReason + "**");
  lines.push("", "## 📋 最終エポックの明細(○=正解 ×=不正解 ?=質問で停止 E=エラー)", "",
             "| # | 決裁 | 区分 | 正解 | 結果 | 教えた回数 |", "|---|---|---|---|---|---|");
  LN.all.forEach(function(c, i){
    var expect = c.expect_name + (c.expect_code ? " [" + c.expect_code + "]" : "");
    var r = LN.results[i];
    var led = LN.ledger[c.label];
    lines.push("| " + (i + 1) + " | " + c.label + " | " + (i >= LN.train.length ? "検証" : "学習")
      + " | " + (expect || "(なし)") + " | " + (r ? LN_MARK[r.st] : "(未実行)") + " | "
      + (led ? led.count : 0) + " |");
  });
  var labels = Object.keys(LN.ledger).sort();
  if(labels.length && cfg.mode === "api"){
    lines.push("", "## 🗂 事例カードの台帳(1決裁=1カード。差し替えて磨いた回数)", "",
               "| 決裁 | 教えた回数 | カードID |", "|---|---|---|");
    labels.forEach(function(lb){
      var e = LN.ledger[lb];
      lines.push("| " + lb + " | " + e.count + (e.count > 1 ? "(差し替え済み)" : "") + " | "
        + (e.docId || "(追跡できず)") + " |");
    });
  }
  if(labels.length && cfg.mode === "browser"){
    lines.push("", "## 📤 学習した事例の反映手順(ナレッジAPIキー不要)", "",
               "1. 「判定事例.txt を保存」でファイルを保存する(下の内容と同じ。1決裁=1ブロック、ブロックは空行区切り)",
               "2. **③の既定(環境変数に貼る方式)で作ったアプリ**: Difyでアプリを開き「環境変数」の `learned_cases` に",
               "   判定事例.txt の中身をそのまま貼って保存する(貼れる量の目安は日本語で5万〜10万字=Difyの MAX_VARIABLE_SIZE 既定200KB。",
               "   超えるときは古い決裁のブロックから削る)。次の判定から「参考事例の選択」ノードが似た事例を4件まで選んで参考にする",
               "3. **③で「Difyの事例ナレッジ」を選んで作ったアプリ**: ナレッジ「事例ナレッジ」を開き、前回アップロードした",
               "   判定事例.txt があれば削除してから「ファイルをアップロード」で入れる(チャンク設定は既定=段落(空行)区切りでよい。",
               "   カードが長い場合は最大チャンク長を1000以上にすると1カード=1チャンク)。状態が「利用可能」になれば",
               "   「類似事例の検索」が次回からこのカードを参照する",
               "", "### 仮ナレッジの中身(判定事例.txt)", "", "```", lnCardsText().replace(/\n$/, ""), "```");
  }
  var misses = [];
  LN.all.forEach(function(c, i){
    var r = LN.results[i];
    if(!r || (r.st !== "ng" && r.st !== "ask")) return;
    var expect = c.expect_name + (c.expect_code ? " [" + c.expect_code + "]" : "");
    misses.push("- 決裁: " + c.label + (i >= LN.train.length ? "(検証)" : "") + " / 正解: " + expect
      + "\n  アプリの回答(抜粋): " + (r.st === "ask" ? "(質問で停止)" : "") + (r.got || "").slice(0, 300));
  });
  lines.push("", "## 📌 まだ間違える決裁(次の一手)", "");
  if(!misses.length){
    lines.push("最終エポックの誤答はありません。");
  }else{
    lines.push("カードの差し替えで直りきらなかった分は、判定アプリの「アプリ設定 → 環境変数」への追記で手当てします",
               "(自動では書き換えられないため、ここから先は手動です):", "",
               "- **どの形式にも効く**: `accounting_policy` に「◯◯のような契約(見分けられる条件)は「正解科目」に分類する」を1行",
               "- **ツリー判定形式**: 正解科目が属する細分の `rules_*` の該当行に見分ける条件を追記",
               "- **コード2段選択形式**: `codes10_list` の該当行の定義に追記(7桁違いは `codes7_list`)",
               "- **コード一発選択形式**: `codes_list` の正解科目の行の定義に追記",
               "",
               "具体的な追記文は、下の誤答一覧を判定アプリのチャットに貼り",
               "「この誤答をなくすには、どの環境変数にどんな行を追記すべきか。コピペできる形で提案して」と続けると作れます。",
               "", "### 誤答一覧", "");
    misses.forEach(function(mm){ lines.push(mm); });
  }
  lines.push("", "## ⚠️ この数字の読み方(正直な注意)", "");
  lines.push("- **学習正答率は「正解を教えた後」に同じ決裁で測った数字**です。初見の実力は検証正答率(ホールドアウト)で見てください"
    + (LN.val.length ? "。" : "(今回は検証0件のため、初見の精度は測っていません)。"));
  lines.push("- 自動で更新するのは**事例カードだけ**です(1決裁=1カードを差し替え)。"
    + "アプリのプロンプトや環境変数はAPIから変更できないため、残る誤答は上の「次の一手」で手動追記してください。");
  if(cfg.mode === "browser"){
    lines.push("- 仮ナレッジモードの参考事例は、読み取り内容とカードの**文字の重なり**で選んだ最大4枚です。"
      + "③の既定(環境変数 learned_cases 方式)のアプリも同じ選び方なので、貼れば本番でもほぼ同じ結果になります。"
      + "Difyのナレッジ検索(意味の近さ)より粗いので、ナレッジ方式のアプリはカードをナレッジにアップロードして測り直してください。");
  }
  lines.push("- 目標到達・改善なしで早めに止めるのは、手元の決裁に合わせ込みすぎる(過学習)のを防ぐ、機械学習で標準のやり方です。");
  lines.push(cfg.mode === "api"
    ? "- 決裁→カードIDの台帳(差し替えに使用)は、このブラウザにナレッジIDごとに保存されます。"
      + "別のPC・ブラウザで続きを回すと前回のカードを見つけられず古いカードが残るので、その場合はナレッジの画面で手で削除してください。"
    : "- 仮ナレッジ(決裁→カード本文)は、このブラウザにURLとアプリキーの組ごとに保存されます。"
      + "別のPC・ブラウザには引き継がれないので、続きを回すときは同じブラウザで、または 判定事例.txt を"
      + "アプリの環境変数 learned_cases(ナレッジ方式のアプリはナレッジ)に入れてから回してください。");
  LN.warns.forEach(function(w2){ lines.push("- ⚠️ " + w2); });
  return lines.join("\n") + "\n";
}

// ---- 接続テスト(判定アプリと、ナレッジAPI+事例ナレッジIDの両方)
async function lnConnTest(){
  var cfg = lnCfg();
  if(!cfg.base){ $("lnTestOut").textContent = "APIサーバー(…/v1)を入力してください。"; return; }
  lnSaveCfg();
  if(!cfg.key && !cfg.dsKey){
    // キー未入力: URLだけで疎通(CORSに引っかかるか)を事前チェックする
    $("lnTestOut").textContent = "キーが未入力なので、URLの疎通(CORSに引っかかるか)だけ確認します…";
    $("lnTestOut").textContent = await evProbeUrl(cfg.base, LN.aborters);
    return;
  }
  $("lnTestOut").textContent = "接続テスト中…";
  var out = [];
  if(cfg.key){
    var msg;
    try{
      var r = await evFetch(cfg.base + "/info", {headers: {Authorization: "Bearer " + cfg.key}}, 30, LN.aborters);
      if(r.status === 404) r = await evFetch(cfg.base + "/parameters", {headers: {Authorization: "Bearer " + cfg.key}}, 30, LN.aborters);
      if(r.ok) msg = "✅ 接続OK";
      else if(r.status === 401) msg = "❌ HTTP 401 — キーが違います(app-… のキーか確認)";
      else if(r.status === 404) msg = "❌ HTTP 404 — URLを確認してください(末尾は /v1。アプリの「APIアクセス」に出る「API サーバー」のURLで、アドレス欄の …/app/… ではありません)";
      else msg = "❌ HTTP " + r.status;
    }catch(e){
      msg = "❌ 通信できません — URLの誤り・社内ネットワーク外・またはDify側のCORS設定";
    }
    out.push("判定アプリ: " + msg);
  }else{
    out.push("判定アプリ: (キー未入力)");
  }
  if(cfg.dsKey && cfg.dsId){
    var msg2;
    try{
      var r2 = await evFetch(cfg.base + "/datasets/" + encodeURIComponent(cfg.dsId) + "/documents?page=1&limit=1",
                             {headers: {Authorization: "Bearer " + cfg.dsKey}}, 30, LN.aborters);
      if(r2.ok) msg2 = "✅ 接続OK(カードの一覧と削除に使えます)";
      else if(r2.status === 401) msg2 = "❌ HTTP 401 — ナレッジAPIキー(dataset-…)が違います";
      else if(r2.status === 404) msg2 = "❌ HTTP 404 — 事例ナレッジのID(datasets/のあとの英数字)を確認してください";
      else if(r2.status === 403) msg2 = "❌ HTTP 403 — このキーの範囲(スコープ)に事例ナレッジが入っていないか、ナレッジの左メニュー「API アクセス」がOFFです";
      else msg2 = "❌ HTTP " + r2.status;
    }catch(e){
      msg2 = "❌ 通信できません(CORS/到達性。判定アプリ側がOKならURLは合っています)";
    }
    out.push("事例ナレッジ: " + msg2);
  }else if(!cfg.dsKey){
    out.push("事例ナレッジ: (ナレッジAPIキー未入力 → 仮ナレッジモード。③の既定(環境変数方式)のアプリはこちらです。教えたカードはこのブラウザに溜め、"
      + "次の判定の「OK」に参考事例として添えます。最後に「判定事例.txt を保存」し、アプリの環境変数 learned_cases に貼ってください"
      + "(ナレッジ方式のアプリはナレッジに手でアップロード))");
  }else{
    out.push("事例ナレッジ: (事例ナレッジのIDが未入力)");
  }
  if(out.join("\n").indexOf("通信できません") >= 0) out.push(evCorsHint(cfg.base));
  $("lnTestOut").innerHTML = out.map(esc).join("<br>");
}

function lnSaveCfg(){
  try{
    if($("lnSaveCfg").checked){
      localStorage.setItem("kanjoLearn", JSON.stringify({
        url: $("lnUrl").value, key: $("lnKey").value,
        dsKey: $("lnDsKey").value, dsId: $("lnDsId").value}));
    }else{
      localStorage.removeItem("kanjoLearn");
    }
  }catch(e){}
}

(function lnInit(){
  try{
    var cfg = JSON.parse(localStorage.getItem("kanjoLearn") || "null");
    if(cfg){
      $("lnUrl").value = cfg.url || "";
      $("lnKey").value = cfg.key || "";
      $("lnDsKey").value = cfg.dsKey || "";
      $("lnDsId").value = cfg.dsId || "";
      $("lnSaveCfg").checked = true;
    }
  }catch(e){}
  $("lnSaveCfg").onchange = lnSaveCfg;
  $("lnTest").onclick = lnConnTest;
  $("lnRun").onclick = lnRunAll;
  $("lnStop").onclick = function(){
    LN.stopFlag = true;
    LN.aborters.slice().forEach(function(c){ try{ c.abort(); }catch(e){} });
  };
  $("lnDlMd").onclick = function(){ save(LN.report || lnBuildReport(lnCfg()), "自動学習レポート.md"); };
  if($("lnDlCards")) $("lnDlCards").onclick = function(){ save(lnCardsText(), "判定事例.txt"); };
  if($("lnClearCards")) $("lnClearCards").onclick = function(){
    if(!confirm("このブラウザに保存された台帳(仮ナレッジのカードとカードIDの対応)を消します。よろしいですか?")) return;
    LN.ledger = {};
    try{ localStorage.removeItem(lnLedgerKey(lnLedgerNs(lnCfg()))); }catch(e){}
    lnRenderLedger();
    lnRenderDetail();
  };
  var drop = $("lnDrop");
  drop.onclick = function(e){ if(e.target !== $("lnDir")) $("lnDir").click(); };
  $("lnDir").onchange = function(){
    var items = [];
    for(var i = 0; i < this.files.length; i++){
      var f = this.files[i];
      items.push({rel: (f.webkitRelativePath || f.name), file: f});
    }
    if(items.length) lnIngest(items);
  };
  drop.ondragover = function(e){ e.preventDefault(); drop.style.borderColor = "var(--accent)"; };
  drop.ondragleave = function(){ drop.style.borderColor = "#b6bdc6"; };
  drop.ondrop = function(e){
    e.preventDefault();
    drop.style.borderColor = "#b6bdc6";
    var out = [];
    var jobs = [];
    for(var i = 0; i < e.dataTransfer.items.length; i++){
      var entry = e.dataTransfer.items[i].webkitGetAsEntry && e.dataTransfer.items[i].webkitGetAsEntry();
      if(entry) jobs.push(evWalkEntry(entry, "", out));
    }
    Promise.all(jobs).then(function(){ if(out.length) lnIngest(out); });
  };
})();
