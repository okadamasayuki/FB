#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""社内(Copilot等)に持ち出す1ファイル版 `ツリーからDify.py` を組み立てる。

  python3 tools/build_standalone.py

tools/miniyaml.py と tools/generate_workflow.py と tools/workflow_extras.yml から、
依存の無い単一ファイルを生成する。ロジックを直すときは元の tools/ 側を直して、
このスクリプトで作り直すこと(二重管理しない)。
"""
import io
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, 'tools'))
import miniyaml

OUT = os.path.join(ROOT, 'ツリーからDify.py')

HEADER = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==============================================================================
  分類ツリー → Dify ワークフロー(YAML)変換ツール
  ※ このファイルは「AIへの指示書」と「変換プログラム」が一体になっています
==============================================================================

■ 使い方(Copilot などのチャットAIで)

    1. このファイルの中身を全部コピーして、チャットAIに貼る
    2. 分類ツリーのファイル(分類ツリー_10桁.md など)を添付する、または中身を貼る
    3. AIが Dify にインポートできる YAML を出力します

■ 手元のPCで直接動かす場合(Python 3だけで動きます。これが最も確実です)

    python3 ツリーからDify.py 分類ツリー_10桁.md
      → contract-account-classification-pick.yml(コード一発選択形式)ができます
      → どの形式も、まず契約の一般的な仕訳の流れ(3〜5行)を整理してキャッシュ(現金・預金)の
        相手勘定を1つ特定し、その科目の勘定科目コードを確定します。違いはコードの決め方だけ:
        10桁/7桁の候補を横並びで1回で選ぶ既定の --pick、分類ツリーを1段ずつ下りる --tree、
        7桁を横並びで選び紐付く10桁を書き分けの定義で絞り込む --flat、3形式ぜんぶは --all
      → 従来のフォーム入力(入力欄で実行するworkflow)は --form、一発選択+フォームは --both
      → --learn を付けると自己学習つき(チャットで「正解: ◯◯」と返信すると判定事例カードを返し、
        次回から似た契約の判定前に過去の事例を参考にする)。既定の --learn-mode env は
        ナレッジもAPIキーも不要(⑤がまとめた 判定事例.txt をアプリの環境変数 learned_cases に貼る)
      → --learn-mode kb にするとDifyの事例ナレッジ方式(検索ノード+ナレッジ登録APIで自動保存。
        ナレッジの作成と環境変数 dify_base_url / dataset_api_key / case_dataset_id が必要で、
        「類似事例の検索」ノードでナレッジを選ぶまで公開できません)
      → kb でさらに --learn-dataset-id / --learn-base-url / --learn-dataset-key を付けると、
        ナレッジの選択と環境変数が設定済みの「設定込みDSL」になります(インポート後の再設定が不要。
        キーはDSLに平文で入るため、ファイルの共有先に注意)

==============================================================================
【AIへの指示】 ここから下は、このファイルがチャットに貼られた場合の指示です。
==============================================================================

あなたの役割は、渡された「分類ツリー」から Dify ワークフローの YAML を作ることです。

## 大原則

1. **この変換に判断は要りません。** プログラムの通りに機械的に変換するだけです。
   自分で考えて内容を足したり削ったりしないでください。
2. **エラーで止めない。** 分からないことがあれば、利用者に日本語で質問してください。
3. **YAMLは必ず全体を出力する。** 「以下同様」「省略」は絶対に使わないこと。
   長い場合は分割して出し、分割したことを伝えてください。

## 手順

1. ツリーを読み込んで、**必ず先に次の数字を報告**してください。
   - 最終ラベルの数 / 判定の段の数 / コードの数
2. プログラムを実行して YAML を作ります。
3. 出来上がった YAML について、**必ず次の数字を報告**してください。
   - ノード数 / エッジ数 / 環境変数の数
   - LLMノードの数(コード一発選択=4、コード2段選択=5、
     ツリー判定=判定の段の数+3、フォーム=判定の段の数+3 になるはずです)
4. YAML をそのままファイルに保存できる形で出力します。

## 変換できないときによくある原因(質問の例)

- 「ツリーの1行目が `区分判定(1段目)` になっていません。ツリー全体を貼っていただけますか?」
- 「同じ名前の中間段階が複数の場所にあります(例:「その他」)。
   Difyでは分岐の名前が重複できないので、**どちらかの名前を変えて**いただけますか?」
- 「インデントが半角スペース4つ分になっていない行があります。ツリーを貼り直していただけますか?」

## Pythonを実行できない環境の場合

**まず最初に「このコードを実行できません」とはっきり伝えてください。**
そのうえで、YAML を手作業で作るのは現実的ではない(数千行になる)ため、
「手元のPCで `python3 ツリーからDify.py 分類ツリー.md` を実行してください」と案内してください。

## できあがったYAMLの使い方(利用者への案内)

Dify の「アプリを作成 → DSLファイルをインポート」で取り込みます。
取り込むと、契約書をチャットで読み取って、仕訳の流れを整理し、キャッシュ(現金・預金)の
相手勘定となる勘定科目とそのコードを返すアプリになります
(--form で作った場合だけ、入力欄で実行する従来のワークフローです)。

==============================================================================
  ここから下はプログラムです(チャットAIは読み飛ばして構いません)
==============================================================================
"""
import argparse
import copy
import json
import os
import re
import sys
'''

FOOTER = '''

# ---------------------------------------------------------------- 実行

def main():
    ap = argparse.ArgumentParser(description='分類ツリーから Dify ワークフローYAMLを作る')
    ap.add_argument('tree', help='分類ツリーのファイル(.md)')
    ap.add_argument('-o', '--output', default='contract-account-classification-pick.yml')
    ap.add_argument('--form', action='store_true',
                    help='フォーム形式(workflow。分類ツリーを1段ずつ下りる従来の形)で作る。'
                         '既定はコード一発選択形式(advanced-chat。契約書をチャットに添付して会話で進め、'
                         '仕訳の流れを整理してキャッシュの相手勘定を1つ判定し、コードを機械確定)')
    ap.add_argument('--tree', dest='style_tree', action='store_true',
                    help='ツリー判定形式(advanced-chat。コードの決め方だけが違い、相手勘定を分類ツリーで'
                         '1段ずつ下りて位置づける段階判定)で作る')
    ap.add_argument('--flat', action='store_true',
                    help='コード2段選択形式(advanced-chat。7桁コードの候補を横並びで1つ選び、'
                         'その7桁に紐付く10桁を名称と書き分けの定義で絞り込む)で作る。'
                         'ツリーに[7桁]のコードが必要')
    ap.add_argument('--pick', action='store_true',
                    help='コード一発選択形式(advanced-chat。10桁(無い科目は7桁)の候補すべてを'
                         '横並びで提示して1回で選ぶ)で作る。ツリーに[7桁]のコードが必要')
    ap.add_argument('--both', action='store_true',
                    help='コード一発選択形式と従来のフォーム形式の両方を作る(フォーム形式は別ファイルに)')
    ap.add_argument('--all', action='store_true',
                    help='チャット入力の3形式(コード一発選択・ツリー判定・コード2段選択)すべてを作る')
    ap.add_argument('--learn', action='store_true',
                    help='チャット3形式に自己学習(「正解:」返信で判定事例カード+判定前に過去の事例を参考)を組み込む。'
                         '既定(--learn-mode env)はナレッジもAPIキーも不要')
    ap.add_argument('--learn-mode', choices=['env', 'kb'], default='env',
                    help='自己学習の事例の置き場。env=環境変数 learned_cases に貼る(既定。ナレッジ不要)/ '
                         'kb=Difyの事例ナレッジ(検索ノード+自動保存。ナレッジの作成と環境変数 dify_base_url / '
                         'dataset_api_key / case_dataset_id が必要)')
    ap.add_argument('--learn-dataset-id', default='',
                    help='自己学習(kb): 事例ナレッジのID(ナレッジURLの /datasets/ のあとの英数字)。'
                         '「類似事例の検索」ノードに選択済みで入り、環境変数 case_dataset_id にも書き込む')
    ap.add_argument('--learn-base-url', default='',
                    help='自己学習(kb): 環境変数 dify_base_url に書き込む値(…/v1)')
    ap.add_argument('--learn-dataset-key', default='',
                    help='自己学習(kb): 環境変数 dataset_api_key に書き込む値(dataset-…)。'
                         'DSLファイルに平文で入るため、ファイルの共有先に注意')
    args = ap.parse_args()

    if not os.path.exists(args.tree):
        print('■ ファイルが見つかりません: %s' % args.tree)
        sys.exit(1)
    text = io.open(args.tree, encoding='utf-8').read()
    extras = json.loads(EXTRAS_JSON)
    learn_cfg = {'mode': args.learn_mode, 'base_url': args.learn_base_url, 'dataset_key': args.learn_dataset_key,
                 'dataset_id': args.learn_dataset_id}

    if args.all:
        styles = ['pick', 'tree', 'flat']
    elif args.both:
        styles = ['pick', 'form']
    else:
        styles = [s for s, on in (('form', args.form), ('tree', args.style_tree),
                                  ('flat', args.flat), ('pick', args.pick)) if on]
        if not styles:
            styles = ['pick']

    def derived(suffix):
        if args.output.endswith('-pick.yml'):
            base = args.output[:-len('-pick.yml')]
        elif args.output.endswith('.yml'):
            base = args.output[:-len('.yml')]
        else:
            base = args.output
        return base + suffix + '.yml'

    MAKERS = {'tree': ('ツリー判定形式', generate_tree, '-tree'),
              'flat': ('コード2段選択形式', generate_flat, '-flat'),
              'pick': ('コード一発選択形式', generate_pick, '-pick'),
              'form': ('フォーム形式(従来)', generate, '')}
    jobs = []
    for s in styles:
        label, make, suffix = MAKERS[s]
        if len(styles) == 1:
            out = args.output
        elif s == 'pick' and args.output.endswith('-pick.yml'):
            out = args.output
        else:
            out = derived(suffix)
        jobs.append((label, make, out))

    for label, make, out in jobs:
        try:
            d = make(text, extras) if make is generate else make(text, extras, args.learn, learn_cfg)
        except SystemExit as e:
            if make in (generate_flat, generate_pick) and len(jobs) > 1 and '[7桁]' in str(e):
                print('■ %sはスキップ: %s' % (label, e))
                continue
            print('')
            print('■ 変換できませんでした')
            print(str(e))
            print('')
            print('※ このメッセージをそのまま伝えず、内容をかみくだいて利用者に質問してください。')
            sys.exit(1)

        with io.open(out, 'w', encoding='utf-8') as f:
            f.write(dump(d))

        g = d['workflow']['graph']
        kinds = {}
        for n in g['nodes']:
            t = n['data']['type']
            kinds[t] = kinds.get(t, 0) + 1
        print('■ 変換しました: %s(%s)' % (out, label))
        print('  ノード %d個 / エッジ %d個 / 環境変数 %d個'
              % (len(g['nodes']), len(g['edges']), len(d['workflow']['environment_variables'])))
        print('  内訳: ' + ' / '.join('%s %d' % (k, v) for k, v in sorted(kinds.items(), key=lambda x: -x[1])))
    print('')
    print('次: Dify の「アプリを作成 → DSLファイルをインポート」で取り込んでください。')


if __name__ == '__main__':
    main()
'''


def slim_extras(extras):
    """HTML/単体版に埋め込む素材だけを取り出す。
    生成時に必ず上書きされる項目(app.description・全体集約の変数一覧)は、
    現行ツリーの規模や小区分の内訳が読み取れてしまうので空にしてから埋め込む。"""
    import copy
    slim = {'app': copy.deepcopy(extras['app']),
            'features': copy.deepcopy(extras['features']),
            'conversation_variables': extras.get('conversation_variables', []),
            'scaffold_nodes': copy.deepcopy(extras['scaffold_nodes']),
            'chat': copy.deepcopy(extras['chat']),
            'flat': copy.deepcopy(extras['flat']),
            'pick': copy.deepcopy(extras['pick'])}
    slim['app']['description'] = ''
    for n in slim['scaffold_nodes'] + slim['chat']['scaffold_nodes']:
        if n.get('id') == 'aggregator':
            n['data']['variables'] = []
    return slim


def strip_module(src, drop_imports=(), drop_names=()):
    """モジュールの docstring と指定のimport/定義を落とす"""
    src = re.sub(r'\A#![^\n]*\n', '', src)
    src = re.sub(r'\A# -\*- coding[^\n]*\n', '', src)
    src = re.sub(r'\A"""(?:.|\n)*?"""\n', '', src)
    out = []
    skip = False
    for line in src.split('\n'):
        if skip:
            if line and not line[0].isspace():
                skip = False
            else:
                continue
        if any(re.match(r'^(import|from)\s+%s\b' % re.escape(m), line) for m in drop_imports):
            continue
        if any(re.match(r'^(def|class)\s+%s\b' % re.escape(n), line) for n in drop_names):
            skip = True
            continue
        if re.match(r"^if __name__ == '__main__':", line):
            skip = True
            continue
        out.append(line)
    return '\n'.join(out)


def main():
    mini = io.open(os.path.join(ROOT, 'tools', 'miniyaml.py'), encoding='utf-8').read()
    mini = strip_module(mini, drop_imports=('re',))
    gen = io.open(os.path.join(ROOT, 'tools', 'generate_workflow.py'), encoding='utf-8').read()
    gen = strip_module(gen, drop_imports=('argparse', 'copy', 'os', 're', 'sys', 'miniyaml'),
                       drop_names=('main',))
    gen = gen.replace('miniyaml.dump', 'dump')
    gen = re.sub(r"^ROOT = os\.path[^\n]*\n", "", gen, flags=re.M)

    extras = miniyaml.load(io.open(os.path.join(ROOT, 'tools', 'workflow_extras.yml'),
                                   encoding='utf-8').read())
    slim = slim_extras(extras)
    blob = json.dumps(slim, ensure_ascii=False, separators=(',', ':'))

    body = [HEADER, 'import io', '',
            '# --- YAML書き出し(tools/miniyaml.py 由来)---', mini, '',
            '# --- ワークフロー生成(tools/generate_workflow.py 由来)---', gen, '',
            '# --- ひな形(開始・サマリー・仕訳生成などの共通ノード)---',
            'EXTRAS_JSON = %s' % json.dumps(blob, ensure_ascii=False),
            FOOTER]
    io.open(OUT, 'w', encoding='utf-8').write('\n'.join(body))
    print('written %s (%.0f KB)' % (OUT, os.path.getsize(OUT) / 1024.0))


if __name__ == '__main__':
    main()
