#!/usr/bin/env python3
"""tools/sheet_reader.js(表ファイルの読み込み: xlsx/xls判定/HTML表/XML/CSV)を
Excelからツリー.html と 十桁定義.html のマーカー間に埋め込む。

  python3 tools/sync_sheet_reader.py

パーサを直すときは tools/sheet_reader.js を直してこのスクリプトを実行する(HTML側は直接編集しない)。
"""
import io
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BEGIN = '// SHEET_READER_BEGIN(tools/sheet_reader.js を tools/sync_sheet_reader.py で埋め込む。ここは直接編集しない)'
END = '// SHEET_READER_END'
TARGETS = ['Excelからツリー.html', '十桁定義.html']


def main():
    js = io.open(os.path.join(ROOT, 'tools', 'sheet_reader.js'), encoding='utf-8').read().rstrip('\n')
    assert '</script' not in js.lower(), 'sheet_reader.js に </script> は書けない'
    for name in TARGETS:
        path = os.path.join(ROOT, name)
        html = io.open(path, encoding='utf-8').read()
        a = html.index(BEGIN) + len(BEGIN)
        b = html.index(END, a)
        html = html[:a] + '\n' + js + '\n' + html[b:]
        io.open(path, 'w', encoding='utf-8').write(html)
        sys.stderr.write('synced %s (%d KB)\n' % (name, len(html.encode('utf-8')) // 1024))


if __name__ == '__main__':
    main()
