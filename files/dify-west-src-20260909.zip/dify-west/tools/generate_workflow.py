#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""READMEの分類ツリーから Dify ワークフローYAML一式を自動生成する。

使い方:
  python3 tools/generate_workflow.py                     # 分類ツリー.md → contract-account-classification.yml
  python3 tools/generate_workflow.py -t tree.txt -o out.yml

入力は「分類ツリー.md」のコードブロック(または同形式のテキストファイル)。
ツリーの記法:
  - `├─ ラベル` / `└─ ラベル`(インデント1段 = 「│   」または空白4文字)
  - `◆ ラベル[: 定義]` = 最終出力ラベル(定義は環境変数にそのまま入る)
  - `◆` の無い行 = さらに細分判定を持つ中間段階。`✏ rules_名` があればその段の基準を環境変数化
  - ` ★` = その段のフォールバック先 / `🔒` = 条件分岐が名称参照(表示のみ、動作には影響しない)
  - 中間段階の行にも `ラベル ★🔒: 定義 …… 注記` の形で定義を書ける(環境変数に転記される)

ツリーから決まらない素材(各ノードの出力例・更問いの質問例・プロンプト内固定の定義・ノードID・座標)は
tools/workflow_extras.yml から補う。extras に無い新しい分岐にはデフォルトを自動生成するので、
ツリーに行を足すだけでワークフローが組み上がる。
"""
import argparse
import copy
import os
import re
import sys

import miniyaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROOT_LABEL = '区分判定'

MODEL = {'completion_params': {'temperature': 0.1}, 'mode': 'chat', 'name': 'gpt-4o', 'provider': 'openai'}

USER_BODY = ('\n\n<契約書本文>\n{{#aggregator_text.output#}}\n</契約書本文>\n\n'
             '<補足情報>\n{{#start.additional_info#}}\n</補足情報>\n'
             '(補足情報は、過去の質問への回答です。空の場合もあります。)')

SUPPLEMENT_SECTION = [
    '【補足情報の扱い】',
    '- ユーザー入力の<補足情報>には、過去にあなたが出力した質問への回答が入っていることがある。契約書本文と合わせて判定に使うこと。',
]

# チャット版(advanced-chat)は本文を会話変数から読み、回答・訂正は会話履歴(memory)で受け取る。
# 3形式共通の前段(llm_journal)が特定した相手勘定を判定対象として各段に渡す
USER_BODY_CHAT = ('\n\n<仕訳の分析>\n{{#llm_journal.text#}}\n</仕訳の分析>\n\n'
                  '<契約書本文>\n{{#conversation.contract_text#}}\n</契約書本文>\n\n'
                  '<読み取り内容(確認済み)>\n{{#conversation.contract_summary#}}\n</読み取り内容>\n'
                  '(仕訳の分析の「相手勘定」「性質」を判定の中心に置き、これまでの会話でのユーザーの回答・訂正も判断材料に使うこと。)')

SUPPLEMENT_SECTION_CHAT = [
    '【会話の扱い】',
    '- ユーザー入力の<仕訳の分析>は、前段で整理した仕訳の流れとキャッシュ(現金・預金)の相手勘定の特定結果。判定はこの相手勘定を対象に行うこと。',
    '- これまでの会話には、読み取り内容へのユーザーの確認・訂正や、過去にあなたが出力した質問への回答が入っていることがある。契約書本文と合わせて判定に使うこと。',
]

# 会計方針・判定ルールの既定値(1,008通のE2Eテストの誤答分析で判明した迷いどころを初期値として収載。
# 環境変数 accounting_policy としてアプリ側で自由に書き足せる)
ACCOUNTING_POLICY_DEFAULT = (
    '- リース・長期の賃借契約: 契約期間が1年超で中途解約できない(または解約に高額な違約金が伴う)場合は、'
    '費用処理ではなく使用権資産とリース債務を計上する。少額または1年以内の短期リースのみ費用処理とする\n'
    '- 貸付金・借入金の長期/短期: 返済期限が1年超なら長期(長期貸付金・長期借入金 など)、1年以内なら短期として区分する\n'
    '- 人材紹介(採用の成功報酬)の紹介手数料は、人材派遣料ではなく「その他経費」とする\n'
    '- 自社が売主・貸主・受託者など「対価を受け取る側」の契約では、収益側の仕訳'
    '(売掛金・営業収入・前受収益・受入敷金 など)を書く')

# 会話履歴の渡し方。参考にした社内チャットフロー(契約仕訳アシスタント)の設定をそのまま使う
MEMORY_BLOCK = {
    'query_prompt_template': '{{#sys.query#}}',
    'role_prefix': {'assistant': '', 'user': ''},
    'window': {'enabled': False, 'size': 50},
}

QUESTION_SECTION_HEAD = [
    '【更問い(判定に必要な情報が無い場合)】',
    '- 契約書本文と補足情報を読んでも判定に必要な情報が不足している場合は、ラベルを出力する代わりに、次の2行の形式で質問を出力する。',
    '  質問: (このノードの判定に必要な点を1つだけ、選択式で答えられるように聞く)',
    '  回答例: (ユーザーがそのまま使える回答の文例を「 / 」区切りで2〜3個示す)',
    '- 質問は1回の出力につき1つだけとし、判定を最も左右する点を聞くこと。',
    '- このノードでの質問の例:',
]

QUESTION_SECTION_HEAD_CHAT = [
    '【更問い(判定に必要な情報が無い場合)】',
    '- 仕訳の分析・契約書本文とこれまでの会話を読んでも判定に必要な情報が不足している場合は、ラベルを出力する代わりに、次の2行の形式で質問を出力する。',
    '  質問: (このノードの判定に必要な点を1つだけ、選択式で答えられるように聞く)',
    '  回答例: (ユーザーがそのまま使える回答の文例を「 / 」区切りで2〜3個示す)',
    '- 質問は1回の出力につき1つだけとし、判定を最も左右する点を聞くこと。',
    '- このノードでの質問の例:',
]


# ---------------------------------------------------------------- ツリーのパース

class Node(object):
    def __init__(self, label):
        self.label = label
        self.leaf = False
        self.star = False
        self.lock = False
        self.definition = None
        self.env = None
        self.note = None
        self.code = None       # [7桁] または [3桁] の勘定科目コード
        self.children = []
        self.parent = None

    @property
    def is_branch(self):
        return bool(self.children)


LINE_RE = re.compile(r'^((?:│   |    )*)(?:├─|└─) (.+)$')


def parse_tree(text):
    if '```' in text:
        blocks = text.split('```')
        tree = next((b for b in blocks if ROOT_LABEL + '(1段目)' in b), None)
        if tree is None:
            raise SystemExit('ツリーのコードブロック(「%s(1段目)」を含む)が見つかりません' % ROOT_LABEL)
    else:
        tree = text
    root = Node(ROOT_LABEL)
    stack = [root]
    for raw in tree.split('\n'):
        raw = raw.rstrip()
        if not raw or raw.startswith(ROOT_LABEL):
            continue
        m = LINE_RE.match(raw)
        if not m:
            raise SystemExit('ツリーの行を解釈できません: %r' % raw)
        depth = len(m.group(1)) // 4
        if depth + 1 > len(stack):
            raise SystemExit('インデントが飛んでいます: %r' % raw)
        node = parse_line(m.group(2))
        parent = stack[depth]
        node.parent = parent
        parent.children.append(node)
        del stack[depth + 1:]
        stack.append(node)
    finalize(root)
    return root


def parse_line(content):
    leaf = content.startswith('◆ ')
    if leaf:
        content = content[2:]
    ann = ''
    i = content.find(' …')
    if i >= 0:
        content, ann = content[:i], content[i:]
    node_env = None
    m = re.search(r'✏ (rules_[A-Za-z0-9_]+)', ann)
    if m:
        node_env = m.group(1)
    definition = None
    if ': ' in content:
        content, definition = content.split(': ', 1)
    node = Node('')
    node.leaf = leaf
    node.env = node_env
    node.definition = definition
    m = re.search(r' \[(\d+)\]', content)
    if m:
        node.code = m.group(1)
        content = content.replace(m.group(0), '', 1)
    elif definition:
        # 「ラベル: 定義 [1234]」のように定義文側にコードが紛れ込んでも拾う
        m = re.search(r'\s*\[(\d+)\]\s*$', definition) or re.match(r'^\[(\d+)\]\s*', definition)
        if m:
            node.code = m.group(1)
            node.definition = (definition[:m.start()] + definition[m.end():]).strip() or None
    if '🔒' in content:
        node.lock = True
        content = content.replace('🔒', '')
    j = content.find('★')
    if j >= 0:
        node.star = True
        after = content[j + 1:].strip()
        if after:
            node.note = after.strip('()')
        content = content[:j]
    node.label = content.strip()
    if not node.label:
        raise SystemExit('ラベルが空の行があります: %r' % content)
    return node


def finalize(root):
    """整合性チェック。◆(最終ラベル)と★(受け皿)はツリーに書かれていなければ自動で補う"""
    auto_star = []

    def walk(n):
        if n.leaf and n.children:
            raise SystemExit('◆ の行に子があります: %s' % n.label)
        if not n.leaf and n is not root and not n.children:
            n.leaf = True          # 子が無い＝最終ラベル(◆ は省略可)
        stars = [c for c in n.children if c.star]
        if n.children and len(stars) > 1:
            raise SystemExit('「%s」の配下の ★(フォールバック先)が %d個あります。1つにしてください'
                             % (n.label, len(stars)))
        if n.children and not stars:
            # ★が書かれていなければ「その他」を含むものを優先、無ければ最後の選択肢を受け皿にする
            cands = [c for c in n.children if 'その他' in c.label] or [c for c in n.children if '分類不能' in c.label]
            target = cands[-1] if cands else n.children[-1]
            target.star = True
            auto_star.append((n.label if n is not root else ROOT_LABEL, target.label))
        for c in n.children:
            walk(c)
    walk(root)
    if auto_star:
        sys.stderr.write('★(判定が紛れたときの受け皿)をツリーから読み取れなかったため、%d箇所を自動で決めました:\n'
                         % len(auto_star))
        for parent, label in auto_star[:10]:
            sys.stderr.write('  ・%s → %s\n' % (parent, label))
        if len(auto_star) > 10:
            sys.stderr.write('  …ほか %d箇所\n' % (len(auto_star) - 10))
    # 同じ名前の分岐が別の場所にあっても、経路で区別するので問題ない(参考として知らせるだけ)
    labels, dups = [ROOT_LABEL], []

    def collect(n):
        for c in n.children:
            if c.is_branch:
                if c.label in labels and c.label not in dups:
                    dups.append(c.label)
                labels.append(c.label)
            collect(c)
    collect(root)
    if dups:
        sys.stderr.write('同じ名前の分岐が複数あります(別のものとして扱います): %s\n'
                         % '、'.join(dups[:10]))

    def check_codes(n, seven):
        if n.code is not None:
            if len(n.code) == 7:
                if seven:
                    raise SystemExit('[7桁]の配下に再度[7桁]があります: %s' % n.label)
                seven = n.code
            elif len(n.code) == 3:
                if not seven:
                    raise SystemExit('[3桁]の上位に[7桁]がありません: %s' % n.label)
            elif seven and n.code.startswith(seven):
                pass          # 上位の[7桁]と先頭が一致するフルコード(そのまま採用)
            elif seven:
                raise SystemExit('[7桁]の配下のコードは、[3桁]か、その7桁で始まるフルコードにしてください: %s [%s]'
                                 % (n.label, n.code))
            elif n.children:
                raise SystemExit('途中の段に付けるコードは[7桁]にしてください: %s [%s]' % (n.label, n.code))
        for c in n.children:
            check_codes(c, seven)
    check_codes(root, None)


# ---------------------------------------------------------------- ステージ構築

def node_key(node):
    """ステージを引くためのキー。同じ名前の分岐が複数あってもぶつからないよう、経路で持つ"""
    parts = []
    n = node
    while n.parent is not None:
        parts.append(n.label)
        n = n.parent
    return '/'.join(reversed(parts)) or ROOT_LABEL


class Stage(object):
    """細分判定を1回行う単位(=LLMノード1つ。分岐する子があれば if-else も持つ)"""

    def __init__(self, node, extras, used_ids, taken):
        self.node = node
        self.label = node.label
        self.env = node.env
        self.is_root = node.parent is None
        self.is_sub = node.parent is not None and node.parent.parent is None
        ex = extras.get('stages', {}).get(self.label, {})
        self.ex = ex
        self.title_prefix = ''
        # 同じラベルの分岐が複数あると extras の固定IDを取り合うので、先に来た方だけが使う
        cand = ex.get('id')
        self.id = cand if (cand and cand not in taken) else self._new_id(used_ids)
        taken.add(self.id)
        used_ids.add(self.id)
        self.ifelse_id = None
        if self.branch_children():
            cand = (ex.get('ifelse') or {}).get('id')
            self.ifelse_id = cand if (cand and cand not in taken) else self._new_ifelse_id(used_ids)
            taken.add(self.ifelse_id)
            used_ids.add(self.ifelse_id)

    def _new_id(self, used_ids):
        if self.env:
            base = 'llm-sub-' + self.env[len('rules_'):].replace('_', '-')
        else:
            base = 'llm-sub-x'
        cand, k = base, 2
        while cand in used_ids:
            cand, k = '%s%d' % (base, k), k + 1
        return cand

    def _new_ifelse_id(self, used_ids):
        base = 'if-else-' + self.id.replace('llm-sub-', '').replace('llm-', '')
        cand, k = base, 2
        while cand in used_ids:
            cand, k = '%s%d' % (base, k), k + 1
        return cand

    def branch_children(self):
        return [c for c in self.node.children if c.is_branch]

    def fallback(self):
        return next(c for c in self.node.children if c.star)

    def top_category(self):
        n = self.node
        while n.parent is not None and n.parent.parent is not None:
            n = n.parent
        return n.label

    def parent_phrase(self):
        if 'parent_phrase' in self.ex:
            return self.ex['parent_phrase']
        # 3段目は区分名、4段目以降は直上の段階名
        if self.node.parent is not None and self.node.parent.parent is not None \
                and self.node.parent.parent.parent is not None:
            return self.node.parent.label
        return self.top_category()


def build_stages(root, extras):
    used_ids, taken = set(), set()
    for st in extras.get('stages', {}).values():
        used_ids.add(st.get('id'))
        if st.get('ifelse'):
            used_ids.add(st['ifelse'].get('id'))
    stages = {}

    def walk(node):
        stage = Stage(node, extras, used_ids, taken)
        stages[node_key(node)] = stage
        for c in stage.branch_children():
            walk(c)
    walk(root)
    # 同じ名前の分岐が複数ある場合、Difyの画面で見分けが付くようタイトルに親を添える
    seen = {}
    for st in stages.values():
        seen[st.label] = seen.get(st.label, 0) + 1
    for st in stages.values():
        if seen[st.label] > 1 and st.node.parent is not None:
            st.title_prefix = st.node.parent.label + '/'
    return stages


def postorder(root, stages):
    """集約は「子孫のステージが先」の順(最深の実行結果が勝つ)"""
    out = []

    def walk(node):
        for c in node.children:
            if c.is_branch:
                walk(c)
        out.append(stages[node_key(node)])
    walk(root)
    return out


# ---------------------------------------------------------------- プロンプト生成

def numbered_defs(children, defs):
    lines = []
    for i, c in enumerate(children, 1):
        d = c.definition or defs.get(c.label, '')
        lines.append('%d. %s(例: %s)' % (i, c.label, d) if d else '%d. %s' % (i, c.label))
    return lines


def system_prompt(stage, chat=False):
    node, ex = stage.node, stage.ex
    children = [c for c in node.children if not (stage.is_root and c.note)]
    n = len(children)
    lines = ['あなたは日本の企業会計に精通した経理・会計の専門家です。']
    read_src = '仕訳の分析と契約書の本文' if chat else '契約書の本文'
    if stage.is_root:
        if chat:
            lines.append('前段の仕訳分析で、この契約のキャッシュ(現金・預金)の相手勘定となる勘定科目が特定されています。'
                         'その相手勘定が主として属する勘定科目区分を1つだけ判定し、区分名のラベルのみを出力してください。')
        else:
            lines.append('与えられた契約書の本文を読み、その契約が主として関係する勘定科目区分を1つだけ判定し、区分名のラベルのみを出力してください。')
    else:
        subject = 'この契約の相手勘定(勘定科目)' if chat else 'この契約書'
        if stage.is_sub:
            lines.append('%sは、前段の判定で勘定科目区分「%s」に該当すると判定されています。' % (subject, stage.label))
        else:
            lines.append('%sは、前段の判定で%sのうち「%s」に該当すると判定されています。'
                         % (subject, stage.parent_phrase(), stage.label))
        if stage.env:
            lines.append('下記の【分類基準】に従い、最も適切な細分を1つだけ判定し、ラベルのみを出力してください。')
        elif stage.is_sub:
            lines.append('%sを読み、次の%dの小区分のうち最も適切なものを1つだけ判定し、小区分名のラベルのみを出力してください。' % (read_src, n))
        else:
            lines.append('%sを読み、次の%dつの細分のうち最も適切なものを1つだけ判定し、ラベルのみを出力してください。' % (read_src, n))
    lines.append('')
    defs = ex.get('defs', {})
    if stage.env:
        lines += ['【分類基準】', '{{#env.%s#}}' % stage.env]
    elif stage.is_root:
        lines += ['【勘定科目区分】'] + numbered_defs(children, defs)
    elif stage.is_sub:
        lines += ['【%sの小区分】' % stage.label] + numbered_defs(children, defs)
    else:
        lines += ['【%sの細分】' % stage.label] + numbered_defs(children, defs)
    lines.append('')
    lines.append('【出力ルール】')
    if stage.is_root:
        lines.append('- 出力はラベル1つのみ・1行のみ。説明文・理由・記号・引用符・改行・前後の空白は一切付けない。')
        allowed = [c.label for c in node.children]
        lines.append('- 出力してよいラベルは次の%d種類のみ。一字一句そのまま使うこと。' % len(allowed))
        lines.append('  ' + '、'.join(allowed))
    else:
        lines.append('- 出力はラベル1つのみ・1行のみ。説明文・理由・記号・引用符・番号・改行・前後の空白は一切付けない。')
        if stage.env:
            lines.append('- 出力してよいラベルは【分類基準】に列挙された細分名のみ(行頭の番号や「: 」以降の定義は付けない)。一字一句そのまま使うこと。')
        elif stage.is_sub:
            lines.append('- 出力してよいラベルは上記%d種類の小区分名のみ。一字一句そのまま使うこと。' % n)
        else:
            lines.append('- 出力してよいラベルは上記%d種類のみ。一字一句そのまま使うこと。' % n)
    extra_rules = ex.get('extra_rules')
    if extra_rules is None:
        extra_rules = ['- 「%s」の行は後段の条件分岐が名称を参照しているため、ラベル名を変更しないこと。' % c.label
                       for c in stage.branch_children()] if stage.env else []
    lines += extra_rules
    if stage.is_root:
        fb = next(c for c in node.children if c.star)
        lines.append('- 判定材料はあるがどの区分にも当てはまらない場合のみ「%s」と出力する(情報不足の場合は下記の更問いを優先する)。' % fb.label)
    else:
        lines.append('- 判定材料はあるがどれに当たるか紛れる場合は、最も近いものとして「%s」を出力する(情報不足の場合は下記の更問いを優先する)。'
                     % stage.fallback().label)
    examples = stage.ex.get('examples')
    if examples:
        lines += [''] + ['【出力例】'] + examples
    lines += [''] + (SUPPLEMENT_SECTION_CHAT if chat else SUPPLEMENT_SECTION)
    lines += [''] + (QUESTION_SECTION_HEAD_CHAT if chat else QUESTION_SECTION_HEAD)
    question = stage.ex.get('question')
    if not question:
        opts = [c.label for c in node.children[:3]]
        question = ['質問: この契約は次のどれに最も近いですか?(%s)' % ' / '.join(opts),
                    '回答例: %s' % ' / '.join('%sです' % o for o in opts[:2])]
    lines += ['  ' + q for q in question]
    return '\n'.join(lines)


def user_prompt(stage, chat=False):
    if chat:
        # extras の user_intro はフォーム版の文面なので、チャット版は相手勘定の判定文に組み替える
        if stage.is_root:
            intro = '以下は前段の仕訳分析と契約書の本文です。相手勘定の勘定科目区分を判定し、ラベル名のみを出力してください。'
        elif stage.is_sub:
            intro = '以下は前段の仕訳分析と契約書の本文です。%sの小区分を判定し、ラベル名のみを出力してください。' % stage.label
        else:
            intro = '以下は前段の仕訳分析と契約書の本文です。この%sの細分を判定し、ラベル名のみを出力してください。' % stage.label
        return intro + USER_BODY_CHAT
    intro = stage.ex.get('user_intro')
    if not intro:
        if stage.is_root:
            intro = '以下は契約書の本文です。この契約の勘定科目区分を判定し、ラベル名のみを出力してください。'
        elif stage.is_sub:
            intro = '以下は契約書の本文です。%sの小区分を判定し、ラベル名のみを出力してください。' % stage.label
        else:
            intro = '以下は契約書の本文です。この%sの細分を判定し、ラベル名のみを出力してください。' % stage.label
    return intro + USER_BODY


# ---------------------------------------------------------------- レイアウト

ROW = 140          # バンド内の行間
SCAF_Y = 190       # メインの横ライン(開始〜区分判定)
TOP_Y = 40         # 上部レーン(確認要求)
LEARN_Y = -140     # 自己学習レーン(最上部。どの形式のノードとも重ならない)
AGG_Y = 410        # 右側の集約〜終了ライン
BANDS_Y0 = 700     # 最初のグループバンドの開始y
BAND_GAP = 180     # バンド間の余白


def colx(c):
    return 80 + 304 * c


def stage_depth(stage):
    d, n = 0, stage.node
    while n.parent is not None:
        d += 1
        n = n.parent
    return d


def compute_layout(root, stages, gagg_ids):
    """全ノードの座標を決定的に計算する。
    線の交差を減らすため、区分ごとに横バンドを分け、集約は2段構え
    (グループ別集約→全体集約)にして各バンド内で線を完結させる。"""
    pos = {}
    max_depth = max(stage_depth(st) for st in stages.values())
    ga_col = max(11, 9 + 2 * max_depth)

    # スキャフォールド(メインの横ライン+上部レーン)
    pos['start'] = (colx(0), SCAF_Y)
    pos['doc-extractor'] = (colx(1), SCAF_Y)
    pos['template-join'] = (colx(2), SCAF_Y)
    pos['if-else-read'] = (colx(3), SCAF_Y)
    pos['llm_read'] = (colx(4), TOP_Y)
    pos['aggregator_text'] = (colx(4), SCAF_Y)
    pos['if-else-text'] = (colx(5), SCAF_Y)
    pos['template-scan'] = (colx(5), TOP_Y)
    pos['llm_summary'] = (colx(6), SCAF_Y)
    pos['if-else-confirm'] = (colx(7), SCAF_Y)
    pos[stages[node_key(root)].id] = (colx(8), SCAF_Y)
    if stages[node_key(root)].ifelse_id:
        pos[stages[node_key(root)].ifelse_id] = (colx(9), SCAF_Y)
    pos['template-confirm'] = (colx(8), TOP_Y)
    pos['aggregator'] = (colx(ga_col + 1), AGG_Y + 150)
    pos['template_path'] = (colx(ga_col + 2), AGG_Y + 150)
    pos['template_code'] = (colx(ga_col + 3), AGG_Y + 150)
    pos['if-else-q'] = (colx(ga_col + 4), AGG_Y + 370)
    pos['llm_journal'] = (colx(ga_col + 5), AGG_Y + 590)
    pos['aggregator-out'] = (colx(ga_col + 6), AGG_Y)
    pos['end'] = (colx(ga_col + 7), AGG_Y)

    # 区分ごとのバンド。行0 = 小区分判定+深い段(4段目)の行、行1〜 = 細分判定、
    # 最下行の下 = グループ集約(合流レーン)。合流の線がバンドの下側を通り、交差しない。
    band_y = BANDS_Y0
    for cat in root.children:
        if not cat.is_branch:
            continue
        head = stages[node_key(cat)]
        sub_stages = [stages[node_key(c)] for c in cat.children if c.is_branch]
        rows = 1 + len(sub_stages)
        pos[head.id] = (colx(10), band_y)
        if head.ifelse_id:
            pos[head.ifelse_id] = (colx(11), band_y)
        for i, st in enumerate(sub_stages):
            y = band_y + ROW * (1 + i)
            pos[st.id] = (colx(8 + 2 * stage_depth(st)), y)
            if st.ifelse_id:
                pos[st.ifelse_id] = (colx(9 + 2 * stage_depth(st)), y)

            def deeper(node):
                for c in node.children:
                    if not c.is_branch:
                        continue
                    dst = stages[node_key(c)]
                    pos[dst.id] = (colx(8 + 2 * stage_depth(dst)), y)
                    if dst.ifelse_id:
                        pos[dst.ifelse_id] = (colx(9 + 2 * stage_depth(dst)), y)
                    deeper(c)
            deeper(st.node)
        gy = band_y + rows * ROW + 70
        pos[gagg_ids[node_key(cat)]] = (colx(ga_col), gy)
        band_y = gy + 116 + BAND_GAP
    return pos


def place(pos, nid):
    x, y = pos[nid]
    return {'x': x, 'y': y}


def node_shell(nid, data, pos, height=116):
    return {'data': data, 'height': height, 'id': nid,
            'position': pos, 'positionAbsolute': dict(pos), 'selected': False,
            'sourcePosition': 'right', 'targetPosition': 'left', 'type': 'custom', 'width': 244}


def llm_node(stage, pos, chat=False):
    if stage.env:
        desc = stage.ex.get('desc') or '%sを環境変数 %s の分類基準に従って細分判定します。' % (stage.label, stage.env)
    elif stage.is_root:
        desc = stage.ex.get('desc') or '契約書の主たる勘定科目区分を判定します。'
    else:
        desc = stage.ex.get('desc') or '%sの細分を判定します(基準はプロンプト内固定)。' % stage.label
    suffix = stage.id.replace('llm-', '')
    data = {
        'context': {'enabled': False, 'variable_selector': []},
        'desc': desc,
        'model': copy.deepcopy(MODEL),
        'prompt_template': [
            {'id': 'system-prompt-%s' % suffix, 'role': 'system', 'text': system_prompt(stage, chat)},
            {'id': 'user-prompt-%s' % suffix, 'role': 'user', 'text': user_prompt(stage, chat)},
        ],
        'selected': False,
        'title': stage.ex.get('title') or ('%s%s 細分判定' % (stage.title_prefix, stage.label)),
        'type': 'llm',
        'variables': [],
        'vision': {'enabled': False},
    }
    if chat:
        data['memory'] = copy.deepcopy(MEMORY_BLOCK)
    return node_shell(stage.id, data, place(pos, stage.id))


def case_id_for(child_stage):
    return (child_stage.ex.get('case_id')
            or ('case-' + child_stage.id.replace('llm-sub-', '').replace('llm-', '')))


def make_case(stage, child_stage):
    ex = child_stage.ex
    value = ex.get('case_value') or child_stage.label
    cid = case_id_for(child_stage)
    cond = ex.get('cond_id') or cid.replace('case-', 'cond-')
    return {
        'case_id': cid,
        'conditions': [{
            'comparison_operator': 'start with',
            'id': cond,
            'value': value,
            'varType': 'string',
            'variable_selector': [stage.id, 'text'],
        }],
        'id': cid,
        'logical_operator': 'and',
    }, value


def ifelse_node(stage, stages, pos):
    branch = stage.branch_children()
    cases, values = [], []
    for c in branch:
        case, value = make_case(stage, stages[node_key(c)])
        cases.append(case)
        values.append(value)
    # ケースは値の長い順に並べる(Difyは上から順に評価するため、
    # 「その他」と「その他の◯◆」のような前方一致の包含関係があっても正しく振り分けられる)
    pairs = sorted(zip(cases, values, branch), key=lambda t: -len(t[1]))
    cases = [p[0] for p in pairs]
    values = [p[1] for p in pairs]
    # 前方一致の衝突: 分岐同士の包含は上記の並びで解決する。
    # ケースを持たない葉ラベル(例: 「その他の金融負債」)がケース値(例: 「その他」)に
    # 飲み込まれる場合は、そのケースだけ完全一致に切り替える
    # (葉ラベルはどのケースにも一致せず ELSE に落ち、その段の出力として正しく集約される)
    for case, v, bc in pairs:
        for c in stage.node.children:
            if c.label == bc.label or c.is_branch:
                continue
            if c.label.startswith(v):
                case['conditions'][0]['comparison_operator'] = 'is'
                break
    for c in stage.node.children:
        if c.label.startswith('質問'):
            raise SystemExit('「質問」で始まるラベルは使えません: %s' % c.label)
    if len(set(values)) != len(values):
        raise SystemExit('条件分岐のケース値が重複しています: %s' % values)
    ex_if = stage.ex.get('ifelse') or {}
    if stage.is_root:
        default_title, default_desc = '条件分岐', '細分を持つ区分の場合のみ小区分判定へ分岐します。'
    else:
        default_title = '条件分岐(%s%s細分)' % (stage.title_prefix, stage.label)
        default_desc = '%sの細分のうち、さらに細分を持つものを対応する判定へ分岐します。' % stage.label
    data = {
        'cases': cases,
        'desc': ex_if.get('desc') or default_desc,
        'selected': False,
        'title': ex_if.get('title') or default_title,
        'type': 'if-else',
    }
    return node_shell(stage.ifelse_id, data, place(pos, stage.ifelse_id),
                      height=ex_if.get('height', 126))


def make_edge(nodes_by_id, src, handle, tgt):
    return {
        'data': {'isInIteration': False,
                 'sourceType': nodes_by_id[src]['data']['type'],
                 'targetType': nodes_by_id[tgt]['data']['type']},
        'id': '%s-%s-%s-target' % (src, handle, tgt),
        'source': src, 'sourceHandle': handle,
        'target': tgt, 'targetHandle': 'target',
        'type': 'custom', 'zIndex': 0,
    }


# ---------------------------------------------------------------- 環境変数生成

def code_map_lines(root):
    """コードが解決できる全ノードの「経路,コード」行(中間段階も含む=更問い停止時も7桁が出る)"""
    lines = []

    def walk(n, seven, three, path):
        if n.parent is not None:
            path = path + [n.label]
            full = None
            if n.code is not None:
                if len(n.code) == 7 and not seven:
                    seven, three = n.code, None
                elif len(n.code) == 3:
                    three = n.code
                else:
                    full = n.code   # フルコード(上位の[7桁]の有無によらずそのまま使う)
            if full:
                lines.append('%s,%s' % ('/'.join(path), full))
            elif seven:
                lines.append('%s,%s' % ('/'.join(path), seven + (three or '')))
        for c in n.children:
            walk(c, seven, three, path)
    walk(root, None, None, [])
    return lines


def codes7_lines(root):
    """7桁コードの候補一覧(横並び)。[7桁]の宣言行と、フルコード行の上7桁から作る。
    1行=「- 経路 [7桁]: 定義」。コード選択形式(flat)の1段目の選択肢になる"""
    lines, seen = [], set()

    def walk(n, seven, path):
        if n.parent is not None:
            path = path + [n.label]
            if n.code is not None:
                cand = None
                if len(n.code) == 7 and not seven:
                    seven = cand = n.code
                elif len(n.code) not in (3, 7):
                    cand = n.code[:7]   # フルコード行
                if cand and cand not in seen:
                    seen.add(cand)
                    d = ': ' + n.definition if n.definition else ''
                    lines.append('- %s [%s]%s' % ('/'.join(path), cand, d))
        for c in n.children:
            walk(c, seven, path)
    walk(root, None, [])
    return lines


def codes10_lines(root):
    """7桁→10桁の対応表(書き分け)。「[7桁] 経路」の見出しの下に、
    配下の「  - 名称 [3桁]: 定義」を並べる。コード選択形式(flat)の2段目の選択肢になる"""
    groups, order = {}, []

    def group(seven, path):
        if seven not in groups:
            groups[seven] = ('/'.join(path), [])
            order.append(seven)
        return groups[seven][1]

    def walk(n, seven, path):
        if n.parent is not None:
            path = path + [n.label]
            if n.code is not None:
                if len(n.code) == 7 and not seven:
                    seven = n.code
                    group(seven, path)
                elif len(n.code) == 3 and seven:
                    group(seven, path[:-1]).append((n.label, n.code, n.definition or ''))
                elif len(n.code) not in (3, 7):
                    group(n.code[:7], path[:-1]).append((n.label, n.code[7:], n.definition or ''))
        for c in n.children:
            walk(c, seven, path)
    walk(root, None, [])
    lines = []
    for seven in order:
        head, items = groups[seven]
        lines.append('[%s] %s' % (seven, head))
        for label, three, d in items:
            lines.append('  - %s [%s]%s' % (label, three, ': ' + d if d else ''))
    return lines


def codes_pick_lines(root):
    """全コード候補の横並び一覧(一発選択用)。10桁がある科目は「- 経路/名称 [10桁]: 定義」、
    10桁が無い7桁は「- 経路 [7桁]: 定義」。コード一発選択形式(pick)の選択肢になる"""
    groups, order = {}, []

    def g(seven, path, d=None):
        if seven not in groups:
            groups[seven] = ['/'.join(path), d or '', []]
            order.append(seven)
        return groups[seven]

    def walk(n, seven, path):
        if n.parent is not None:
            path = path + [n.label]
            if n.code is not None:
                if len(n.code) == 7 and not seven:
                    seven = n.code
                    g(seven, path, n.definition or '')
                elif len(n.code) == 3 and seven:
                    g(seven, path[:-1])[2].append((n.label, n.code, n.definition or ''))
                elif len(n.code) not in (3, 7):
                    g(n.code[:7], path[:-1])[2].append((n.label, n.code[7:], n.definition or ''))
        for c in n.children:
            walk(c, seven, path)
    walk(root, None, [])
    lines = []
    for seven in order:
        head, d7, items = groups[seven]
        if items:
            for label, three, d in items:
                lines.append('- %s/%s [%s%s]%s' % (head, label, seven, three, ': ' + d if d else ''))
        else:
            lines.append('- %s [%s]%s' % (head, seven, ': ' + d7 if d7 else ''))
    return lines


# ---------------------------------------------------------------- チャット入り口の共通部品
# 入力・読み取り・認識確認・仕訳の流れ分析(相手勘定の特定)・更問いチェックまでは
# 3つの判定形式(ツリー判定・コード2段選択・コード一発選択)で同一構成にする

CHAT_FRONT_IDS = ['start', 'doc-extractor', 'template-plain', 'if-else-read', 'llm_read',
                  'template-join-read', 'save-text-read', 'template-join', 'save-text',
                  'if-else-att', 'llm_summary', 'save-summary', 'answer-confirm',
                  'llm_journal', 'if-else-q', 'answer-q']


def env_check_simple(pos):
    """company_name の設定漏れだけを点検する軽量版の設定チェック(判定形式ごとの変種用)"""
    return node_shell('env_check', {
        'desc': '環境変数の設定漏れを点検し、未設定なら注意書きを作ります(設定済みなら何も出しません)。',
        'selected': False,
        'template': "{% if (company | trim) == '' %}\n\n---\n"
                    '⚠️ 環境変数 company_name(自社名)が未設定です。アプリ設定の「環境変数」で自社の正式社名を'
                    '設定すると、判定の向き(自社がどちらの当事者か)の取り違えを防げます。'
                    'それまでは、チャットで「当社は◯◯です」と伝えてください。{% endif %}',
        'title': '設定チェック',
        'type': 'template-transform',
        'variables': [{'value_selector': ['env', 'company_name'], 'variable': 'company'}],
    }, place(pos, 'env_check'), height=82)


def chat_front(extras, pos, learn=False, learn_cfg=None):
    """3形式共通の入り口(開始〜読み取り〜認識確認〜仕訳の流れ分析〜更問いチェック)を組み立てる。
    learn=True なら自己学習(事例ナレッジの検索・「正解:」返信での自動保存)も組み込む。
    learn_cfg にナレッジIDがあれば「類似事例の検索」ノードに選択済みで入れる"""
    by_id = {n['id']: n for n in extras['chat']['scaffold_nodes']}
    nodes = [copy.deepcopy(by_id[i]) for i in CHAT_FRONT_IDS]
    nodes.append(env_check_simple(pos))
    if learn:
        cfg = learn_cfg_norm(learn_cfg)
        if cfg['mode'] == 'env':   # ナレッジ無しの短いレーン
            pos['code_cases'] = (colx(8), LEARN_Y)
            pos['llm_case'] = (colx(9), LEARN_Y)
            pos['answer-case'] = (colx(10), LEARN_Y)
        nodes += learn_nodes(pos, cfg)
        for n in nodes:
            if n['id'] == 'llm_journal':
                learn_journal_patch(n, cfg['mode'])
    for n in nodes:
        if n['id'] in pos:
            n['position'] = place(pos, n['id'])
            n['positionAbsolute'] = place(pos, n['id'])
    return nodes


def chat_front_edges(E, learn=False, mode='env'):
    E('start', 'source', 'doc-extractor')
    E('doc-extractor', 'source', 'template-plain')
    E('template-plain', 'source', 'if-else-read')
    E('if-else-read', 'case-need-read', 'llm_read')
    E('llm_read', 'source', 'template-join-read')
    E('template-join-read', 'source', 'save-text-read')
    E('save-text-read', 'source', 'if-else-att')
    E('if-else-read', 'false', 'template-join')
    E('template-join', 'source', 'save-text')
    E('save-text', 'source', 'if-else-att')
    E('if-else-att', 'true', 'llm_summary')
    E('llm_summary', 'source', 'save-summary')
    E('save-summary', 'source', 'env_check')
    E('env_check', 'source', 'answer-confirm')
    if learn and mode == 'env':
        E('if-else-att', 'false', 'if-else-learn')
        E('if-else-learn', 'case-teach', 'llm_case')
        E('llm_case', 'source', 'answer-case')
        E('if-else-learn', 'false', 'code_cases')
        E('code_cases', 'source', 'llm_journal')
    elif learn:
        E('if-else-att', 'false', 'if-else-learn')
        E('if-else-learn', 'case-teach', 'learn_gate')
        E('learn_gate', 'source', 'llm_case')
        E('llm_case', 'source', 'if-else-learn-set')
        E('if-else-learn-set', 'case-set', 'code_case_body')
        E('code_case_body', 'source', 'http_save_case')
        E('http_save_case', 'source', 'answer-learned')
        E('if-else-learn-set', 'false', 'answer-nolearn')
        E('if-else-learn', 'false', 'code_pagecases')
        E('code_pagecases', 'source', 'kr_cases')
        E('kr_cases', 'source', 'llm_journal')
    else:
        E('if-else-att', 'false', 'llm_journal')
    E('llm_journal', 'source', 'if-else-q')
    E('if-else-q', 'case-question', 'answer-q')


def judge_answer_final(extras, pos, answer, desc):
    by_id = {n['id']: n for n in extras['chat']['scaffold_nodes']}
    af = copy.deepcopy(by_id['answer-final'])
    af['data']['answer'] = answer
    af['data']['desc'] = desc
    af['position'] = place(pos, 'answer-final')
    af['positionAbsolute'] = place(pos, 'answer-final')
    return af


ANSWER_TAIL = '\n\n---\n(誤りや補足があれば、そのまま返信してください。判定し直します。)'

ANSWER_FINAL_DESC = '確定した相手勘定(勘定科目)とコードの表、または更問い(質問)を返信します。'

# 3形式共通のアプリ名・説明文の部品(コードの決め方だけが形式ごとに違う)
CHAT_APP_NAME = '契約書 相手勘定判定'

CHAT_DESC_HEAD = ('契約書(PDF・画像・テキスト)をチャットに添付すると、読み取った内容を確認したうえで、'
                  '契約で発生する一般的な仕訳の流れ(3〜5行)を整理し、キャッシュ(現金・預金)の'
                  '相手勘定となる勘定科目を1つ判定するチャットフロー。'
                  '文字を取り出せないスキャンPDFや画像はAIが直接読み取る。')

CHAT_DESC_TAIL = ('回答は相手勘定・確定コード・判定経路・理由・根拠の仕訳の表を1つ返す。'
                  '情報が足りない場合はAIが質問し、回答すると確定するまで対話を継続する。'
                  'このDSLはREADMEの分類ツリーから tools/generate_workflow.py で自動生成したもの。')


def chat_opening(method, learn=False, mode='env'):
    out = ('契約書(PDF・画像・テキスト)をアップロードし、テキスト欄に「.」など任意の1文字を入れて送信してください(入力した文字は使われません)。\n'
           'まず契約書から読み取った内容(契約名・当事者・主目的など)をお見せします。「OK」または訂正内容を返信いただくと、'
           '契約の一般的な仕訳の流れを整理し、キャッシュ(現金・預金)の相手勘定となる勘定科目を1つ判定して、'
           '勘定科目コードを確定します(コードの確定方法: %s)。\n'
           '情報が足りない場合は質問しますので、回答を送っていただければ確定するまで対話を続けます。' % method)
    if learn and mode == 'env':
        out += ('\n判定が違っていたら「正解: ◯◯」と返信してください。判定事例カードを返します。⑤の自動学習が集めた 判定事例.txt を'
                'アプリの環境変数 learned_cases に貼ると、次回から似た契約の判定で自動的に参考にします。')
    elif learn:
        out += ('\n判定が違っていたら「正解: ◯◯」と返信してください。判定事例カードを作って事例ナレッジに保存し'
                '(保存先が未設定ならカードを返信します)、次回から似た契約の判定で自動的に参照します。')
    return out


def learn_desc_note(learn_cfg):
    """アプリ説明文の自己学習の注記(設定込みで生成した場合は「設定済み」と書く)"""
    cfg = learn_cfg_norm(learn_cfg)
    if cfg['mode'] == 'env':
        return ('自己学習つき(ナレッジ・APIキー不要): チャットで「正解: ◯◯」と返信すると判定事例カードを返す。'
                '環境変数 learned_cases に貼った事例(⑤の自動学習が出す 判定事例.txt)から、判定前に似た契約の事例を選んで参考にする。')
    done = cfg['base_url'] and cfg['dataset_key'] and cfg['dataset_id']
    return ('自己学習(事例ナレッジ)つき: チャットで「正解: ◯◯」と返信すると判定事例カードを作って'
            'Difyのナレッジに自動保存し、次回から似た契約の判定前に検索して参考にする'
            + ('(保存先のナレッジと環境変数は生成時に設定済み)。' if done else
               '(ナレッジの作成と環境変数 dify_base_url / dataset_api_key / case_dataset_id の設定が必要。'
               '未設定でも判定は動き、「正解:」の返信には判定事例カードの文面が返る)。'))


COMPANY_ENV = {
    'description': '自社の会社名。判定を必ず自社の視点で行わせるために使う(契約書のどちらの当事者が自社かの特定に効く)。',
    'id': 'env-company-name',
    'name': 'company_name',
    'value': '',
    'value_type': 'string',
}

POLICY_ENV = {
    'description': '会社の会計方針・判定ルール(自由記述)。判定で迷いやすい点をここに書き足すと次回から反映される。',
    'id': 'env-accounting-policy',
    'name': 'accounting_policy',
    'value': ACCOUNTING_POLICY_DEFAULT,
    'value_type': 'string',
}


# ---------------------------------------------------------------- 自己学習(B案: 事例ナレッジ)
# チャットで「正解: ◯◯」と返信すると事例カードを作ってDifyのナレッジに自動保存し、
# 次回から判定前に似た事例を検索して仕訳の流れ分析(相手勘定の特定)に渡す。
# 保存先が未設定でも判定は通常どおり動く(検索は空・「正解:」にはカードの文面だけを返す)。
# ⑤の自動学習ページはナレッジAPIキーが無いとき、返ってきたカードをブラウザ側の仮ナレッジに溜め、
# 次の判定の「OK」に「参考事例:」として添える(code_pagecases が取り出して判定プロンプトへ渡す)。

LEARN_ENVS = [{
    'description': 'DifyのAPIエンドポイント(例: https://dify.example.com/v1)。自己学習の事例保存に使う。'
                   '各アプリの「APIアクセス」画面に表示されるAPIサーバーのURLと同じ。',
    'id': 'env-dify-base-url',
    'name': 'dify_base_url',
    'value': '',
    'value_type': 'string',
}, {
    'description': 'ナレッジ(データセット)APIキー(dataset-…)。Difyの「サービスAPI」→「APIキー」で発行(1.12以降はナレッジ一覧の右上、1.9〜1.11はナレッジを開いた左メニューの一番下、1.8以前は一覧左上の「API ACCESS」タブ)。'
                   'アプリのAPIキー(app-…)とは別物。',
    'id': 'env-dataset-api-key',
    'name': 'dataset_api_key',
    'value': '',
    'value_type': 'string',
}, {
    'description': '事例ナレッジのID。Difyで空のナレッジを1つ作り、そのURLの /datasets/<この部分>/documents を貼る。'
                   '判定前の類似事例検索は「類似事例の検索」ノードにも同じナレッジを選ぶ(1回だけ)。',
    'id': 'env-case-dataset-id',
    'name': 'case_dataset_id',
    'value': '',
    'value_type': 'string',
}]

LEARN_JOURNAL_SECTION = '# 過去の正解事例(あれば最優先で参考にする)\n- 下の【過去の正解事例】には、この会社で過去に人が確認した似た契約の判定事例が入っていることがある(空のこともある)\n- 事例の「正解」「決め手」は、相手勘定の選定で一般則より優先して参考にする(ただし今回の契約内容が事例と明らかに違う場合は引きずられない)\n- ユーザーの返信に「参考事例:」以下の文章が付いている場合、それは自動学習ページが添えた過去の判定事例(参考資料)であり、読み取り内容への訂正ではない\n\n【過去の正解事例】\n{{#context#}}\n{{#code_pagecases.cases#}}\n\n'

LEARN_CASE_SYSTEM = '''あなたは日本の会計実務に精通した経理・会計の専門家です。ユーザーがチャットで教えてくれた「正解」をもとに、次回から似た契約の判定に使う【判定事例】カードを1枚作ってください。出力はすべて日本語で行ってください。

# 材料
- これまでの会話に、判定した契約の読み取り内容・仕訳の流れ分析・アプリの判定結果が入っている
- ユーザーの最後の入力が正解(例: 「正解: 支払手数料」「正解: 費用/経費/支払手数料 [5030002001]」)
- アプリの判定が正解と同じだった場合も、事例として保存する価値はある(正しい判定の再現に効く)

# ルール
- 事実はこれまでの会話(読み取り内容・ユーザーの訂正)から取る。推測で補完しない
- 金額は書かない。社名などの固有名詞は書かず、立場(貸主/借主 など)で書く
- 「決め手」は、似た契約が来たときにこの科目を選べる見分け方として書く

# 出力形式(前置き・後書き・コードブロック記号は書かない。この形式だけを出力する)
【判定事例】
契約の種類: (契約・決裁の種類を具体的に)
当社の立場: (支払う側/受け取る側 など)
主な条件: (期間・支払条件・解約条件など判定を左右した条件。金額は書かない)
間違えやすい判定: (アプリが誤答した場合はその科目と誤答理由を短く。正解していた場合は「-」)
正解: (ユーザーが教えた勘定科目。コードが分かれば [コード] も)
決め手: (この契約をその科目と判定する見分け方を1〜2行)'''

LEARN_CASE_USER = '''以下は確認済みの読み取り内容と、ユーザーが教えてくれた正解です。これまでの会話の判定結果・訂正も材料にして、【判定事例】カードを1枚作ってください。

<読み取り内容(確認済み)>
{{#conversation.contract_summary#}}
</読み取り内容>

<ユーザーが教えた正解>
{{#sys.query#}}
</ユーザーが教えた正解>'''

LEARN_SAVE_BODY_CODE = '''def main(card: str, query: str) -> dict:
    # 事例カードを、ナレッジ登録API(create-by-text)のリクエストボディ(JSON)にする。
    import json
    import unicodedata

    def nk(s):
        return unicodedata.normalize('NFKC', (s or '')).strip()

    name = ''
    for line in (card or '').split('\\n'):
        line = nk(line)
        if line.startswith('契約の種類:'):
            name = line.split(':', 1)[1].strip()
            break
    if not name:
        name = nk(query)[:40] or '判定事例'
    return {'body': json.dumps({
        'name': ('判定事例: ' + name)[:100],
        'text': card,
        'indexing_technique': 'high_quality',
        'process_rule': {'mode': 'automatic'},
    }, ensure_ascii=False)}
'''

LEARN_ANSWER_SAVED = ('✅ 正解を事例ナレッジに保存しました(HTTP {{#http_save_case.status_code#}})。'
                      '次回から、似た契約の判定前に自動で検索して参考にします。\n\n{{#llm_case.text#}}\n\n---\n'
                      '(HTTPが200番台以外の場合は保存できていません。環境変数 dify_base_url / dataset_api_key / '
                      'case_dataset_id を確認してください。)')

LEARN_ANSWER_NOSAVE = '📋 正解を受け取り、判定事例カードを作りました。保存先(環境変数 dify_base_url / dataset_api_key / case_dataset_id)が未設定のため、事例ナレッジには保存していません。\n\n{{#llm_case.text#}}\n\n---\nこのカードは、事例ナレッジに「テキストを追加」で貼るか、⑤の自動学習(ナレッジAPIキーなし)が仮ナレッジとして記録します。環境変数を設定すると、次回から自動で保存されます。'

# ⑤が「OK」の返信に添える参考事例(ブラウザ側の仮ナレッジ)を取り出すコードノード
LEARN_PAGECASES_CODE = "def main(query: str) -> dict:\n    # ⑤の自動学習ページが「OK」の返信に添える参考事例(ブラウザ側の仮ナレッジ)を取り出す。無ければ空。\n    q = query or ''\n    mark = '参考事例:'\n    i = q.find(mark)\n    return {'cases': q[i + len(mark):].strip() if i >= 0 else ''}\n"


# ---- 事例の置き場「環境変数」方式(既定): ナレッジもAPIキーも使わない。
# 「正解:」の返信にはカードを返すだけ。⑤の自動学習がカードを集めて 判定事例.txt にまとめる。
# 社内展開では 判定事例.txt の中身をアプリの環境変数 learned_cases に貼る。判定前に code_cases が
# 読み取り内容に似た事例を4件まで選び(⑤と同じ2文字組の重なり)、判定プロンプトの【過去の正解事例】に渡す。
LEARN_CASES_ENV = {
    'description': '⑤の自動学習が出力した「判定事例.txt」の中身をそのまま貼る(空でも可)。判定前に、ここから読み取り内容に'
                   '似た事例を4件まで選んで参考にする。貼れる量の目安は日本語で5万〜10万字(Difyの MAX_VARIABLE_SIZE=既定200KB。'
                   '超えるなら古い決裁のブロックから削る)。',
    'id': 'env-learned-cases',
    'name': 'learned_cases',
    'value': '',
    'value_type': 'string',
}

LEARN_JOURNAL_SECTION_ENV = ('# 過去の正解事例(あれば最優先で参考にする)\n'
                             '- 下の【過去の正解事例】には、この会社で過去に人が確認した似た契約の判定事例が入っていることがある(空のこともある)\n'
                             '- 事例の「正解」「決め手」は、相手勘定の選定で一般則より優先して参考にする(ただし今回の契約内容が事例と明らかに違う場合は引きずられない)\n'
                             '- ユーザーの返信に「参考事例:」以下の文章が付いている場合、それは自動学習ページが添えた過去の判定事例(参考資料)であり、読み取り内容への訂正ではない\n'
                             '\n【過去の正解事例】\n{{#code_cases.cases#}}\n\n')

LEARN_CASES_CODE = """def main(query: str, summary: str, learned: str) -> dict:
    # 判定前に参考にする過去の判定事例を集める(ナレッジやAPIキーは使わない)。
    #  - ⑤の自動学習ページが「OK」の返信に添えた「参考事例:」以下(あれば)
    #  - 環境変数 learned_cases(⑤が出す 判定事例.txt の中身。「### 決裁名」見出しつきのブロック、または【判定事例】カードの列)
    # 読み取り内容(summary)と文字の重なり(2文字組)が大きい順に4件まで返す。
    import unicodedata

    def cards_of(text):
        t = (text or '').replace('\\r', '')
        out = []
        if '\\n### ' in ('\\n' + t):
            for seg in ('\\n' + t).split('\\n### ')[1:]:
                out.append((seg.split('\\n', 1)[1] if '\\n' in seg else '').strip())
        else:
            for seg in t.split('【判定事例】'):
                seg = seg.strip()
                if seg:
                    out.append('【判定事例】\\n' + seg)
        return [c for c in out if c]

    def grams(s):
        t = unicodedata.normalize('NFKC', s or '')
        t = ''.join(ch for ch in t if ch not in ' \\t\\n|[]【】()「」:、。・,./-*#')
        return set(t[i:i + 2] for i in range(len(t) - 1))

    def sim(a, b):
        return len(a & b) / ((len(a) * len(b)) ** 0.5) if a and b else 0.0

    q = query or ''
    i = q.find('参考事例:')
    page = cards_of(q[i + len('参考事例:'):]) if i >= 0 else []
    cands, seen = [], set()
    for c in page + cards_of(learned):
        key = ''.join(c.split())
        if key not in seen:
            seen.add(key)
            cands.append(c)
    g = grams(summary)
    scored = sorted(((sim(g, grams(c)), c) for c in cands), key=lambda x: -x[0])
    return {'cases': '\\n\\n'.join(c for s, c in scored[:4] if s > 0)}
"""

LEARN_ANSWER_CARD = ('📋 正解を受け取り、判定事例カードを作りました。\n\n{{#llm_case.text#}}\n\n---\n'
                     'このカードは⑤の自動学習が集めて 判定事例.txt にまとめます。社内で使うアプリには、その中身をアプリの環境変数 '
                     'learned_cases に貼ると、次回から似た契約の判定前に参考にします(ナレッジ・APIキー不要)。')


def learn_cfg_norm(cfg):
    """自己学習の設定を正規化する。mode: 'env'(既定。環境変数 learned_cases に事例を貼る。ナレッジ不要)
    または 'kb'(Difyの事例ナレッジ。検索ノード+自動保存。ナレッジIDやキーは生成時に書き込める)"""
    cfg = cfg or {}
    mode = (cfg.get('mode') or '').strip().lower()
    return {'mode': 'kb' if mode == 'kb' else 'env',
            'base_url': (cfg.get('base_url') or '').strip(),
            'dataset_key': (cfg.get('dataset_key') or '').strip(),
            'dataset_id': (cfg.get('dataset_id') or '').strip()}


def learn_envs(cfg):
    """環境変数方式なら learned_cases の1つ。ナレッジ方式なら LEARN_ENVS のコピーに生成時の値(あれば)を書き込んで返す"""
    if cfg['mode'] == 'env':
        return [dict(LEARN_CASES_ENV)]
    vals = {'dify_base_url': cfg['base_url'],
            'dataset_api_key': cfg['dataset_key'],
            'case_dataset_id': cfg['dataset_id']}
    out = []
    for e in LEARN_ENVS:
        e = dict(e)
        if vals.get(e['name']):
            e['value'] = vals[e['name']]
        out.append(e)
    return out


def learn_journal_patch(node, mode='env'):
    """llm_journal に過去の正解事例の参照を組み込む(環境変数方式は code_cases の出力、ナレッジ方式は検索結果 context)"""
    sys_p = node['data']['prompt_template'][0]
    anchor = '# 仕訳の流れの作り方'
    if mode == 'env':
        sys_p['text'] = sys_p['text'].replace(anchor, LEARN_JOURNAL_SECTION_ENV + anchor)
        return
    node['data']['context'] = {'enabled': True, 'variable_selector': ['kr_cases', 'result']}
    sys_p['text'] = sys_p['text'].replace(anchor, LEARN_JOURNAL_SECTION + anchor)


def learn_nodes(pos, cfg):
    """自己学習のノード一式。cfg['mode'] が 'env' なら環境変数方式(ナレッジ不要)、'kb' なら事例ナレッジ方式"""
    if cfg['mode'] == 'env':
        return learn_nodes_env(pos)
    return learn_nodes_kb(pos, cfg['dataset_id'])


def learn_ifelse_node(pos):
    return node_shell('if-else-learn', {
        'cases': [{
            'case_id': 'case-teach',
            'conditions': [{
                'comparison_operator': 'start with',
                'id': 'cond-teach',
                'value': '正解',
                'varType': 'string',
                'variable_selector': ['sys', 'query'],
            }],
            'id': 'case-teach',
            'logical_operator': 'and',
        }],
        'desc': '「正解: ◯◯」の返信なら事例の保存へ、それ以外は判定へ進みます。',
        'selected': False,
        'title': '条件分岐(正解の受け取り)',
        'type': 'if-else',
    }, place(pos, 'if-else-learn'), height=126)


def learn_llm_case_node(pos):
    return node_shell('llm_case', {
        'context': {'enabled': False, 'variable_selector': []},
        'desc': '教えてもらった正解と会話の内容から、次回の判定に使う【判定事例】カードを1枚作ります。',
        'memory': copy.deepcopy(MEMORY_BLOCK),
        'model': copy.deepcopy(MODEL),
        'prompt_template': [
            {'id': 'system-prompt-case', 'role': 'system', 'text': LEARN_CASE_SYSTEM},
            {'id': 'user-prompt-case', 'role': 'user', 'text': LEARN_CASE_USER},
        ],
        'selected': False,
        'title': '判定事例カード作成',
        'type': 'llm',
        'variables': [],
        'vision': {'enabled': False},
    }, place(pos, 'llm_case'), height=98)


def learn_nodes_env(pos):
    """環境変数方式: 参考事例の選択 → 判定 / 「正解:」→ カード作成 → カードを返信(保存しない)"""
    out = []
    out.append(node_shell('code_cases', {
        'code': LEARN_CASES_CODE,
        'code_language': 'python3',
        'desc': '判定前に参考にする過去の判定事例を選びます: 環境変数 learned_cases(⑤が出す 判定事例.txt を貼る)と、'
                '⑤が「OK」に添えた参考事例から、読み取り内容に似た順に4件まで。ナレッジやAPIキーは使いません。',
        'outputs': {'cases': {'children': None, 'type': 'string'}},
        'selected': False,
        'title': '参考事例の選択',
        'type': 'code',
        'variables': [{'value_selector': ['sys', 'query'], 'variable': 'query'},
                      {'value_selector': ['conversation', 'contract_summary'], 'variable': 'summary'},
                      {'value_selector': ['env', 'learned_cases'], 'variable': 'learned'}],
    }, place(pos, 'code_cases'), height=92))
    out.append(learn_ifelse_node(pos))
    out.append(learn_llm_case_node(pos))
    out.append(node_shell('answer-case', {
        'answer': LEARN_ANSWER_CARD,
        'desc': '作った判定事例カードを返信します(⑤が集めます。社内展開では 判定事例.txt を環境変数 learned_cases に貼ります)。',
        'selected': False,
        'title': '回答(判定事例カード)',
        'type': 'answer',
        'variables': [],
    }, place(pos, 'answer-case'), height=120))
    return out


def learn_nodes_kb(pos, dataset_id=''):
    """事例ナレッジ方式のノード一式。dataset_id を渡すと「類似事例の検索」に選択済みで入る"""
    out = []
    out.append(node_shell('kr_cases', {
        'dataset_ids': [dataset_id] if dataset_id else [],
        'desc': '事例ナレッジから、いま読んでいる契約に似た過去の判定事例を検索します。'
                + ('生成時に入力された事例ナレッジを設定済みです(変えるときはここで選び直してください)。'
                   if dataset_id else
                   'インポート後、このノードで事例ナレッジを1回選んでください(未選択でも判定は動きます)。'),
        'multiple_retrieval_config': {'reranking_enable': False, 'score_threshold': None, 'top_k': 4},
        'query_variable_selector': ['conversation', 'contract_summary'],
        'retrieval_mode': 'multiple',
        'selected': False,
        'title': '類似事例の検索',
        'type': 'knowledge-retrieval',
    }, place(pos, 'kr_cases'), height=92))
    out.append(node_shell('code_pagecases', {
        'code': LEARN_PAGECASES_CODE,
        'code_language': 'python3',
        'desc': '⑤の自動学習ページが「OK」の返信に添えた参考事例(ブラウザ側の仮ナレッジ)を取り出します。無ければ空です。',
        'outputs': {'cases': {'children': None, 'type': 'string'}},
        'selected': False,
        'title': '参考事例の取り出し',
        'type': 'code',
        'variables': [{'value_selector': ['sys', 'query'], 'variable': 'query'}],
    }, place(pos, 'code_pagecases'), height=92))
    out.append(learn_ifelse_node(pos))
    out.append(node_shell('learn_gate', {
        'desc': '事例ナレッジの保存先(環境変数3つ)が設定済みかを点検します。',
        'selected': False,
        'template': "{% if (u | trim) == '' or (k | trim) == '' or (d | trim) == '' %}off{% else %}on{% endif %}",
        'title': '保存先チェック',
        'type': 'template-transform',
        'variables': [{'value_selector': ['env', 'dify_base_url'], 'variable': 'u'},
                      {'value_selector': ['env', 'dataset_api_key'], 'variable': 'k'},
                      {'value_selector': ['env', 'case_dataset_id'], 'variable': 'd'}],
    }, place(pos, 'learn_gate'), height=82))
    out.append(node_shell('if-else-learn-set', {
        'cases': [{
            'case_id': 'case-set',
            'conditions': [{
                'comparison_operator': 'start with',
                'id': 'cond-set',
                'value': 'on',
                'varType': 'string',
                'variable_selector': ['learn_gate', 'output'],
            }],
            'id': 'case-set',
            'logical_operator': 'and',
        }],
        'desc': '保存先が設定済みならナレッジへ保存、未設定ならカードだけを返信します。',
        'selected': False,
        'title': '条件分岐(保存先の有無)',
        'type': 'if-else',
    }, place(pos, 'if-else-learn-set'), height=126))
    out.append(learn_llm_case_node(pos))
    out.append(node_shell('code_case_body', {
        'code': LEARN_SAVE_BODY_CODE,
        'code_language': 'python3',
        'desc': '事例カードを、ナレッジ登録API(create-by-text)のリクエストにします。',
        'outputs': {'body': {'children': None, 'type': 'string'}},
        'selected': False,
        'title': '保存リクエスト作成',
        'type': 'code',
        'variables': [{'value_selector': ['llm_case', 'text'], 'variable': 'card'},
                      {'value_selector': ['sys', 'query'], 'variable': 'query'}],
    }, place(pos, 'code_case_body'), height=92))
    out.append(node_shell('http_save_case', {
        'authorization': {'config': None, 'type': 'no-auth'},
        'body': {'data': [{'id': 'key-value-body-case', 'key': '', 'type': 'text',
                           'value': '{{#code_case_body.body#}}'}], 'type': 'json'},
        'desc': '事例カードをDifyの事例ナレッジに登録します(document/create-by-text)。',
        'headers': 'Content-Type: application/json\nAuthorization: Bearer {{#env.dataset_api_key#}}',
        'method': 'post',
        'params': '',
        'retry_config': {'max_retries': 1, 'retry_enabled': True, 'retry_interval': 2000},
        'selected': False,
        'timeout': {'max_connect_timeout': 30, 'max_read_timeout': 120, 'max_write_timeout': 30},
        'title': 'ナレッジへ保存',
        'type': 'http-request',
        'url': '{{#env.dify_base_url#}}/datasets/{{#env.case_dataset_id#}}/document/create-by-text',
        'variables': [],
    }, place(pos, 'http_save_case'), height=92))
    out.append(node_shell('answer-learned', {
        'answer': LEARN_ANSWER_SAVED,
        'desc': '保存した事例カードと保存結果を返信します。',
        'selected': False,
        'title': '回答(事例を保存)',
        'type': 'answer',
        'variables': [],
    }, place(pos, 'answer-learned'), height=120))
    out.append(node_shell('answer-nolearn', {
        'answer': LEARN_ANSWER_NOSAVE,
        'desc': '保存先(環境変数)が未設定のときは、作ったカードの文面をそのまま返信します。',
        'selected': False,
        'title': '回答(保存先未設定・カードのみ)',
        'type': 'answer',
        'variables': [],
    }, place(pos, 'answer-nolearn'), height=120))
    return out


def compute_layout_flat():
    pos = compute_layout_front()
    pos['llm_code7'] = (colx(9), SCAF_Y)
    pos['llm_code10'] = (colx(10), SCAF_Y)
    pos['code_final'] = (colx(11), SCAF_Y)
    pos['answer-final'] = (colx(12), SCAF_Y)
    return pos


def compute_layout_pick():
    pos = compute_layout_front()
    pos['llm_pick'] = (colx(9), SCAF_Y)
    pos['code_pick'] = (colx(10), SCAF_Y)
    pos['answer-final'] = (colx(11), SCAF_Y)
    return pos


def compute_layout_tree(root, stages, gagg_ids):
    """ツリー判定形式のレイアウト。共通の入り口+段階判定のバンド"""
    pos = compute_layout_front()
    max_depth = max(stage_depth(st) for st in stages.values())
    ga_col = max(12, 10 + 2 * max_depth)

    pos[stages[node_key(root)].id] = (colx(9), SCAF_Y)
    if stages[node_key(root)].ifelse_id:
        pos[stages[node_key(root)].ifelse_id] = (colx(10), SCAF_Y)
    pos['aggregator'] = (colx(ga_col + 1), AGG_Y + 150)
    pos['template_path'] = (colx(ga_col + 2), AGG_Y + 150)
    pos['template_code'] = (colx(ga_col + 3), AGG_Y + 150)
    pos['if-else-q-tree'] = (colx(ga_col + 4), AGG_Y + 150)
    pos['answer-q-tree'] = (colx(ga_col + 5), AGG_Y + 40)
    pos['code_result'] = (colx(ga_col + 5), AGG_Y + 260)
    pos['answer-final'] = (colx(ga_col + 6), AGG_Y + 260)

    band_y = BANDS_Y0
    for cat in root.children:
        if not cat.is_branch:
            continue
        head = stages[node_key(cat)]
        sub_stages = [stages[node_key(c)] for c in cat.children if c.is_branch]
        rows = 1 + len(sub_stages)
        pos[head.id] = (colx(11), band_y)
        if head.ifelse_id:
            pos[head.ifelse_id] = (colx(12), band_y)
        for i, st in enumerate(sub_stages):
            y = band_y + ROW * (1 + i)
            pos[st.id] = (colx(9 + 2 * stage_depth(st)), y)
            if st.ifelse_id:
                pos[st.ifelse_id] = (colx(10 + 2 * stage_depth(st)), y)

            def deeper(node):
                for c in node.children:
                    if not c.is_branch:
                        continue
                    dst = stages[node_key(c)]
                    pos[dst.id] = (colx(9 + 2 * stage_depth(dst)), y)
                    if dst.ifelse_id:
                        pos[dst.ifelse_id] = (colx(10 + 2 * stage_depth(dst)), y)
                    deeper(c)
            deeper(st.node)
        gy = band_y + rows * ROW + 70
        pos[gagg_ids[node_key(cat)]] = (colx(ga_col), gy)
        band_y = gy + 116 + BAND_GAP
    return pos


NO_CODES_MSG = ('ツリーに [7桁] のコードが1つもありません。%sは、'
                'ツリーの [7桁][3桁] を選択肢にする形式なので、コード付きのツリーで生成してください。')


def generate_flat(tree_text, extras, learn=False, learn_cfg=None):
    """コード2段選択形式(advanced-chat)。入力・読み取り・仕訳の流れ分析(相手勘定の特定)は
    3形式共通。コードの確定は、7桁コードの候補を横並びで1つ選び、その7桁に紐付く10桁を
    名称と書き分けの定義(環境変数)で絞り込む2段選択。コードの確定は機械(コードノード)"""
    root = parse_tree(tree_text)
    c7 = codes7_lines(root)
    c10 = codes10_lines(root)
    if not c7:
        raise SystemExit(NO_CODES_MSG % 'コード2段選択形式')

    pos = compute_layout_flat()
    nodes = chat_front(extras, pos, learn, learn_cfg)
    nodes += [copy.deepcopy(n) for n in extras['flat']['scaffold_nodes']]
    nodes.append(judge_answer_final(
        extras, pos, '{{#code_final.text#}}' + ANSWER_TAIL, ANSWER_FINAL_DESC))
    for n in nodes:
        if n['id'] in pos:
            n['position'] = place(pos, n['id'])
            n['positionAbsolute'] = place(pos, n['id'])
    nodes_by_id = {n['id']: n for n in nodes}
    if len(nodes_by_id) != len(nodes):
        raise SystemExit('ノードIDが重複しています')

    edges = []

    def E(src, handle, tgt):
        edges.append(make_edge_chat(nodes_by_id, src, handle, tgt))
    chat_front_edges(E, learn, learn_cfg_norm(learn_cfg)['mode'])
    E('if-else-q', 'false', 'llm_code7')
    E('llm_code7', 'source', 'llm_code10')
    E('llm_code10', 'source', 'code_final')
    E('code_final', 'source', 'answer-final')

    app = copy.deepcopy(extras['app'])
    app['mode'] = 'advanced-chat'
    app['name'] = CHAT_APP_NAME + '(コード2段選択)'
    app['description'] = (
        CHAT_DESC_HEAD +
        'コードの確定は、7桁コードの候補(%d件)を横並びで1つ選び、その7桁に紐付く10桁(%d件)を'
        '名称と書き分けの定義(環境変数で編集可)で絞り込む2段選択方式。'
        'コードはLLMに書かせず、選ばれた経路・名称から対応表で機械的に確定する。'
        % (len(c7), sum(1 for l in c10 if l.startswith('  - '))) +
        (learn_desc_note(learn_cfg) if learn else '') + CHAT_DESC_TAIL)

    envs = [{
        'description': '7桁コードの候補一覧(横並び)。分類ツリーの[7桁]とフルコードの上7桁から自動生成。'
                       '1行=「- 経路 [7桁]: 定義」。修正はツリー側が正で、ここでの編集は再生成までの応急対応。',
        'id': 'env-codes7-list',
        'name': 'codes7_list',
        'value': '\n'.join(c7),
        'value_type': 'string',
    }, {
        'description': '7桁→10桁の対応表(書き分け)。「[7桁] 経路」の見出しの下に、配下の「- 名称 [3桁]: 定義」。'
                       'ツリーの[3桁]と定義(十桁定義)から自動生成。定義を書き足すと10桁絞り込みの判定に反映される。'
                       '修正はツリー側が正で、ここでの編集は再生成までの応急対応。',
        'id': 'env-codes10-list',
        'name': 'codes10_list',
        'value': '\n'.join(c10),
        'value_type': 'string',
    }, dict(COMPANY_ENV), dict(POLICY_ENV)]
    if learn:
        envs += learn_envs(learn_cfg_norm(learn_cfg))

    features = copy.deepcopy(extras['features'])
    features['opening_statement'] = chat_opening('7桁を選んでから10桁を絞り込む2段選択', learn, learn_cfg_norm(learn_cfg)['mode'])

    return {
        'app': app,
        'kind': 'app',
        'version': '0.3.0',
        'workflow': {
            'conversation_variables': copy.deepcopy(extras['chat']['conversation_variables']),
            'environment_variables': envs,
            'features': features,
            'graph': {'edges': edges, 'nodes': nodes, 'viewport': {'x': 0, 'y': 0, 'zoom': 0.7}},
        },
    }


def generate_pick(tree_text, extras, learn=False, learn_cfg=None):
    """コード一発選択形式(advanced-chat)。入力・読み取り・仕訳の流れ分析(相手勘定の特定)は
    3形式共通。コードの確定は、10桁(無い科目は7桁)のコード候補すべてを横並びで提示して
    1回で選ぶ。コードの確定は機械(コードノード)"""
    root = parse_tree(tree_text)
    cl = codes_pick_lines(root)
    if not cl:
        raise SystemExit(NO_CODES_MSG % 'コード一発選択形式')

    pos = compute_layout_pick()
    nodes = chat_front(extras, pos, learn, learn_cfg)
    nodes += [copy.deepcopy(n) for n in extras['pick']['scaffold_nodes']]
    nodes.append(judge_answer_final(
        extras, pos, '{{#code_pick.text#}}' + ANSWER_TAIL, ANSWER_FINAL_DESC))
    for n in nodes:
        if n['id'] in pos:
            n['position'] = place(pos, n['id'])
            n['positionAbsolute'] = place(pos, n['id'])
    nodes_by_id = {n['id']: n for n in nodes}
    if len(nodes_by_id) != len(nodes):
        raise SystemExit('ノードIDが重複しています')

    edges = []

    def E(src, handle, tgt):
        edges.append(make_edge_chat(nodes_by_id, src, handle, tgt))
    chat_front_edges(E, learn, learn_cfg_norm(learn_cfg)['mode'])
    E('if-else-q', 'false', 'llm_pick')
    E('llm_pick', 'source', 'code_pick')
    E('code_pick', 'source', 'answer-final')

    app = copy.deepcopy(extras['app'])
    app['mode'] = 'advanced-chat'
    app['name'] = CHAT_APP_NAME + '(コード一発選択)'
    app['description'] = (
        CHAT_DESC_HEAD +
        'コードの確定は、10桁(無い科目は7桁)のコード候補(%d件)をすべて横並びで提示して1つ選ぶ一発選択方式。'
        'コードはLLMに書かせず、選ばれた経路から対応表で機械的に確定する。'
        % len(cl) +
        (learn_desc_note(learn_cfg) if learn else '') + CHAT_DESC_TAIL)

    envs = [{
        'description': '全コード候補の横並び一覧(一発選択用)。10桁がある科目は「- 経路/名称 [10桁]: 定義」、'
                       '10桁が無い7桁は「- 経路 [7桁]: 定義」。ツリーの[7桁][3桁]と定義から自動生成。'
                       '修正はツリー側が正で、ここでの編集は再生成までの応急対応。',
        'id': 'env-codes-list',
        'name': 'codes_list',
        'value': '\n'.join(cl),
        'value_type': 'string',
    }, dict(COMPANY_ENV), dict(POLICY_ENV)]
    if learn:
        envs += learn_envs(learn_cfg_norm(learn_cfg))

    features = copy.deepcopy(extras['features'])
    features['opening_statement'] = chat_opening('全コード候補からの一発選択', learn, learn_cfg_norm(learn_cfg)['mode'])

    return {
        'app': app,
        'kind': 'app',
        'version': '0.3.0',
        'workflow': {
            'conversation_variables': copy.deepcopy(extras['chat']['conversation_variables']),
            'environment_variables': envs,
            'features': features,
            'graph': {'edges': edges, 'nodes': nodes, 'viewport': {'x': 0, 'y': 0, 'zoom': 0.7}},
        },
    }


# ツリー判定形式の結果整形コードノード(コード2段選択・一発選択の code_final / code_pick に対応)
CODE_RESULT_CODE = '''def main(path: str, code: str, journal: str) -> dict:
    # ツリー判定の経路とコードを、前段の仕訳分析(相手勘定・根拠の仕訳)と合わせて結果表にまとめる。
    import unicodedata

    def nk(s):
        return unicodedata.normalize('NFKC', (s or '')).strip()

    def field(text, key):
        for line in (text or '').split('\\n'):
            line = nk(line)
            if line.startswith(key + ':'):
                return nk(line[len(key) + 1:])
        return ''

    path = nk(path)
    code = nk(code)
    final = '' if code in ('', 'コード未登録') else code

    # 結果表(相手勘定=判定経路の末端科目。仕訳分析の科目名と違う場合は併記)
    leaf = path.split('/')[-1] if path else ''
    subject = leaf or '-'
    j_account = field(journal, '相手勘定')
    if j_account and leaf and nk(j_account) != nk(leaf):
        subject = '%s(仕訳上の名称: %s)' % (leaf, j_account)

    out = ['## 🔢 判定結果(キャッシュの相手勘定)',
           '| 項目 | 内容 |',
           '|---|---|',
           '| 相手勘定(科目) | %s |' % subject,
           '| 確定コード | %s |' % (code or '未確定'),
           '| 判定経路 | %s |' % (path or '-'),
           '| 判定の理由 | %s |' % (field(journal, '理由') or '-'),
           '| 根拠の仕訳 | %s |' % (field(journal, '根拠の仕訳') or '-')]
    return {'text': '\\n'.join(out), 'code': final}
'''


def generate_tree(tree_text, extras, learn=False, learn_cfg=None):
    """ツリー判定形式(advanced-chat)。入力・読み取り・仕訳の流れ分析(相手勘定の特定)は
    3形式共通。コードの確定は、相手勘定を分類ツリーで1段ずつ下りて位置づける段階判定
    (従来フォーム版と同じ判定部)。判定経路から勘定科目コード(code_map の最長一致)を確定する"""
    root = parse_tree(tree_text)
    stages = build_stages(root, extras)

    used = {st.id for st in stages.values()} | {st.ifelse_id for st in stages.values() if st.ifelse_id}
    gagg_ids = {}
    for cat in root.children:
        if not cat.is_branch:
            continue
        suffix = stages[node_key(cat)].id.replace('llm-sub-', '').replace('llm-', '')
        gid = 'aggregator-' + suffix
        k = 2
        while gid in used:
            gid, k = 'aggregator-%s%d' % (suffix, k), k + 1
        used.add(gid)
        gagg_ids[node_key(cat)] = gid

    pos = compute_layout_tree(root, stages, gagg_ids)
    by_chat = {n['id']: n for n in extras['chat']['scaffold_nodes']}
    nodes = chat_front(extras, pos, learn, learn_cfg)

    stage_nodes = []

    def emit(node):
        stage = stages[node_key(node)]
        stage_nodes.append(llm_node(stage, pos, chat=True))
        if stage.ifelse_id:
            stage_nodes.append(ifelse_node(stage, stages, pos))
        for c in stage.branch_children():
            emit(c)
    emit(root)
    nodes += stage_nodes

    for cat in root.children:
        if not cat.is_branch:
            continue
        gid = gagg_ids[node_key(cat)]
        data = {
            'desc': '%s系の判定結果を1つに集約します(最も深い判定が優先)。' % cat.label,
            'output_type': 'string',
            'selected': False,
            'title': '変数集約(%s)' % cat.label,
            'type': 'variable-aggregator',
            'variables': [[st.id, 'text'] for st in postorder_sub(cat, stages)],
        }
        nodes.append(node_shell(gid, data, place(pos, gid)))

    agg = copy.deepcopy({n['id']: n for n in extras['scaffold_nodes']}['aggregator'])
    agg['data']['variables'] = ([[gagg_ids[node_key(c)], 'output'] for c in root.children if c.is_branch]
                                + [[stages[node_key(root)].id, 'text']])
    agg['position'] = place(pos, 'aggregator')
    agg['positionAbsolute'] = place(pos, 'aggregator')
    nodes.append(agg)

    path_order = sorted(stages.values(), key=lambda st: stage_depth(st))
    tp_parts = []
    for st in path_order:
        v = st.id.replace('-', '_')
        tp_parts.append("{%% if %s and %s[:2] != '質問' %%}%s{{ %s }}{%% endif %%}"
                        % (v, v, '' if st.is_root else '/', v))
    nodes.append(node_shell('template_path', {
        'desc': '判定で通ってきた経路を「流動資産/現金・預金/預金」のように「/」で連結します。',
        'selected': False,
        'template': ''.join(tp_parts),
        'title': '経路組み立て',
        'type': 'template-transform',
        'variables': [{'value_selector': [st.id, 'text'], 'variable': st.id.replace('-', '_')}
                      for st in path_order],
    }, place(pos, 'template_path')))

    code_tmpl = (
        "{% set ns = namespace(code='', p=path) %}"
        "{% for _ in range(12) %}{% if ns.code == '' and ns.p %}"
        "{% for line in map.split('\\n') %}"
        "{% if line and line.split(',')[0] == ns.p %}{% set ns.code = line.split(',')[1] %}{% endif %}"
        "{% endfor %}"
        "{% if ns.code == '' %}{% set ns.p = ns.p.rsplit('/', 1)[0] if '/' in ns.p else '' %}{% endif %}"
        "{% endif %}{% endfor %}"
        "{{ ns.code if ns.code else 'コード未登録' }}")
    nodes.append(node_shell('template_code', {
        'desc': '経路から勘定科目コード(共通7桁、下3桁まで確定していれば10桁)を対応表 code_map で決定的に確定します。未登録は「コード未登録」。',
        'selected': False,
        'template': code_tmpl,
        'title': 'コード確定',
        'type': 'template-transform',
        'variables': [{'value_selector': ['template_path', 'output'], 'variable': 'path'},
                      {'value_selector': ['env', 'code_map'], 'variable': 'map'}],
    }, place(pos, 'template_code')))

    # 段階判定そのものからの更問い(共通前段の更問いチェックとは別に、集約後にもう1回チェック)
    q = copy.deepcopy(by_chat['if-else-q'])
    q['id'] = 'if-else-q-tree'
    q['data']['cases'][0]['conditions'][0]['variable_selector'] = ['aggregator', 'output']
    q['data']['desc'] = '段階判定が更問い(質問)を返した場合はコード確定に進まず、質問をそのまま返信します。'
    q['data']['title'] = '条件分岐(更問いチェック:段階判定)'
    q['position'] = place(pos, 'if-else-q-tree')
    q['positionAbsolute'] = place(pos, 'if-else-q-tree')
    nodes.append(q)

    aq = copy.deepcopy(by_chat['answer-q'])
    aq['id'] = 'answer-q-tree'
    aq['data']['answer'] = '{{#aggregator.output#}}\n\n(回答をそのまま返信してください。判定を続けます。)'
    aq['data']['desc'] = '段階判定に必要な情報が足りないときの質問を返信します。'
    aq['position'] = place(pos, 'answer-q-tree')
    aq['positionAbsolute'] = place(pos, 'answer-q-tree')
    nodes.append(aq)

    nodes.append(node_shell('code_result', {
        'code': CODE_RESULT_CODE,
        'code_language': 'python3',
        'desc': 'ツリー判定の経路とコードを、仕訳分析(相手勘定・根拠の仕訳)と合わせて結果表にまとめます(LLMはコードに触れません)。',
        'outputs': {'code': {'children': None, 'type': 'string'},
                    'text': {'children': None, 'type': 'string'}},
        'selected': False,
        'title': '判定結果整形',
        'type': 'code',
        'variables': [
            {'value_selector': ['template_path', 'output'], 'variable': 'path'},
            {'value_selector': ['template_code', 'output'], 'variable': 'code'},
            {'value_selector': ['llm_journal', 'text'], 'variable': 'journal'},
        ],
    }, place(pos, 'code_result'), height=92))

    nodes.append(judge_answer_final(
        extras, pos, '{{#code_result.text#}}' + ANSWER_TAIL, ANSWER_FINAL_DESC))

    nodes_by_id = {n['id']: n for n in nodes}
    if len(nodes_by_id) != len(nodes):
        raise SystemExit('ノードIDが重複しています')

    edges = []

    def E(src, handle, tgt):
        edges.append(make_edge_chat(nodes_by_id, src, handle, tgt))
    chat_front_edges(E, learn, learn_cfg_norm(learn_cfg)['mode'])
    E('if-else-q', 'false', stages[node_key(root)].id)

    def wire(node, sink):
        stage = stages[node_key(node)]
        if stage.ifelse_id:
            E(stage.id, 'source', stage.ifelse_id)
            for c in stage.branch_children():
                E(stage.ifelse_id, case_id_for(stages[node_key(c)]), stages[node_key(c)].id)
                wire(c, gagg_ids[node_key(c)] if node is root else sink)
            E(stage.ifelse_id, 'false', sink)
        else:
            E(stage.id, 'source', sink)
    wire(root, 'aggregator')
    for cat in root.children:
        if cat.is_branch:
            E(gagg_ids[node_key(cat)], 'source', 'aggregator')
    E('aggregator', 'source', 'template_path')
    E('template_path', 'source', 'template_code')
    E('template_code', 'source', 'if-else-q-tree')
    E('if-else-q-tree', 'case-question', 'answer-q-tree')
    E('if-else-q-tree', 'false', 'code_result')
    E('code_result', 'source', 'answer-final')

    order = postorder(root, stages)
    leaves = []

    def count_leaves(n):
        for c in n.children:
            (leaves.append(c.label) if c.leaf else count_leaves(c))
    count_leaves(root)
    app = copy.deepcopy(extras['app'])
    app['mode'] = 'advanced-chat'
    app['name'] = CHAT_APP_NAME + '(ツリー判定)'
    app['description'] = (
        CHAT_DESC_HEAD +
        'コードの確定は、相手勘定を分類ツリーで1段ずつ下りて位置づける段階判定方式'
        '(%dステージ・最終ラベル%d種類。細分の分類基準は環境変数 rules_*(%d個)で編集できる)。'
        'コードはLLMに書かせず、判定経路から対応表 code_map で機械的に確定する。'
        % (len(order), len(leaves), sum(1 for st in stages.values() if st.env)) +
        (learn_desc_note(learn_cfg) if learn else '') + CHAT_DESC_TAIL)

    envs = env_vars(root, stages, extras)
    envs.append({
        'description': '経路→勘定科目コードの対応表(ツリーの[7桁][3桁]から自動生成。1行=「経路,コード」。'
                       '修正はツリー側が正で、ここでの編集は再生成までの応急対応)。',
        'id': 'env-code-map',
        'name': 'code_map',
        'value': '\n'.join(code_map_lines(root)),
        'value_type': 'string',
    })
    envs.append(dict(COMPANY_ENV))
    envs.append(dict(POLICY_ENV))
    if learn:
        envs += learn_envs(learn_cfg_norm(learn_cfg))

    features = copy.deepcopy(extras['features'])
    features['opening_statement'] = chat_opening('分類ツリーを1段ずつ下りる段階判定', learn, learn_cfg_norm(learn_cfg)['mode'])

    return {
        'app': app,
        'kind': 'app',
        'version': '0.3.0',
        'workflow': {
            'conversation_variables': copy.deepcopy(extras['chat']['conversation_variables']),
            'environment_variables': envs,
            'features': features,
            'graph': {'edges': edges, 'nodes': nodes, 'viewport': {'x': 0, 'y': 0, 'zoom': 0.7}},
        },
    }


def env_vars(root, stages, extras):
    out = []

    def walk(node):
        stage = stages[node_key(node)]
        if stage.env:
            lines = []
            for i, c in enumerate(node.children, 1):
                lines.append('%d. %s: %s' % (i, c.label, c.definition) if c.definition
                             else '%d. %s' % (i, c.label))
            desc = extras.get('env_descriptions', {}).get(stage.env)
            if not desc:
                desc = ('%sの細分の分類基準。行を追記・編集すると判定に反映される'
                        '(ラベル名: 定義 または ラベル名のみ の形式。名前から分かるものは定義省略可)。' % stage.label)
                for bc in stage.branch_children():
                    desc += ' ※「%s」の行は条件分岐が名称を参照しているため名称変更不可。' % bc.label
            ids = extras.get('env_ids', {}).get(stage.env, {})
            out.append({
                'description': desc,
                'id': ids.get('id', 'env-' + stage.env.replace('_', '-')),
                'name': stage.env,
                'value': '\n'.join(lines),
                'value_type': ids.get('value_type', 'string'),
            })
        for c in stage.branch_children():
            walk(c)
    walk(root)
    return out


# ---------------------------------------------------------------- 全体組み立て

def postorder_sub(node, stages):
    """このノード配下(自身含む)のステージを「子孫が先」の順で返す"""
    out = []

    def walk(n):
        for c in n.children:
            if c.is_branch:
                walk(c)
        out.append(stages[node_key(n)])
    walk(node)
    return out


def generate(tree_text, extras):
    root = parse_tree(tree_text)
    stages = build_stages(root, extras)

    # グループ別集約ノードのID(区分ごと)。線が各バンド内で完結するように2段集約にする
    used = {st.id for st in stages.values()} | {st.ifelse_id for st in stages.values() if st.ifelse_id}
    gagg_ids = {}
    for cat in root.children:
        if not cat.is_branch:
            continue
        suffix = stages[node_key(cat)].id.replace('llm-sub-', '').replace('llm-', '')
        gid = 'aggregator-' + suffix
        k = 2
        while gid in used:
            gid, k = 'aggregator-%s%d' % (suffix, k), k + 1
        used.add(gid)
        gagg_ids[node_key(cat)] = gid

    pos = compute_layout(root, stages, gagg_ids)

    nodes = [copy.deepcopy(n) for n in extras['scaffold_nodes']]
    for n in nodes:
        if n['id'] in pos:
            n['position'] = place(pos, n['id'])
            n['positionAbsolute'] = place(pos, n['id'])
    order = postorder(root, stages)

    stage_nodes = []
    def emit(node):
        stage = stages[node_key(node)]
        stage_nodes.append(llm_node(stage, pos))
        if stage.ifelse_id:
            stage_nodes.append(ifelse_node(stage, stages, pos))
        for c in stage.branch_children():
            emit(c)
    emit(root)
    nodes += stage_nodes

    # グループ別集約ノード
    for cat in root.children:
        if not cat.is_branch:
            continue
        gid = gagg_ids[node_key(cat)]
        data = {
            'desc': '%s系の判定結果を1つに集約します(最も深い判定が優先)。' % cat.label,
            'output_type': 'string',
            'selected': False,
            'title': '変数集約(%s)' % cat.label,
            'type': 'variable-aggregator',
            'variables': [[st.id, 'text'] for st in postorder_sub(cat, stages)],
        }
        nodes.append(node_shell(gid, data, place(pos, gid)))

    # 経路組み立て: 実行された段の出力を浅い順に「/」で連結する
    # (未実行の段は空、更問い(「質問」で始まる出力)は経路に含めない)
    path_order = sorted(stages.values(), key=lambda st: stage_depth(st))
    tp_parts = []
    for st in path_order:
        v = st.id.replace('-', '_')
        tp_parts.append("{%% if %s and %s[:2] != '質問' %%}%s{{ %s }}{%% endif %%}"
                        % (v, v, '' if st.is_root else '/', v))
    nodes.append(node_shell('template_path', {
        'desc': '判定で通ってきた経路を「流動資産/現金・預金/預金」のように「/」で連結します。',
        'selected': False,
        'template': ''.join(tp_parts),
        'title': '経路組み立て',
        'type': 'template-transform',
        'variables': [{'value_selector': [st.id, 'text'], 'variable': st.id.replace('-', '_')}
                      for st in path_order],
    }, place(pos, 'template_path')))

    # コード確定: 経路 → 勘定科目コード(共通7桁+会社別3桁)。対応表 code_map の最長一致で決定的に引く
    code_tmpl = (
        "{% set ns = namespace(code='', p=path) %}"
        "{% for _ in range(12) %}{% if ns.code == '' and ns.p %}"
        "{% for line in map.split('\\n') %}"
        "{% if line and line.split(',')[0] == ns.p %}{% set ns.code = line.split(',')[1] %}{% endif %}"
        "{% endfor %}"
        "{% if ns.code == '' %}{% set ns.p = ns.p.rsplit('/', 1)[0] if '/' in ns.p else '' %}{% endif %}"
        "{% endif %}{% endfor %}"
        "{{ ns.code if ns.code else 'コード未登録' }}")
    nodes.append(node_shell('template_code', {
        'desc': '経路から勘定科目コード(共通7桁、下3桁まで確定していれば10桁)を対応表 code_map で決定的に確定します。未登録は「コード未登録」。',
        'selected': False,
        'template': code_tmpl,
        'title': 'コード確定',
        'type': 'template-transform',
        'variables': [{'value_selector': ['template_path', 'output'], 'variable': 'path'},
                      {'value_selector': ['env', 'code_map'], 'variable': 'map'}],
    }, place(pos, 'template_code')))

    nodes_by_id = {n['id']: n for n in nodes}
    if len(nodes_by_id) != len(nodes):
        raise SystemExit('ノードIDが重複しています')

    # 全体集約: グループ別集約の結果(実行された1つだけが値を持つ)+ 区分判定
    agg = nodes_by_id['aggregator']
    agg['data']['variables'] = ([[gagg_ids[node_key(c)], 'output'] for c in root.children if c.is_branch]
                                + [[stages[node_key(root)].id, 'text']])

    # 終了ノード: main_account は経路(スラッシュ連結)、account_code は勘定科目コード
    end_node = nodes_by_id['end']
    for o in end_node['data']['outputs']:
        if o['variable'] == 'main_account':
            o['value_selector'] = ['template_path', 'output']
    if not any(o['variable'] == 'account_code' for o in end_node['data']['outputs']):
        end_node['data']['outputs'].append({'value_selector': ['template_code', 'output'],
                                            'variable': 'account_code'})
    end_node['data']['desc'] = '契約内容サマリー(認識確認用)、仕訳または更問い、判定経路(/区切り)、勘定科目コードを出力します。'

    # エッジ
    edges = []
    def E(src, handle, tgt):
        edges.append(make_edge(nodes_by_id, src, handle, tgt))
    E('start', 'source', 'doc-extractor')
    E('doc-extractor', 'source', 'template-join')
    E('template-join', 'source', 'if-else-read')
    E('if-else-read', 'case-no-extract', 'llm_read')
    E('llm_read', 'source', 'aggregator_text')
    E('if-else-read', 'false', 'aggregator_text')
    E('aggregator_text', 'source', 'if-else-text')
    E('if-else-text', 'case-no-text', 'template-scan')
    E('template-scan', 'source', 'aggregator-out')
    E('if-else-text', 'false', 'llm_summary')
    E('llm_summary', 'source', 'if-else-confirm')
    E('if-else-confirm', 'case-unconfirmed', 'template-confirm')
    E('if-else-confirm', 'false', stages[node_key(root)].id)
    E('template-confirm', 'source', 'aggregator-out')
    def wire(node, sink):
        stage = stages[node_key(node)]
        if stage.ifelse_id:
            E(stage.id, 'source', stage.ifelse_id)
            for c in stage.branch_children():
                E(stage.ifelse_id, case_id_for(stages[node_key(c)]), stages[node_key(c)].id)
                # 区分の直下に入るときはグループ別集約に切り替える
                wire(c, gagg_ids[node_key(c)] if node is root else sink)
            E(stage.ifelse_id, 'false', sink)
        else:
            E(stage.id, 'source', sink)
    wire(root, 'aggregator')
    for cat in root.children:
        if cat.is_branch:
            E(gagg_ids[node_key(cat)], 'source', 'aggregator')
    E('aggregator', 'source', 'template_path')
    E('template_path', 'source', 'template_code')
    E('template_code', 'source', 'if-else-q')
    E('if-else-q', 'case-question', 'aggregator-out')
    E('if-else-q', 'false', 'llm_journal')
    E('llm_journal', 'source', 'aggregator-out')
    E('aggregator-out', 'source', 'end')

    # app 説明文
    leaves = []
    def count_leaves(n):
        for c in n.children:
            (leaves.append(c.label) if c.leaf else count_leaves(c))
    count_leaves(root)
    app = copy.deepcopy(extras['app'])
    app['description'] = (
        '契約書ファイル(PDF・画像・テキスト)を読み込み、契約の主たる勘定科目を段階的に判定して、'
        '金額なしの仕訳(借方/貸方)と確信度・誤分類時の影響度を出力するワークフロー。'
        '文字を取り出せないスキャンPDFや画像はAIが直接読み取る。初回実行は契約内容の認識確認で停止し、'
        '情報不足時は更問い(質問+回答例)を返す。分類は%dステージの段階判定で、最終ラベルは%d種類。'
        '細分の分類基準は環境変数 rules_*(%d個)で編集できる。'
        'このDSLはREADMEの分類ツリーから tools/generate_workflow.py で自動生成したもの。'
        % (len(order), len(leaves), sum(1 for st in stages.values() if st.env)))

    envs = env_vars(root, stages, extras)
    envs.append({
        'description': '経路→勘定科目コードの対応表(ツリーの[7桁][3桁]から自動生成。1行=「経路,コード」。'
                       '修正はツリー側が正で、ここでの編集は再生成までの応急対応)。',
        'id': 'env-code-map',
        'name': 'code_map',
        'value': '\n'.join(code_map_lines(root)),
        'value_type': 'string',
    })

    return {
        'app': app,
        'kind': 'app',
        'version': '0.1.5',
        'workflow': {
            'conversation_variables': extras.get('conversation_variables', []),
            'environment_variables': envs,
            'features': copy.deepcopy(extras['features']),
            'graph': {'edges': edges, 'nodes': nodes, 'viewport': {'x': 0, 'y': 0, 'zoom': 0.7}},
        },
    }


def compute_layout_front():
    """3形式共通の入り口(読み取り〜認識確認〜仕訳の流れ分析〜更問いチェック)のレイアウト"""
    pos = {}
    pos['start'] = (colx(0), SCAF_Y)
    pos['doc-extractor'] = (colx(1), SCAF_Y)
    pos['template-plain'] = (colx(2), SCAF_Y)
    pos['if-else-read'] = (colx(3), SCAF_Y)
    pos['llm_read'] = (colx(4), TOP_Y)
    pos['template-join-read'] = (colx(5), TOP_Y)
    pos['save-text-read'] = (colx(6), TOP_Y)
    pos['template-join'] = (colx(4), SCAF_Y)
    pos['save-text'] = (colx(5), SCAF_Y)
    pos['if-else-att'] = (colx(6), SCAF_Y)
    pos['llm_summary'] = (colx(7), TOP_Y)
    pos['save-summary'] = (colx(8), TOP_Y)
    pos['env_check'] = (colx(9), TOP_Y)
    pos['answer-confirm'] = (colx(10), TOP_Y)
    pos['llm_journal'] = (colx(7), SCAF_Y)
    pos['if-else-q'] = (colx(8), SCAF_Y)
    pos['answer-q'] = (colx(11), TOP_Y)
    # 自己学習(learn=True のときだけ使われる。上部の専用レーンでどの形式とも重ならない)
    pos['if-else-learn'] = (colx(7), LEARN_Y)
    pos['code_pagecases'] = (colx(8), LEARN_Y)
    pos['kr_cases'] = (colx(9), LEARN_Y)
    pos['learn_gate'] = (colx(10), LEARN_Y)
    pos['llm_case'] = (colx(11), LEARN_Y)
    pos['if-else-learn-set'] = (colx(12), LEARN_Y)
    pos['code_case_body'] = (colx(13), LEARN_Y)
    pos['http_save_case'] = (colx(14), LEARN_Y)
    pos['answer-learned'] = (colx(15), LEARN_Y)
    pos['answer-nolearn'] = (colx(13), LEARN_Y - 150)
    return pos


def make_edge_chat(nodes_by_id, src, handle, tgt):
    """チャット版のエッジ(参考チャットフローと同じ isInLoop 形式)"""
    return {
        'data': {'isInLoop': False,
                 'sourceType': nodes_by_id[src]['data']['type'],
                 'targetType': nodes_by_id[tgt]['data']['type']},
        'id': '%s-%s-%s-target' % (src, handle, tgt),
        'source': src, 'sourceHandle': handle,
        'target': tgt, 'targetHandle': 'target',
        'type': 'custom', 'zIndex': 0,
    }


def set_llm_model(dsl, provider=None, name=None):
    """生成済みDSLの全LLMノードのモデルを差し替える。

    Difyはモデルをノード単位で保存するため、インポート先に無いプロバイダー/モデル名の
    DSLを取り込むと、キャンバス上でノードを1つずつ選び直すことになる。
    生成時に実際に使うモデルを書き込んでおけば、インポートしてそのまま動く。
    provider はDifyの内部名(例: openai / azure_openai / langgenius/openai/openai)。
    確実なのは、そのモデルで動いている既存アプリをDSLエクスポートして
    model: の provider / name を写すこと。"""
    n = 0
    for node in dsl['workflow']['graph']['nodes']:
        model = node.get('data', {}).get('model')
        if node.get('data', {}).get('type') == 'llm' and isinstance(model, dict):
            if provider:
                model['provider'] = provider
            if name:
                model['name'] = name
            n += 1
    return n


def main():
    ap = argparse.ArgumentParser(description='READMEの分類ツリーからDifyワークフローYAMLを生成')
    ap.add_argument('-t', '--tree', default=os.path.join(ROOT, '分類ツリー.md'),
                    help='ツリーを含むファイル(既定: 分類ツリー.md)')
    ap.add_argument('-x', '--extras', default=os.path.join(ROOT, 'tools', 'workflow_extras.yml'))
    ap.add_argument('-o', '--output', default=os.path.join(ROOT, 'contract-account-classification.yml'))
    ap.add_argument('--provider', default='langgenius/azure_openai/azure_openai',
                    help='全LLMノードに設定するモデルプロバイダー(例: openai / azure_openai)。'
                         '既存アプリのDSLエクスポートの model: provider を写すのが確実')
    ap.add_argument('--model', default='GPT-4o',
                    help='全LLMノードに設定するモデル名(例: gpt-4o)')
    ap.add_argument('--learn', action='store_true',
                    help='チャット3形式に自己学習(「正解:」返信で判定事例カードを作り、次回の判定前に似た事例を参考にする)を組み込む')
    ap.add_argument('--learn-mode', choices=['env', 'kb'], default='env',
                    help='自己学習の事例の置き場。env(既定): 環境変数 learned_cases に⑤の 判定事例.txt を貼る(ナレッジ・APIキー不要)。'
                         'kb: Difyの事例ナレッジ(検索ノード+自動保存。ナレッジの作成とAPIキーが必要)')
    ap.add_argument('--learn-dataset-id', default='',
                    help='自己学習: 事例ナレッジのID(ナレッジURLの /datasets/ のあとの英数字)。'
                         '「類似事例の検索」ノードに選択済みで入り、環境変数 case_dataset_id にも書き込む')
    ap.add_argument('--learn-base-url', default='',
                    help='自己学習: 環境変数 dify_base_url に書き込む値(…/v1)')
    ap.add_argument('--learn-dataset-key', default='',
                    help='自己学習: 環境変数 dataset_api_key に書き込む値(dataset-…)。'
                         'DSLファイルに平文で入るため、ファイルの共有先に注意')
    args = ap.parse_args()

    extras = miniyaml.load(open(args.extras, encoding='utf-8').read())
    tree_text = open(args.tree, encoding='utf-8').read()
    learn_cfg = {'mode': args.learn_mode, 'base_url': args.learn_base_url, 'dataset_key': args.learn_dataset_key,
                 'dataset_id': args.learn_dataset_id}
    for style, builder, out in [('フォーム版(従来)', generate, args.output),
                                ('ツリー判定版', generate_tree, args.output.replace('.yml', '-tree.yml')),
                                ('コード2段選択版', generate_flat, args.output.replace('.yml', '-flat.yml')),
                                ('コード一発選択版', generate_pick, args.output.replace('.yml', '-pick.yml'))]:
        if builder in (generate_flat, generate_pick) and not codes7_lines(parse_tree(tree_text)):
            sys.stderr.write('%sはスキップ: ツリーに [7桁] のコードが無いため'
                             '(コード付きのツリーなら %s に生成されます)\n' % (style, out))
            continue
        d = (builder(tree_text, extras, args.learn, learn_cfg)
             if builder is not generate else builder(tree_text, extras))
        if args.provider or args.model:
            n = set_llm_model(d, args.provider or None, args.model or None)
            sys.stderr.write('%s: LLMノード %d個のモデルを %s / %s に設定\n'
                             % (style, n, args.provider or '(変更なし)', args.model or '(変更なし)'))
        with open(out, 'w', encoding='utf-8') as f:
            f.write(miniyaml.dump(d))
        g = d['workflow']['graph']
        sys.stderr.write('generated %s: %d nodes / %d edges / %d env vars\n'
                         % (out, len(g['nodes']), len(g['edges']),
                            len(d['workflow']['environment_variables'])))


if __name__ == '__main__':
    main()
