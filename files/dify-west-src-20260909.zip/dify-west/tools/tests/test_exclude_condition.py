#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""絞り込みの条件による除外のテスト。

条件を指定したときだけ「除外:」が適用されること、検算が「元=適用後+除外」で
全数一致すること、反映(10桁)でも対応する科目が落ちて照合が通ることを確かめる。
"""
import importlib.util
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
spec = importlib.util.spec_from_file_location('chk', os.path.join(ROOT, 'ツリー検査.py'))
chk = importlib.util.module_from_spec(spec)
spec.loader.exec_module(chk)

ok = ng = 0


def check(name, cond, detail=''):
    global ok, ng
    if cond:
        ok += 1
        print('  [PASS] %s' % name)
    else:
        ng += 1
        print('  [FAIL] %s  %s' % (name, detail))


T7 = '''区分判定(1段目)
├─ 資産
│   └─ 流動資産
│       ├─ 現金                     [1010001]
│       ├─ 預金                     [1010003]
│       └─ 仮払金                   [1010015]
└─ 負債
    └─ 流動負債
        ├─ 買掛金                   [2010002]
        └─ 仮受金                   [2010011]
'''
T10 = '''区分判定(1段目)
├─ 資産
│   └─ 流動資産
│       ├─ 現金                     [1010001001]
│       ├─ 預金
│       │   ├─ 普通預金             [1010003001]
│       │   └─ 当座預金             [1010003002]
│       └─ 仮払金                   [1010015001]
└─ 負債
    └─ 流動負債
        ├─ 買掛金                   [2010002001]
        └─ 仮受金
            ├─ 仮受金A              [2010011001]
            └─ 仮受金B              [2010011002]
'''
OPS = '除外: 仮払金 [1010015]\n除外: 仮受金 [2010011]\n昇格: 預金 [1010003]'


def apply(reply, allow):
    root, _ = chk.parse(T7)
    orig, _ = chk.parse(T7)
    ops, notes, bad = chk.parse_ops(reply)
    applied, errs, excluded = chk.apply_ops(root, ops, allow_exclude=allow)
    return root, orig, applied, errs, excluded


# 1. 条件なし → 除外はエラー、昇格だけ適用
root, orig, applied, errs, excluded = apply(OPS, False)
check('条件なし: 除外は2件ともエラー',
      sum(1 for e in errs if '絞り込みの条件」を入れたときだけ' in e) == 2, str(errs))
check('条件なし: 昇格は適用される', any('昇格: 預金' in a for a in applied))
check('条件なし: 何も除外されない', excluded == [])
vok, _, _ = chk.verify_tree(orig, root)
check('条件なし: コードは全部残る', vok)

# 2. 条件あり → 除外が適用され、元=適用後+除外
root, orig, applied, errs, excluded = apply(OPS, True)
check('条件あり: エラーなし', errs == [], str(errs))
check('条件あり: 2科目を除外', sorted(c for _, c in excluded) == ['1010015', '2010011'],
      str(excluded))
vok, vbad, vsum = chk.verify_tree(orig, root, excluded_codes=[c for _, c in excluded])
check('検算: 元=適用後+除外で全数一致', vok and any('元 = 適用後 + 除外' in x for x in vsum),
      str(vbad[:2] or vsum))
check('ツリーから消えている',
      all(n.label not in ('仮払金', '仮受金') for n in chk._all(root)))

# 3. 除外リストに無いコードが消えたら検出する
root2, _ = chk.parse(T7)
root2.children[0].children[0].children = []  # 資産/流動資産 の中身を勝手に消す
vok2, vbad2, _ = chk.verify_tree(orig, root2, excluded_codes=['1010015'])
check('除外以外の欠けはエラーのまま', not vok2 and any('消えています' in b for b in vbad2))

# 4. 反映: 除外した7桁に対応する10桁が落ち、照合が通る
b_root, _, _, _, excluded = apply(OPS, True)[0], None, None, None, apply(OPS, True)[4]
a_root, _ = chk.parse(T10)
merged, rep = chk.merge_apply(b_root, a_root, excluded_codes=[c for _, c in excluded])
dropped = sorted(c for c, _ in rep['dropped'])
check('反映: 対応する10桁3科目を落とす',
      dropped == ['1010015001', '2010011001', '2010011002'], str(dropped))
mok, mbad, msum = chk.verify_tree(a_root, merged, excluded_codes=dropped)
check('反映の検算: 元=反映後+除外で全数一致', mok, str(mbad[:2]))
check('反映後に除外科目が無い',
      all(n.label not in ('仮払金', '仮受金A', '仮受金B') for n in chk._all(merged)))

# 5. 枝ごと除外(親/ラベル指定)
root3, _ = chk.parse(T10)
orig3, _ = chk.parse(T10)
ops3, _, _ = chk.parse_ops('除外: 流動負債/仮受金')
applied3, errs3, excluded3 = chk.apply_ops(root3, ops3, allow_exclude=True)
check('枝ごと除外: 配下2科目をまとめて除外',
      sorted(c for _, c in excluded3) == ['2010011001', '2010011002'], str(excluded3) + str(errs3))

# 6. カード: 条件があるときだけ除外の案内が入る
cards_no = chk.make_cards(chk.parse(T7)[0])
cards_yes = chk.make_cards(chk.parse(T7)[0], condition='相手勘定が現金になりうる科目だけを残す')
check('カード: 条件なしは除外の案内なし', '除外:' not in cards_no.split('確認してほしいこと')[1][:400]
      and '「昇格:」「指摘:」の行だけ' in cards_no)
check('カード: 条件ありは除外の案内あり',
      '【条件】相手勘定が現金になりうる' in cards_yes and '「除外:」「昇格:」「指摘:」' in cards_yes)

print('\n絞り込み条件のテスト 合計 %d件 / 成功 %d件 / 失敗 %d件' % (ok + ng, ok, ng))
sys.exit(1 if ng else 0)
