#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""チャット版DSLの「ファイルの入り方・読み方」が、動作実績のある社内チャットフロー
(契約仕訳アシスタント)のエクスポートと同一構成になっていることを機械照合する。
あわせて、共通の前段(読み取り〜仕訳の流れ分析〜更問いチェック)が
3形式(ツリー判定/コード2段選択/コード一発選択)で同一であることも照合する。

期待値は、そのエクスポートから写した Dify の一般的な設定ブロック(業務データは含まない)。
"""
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, os.path.join(ROOT, 'tools'))
import miniyaml            # noqa: E402
import generate_workflow as gw   # noqa: E402

ok = ng = 0


def check(name, cond, detail=''):
    global ok, ng
    if cond:
        ok += 1
        print('  [PASS] %s' % name)
    else:
        ng += 1
        print('  [FAIL] %s %s' % (name, detail))


# 参考エクスポートと同一であるべき期待値(そのまま写し)
REF_FILE_UPLOAD = {
    # 拡張子は参考エクスポート+決裁書類の実態(Excel・パワポ・CSV)を意図的に追加
    'allowed_file_extensions': ['.PDF', '.TXT', '.MD', '.MARKDOWN', '.DOCX',
                                '.XLSX', '.XLS', '.PPTX', '.PPT', '.CSV',
                                '.PNG', '.JPG', '.JPEG', '.WEBP', '.GIF'],
    'allowed_file_types': ['document', 'image'],
    'allowed_file_upload_methods': ['local_file', 'remote_url'],
    'enabled': True,
    'image': {'detail': 'high', 'enabled': True, 'number_limits': 10,
              'transfer_methods': ['local_file', 'remote_url']},
    'number_limits': 10,
}
REF_DOC_EXTRACTOR = {
    'desc': 'アップロードされた契約書ファイル(PDF/テキスト/Word)から本文テキストを抽出する。画像は抽出対象外(LLMが直接読む)。',
    'is_array_file': True,
    'selected': False,
    'title': '契約書テキスト抽出',
    'type': 'document-extractor',
    'variable_selector': ['sys', 'files'],
}
REF_JOIN_TEMPLATE = ('{{ contract }}\n{% for t in new_texts %}\n\n'
                     '【アップロード書類{{ loop.index }}】\n{{ t }}\n{% endfor %}')
REF_VISION = {'configs': {'detail': 'high', 'variable_selector': ['sys', 'files']},
              'enabled': True}
REF_MEMORY = {'query_prompt_template': '{{#sys.query#}}',
              'role_prefix': {'assistant': '', 'user': ''},
              'window': {'enabled': False, 'size': 50}}
REF_ATT_CASE = {
    'case_id': 'true',
    'conditions': [{'comparison_operator': 'not empty', 'id': 'cond-files-exist',
                    'value': '', 'varType': 'array[file]',
                    'variable_selector': ['sys', 'files']}],
    'id': 'true',
    'logical_operator': 'and',
}

# 3形式の入り口一致の確認用(コード付きの最小ツリー)
TREE_CODED = '''区分判定(1段目)
├─ 資産
│   ├─ 流動資産 [1100000]: 1年以内に現金化される資産
│   │   ├─ ◆ 現金 [110]: 手元現金・小口現金
│   │   └─ ◆ 預金 [120]: 銀行預金
│   └─ ◆ 電話加入権 [1230000]
└─ 費用
    └─ 経費 [5100000]: 販売費及び一般管理費
        ├─ ◆ 通信費 [310]: 電話・ネットワーク利用料
        └─ ◆ 会議費 [320]: 会議・打合せの費用
'''


def main():
    extras = miniyaml.load(io.open(os.path.join(ROOT, 'tools', 'workflow_extras.yml'),
                                   encoding='utf-8').read())
    tree = io.open(os.path.join(ROOT, '分類ツリー.md'), encoding='utf-8').read()
    d = gw.generate_tree(tree, extras)
    g = d['workflow']['graph']
    nodes = {n['id']: n for n in g['nodes']}

    print('== アプリの形式')
    check('mode が advanced-chat(チャットフロー)', d['app']['mode'] == 'advanced-chat')
    check('DSLバージョンが参考エクスポートと同じ 0.3.0', d['version'] == '0.3.0')

    print('== ファイル受付(features.file_upload)')
    fu = d['workflow']['features']['file_upload']
    for k, v in REF_FILE_UPLOAD.items():
        if k in ('number_limits',) or (k == 'image'):
            continue     # 枚数上限のみ 3→10 に拡張(意図的な差)
        check('file_upload.%s が参考と同一' % k, fu.get(k) == v, repr(fu.get(k)))
    check('image.detail=high / enabled=true', fu['image']['detail'] == 'high' and fu['image']['enabled'] is True)

    print('== 契約書テキスト抽出(document-extractor)')
    de = nodes['doc-extractor']['data']
    for k, v in REF_DOC_EXTRACTOR.items():
        check('doc-extractor.%s が参考と同一' % k, de.get(k) == v, repr(de.get(k)))

    print('== 契約書テキスト結合と保存(会話変数)')
    tj = nodes['template-join']['data']
    check('結合テンプレートが参考と同一', tj['template'] == REF_JOIN_TEMPLATE, repr(tj['template']))
    check('結合の入力が conversation.contract_text + 抽出結果',
          [v['value_selector'] for v in tj['variables']] ==
          [['conversation', 'contract_text'], ['doc-extractor', 'text']])
    sv = nodes['save-text']['data']
    check('保存が assigner v2 / over-write / conversation.contract_text',
          sv['type'] == 'assigner' and sv['version'] == '2'
          and sv['items'][0]['operation'] == 'over-write'
          and sv['items'][0]['variable_selector'] == ['conversation', 'contract_text'])

    print('== 添付ありで分岐')
    att = nodes['if-else-att']['data']
    check('分岐条件が参考と同一(sys.files not empty)', att['cases'][0] == REF_ATT_CASE,
          repr(att['cases'][0]))

    print('== 本文を読むLLMの vision(参考: 事実抽出/仕訳の作成)')
    for nid in ('llm_read', 'llm_summary', 'llm_journal'):
        check('%s の vision ブロックが参考と同一' % nid,
              nodes[nid]['data'].get('vision') == REF_VISION,
              repr(nodes[nid]['data'].get('vision')))

    print('== 仕訳の流れ分析(3形式共通の前段)')
    jn = nodes['llm_journal']['data']
    check('llm_journal の memory が参考と同一', jn.get('memory') == REF_MEMORY)
    check('llm_journal の本文参照が conversation.contract_text',
          '{{#conversation.contract_text#}}' in jn['prompt_template'][1]['text'])
    check('llm_journal が自社視点(company_name)と会計方針を参照',
          '{{#env.company_name#}}' in jn['prompt_template'][0]['text']
          and '{{#env.accounting_policy#}}' in jn['prompt_template'][0]['text'])
    check('llm_journal が相手勘定と主目的の行を出力する指示',
          '相手勘定' in jn['prompt_template'][0]['text']
          and '主目的' in jn['prompt_template'][0]['text'])
    check('更問いチェックが llm_journal を見る',
          nodes['if-else-q']['data']['cases'][0]['conditions'][0]['variable_selector']
          == ['llm_journal', 'text'])
    check('answer-q が llm_journal の質問を返す',
          '{{#llm_journal.text#}}' in nodes['answer-q']['data']['answer'])

    print('== ツリー判定形式の結果整形(コードノード)')
    cr = nodes['code_result']['data']
    check('判定結果整形がコードノード(LLMはコードに触れない)',
          cr['type'] == 'code'
          and [v['value_selector'] for v in cr['variables']]
          == [['template_path', 'output'], ['template_code', 'output'], ['llm_journal', 'text']])
    check('answer-final は code_result.text',
          '{{#code_result.text#}}' in nodes['answer-final']['data']['answer'])

    print('== 返信(answer)とエッジ形式')
    check('answerノードが4つ(確認・質問×2・結果)',
          sorted(i for i, n in nodes.items() if n['data']['type'] == 'answer')
          == ['answer-confirm', 'answer-final', 'answer-q', 'answer-q-tree'])
    check('endノードが無い(チャットフローはanswerで返す)',
          not any(n['data']['type'] == 'end' for n in g['nodes']))
    check('エッジが参考と同じ isInLoop 形式',
          all('isInLoop' in e['data'] and 'isInIteration' not in e['data'] for e in g['edges']))

    print('== 会話変数')
    names = [v['name'] for v in d['workflow']['conversation_variables']]
    check('contract_text / contract_summary を保持', names == ['contract_text', 'contract_summary'])

    print('== 3形式の入り口が同一(コード付き最小ツリー)')
    fronts = {}
    for name, fn in (('tree', gw.generate_tree), ('flat', gw.generate_flat), ('pick', gw.generate_pick)):
        dd = fn(TREE_CODED, extras)
        by = {n['id']: n for n in dd['workflow']['graph']['nodes']}
        front = {}
        for i in gw.CHAT_FRONT_IDS + ['env_check']:
            data = dict(by[i]['data'])
            front[i] = json.dumps(data, ensure_ascii=False, sort_keys=True)
        fronts[name] = front
    for i in gw.CHAT_FRONT_IDS + ['env_check']:
        check('入り口ノード %s が3形式で同一' % i,
              fronts['tree'][i] == fronts['flat'][i] == fronts['pick'][i])

    # 参考エクスポートが手元にあれば、実物とも突き合わせる(無ければスキップ)
    ref_path = os.environ.get('REF_CHATFLOW', '')
    if ref_path and os.path.exists(ref_path):
        print('== 実物エクスポートとの直接照合')
        r = miniyaml.load(io.open(ref_path, encoding='utf-8').read())
        rn = {n['data'].get('title'): n for n in r['workflow']['graph']['nodes']}
        rd = rn['契約書テキスト抽出']['data']
        de2 = dict(de)
        check('doc-extractor が実物と一致(desc以外)',
              all(de2.get(k) == rd.get(k) for k in ('is_array_file', 'type', 'variable_selector', 'title')))
        rv = rn['仕訳の作成']['data']
        check('vision が実物と一致', nodes['llm_journal']['data']['vision'] == rv['vision'])
        check('memory が実物と一致', nodes['llm_journal']['data']['memory'] == rv['memory'])
        rfu = r['workflow']['features']['file_upload']
        check('file_upload が実物と一致(枚数上限を除く)',
              all(fu.get(k) == rfu.get(k) for k in ('allowed_file_extensions', 'allowed_file_types',
                                                    'allowed_file_upload_methods', 'enabled')))

    print('=' * 60)
    print('チャット版同一性テスト 合計 %d件 / 成功 %d件 / 失敗 %d件' % (ok + ng, ok, ng))
    sys.exit(1 if ng else 0)


if __name__ == '__main__':
    main()
