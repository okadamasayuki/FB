#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AIが1行で返してきた回答を、正しく複数の指示として読めるかの回帰テスト。

チャットAIは改行を落として1行で返すことがあり、そのとき全角コロン・全角カッコ・
箇条書き記号・番号が混ざる。どの組み合わせでも、ラベルとコードを正確に取り出せること。
"""
import importlib.util
import io
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
spec = importlib.util.spec_from_file_location('chk', os.path.join(ROOT, 'ツリー検査.py'))
chk = importlib.util.module_from_spec(spec)
spec.loader.exec_module(chk)

CASES = json.load(io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                       'oneline_cases.json'), encoding='utf-8'))
WANT = {2: ['有価証券', '貸倒引当金'], 4: ['現金', '有価証券', '貸倒引当金', '預金']}
TIMES2 = ('×2が途中', '全角×と全角数字', '2回表記', '2階層表記', '全部入り最悪ケース',
          '半角コロン・スペース区切り')

ok = ng = 0
for name, text, want in CASES:
    ops, notes, bad = chk.parse_ops(text)
    labels = [o['path'][0] if o['path'] else '' for o in ops]
    codes = [o['code'] for o in ops]
    problems = []
    if labels != WANT[want]:
        problems.append('ラベル %s' % labels)
    if not all(c and c.isdigit() and len(c) == 7 for c in codes):
        problems.append('コード %s' % codes)
    if name in TIMES2 and 2 not in [o['times'] for o in ops]:
        problems.append('段数 %s' % [o['times'] for o in ops])
    if problems:
        ng += 1
        print('  [FAIL] %-24s %s' % (name, ' / '.join(problems)))
    else:
        ok += 1
        print('  [PASS] %s' % name)

# 指示のあいだに改行がある通常の回答も、当然そのまま読めること
ops, notes, bad = chk.parse_ops('昇格: 有価証券 [1101002]\n昇格: 貸倒引当金 [1102004] ×2\n指摘: ふつうの回答')
if [o['path'][0] for o in ops] == ['有価証券', '貸倒引当金'] and len(notes) == 1:
    ok += 1
    print('  [PASS] 改行つきの通常回答')
else:
    ng += 1
    print('  [FAIL] 改行つきの通常回答')

print('\n一行回答テスト 合計 %d件 / 成功 %d件 / 失敗 %d件' % (ok + ng, ok, ng))
sys.exit(1 if ng else 0)
