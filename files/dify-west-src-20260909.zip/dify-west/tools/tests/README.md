# ツール類のテスト

生成ロジックが人に渡しても事故らない状態かどうかを確認するテストです。
追加ライブラリは不要で、リポジトリ直下から次のように実行します。

```
python3 tools/tests/test_chat_same.py          # チャット入り口が社内チャットフローと同一設定か
python3 tools/tests/test_freq_filter.py        # ①「よく使う勘定科目リスト」での絞り込み
python3 tools/tests/test_empty_branch.py       # ②の昇格で空になった分類の検出・削除
python3 tools/tests/test_exclude_condition.py  # ②「絞り込みの条件」による除外の検算
python3 tools/tests/test_oneline_reply.py      # ②のAI回答(指示リスト)の読み取り
```

| ファイル | 見ているもの |
|---|---|
| test_chat_same.py | 生成DSLのファイル受け取り・読み取り・会話設定が、動作実績のある社内チャットフローのエクスポートと一致すること。共通の前段(読み取り〜仕訳の流れ分析〜更問いチェック)が3形式(ツリー判定/コード2段選択/コード一発選択)で同一であること |
| test_freq_filter.py | よく使う科目リスト(件数N以上 / 上位N)で正しく絞れ、ずれを報告できること |
| test_empty_branch.py | 昇格で配下が空になった分類を検出して消せること、消しても科目とコードが1つも失われないこと |
| test_exclude_condition.py | 条件付き除外が「元 = 適用後 + 除外」の全数一致で検算されること |
| test_oneline_reply.py | ②のAI回答のゆらぎ(1行形式など)を正しく読めること(`oneline_cases.json` が入力) |

サンプルデータは `sample7.md`(7桁ツリー)と `oneline_cases.json` です。
