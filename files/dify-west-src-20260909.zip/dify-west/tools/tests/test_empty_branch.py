#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""昇格で配下が空になった分類の検出と削除のテスト。

空になった枝は「選んでも何も無い行き止まり」で、コードも付かないため
③に渡すと「コード未登録」になる。検出して消せること、
そして消しても勘定科目とコードは1つも失われないことを確かめる。
"""
import importlib.util
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
spec = importlib.util.spec_from_file_location('chk', os.path.join(ROOT, 'ツリー検査.py'))
chk = importlib.util.module_from_spec(spec)
spec.loader.exec_module(chk)

ok = ng = 0


def check(name, cond, detail=''):
    global ok, ng
    if cond:
        ok += 1
        print('  [PASS] %s' % name)
    else:
        ng += 1
        print('  [FAIL] %s  %s' % (name, detail))


TREE = '''区分判定(1段目)
├─ 資産
│   ├─ 中区分
│   │   └─ 小区分
│   │       ├─ 現金                     [1010001]
│   │       └─ 預金                     [1010002]
│   ├─ 無形固定資産
│   │   └─ のれん                       [1030002]
│   └─ その他資産
│       └─ 立替金                       [1010014]
└─ 費用
    └─ 経費
        └─ 通信費                       [5030002]
'''


def apply(reply):
    root, _ = chk.parse(TREE)
    orig, _ = chk.parse(TREE)
    ops, _, _ = chk.parse_ops(reply)
    applied, errs, _ = chk.apply_ops(root, ops)
    return root, orig, applied, errs


# 1. 空になっていなければ何も出ない
root, orig, applied, errs = apply('指示: なし')
check('変更なしのときは空の分類が出ない', chk.find_empty_branches(root) == [])

# 2. 配下を全部昇格させると、その分類が空として出る
root, orig, applied, errs = apply('昇格: のれん [1030002]')
empt = chk.find_empty_branches(root)
check('配下が空になった分類を検出', [chk._label_path(n)[-1] for n in empt] == ['無形固定資産'],
      str([chk._label_path(n) for n in empt]))

# 3. 一部だけ残っていれば検出しない
root, orig, applied, errs = apply('昇格: 現金 [1010001] ×2')
check('一部だけ昇格なら検出しない', chk.find_empty_branches(root) == [],
      str([chk._label_path(n) for n in chk.find_empty_branches(root)]))

# 4. 削除しても科目・コードは1つも減らない
root, orig, applied, errs = apply('昇格: のれん [1030002]')
before_codes = sorted(n.code for n in chk._all(root) if n.code)
removed = chk.drop_nodes(chk.find_empty_branches(root))
after_codes = sorted(n.code for n in chk._all(root) if n.code)
vok, vbad, vsum = chk.verify_tree(orig, root)
check('削除したのは空の分類だけ', removed == ['資産/無形固定資産'], str(removed))
check('コードは1つも減らない', before_codes == after_codes)
check('削除後も全数照合が通る', vok, str(vbad[:3]))
check('末端の数は変わらない', len(chk.leaves(orig)) == len(chk.leaves(root)))

# 5. 入れ子: 親も空になったら連鎖して消える
root, orig, applied, errs = apply('昇格: 現金 [1010001] ×2\n昇格: 預金 [1010002] ×2')
removed = chk.drop_nodes(chk.find_empty_branches(root))
vok2, _, _ = chk.verify_tree(orig, root)
check('空になった親も連鎖して削除', removed == ['資産/中区分/小区分', '資産/中区分'], str(removed))
check('連鎖削除でも全数照合が通る', vok2)

# 6. コードの付いた行は「空」とみなさない(消してはいけない)
root, _ = chk.parse('区分判定(1段目)\n├─ 資産\n│   └─ 現金                     [1010001]\n')
check('コード付きの末端は空とみなさない', chk.find_empty_branches(root) == [])
removed = chk.drop_nodes([n for n in chk._all(root)])
check('コード付きは削除できない', removed == [], str(removed))

print('\n空になった分類のテスト 合計 %d件 / 成功 %d件 / 失敗 %d件' % (ok + ng, ok, ng))
sys.exit(1 if ng else 0)
