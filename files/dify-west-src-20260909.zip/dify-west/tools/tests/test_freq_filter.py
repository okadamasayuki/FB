#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""「よく使う勘定科目リスト」での絞り込みのテスト。

リスト(A=コード/B=科目名/C=データ件数)と条件(件数N以上 / 上位N科目)から
該当コードだけのツリーが作れること、条件やコード体系のずれを正しく報告することを確かめる。
"""
import importlib.util
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
spec = importlib.util.spec_from_file_location('xl', os.path.join(ROOT, 'Excelからツリー.py'))
xl = importlib.util.module_from_spec(spec)
spec.loader.exec_module(xl)

ok = ng = 0


def check(name, cond, detail=''):
    global ok, ng
    if cond:
        ok += 1
        print('  [PASS] %s' % name)
    else:
        ng += 1
        print('  [FAIL] %s  %s' % (name, detail))


class Opt(object):
    def __init__(self, **kw):
        self.use = '○'
        self.detail_sep = '/／'
        self.code_digits = 10
        self.split = 7
        self.sep = '／'
        self.root = '区分判定'
        self.start_row = 0
        self.exclude = []
        self.freq_entries = None
        self.freq_min = 0
        self.freq_top = 0
        self.__dict__.update(kw)


MASTER = [['区分1', '区分2', '明細', 'コード', '利用区分'],
          ['資産', '流動資産', '現金', '1010001001', '○'],
          ['資産', '流動資産', '預金', '1010003001', '○'],
          ['資産', '流動資産', '売掛金', '1010005001', '○'],
          ['資産', '有形固定資産', '建物', '1020001001', '○'],
          ['費用', '経費', '通信費', '5030002001', '○'],
          ['費用', '経費', '交際費', '5030012001', '○']]
COLS = {'l1': 0, 'l2': 1, 'l3': 2, 'code': 3, 'use': 4}


def run(entries, fmin=0, ftop=0):
    return xl.convert_rows(MASTER, COLS, Opt(freq_entries=entries, freq_min=fmin, freq_top=ftop))


# 1. リストの読み取り(見出し・カンマ・全角数字)
rows = [['勘定科目コード', '勘定科目名', 'データ件数'],
        ['1010001001', '資産/流動資産/現金', '1,234'],
        ['１０１０００３００１', '資産/流動資産/預金', '８００'],
        ['5030002001', '費用/経費/通信費', '50'],
        ['', '空行', ''],
        ['5030012001', '費用/経費/交際費', '10']]
entries = xl.read_freq_rows(rows)
check('見出し・空行を飛ばして読める', len(entries) == 4, str(entries))
check('カンマ付き件数を読める', entries[0][2] == 1234)
check('全角数字のコード・件数を読める', entries[1] == ('1010003001', '資産/流動資産/預金', 800), str(entries[1]))

# 2. 条件なし = リスト全部
res = run(entries)
codes = sorted(c for _, c in res['records'])
check('条件なしはリストの4科目', codes == ['1010001001', '1010003001', '5030002001', '5030012001'], str(codes))
check('リスト外の行数を数えている', res['freq_dropped'] == 2)

# 3. 件数N以上
res = run(entries, fmin=100)
codes = sorted(c for _, c in res['records'])
check('100件以上 → 2科目', codes == ['1010001001', '1010003001'], str(codes))

# 4. 上位N科目
res = run(entries, ftop=3)
codes = sorted(c for _, c in res['records'])
check('上位3科目', codes == ['1010001001', '1010003001', '5030002001'], str(codes))

# 5. 両方指定はAND
res = run(entries, fmin=100, ftop=1)
codes = [c for _, c in res['records']]
check('100件以上かつ上位1 → 現金だけ', codes == ['1010001001'], str(codes))

# 6. マスタに無いコードは警告
entries2 = entries + [('9999999999', '存在しない科目', 5000)]
res = run(entries2)
check('マスタに無いコードを警告', any('見つかりません' in w for w in res['warn']), str(res['warn']))

# 7. 1件も一致しなければ止まる
try:
    run([('8888888888', 'x', 10)])
    check('全滅なら ToolError', False)
except xl.ToolError as e:
    check('全滅なら ToolError', '一致する行が1行もありません' in str(e), str(e)[:60])

# 8. 同じコードが複数行 → 件数の大きい方
res = run([('1010001001', '現金', 10), ('1010001001', '現金', 500)], fmin=100)
check('重複コードは件数の大きい方を採用', [c for _, c in res['records']] == ['1010001001'])

# 9. 絞り込み無しのときは今までどおり
res = xl.convert_rows(MASTER, COLS, Opt())
check('リスト無しは全6科目', len(res['records']) == 6)
check('リスト無しでは freq の報告をしない', not res['freq_active'])

print('\nよく使う科目リストのテスト 合計 %d件 / 成功 %d件 / 失敗 %d件' % (ok + ng, ok, ng))
sys.exit(1 if ng else 0)
