#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""③ページ(ツリーからDify.html)に動画プレーヤーを埋め込む。

  python3 tools/sync_demo_player.py   → ツリーからDify.html のマーカー間を差し替え

③はビルドを持たない単一HTMLなので、tools/demo_player.css(スタイル)・tools/demo_player.js(共通エンジン)・
tools/tree_demo_script.js(③の台本)の内容を、マーカーの間にそのまま貼り込む方式。
エンジンや台本を直したら、これを実行してから build_bundle.py を実行する(④は build_eval_page.py が同じファイルを埋め込む)。
"""
import io
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PAGE = os.path.join(ROOT, 'ツリーからDify.html')
CSS_BEGIN, CSS_END = '  /* DEMO_PLAYER_CSS_BEGIN */', '  /* DEMO_PLAYER_CSS_END */'
JS_BEGIN, JS_END = '// DEMO_PLAYER_JS_BEGIN', '// DEMO_PLAYER_JS_END'


def read(name):
    return io.open(os.path.join(ROOT, 'tools', name), encoding='utf-8').read().rstrip('\n')


def splice(s, begin, end, body):
    i = s.index(begin) + len(begin)
    j = s.index(end)
    assert i <= j, 'マーカーの順序がおかしい'
    return s[:i] + '\n' + body + '\n' + s[j:]


def main():
    s = io.open(PAGE, encoding='utf-8').read()
    if CSS_BEGIN not in s:
        # 初回: 旧インライン版(動画のCSS/JS)をマーカーに置き換える
        a = '  /* ---- 動画(ページ内アニメーション): 事例ナレッジの作り方 ---- */'
        assert s.count(a) == 1
        i = s.index(a)
        j = s.index('</style>', i)
        s = s[:i] + CSS_BEGIN + '\n' + CSS_END + '\n' + s[j:]
        b = '// ============================================================ 動画: 事例ナレッジの作り方(ページ内アニメーション)'
        assert s.count(b) == 1
        i = s.index(b)
        j = s.rindex('</script>')
        s = s[:i] + JS_BEGIN + '\n' + JS_END + '\n' + s[j:]
    for tok in (CSS_BEGIN, CSS_END, JS_BEGIN, JS_END):
        assert s.count(tok) == 1, tok
    css = read('demo_player.css')
    js = read('demo_player.js') + '\n\n' + read('tree_demo_script.js')
    assert '</script' not in js.lower() and '</style' not in css.lower()
    s = splice(s, CSS_BEGIN, CSS_END, css)
    s = splice(s, JS_BEGIN, JS_END, js)
    io.open(PAGE, 'w', encoding='utf-8').write(s)
    print('synced %s (%d KB)' % (os.path.basename(PAGE), len(s.encode('utf-8')) // 1024))


if __name__ == '__main__':
    main()
