// ============================================================ 表ファイルの読み込み(①と②-2で共用)
// tools/sync_sheet_reader.py が Excelからツリー.html と 十桁定義.html のマーカー間に埋め込む(HTML側は直接編集しない)。
// 外部ライブラリなし・通信なし。zipはブラウザ標準の DecompressionStream で展開する。古い .xls(OLE2 + BIFF)も自前で読む。
// ブラウザ標準の DecompressionStream だけで zip を展開する(外部ライブラリ不要)
async function unzip(buf){
  const u8 = new Uint8Array(buf), dv = new DataView(buf);
  let eocd = -1;
  for(let i = u8.length - 22; i >= 0; i--){
    if(dv.getUint32(i, true) === 0x06054b50){ eocd = i; break; }
  }
  if(eocd < 0) throw new Err('このファイルはzip形式ではありません。.xlsx か .csv を渡してください。');
  const count = dv.getUint16(eocd + 10, true);
  let off = dv.getUint32(eocd + 16, true);
  const files = {};
  for(let k = 0; k < count; k++){
    if(dv.getUint32(off, true) !== 0x02014b50) break;
    const nlen = dv.getUint16(off + 28, true);
    const elen = dv.getUint16(off + 30, true);
    const clen = dv.getUint16(off + 32, true);
    const method = dv.getUint16(off + 10, true);
    const csize = dv.getUint32(off + 20, true);
    const lho = dv.getUint32(off + 42, true);
    const name = new TextDecoder().decode(u8.subarray(off + 46, off + 46 + nlen));
    const lnlen = dv.getUint16(lho + 26, true);
    const lelen = dv.getUint16(lho + 28, true);
    const start = lho + 30 + lnlen + lelen;
    const data = u8.subarray(start, start + csize);
    let out;
    if(method === 0){ out = data; }
    else{
      const st = new Blob([data]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
      out = new Uint8Array(await new Response(st).arrayBuffer());
    }
    files[name] = new TextDecoder().decode(out);
    off += 46 + nlen + elen + clen;
  }
  return files;
}

function Err(msg){ const e = new Error(msg); e.userFacing = true; return e; }

const XN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
const XR = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";

function xml(text){
  const d = new DOMParser().parseFromString(text, "application/xml");
  if(d.querySelector("parsererror")) throw new Err("ファイルの中身を読めませんでした(壊れている可能性があります)。");
  return d;
}

function textOf(el){
  let s = "";
  const ts = el.getElementsByTagNameNS(XN, "t");
  for(let i = 0; i < ts.length; i++) s += ts[i].textContent || "";
  return s;
}

function colIndex(ref){
  const m = /^([A-Z]+)/.exec(ref || "");
  if(!m) return -1;
  let n = 0;
  for(const ch of m[1]) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n - 1;
}

function letter(idx){
  let s = "", n = idx + 1;
  while(n > 0){ const r = (n - 1) % 26; s = String.fromCharCode(65 + r) + s; n = Math.floor((n - 1) / 26); }
  return s;
}

async function readXlsx(buf){
  const files = await unzip(buf);
  const shared = [];
  if(files["xl/sharedStrings.xml"]){
    const d = xml(files["xl/sharedStrings.xml"]);
    const sis = d.getElementsByTagNameNS(XN, "si");
    for(let i = 0; i < sis.length; i++) shared.push(textOf(sis[i]));
  }
  if(!files["xl/workbook.xml"]) throw new Err(".xlsx として読めませんでした。Excelで「.xlsx」として保存し直してください。");
  const wb = xml(files["xl/workbook.xml"]);
  const target = {};
  if(files["xl/_rels/workbook.xml.rels"]){
    const rd = xml(files["xl/_rels/workbook.xml.rels"]);
    const rs = rd.getElementsByTagName("Relationship");
    for(let i = 0; i < rs.length; i++) target[rs[i].getAttribute("Id")] = rs[i].getAttribute("Target");
  }
  const sheets = [];
  const shEls = wb.getElementsByTagNameNS(XN, "sheet");
  for(let i = 0; i < shEls.length; i++){
    const id = shEls[i].getAttributeNS(XR, "id");
    let t = target[id] || ("worksheets/sheet" + (i + 1) + ".xml");
    t = t.charAt(0) === "/" ? t.slice(1) : (t.indexOf("xl/") === 0 ? t : "xl/" + t);
    sheets.push({name: shEls[i].getAttribute("name"), part: t});
  }
  if(!sheets.length) throw new Err("シートが1枚もありません。別のファイルか確認してください。");

  function rowsOf(part){
    if(!files[part]) return [];
    const d = xml(files[part]);
    const rowEls = d.getElementsByTagNameNS(XN, "row");
    const out = [];
    for(let i = 0; i < rowEls.length; i++){
      const cs = rowEls[i].getElementsByTagNameNS(XN, "c");
      const cells = {};
      let maxc = -1, seq = 0;
      for(let j = 0; j < cs.length; j++){
        const c = cs[j];
        const ref = c.getAttribute("r"), ty = c.getAttribute("t");
        let ci = ref ? colIndex(ref) : seq;
        if(ci < 0) ci = seq;
        seq = ci + 1;
        const vs = c.getElementsByTagNameNS(XN, "v");
        let val = "";
        if(ty === "s" && vs.length) val = shared[parseInt(vs[0].textContent, 10)] || "";
        else if(ty === "inlineStr"){
          const is = c.getElementsByTagNameNS(XN, "is");
          val = is.length ? textOf(is[0]) : "";
        }
        else if(vs.length) val = vs[0].textContent || "";
        cells[ci] = val.trim();
        if(ci > maxc) maxc = ci;
      }
      const row = [];
      for(let k = 0; k <= maxc; k++) row.push(cells[k] === undefined ? "" : cells[k]);
      out.push(row);
    }
    return out;
  }

  const table = {};
  for(const s of sheets) table[s.name] = rowsOf(s.part);
  return {sheets: sheets.map(s => s.name), table: table};
}

function readCsv(text, delim){
  if(text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
  const rows = [];
  let row = [], cell = "", q = false;
  for(let i = 0; i < text.length; i++){
    const ch = text[i];
    if(q){
      if(ch === '"'){ if(text[i + 1] === '"'){ cell += '"'; i++; } else q = false; }
      else cell += ch;
    }else if(ch === '"') q = true;
    else if(ch === delim){ row.push(cell.trim()); cell = ""; }
    else if(ch === "\n"){ row.push(cell.trim()); rows.push(row); row = []; cell = ""; }
    else if(ch !== "\r") cell += ch;
  }
  if(cell !== "" || row.length){ row.push(cell.trim()); rows.push(row); }
  return rows;
}

// ============================================================ 古い形式の .xls(Excel 97-2003 = BIFF8 / Excel 5.0-95 = BIFF5 / Excel 2.x-4.0 = BIFF2-4)
// 外部ライブラリなし・通信なし。OLE2 複合ファイルから Workbook(BIFF8)/ Book(BIFF5)ストリームを取り出し、セルのレコードだけを読む。
// 文字列(共有文字列表 SST が CONTINUE レコードに分かれる場合・ふりがな付き・書式付きも)、数値(NUMBER/RK/MULRK)、
// 数式の計算結果、真偽値/エラー、日付書式(組み込み・ユーザー定義)に対応。パスワード付き(FILEPASS)は理由つきで断る。
function ErrA(msg, advice){ const e = new Err(msg); e.advice = advice; return e; }

// ---- OLE2 複合ファイル(セクタ連鎖・DIFAT・ミニストリーム)
function cfbRead(buf){
  const u8 = new Uint8Array(buf), dv = new DataView(buf);
  if(u8.length < 512) throw new Err("ファイルが小さすぎます");
  const ssz = 1 << dv.getUint16(0x1e, true), mssz = 1 << dv.getUint16(0x20, true);
  const nFat = dv.getUint32(0x2c, true), dirStart = dv.getUint32(0x30, true), cutoff = dv.getUint32(0x38, true);
  const miniFatStart = dv.getUint32(0x3c, true), difatStart = dv.getUint32(0x44, true), nDifat = dv.getUint32(0x48, true);
  const END = 0xfffffffa;   // これ以上は特殊値(DIFAT/FAT/終端/空き)
  const per = ssz / 4;
  const secOff = n => (n + 1) * ssz;
  const fatSecs = [];
  for(let i = 0; i < 109 && fatSecs.length < nFat; i++){ const s = dv.getUint32(0x4c + i * 4, true); if(s < END) fatSecs.push(s); }
  for(let ds = difatStart, g = 0; ds < END && g <= nDifat && fatSecs.length < nFat; g++){
    const base = secOff(ds);
    if(base + ssz > u8.length) break;
    for(let i = 0; i < per - 1 && fatSecs.length < nFat; i++){ const s = dv.getUint32(base + i * 4, true); if(s < END) fatSecs.push(s); }
    ds = dv.getUint32(base + (per - 1) * 4, true);
  }
  const fat = new Uint32Array(fatSecs.length * per);
  fatSecs.forEach((s, i) => {
    const base = secOff(s);
    for(let k = 0; k < per && base + k * 4 + 4 <= u8.length; k++) fat[i * per + k] = dv.getUint32(base + k * 4, true);
  });
  function chain(start, tbl){
    const out = [], seen = new Set();
    for(let s = start; s < END && s < tbl.length && !seen.has(s); s = tbl[s]){ out.push(s); seen.add(s); }
    return out;
  }
  function readChain(start){
    const secs = chain(start, fat), out = new Uint8Array(secs.length * ssz);
    secs.forEach((s, i) => { const o = secOff(s); if(o < u8.length) out.set(u8.subarray(o, Math.min(o + ssz, u8.length)), i * ssz); });
    return out;
  }
  const dir = readChain(dirStart), entries = [], u16dec = new TextDecoder("utf-16le");
  for(let o = 0; o + 128 <= dir.length; o += 128){
    const dd = new DataView(dir.buffer, dir.byteOffset + o, 128);
    const nlen = dd.getUint16(0x40, true), type = dir[o + 0x42];
    entries.push({name: nlen >= 2 ? u16dec.decode(dir.subarray(o, o + Math.min(nlen, 64) - 2)) : "", type: type,
                  left: dd.getUint32(0x44, true), right: dd.getUint32(0x48, true), child: dd.getUint32(0x4c, true),
                  start: dd.getUint32(0x74, true), size: dd.getUint32(0x78, true)});
  }
  const root = entries[0];
  if(!root || root.type !== 5) throw new Err("複合ファイルの目次(ディレクトリ)が壊れています");
  const miniFat = new Uint32Array(readChain(miniFatStart).buffer);
  const mini = readChain(root.start);
  function readStream(e){
    if(e.size < cutoff && e !== root){
      const secs = chain(e.start, miniFat), out = new Uint8Array(secs.length * mssz);
      secs.forEach((s, i) => out.set(mini.subarray(s * mssz, (s + 1) * mssz), i * mssz));
      return out.subarray(0, e.size);
    }
    return readChain(e.start).subarray(0, e.size);
  }
  function siblings(idx){   // idx から左右の枝をたどり、同じ階層の項目をすべて集める
    const out = [], stack = [idx], seen = new Set();
    while(stack.length){
      const i = stack.pop();
      if(i >= entries.length || seen.has(i) || entries[i].type === 0) continue;
      seen.add(i); out.push(entries[i]); stack.push(entries[i].left, entries[i].right);
    }
    return out;
  }
  return {entries: entries, top: siblings(root.child), readStream: readStream};
}

// ---- BIFF レコード
const XLS_DATE_FMT = [14, 15, 16, 17, 18, 19, 20, 21, 22, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 45, 46, 47, 50, 51, 52, 53, 54, 55, 56, 57, 58];
const XLS_TIME_ONLY = [18, 19, 20, 21, 45, 46, 47];
const XLS_ERR = {0: "#NULL!", 7: "#DIV/0!", 15: "#VALUE!", 23: "#REF!", 29: "#NAME?", 36: "#NUM!", 42: "#N/A"};
function xlsCodec(cp){   // BIFF5 以前の文字列のコードページ(無ければ日本語 = 932)
  const map = {866: "ibm866", 874: "windows-874", 932: "shift_jis", 936: "gbk", 949: "euc-kr", 950: "big5", 1200: "utf-16le",
               1250: "windows-1250", 1251: "windows-1251", 1252: "windows-1252", 1253: "windows-1253", 1254: "windows-1254",
               1255: "windows-1255", 1256: "windows-1256", 1257: "windows-1257", 1258: "windows-1258", 10000: "macintosh",
               10001: "shift_jis", 20932: "euc-jp", 51932: "euc-jp", 50220: "iso-2022-jp", 65001: "utf-8"};
  for(const label of [map[cp], "shift_jis"]){ if(label){ try{ return new TextDecoder(label); }catch(e){} } }
  return new TextDecoder("utf-8");
}
function biffRead(u8, hint){   // hint: 8 = Workbook ストリーム / 5 = Book ストリーム / 2 = 生の BIFF2-4
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength), len = u8.length;
  const u16dec = new TextDecoder("utf-16le");
  let biff = hint, codec = xlsCodec(932), date1904 = false, sst = [];
  const formats = {}, xfs = [], bounds = [], sheets = [], table = {};
  let cur = null, pending = null;
  const u16 = p => u8[p] | (u8[p + 1] << 8);
  const u32 = p => dv.getUint32(p, true);
  const latin = (p, n) => { let s = ""; for(let i = 0; i < n; i++) s += String.fromCharCode(u8[p + i]); return s; };
  const wide = (p, n) => u16dec.decode(u8.subarray(p, p + 2 * n));
  function ustr(p, w){   // BIFF8 の文字列(w = 長さの幅 1/2 バイト)→ {s, next}
    const cch = w === 1 ? u8[p] : u16(p); p += w;
    const fl = u8[p++]; let nRun = 0, cbExt = 0;
    if(fl & 8){ nRun = u16(p); p += 2; }
    if(fl & 4){ cbExt = u32(p); p += 4; }
    return {s: (fl & 1) ? wide(p, cch) : latin(p, cch), next: p + ((fl & 1) ? 2 : 1) * cch + nRun * 4 + cbExt};
  }
  function bstr(p, w){ const cch = w === 1 ? u8[p] : u16(p); p += w; return {s: codec.decode(u8.subarray(p, p + cch)), next: p + cch}; }
  const str = (p, w) => biff >= 8 ? ustr(p, w) : bstr(p, w);
  // 共有文字列表(SST)。文字列は CONTINUE レコードをまたいで分かれ、続きの先頭に1バイトのフラグが付く
  function sstParse(segs, count){
    const out = [];
    let si = 0, p = segs[0].start, end = p + segs[0].n;
    const nextSeg = () => { si++; if(si >= segs.length) return false; p = segs[si].start; end = p + segs[si].n; return true; };
    for(let k = 0; k < count; k++){
      if(end - p < 3 && !nextSeg()) break;
      const cch = u16(p); let fl = u8[p + 2]; p += 3;
      let nRun = 0, cbExt = 0;
      if(fl & 8){ nRun = u16(p); p += 2; }
      if(fl & 4){ cbExt = u32(p); p += 4; }
      let s = "", left = cch;
      while(left > 0){
        if(p >= end){ if(!nextSeg()) break; fl = u8[p++]; }
        const w = fl & 1, can = w ? Math.floor((end - p) / 2) : (end - p), take = Math.min(left, can);
        if(take <= 0){ p = end; continue; }
        s += w ? wide(p, take) : latin(p, take);
        p += w ? take * 2 : take; left -= take;
      }
      for(let skip = nRun * 4 + cbExt; skip > 0;){   // 書式の区間・ふりがな: 読み飛ばす(レコードをまたいでもフラグ無し)
        if(p >= end && !nextSeg()) break;
        const t = Math.min(skip, end - p); p += t; skip -= t;
      }
      out.push(s);
    }
    return out;
  }
  function setCell(r, c, v){
    if(!cur || r > 1048575 || c > 16383) return;
    while(cur.length <= r) cur.push([]);
    const row = cur[r];
    while(row.length <= c) row.push("");
    row[c] = v;
  }
  const rkBuf = new DataView(new ArrayBuffer(8));
  function rkNum(v){
    let x;
    if(v & 2) x = (v | 0) >> 2;
    else { rkBuf.setUint32(0, 0, true); rkBuf.setUint32(4, (v & 0xfffffffc) >>> 0, true); x = rkBuf.getFloat64(0, true); }
    return (v & 1) ? x / 100 : x;
  }
  // 書式文字列から「引用符の中・[条件]・エスケープ」を外し、日付/時刻の記号だけを見る。m は h の後・s の前なら「分」
  const cleanFmt = f => f.replace(/"[^"]*"/g, "").replace(/\[[^\]]*\]/g, "").replace(/\\./g, "").replace(/_./g, "").replace(/\*./g, "").replace(/AM\/PM|A\/P/gi, "");
  const dateOnly = c => c.replace(/h+[^a-z]*m+/gi, "").replace(/m+[^a-z]*s+/gi, "").replace(/[hs]/gi, "");
  function isDate(ifmt){
    const f = formats[ifmt];
    if(f !== undefined){ const c = cleanFmt(f); return !/general/i.test(c) && /[ymdh]/i.test(c) && !/^["A-Z;]+$/i.test(f.replace(/\s/g, "")); }
    return XLS_DATE_FMT.indexOf(ifmt) >= 0;
  }
  function dateStr(x, ifmt){
    const f = formats[ifmt], c = f !== undefined ? cleanFmt(f) : "";
    const hasDate = f !== undefined ? /[ymd]/i.test(dateOnly(c)) : XLS_TIME_ONLY.indexOf(ifmt) < 0;
    const hasTime = f !== undefined ? /[hs]/i.test(c) : (XLS_TIME_ONLY.indexOf(ifmt) >= 0 || ifmt === 22);
    let days = Math.floor(x), secs = Math.round((x - days) * 86400);
    if(secs >= 86400){ secs = 0; days++; }
    const epoch = date1904 ? Date.UTC(1904, 0, 1) : (days < 61 ? Date.UTC(1899, 11, 31) : Date.UTC(1899, 11, 30));
    const d = new Date(epoch + days * 86400000), pad = n => (n < 10 ? "0" : "") + n;
    const t = pad(Math.floor(secs / 3600)) + ":" + pad(Math.floor(secs % 3600 / 60)) + ":" + pad(secs % 60);
    if(!hasDate) return t;
    const ds = d.getUTCFullYear() + "/" + (d.getUTCMonth() + 1) + "/" + d.getUTCDate();
    return hasTime ? ds + " " + t.slice(0, 5) : ds;
  }
  function fmtNum(x, ixfe){   // 数値 → 表示文字列(日付書式なら日付。整数は指数表記にしない。小数は Excel と同じ15桁)
    if(!isFinite(x)) return "";
    const ifmt = ixfe >= 0 ? xfs[ixfe] : undefined;
    if(ifmt !== undefined && isDate(ifmt)) return dateStr(x, ifmt);
    if(ifmt !== undefined && /^"TRUE";"TRUE";"FALSE"$/i.test(formats[ifmt] || "")) return x ? "TRUE" : "FALSE";   // 真偽値を数値+書式で書くソフト向け
    if(Number.isInteger(x)) return Math.abs(x) < 1e21 ? x.toFixed(0) : String(x);
    return String(parseFloat(x.toPrecision(15)));
  }
  function openSheet(recPos){
    const b = bounds.find(x => x.pos === recPos);
    let name = (b && b.name) || ("Sheet" + (sheets.length + 1)), base = name, k = 2;
    while(table[name] !== undefined) name = base + "(" + (k++) + ")";
    cur = []; sheets.push(name); table[name] = cur;
  }
  for(let pos = 0; pos + 4 <= len;){
    const id = u16(pos), n = u16(pos + 2), p = pos + 4, recPos = pos;
    pos = p + n;
    if(pos > len) break;
    switch(id){
      case 0x0809: case 0x0009: case 0x0209: case 0x0409: {   // BOF
        if(id === 0x0009) biff = 2; else if(id === 0x0209) biff = 3; else if(id === 0x0409) biff = 4;
        else biff = u16(p) === 0x0600 ? 8 : (hint === 5 ? 5 : 8);
        const dt = u16(p + 2);
        if(dt === 0x0010 || dt === 0x0040) openSheet(recPos); else cur = null;   // ワークシート/マクロシート以外(グラフ等)は無視
        pending = null;
        break; }
      case 0x000a: cur = null; pending = null; break;   // EOF
      case 0x002f: throw new ErrA("このブックはパスワードで暗号化されています", "Excelで開いて「ファイル」→「情報」→「ブックの保護」でパスワードを外し、.xlsx で保存し直してください。");
      case 0x0042: codec = xlsCodec(u16(p)); break;   // CODEPAGE
      case 0x0022: date1904 = u16(p) === 1; break;    // DATEMODE
      case 0x0085: if(biff >= 5) bounds.push({pos: u32(p), name: str(p + 6, 1).s}); break;   // BOUNDSHEET
      case 0x00fc: {   // SST + CONTINUE
        const segs = [{start: p + 8, n: n - 8}];
        while(pos + 4 <= len && u16(pos) === 0x003c){ const cn = u16(pos + 2); segs.push({start: pos + 4, n: cn}); pos += 4 + cn; }
        sst = sstParse(segs, u32(p + 4));
        break; }
      case 0x041e: if(biff >= 5) formats[u16(p)] = str(p + 2, biff >= 8 ? 2 : 1).s; break;   // FORMAT
      case 0x00e0: if(biff >= 5) xfs.push(u16(p + 2)); break;   // XF(ifnt, ifmt, …)
      case 0x00fd: if(cur) setCell(u16(p), u16(p + 2), (sst[u32(p + 6)] || "").trim()); break;   // LABELSST
      case 0x0204: case 0x00d6: if(cur) setCell(u16(p), u16(p + 2), str(p + 6, 2).s.trim()); break;   // LABEL / RSTRING
      case 0x0004: if(cur) setCell(u16(p), u16(p + 2), bstr(p + 7, 1).s.trim()); break;   // LABEL(BIFF2)
      case 0x0203: if(cur) setCell(u16(p), u16(p + 2), fmtNum(dv.getFloat64(p + 6, true), u16(p + 4))); break;   // NUMBER
      case 0x0003: if(cur) setCell(u16(p), u16(p + 2), fmtNum(dv.getFloat64(p + 7, true), -1)); break;   // NUMBER(BIFF2)
      case 0x0002: if(cur) setCell(u16(p), u16(p + 2), String(u16(p + 7))); break;   // INTEGER(BIFF2)
      case 0x027e: if(cur) setCell(u16(p), u16(p + 2), fmtNum(rkNum(u32(p + 6)), u16(p + 4))); break;   // RK
      case 0x00bd: if(cur){   // MULRK
        const r = u16(p), c0 = u16(p + 2);
        for(let k = 0, q = p + 4; q + 6 <= p + n - 2; k++, q += 6) setCell(r, c0 + k, fmtNum(rkNum(u32(q + 2)), u16(q)));
        } break;
      case 0x0205: case 0x0005: if(cur){   // BOOLERR
        const q = id === 0x0005 ? p + 7 : p + 6;
        setCell(u16(p), u16(p + 2), u8[q + 1] ? (XLS_ERR[u8[q]] || "#ERR") : (u8[q] ? "TRUE" : "FALSE"));
        } break;
      case 0x0006: case 0x0206: case 0x0406: if(cur){   // FORMULA: 計算結果だけを使う
        const r = u16(p), c = u16(p + 2), q = biff === 2 ? p + 7 : p + 6;
        if(u16(q + 6) === 0xffff){
          const t = u8[q];
          if(t === 0) pending = {r: r, c: c};   // 文字列は次の STRING レコード
          else if(t === 1) setCell(r, c, u8[q + 2] ? "TRUE" : "FALSE");
          else if(t === 2) setCell(r, c, XLS_ERR[u8[q + 2]] || "#ERR");
          else setCell(r, c, "");
        }else setCell(r, c, fmtNum(dv.getFloat64(q, true), biff === 2 ? -1 : u16(p + 4)));
        } break;
      case 0x0207: if(cur && pending){ setCell(pending.r, pending.c, (biff >= 3 ? str(p, 2) : bstr(p, 1)).s.trim()); pending = null; } break;   // STRING
      case 0x0007: if(cur && pending){ setCell(pending.r, pending.c, bstr(p, 1).s.trim()); pending = null; } break;   // STRING(BIFF2)
    }
  }
  if(!sheets.length) throw new Err("シート(ワークシート)が1枚も見つかりませんでした");
  return {sheets: sheets, table: table};
}
function readXls(buf){
  const u8 = new Uint8Array(buf), id = u8[0] | (u8[1] << 8);
  if(id === 0x0009 || id === 0x0209 || id === 0x0409) return biffRead(u8, 2);   // OLE に入っていない Excel 2.x-4.0
  if(id === 0x0809) return biffRead(u8, 8);                                       // Workbook ストリームだけを取り出したファイル
  const cfb = cfbRead(buf);
  const find = re => cfb.top.find(e => e.type === 2 && re.test(e.name)) || cfb.entries.find(e => e.type === 2 && re.test(e.name));
  let e = find(/^workbook$/i), hint = 8;
  if(!e){ e = find(/^book$/i); hint = 5; }
  if(!e){
    if(find(/^encryptedpackage$/i)) throw new ErrA("パスワードで暗号化されたExcelファイル(.xlsx を暗号化したもの)です", "Excelで開いてパスワードを外し、.xlsx で保存し直してください。");
    if(find(/^worddocument$/i)) throw new ErrA("Wordの文書(.doc)です", "Excelのブックを入れてください。");
    if(find(/^powerpoint document$/i)) throw new ErrA("PowerPointの文書(.ppt)です", "Excelのブックを入れてください。");
    const ctl = new RegExp("[" + String.fromCharCode(1) + "-" + String.fromCharCode(8) + "]", "g");   // 名前の先頭の制御文字を外す
    const names = cfb.top.map(x => x.name.replace(ctl, "")).filter(Boolean);
    throw new Err("Officeの複合ファイルですが、Excelのブック(Workbook)が入っていません(中身: " + names.join(" / ") + ")");
  }
  return biffRead(cfb.readStream(e), hint);
}

// ============================================================ 表のプレビュー(①と②-2で共用)
// 先頭から chunk 行ずつ描き、箱(wrap)を下までスクロールしたら続きを足す。大きな表でも重くならず、全行を確認できる。
// opts: {cols: 表示する最大列数, minCols, chunk, tableClass, headClass(c), cellClass(row, c, i), rowAttr(row, i), onShown(表示ずみ行数, 全行数)}
// セルは全文を持ち、列の幅で見た目だけ省略(…)する。見出しの右端をドラッグすると列の幅を変えられる(もっと見たい列を広げられる)。
var ksPrevCss = false;
function previewEnsureCss(){
  if(ksPrevCss) return; ksPrevCss = true;
  var st = document.createElement("style");
  st.textContent =
    "table.ks-prev{table-layout:fixed;border-collapse:collapse;width:auto}"
    + "table.ks-prev th,table.ks-prev td{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:none}"
    + "table.ks-prev thead th{position:sticky;top:0;z-index:2}"
    + "table.ks-prev .ks-rz{position:absolute;top:0;right:-4px;width:8px;height:100%;cursor:col-resize;z-index:4}"
    + "table.ks-prev .ks-rz:hover{background:var(--accent,#2f6fed);opacity:.4}"
    + "body.ks-resizing{cursor:col-resize;user-select:none}";
  document.head.appendChild(st);
}
function previewTable(wrap, rows, opts){
  opts = opts || {};
  previewEnsureCss();
  const chunk = opts.chunk || 200, titleLen = opts.maxLen || 40;
  let ncol = 0;
  for(const r of rows) if(r.length > ncol) ncol = r.length;
  ncol = Math.max(opts.minCols || 0, Math.min(ncol, opts.cols || 30));
  const esc1 = v => String(v === undefined || v === null ? "" : v).replace(/&/g, "&amp;").replace(/</g, "&lt;");
  const NUMW = 48, DEFW = 150;
  let cg = '<colgroup><col style="width:' + NUMW + 'px">';
  for(let c = 0; c < ncol; c++) cg += '<col style="width:' + DEFW + 'px">';
  cg += "</colgroup>";
  let h = '<table class="ks-prev' + (opts.tableClass ? " " + opts.tableClass : "") + '">' + cg
        + '<thead><tr><th><span class="ks-rz" data-c="0"></span></th>';
  for(let c = 0; c < ncol; c++){
    const cls = opts.headClass ? opts.headClass(c) : "";
    h += "<th" + (cls ? ' class="' + cls + '"' : "") + ">" + letter(c) + '<span class="ks-rz" data-c="' + (c + 1) + '"></span></th>';
  }
  h += "</tr></thead><tbody></tbody></table>";
  wrap.innerHTML = h;
  const table = wrap.querySelector("table"), tbody = table.querySelector("tbody"), colEls = table.querySelectorAll("col");
  function fitTable(){ let w = 0; colEls.forEach(cc => { w += parseFloat(cc.style.width) || 0; }); table.style.width = w + "px"; }
  fitTable();
  let shown = 0;
  function more(){
    const end = Math.min(rows.length, shown + chunk);
    let t = "";
    for(let i = shown; i < end; i++){
      const r = rows[i] || [];
      t += "<tr" + (opts.rowAttr ? opts.rowAttr(r, i) : "") + "><th>" + (i + 1) + "</th>";
      for(let c = 0; c < ncol; c++){
        const raw = String(r[c] === undefined || r[c] === null ? "" : r[c]), cls = opts.cellClass ? opts.cellClass(r, c, i) : "";
        t += "<td" + (cls ? ' class="' + cls + '"' : "")
           + (raw.length > titleLen ? ' title="' + raw.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;") + '"' : "")
           + ">" + esc1(raw) + "</td>";
      }
      t += "</tr>";
    }
    tbody.insertAdjacentHTML("beforeend", t);
    shown = end;
    if(opts.onShown) opts.onShown(shown, rows.length);
  }
  more();
  wrap.scrollTop = 0;
  wrap.onscroll = () => { if(shown < rows.length && wrap.scrollTop + wrap.clientHeight >= wrap.scrollHeight - 80) more(); };
  // 見出しの右端をドラッグして列の幅を変える
  table.querySelectorAll(".ks-rz").forEach(function(rz){
    rz.onmousedown = function(e){
      e.preventDefault(); e.stopPropagation();
      const col = colEls[parseInt(rz.getAttribute("data-c"), 10)];
      if(!col) return;
      const startX = e.clientX, startW = parseFloat(col.style.width) || col.offsetWidth;
      document.body.classList.add("ks-resizing");
      function mv(ev){ col.style.width = Math.max(30, startW + (ev.clientX - startX)) + "px"; fitTable(); }
      function up(){ document.removeEventListener("mousemove", mv); document.removeEventListener("mouseup", up); document.body.classList.remove("ks-resizing"); }
      document.addEventListener("mousemove", mv); document.addEventListener("mouseup", up);
    };
  });
  return {more: more, count: () => shown};
}
const previewNote = (n, total) => n < total ? n + "行目まで表示(全" + total + "行)。下へスクロールすると続きが出ます" : "全" + total + "行を表示しています";

// ============================================================ ファイルの中身を見て読み分ける
// 本物の .xlsx(zip) / 古い .xls(OLE 複合ファイル、または OLE なしの Excel 2.x-4.0) / SpreadsheetML 2003(XML) / HTMLの表(システム出力の「Excel」に多い) / CSV・TSV
function sheetSniff(u8){
  if(!u8.length) return "empty";
  if(u8[0] === 0x50 && u8[1] === 0x4b) return "zip";
  if(u8[0] === 0xd0 && u8[1] === 0xcf && u8[2] === 0x11 && u8[3] === 0xe0) return "ole";
  if(u8[0] === 0x09 && u8[3] === 0x00 && ((u8[1] === 0x00 && u8[2] === 4) || ((u8[1] === 0x02 || u8[1] === 0x04) && u8[2] === 6)
     || (u8[1] === 0x08 && (u8[2] === 8 || u8[2] === 16)))) return "biff";   // BOF レコードで始まる生の BIFF ストリーム
  const head = sheetDecode(u8.subarray(0, 4096)).replace(/^﻿/, "").trim().toLowerCase();
  if(head.indexOf("urn:schemas-microsoft-com:office:spreadsheet") >= 0) return "xml2003";
  if(head.indexOf("<?xml") === 0) return "xml";
  if(head.indexOf("<!doctype html") === 0 || head.indexOf("<html") >= 0 || head.indexOf("<table") >= 0) return "html";
  return "text";
}
// 文字コード: 宣言(charset / encoding)があればそれ、無ければUTF-8、UTF-8で読めなければShift_JIS(日本語のCSV・HTML出力に多い)
function sheetDecode(u8){
  const head = new TextDecoder("utf-8").decode(u8.subarray(0, 4096));
  const m = /charset=["']?([\w-]+)|encoding=["']([\w-]+)/i.exec(head);
  const enc = m ? (m[1] || m[2]).toLowerCase() : "";
  if(enc && enc !== "utf-8" && enc !== "utf8"){ try{ return new TextDecoder(enc).decode(u8); }catch(e){} }
  try{ return new TextDecoder("utf-8", {fatal: true}).decode(u8); }
  catch(e){ try{ return new TextDecoder("shift_jis").decode(u8); }catch(e2){ return new TextDecoder("utf-8").decode(u8); } }
}
// SpreadsheetML 2003(<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet">。拡張子は .xml や .xls)
function readXml2003(text){
  const d = xml(text);
  const NS = "urn:schemas-microsoft-com:office:spreadsheet";
  const sheets = [], table = {};
  const ws = d.getElementsByTagNameNS(NS, "Worksheet");
  for(let i = 0; i < ws.length; i++){
    const name = ws[i].getAttributeNS(NS, "Name") || ("Sheet" + (i + 1));
    const rows = [];
    const rowEls = ws[i].getElementsByTagNameNS(NS, "Row");
    for(let r = 0; r < rowEls.length; r++){
      const rix = parseInt(rowEls[r].getAttributeNS(NS, "Index") || "", 10);
      if(rix > 0) while(rows.length < rix - 1) rows.push([]);
      const cells = rowEls[r].getElementsByTagNameNS(NS, "Cell");
      const row = [];
      for(let c = 0; c < cells.length; c++){
        const cix = parseInt(cells[c].getAttributeNS(NS, "Index") || "", 10);
        if(cix > 0) while(row.length < cix - 1) row.push("");
        const data = cells[c].getElementsByTagNameNS(NS, "Data")[0];
        row.push(data ? (data.textContent || "").trim() : "");
      }
      rows.push(row);
    }
    sheets.push(name); table[name] = rows;
  }
  if(!sheets.length) throw new Err("XML形式のExcelですが、シート(Worksheet)が見つかりませんでした。Excelで開いて .xlsx で保存し直してください。");
  return {sheets: sheets, table: table};
}
// HTMLの表(拡張子だけ .xls / .xlsx のシステム出力)
function readHtmlTables(text){
  const d = new DOMParser().parseFromString(text, "text/html");
  const tables = d.getElementsByTagName("table");
  if(!tables.length) throw new Err("HTML形式のファイルですが、表(table)が見つかりませんでした。Excelで開いて .xlsx で保存し直してください。");
  const sheets = [], table = {};
  for(let t = 0; t < tables.length; t++){
    const name = "表" + (t + 1);
    const rows = [];
    const trs = tables[t].getElementsByTagName("tr");
    for(let r = 0; r < trs.length; r++){
      const cells = trs[r].querySelectorAll("td,th");
      const row = [];
      for(let c = 0; c < cells.length; c++) row.push((cells[c].textContent || "").replace(/\s+/g, " ").trim());
      rows.push(row);
    }
    sheets.push(name); table[name] = rows;
  }
  return {sheets: sheets, table: table};
}
// File を読んで {sheets, table, kind} にする。読めない形式は、何のファイルだったかと直し方を書いた Err を投げる
async function readSpreadsheet(file){
  const buf = await file.arrayBuffer();
  const u8 = new Uint8Array(buf);
  const kind = sheetSniff(u8);
  const low = (file.name || "").toLowerCase();
  const ext = (low.match(/\.[a-z0-9]+$/) || [""])[0];
  const size = file.size + "バイト";
  if(kind === "empty") throw new Err("中身が空(0バイト)でした。OneDrive・SharePointのオンライン専用ファイルなら、いったんPCに保存(このデバイス上に常に保持)してから入れてください。");
  if(kind === "zip"){ const r = await readXlsx(buf); return {sheets: r.sheets, table: r.table, kind: "xlsx"}; }
  if(kind === "ole" || kind === "biff"){   // 古い形式の .xls はそのまま読む(読めなければ理由と直し方)
    let r;
    try{ r = readXls(buf); }
    catch(e){
      throw new Err("古い形式の .xls(Excel 97-2003 / 5.0-95)として読もうとしましたが、読めませんでした: " + (e && e.message ? e.message : e) + "(" + size + ")。"
        + (e && e.advice ? e.advice : "Excelで開いて「名前を付けて保存」→「Excel ブック(*.xlsx)」で保存し直してください。"));
    }
    return {sheets: r.sheets, table: r.table, kind: "xls"};
  }
  const text = sheetDecode(u8);
  if(kind === "xml2003"){ const r = readXml2003(text); return {sheets: r.sheets, table: r.table, kind: "xml"}; }
  if(kind === "html"){ const r = readHtmlTables(text); return {sheets: r.sheets, table: r.table, kind: "html"}; }
  if(kind === "xml") throw new Err("XML形式ですが、Excelの表として読めませんでした。Excelで開いて .xlsx で保存し直してください。");
  if(ext === ".xlsx" || ext === ".xlsm" || ext === ".xls"){
    throw new Err("拡張子は " + ext + " ですが、中身がExcelブック(zip形式)ではありません(" + size + "。先頭: "
      + JSON.stringify(text.slice(0, 40)) + ")。Excelで開いて「名前を付けて保存」→「Excel ブック(*.xlsx)」で保存し直してください。");
  }
  const delim = ext === ".tsv" ? "\t" : (ext === ".txt" && text.indexOf("\t") >= 0 ? "\t" : ",");
  return {sheets: ["(表)"], table: {"(表)": readCsv(text, delim)}, kind: "csv"};
}
