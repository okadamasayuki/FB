// ============================================================ ③の台本: 空の事例ナレッジの作り方 → 設定込みDSLでのインポート
// 共通エンジン(demo_player.js)の上で動く。tools/sync_demo_player.py で ツリーからDify.html に埋め込む。
var DV_ID = "3f2a9c1e-7b4d-4e2a-9c1f-0a8b7d6e5f43";
var DV_KEY = "dataset-Kx9mQ2vL8pR4tW7yB1nC3dF6";
var DV_URL_DOCS = DV_HOST + "/datasets/" + DV_ID + "/documents";
var DV_TOOL = "https://okadamasayuki.github.io/kanjo-tool/";

function scrTool3(v, done){
  var h = '<div style="padding:14px 16px;background:#f6f7f9;height:100%;overflow:hidden">'
    + '<div class="dvy-h">③ ツリーからDify(このページ)</div>'
    + '<div style="background:#fff;border:1px solid var(--line);border-radius:10px;padding:10px;font-size:12px">'
    + '<div>● コード一発選択形式(推奨) ○ ツリー判定形式 ○ コード2段選択形式</div>'
    + '<div style="margin-top:6px">☑ <b>自己学習を入れる</b></div>'
    + '<div style="margin:6px 0 0 14px;padding:8px;border:1px dashed var(--line);border-radius:8px;background:#fbfcfe"><b>設定込みでDSLを作る(任意)</b>'
    + '<div style="display:grid;grid-template-columns:120px 1fr;gap:4px 8px;align-items:center;margin-top:4px">'
    + '<span>事例ナレッジのID</span>' + dvInput("dv-lc1", v[0], "ナレッジURLの /datasets/ のあとの英数字", "min-height:26px")
    + '<span>DifyのURL(…/v1)</span>' + dvInput("dv-lc2", v[1], "https://dify.example.com/v1", "min-height:26px")
    + '<span>ナレッジAPIキー</span>' + dvInput("dv-lc3", v[2], "dataset-…", "min-height:26px") + '</div></div>'
    + '<div style="margin-top:8px"><span class="dvy-btn" id="dv-run">DSLを作る</span></div></div>';
  if(done) h += '<div style="background:#fff;border:1px solid var(--line);border-radius:10px;padding:10px;font-size:12px;margin-top:8px"><b>2. 結果</b>'
    + '<div style="color:#0f6b3f">✅ 自己学習つきで生成しました(設定込み)。ナレッジの選択と環境変数は書き込み済みなので、インポート後の設定は不要です</div>'
    + '<div style="margin-top:6px"><span class="dvy-btn ghost" id="dv-save">DSL(YAML)を保存</span> <span style="color:#666">→ contract-account-classification-pick.yml</span></div></div>';
  return h + '</div>';
}
function scrOrch(published){
  function node(x, y, t, cls, id){
    return '<div class="dvy-node' + (cls ? " " + cls : "") + '"' + (id ? ' id="' + id + '"' : "") + ' style="left:' + x + 'px;top:' + y + 'px">' + t + '</div>';
  }
  var h = dvNav("スタジオ")
    + '<div style="height:36px;background:#fff;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:8px;padding:0 12px;font-size:12px">'
    + '<b>契約書 相手勘定判定(一発選択)</b><span style="color:#888">オーケストレート</span>'
    + '<span style="margin-left:auto;font-size:11px;color:#0f6b3f" id="dv-checklist">✓ チェックリスト: 問題なし</span>'
    + '<span class="dvy-btn" id="dv-publish">公開する</span></div>'
    + '<div style="position:relative;height:calc(100% - 80px);background:#f3f5f8;background-image:radial-gradient(#d8dce1 1px,transparent 1px);background-size:16px 16px">'
    + node(14, 30, "▶ 開始") + node(150, 30, "本文テキスト抽出") + node(286, 30, "読み取り確認")
    + node(14, 110, '類似事例の検索<br><span>knowledge-retrieval</span>', "kr", "dv-krnode")
    + node(150, 110, "仕訳の流れ分析") + node(286, 110, "条件分岐(更問い)")
    + node(14, 190, "コードの確定") + node(150, 190, "結果の整形") + node(286, 190, "回答")
    + '<div class="dvy-panel"><b>類似事例の検索</b><div style="color:#666;margin:4px 0">ナレッジ</div>'
    + '<div id="dv-kbchip"><span class="dvy-chip">📚 判定事例</span></div>'
    + '<div style="color:#666;margin:8px 0 2px">クエリ変数</div><span class="dvy-chip">conversation.contract_summary</span>'
    + '<div style="color:#666;margin:8px 0 2px">検索設定</div><span style="font-size:11px">上位 4 件</span></div>'
    + '</div>';
  if(published) h += '<div class="dvy-toast">✅ 公開しました(環境変数 dify_base_url / dataset_api_key / case_dataset_id も設定済み)</div>';
  return h;
}
var DV_CHAT_MSGS = [
  {html: '🎯 一言でいうと: 事務所を借りて毎月賃料を払う契約です。<br><b>相手勘定(科目)</b>: 賃借料 / <b>確定コード</b>: 5030001001<br><span style="color:#666">…(判定経路・理由・根拠の仕訳)</span>'},
  {me: true, id: "dv-teach", html: '正解: 賃借料 [5030001001]'},
  {id: "dv-saved", html: '✅ 正解を事例ナレッジに保存しました(HTTP 200)。次回から、似た契約の判定前に自動で検索して参考にします。<br><span style="color:#666">【判定事例】契約の種類: 事務所賃貸借契約 / 当社の立場: 借主 / 決め手: …</span>'}
];

var DV_STEPS = [
  {title: "Difyを開いて、上のメニューの「ナレッジ」へ",
   body: "アプリを作る「スタジオ」ではなく、隣の「ナレッジ」が保管庫(事例ナレッジ)の置き場所です。",
   url: DV_HOST + "/apps", t: 4200,
   render: function(){ return scrStudio({apps: [{name: "契約書 相手勘定判定(一発選択)"}, {name: "契約書 相手勘定判定(ツリー)"}]}); },
   act: function(){ dvCur(20, 50); dvCurTo("dv-tab-kb", 400); dvClick(1200); }},
  {title: "「+ ナレッジを作成」を押す",
   body: "ナレッジ一覧の左上にあります。", url: DV_HOST + "/datasets", t: 3800,
   render: function(){ return scrKbList([]); },
   act: function(){ dvCurTo("dv-kbcreate", 300); dvClick(1100); }},
  {title: "ファイルは入れない。画面の下の小さなリンクを押す",
   body: "ここが見落としポイント。ファイルのアップロード画面が出ますが、何も入れずに下の「空のナレッジベースを作成したいです」を押します。",
   url: DV_HOST + "/datasets/create", t: 5800,
   render: function(){ return scrKbCreate(false, ""); },
   act: function(){ dvHl("dv-emptylink", 200); dvCurTo("dv-emptylink", 700); dvClick(1700); }},
  {title: "名前を付ける(例: 判定事例)",
   body: "中身は空のままで大丈夫です。名前は分かればなんでも構いません。",
   url: DV_HOST + "/datasets/create", t: 4600,
   render: function(){ return scrKbCreate(true, ""); },
   act: function(){ dvCurTo("dv-kbname", 300); dvType("dv-kbname", "判定事例", 900, 130); }},
  {title: "「作成」を押す",
   body: "これで空の事例ナレッジができます。", url: DV_HOST + "/datasets/create", t: 3600,
   render: function(){ return scrKbCreate(true, "判定事例"); },
   act: function(){ dvCurTo("dv-kbok", 300); dvClick(1100); }},
  {title: "できました。ドキュメント0件で正常です",
   body: "カードは、使い始めてから「正解: ◯◯」と返信するたびに1枚ずつ増えます。いま空なのは想定どおりです。",
   url: DV_URL_DOCS, t: 5200,
   render: function(){ return scrKbDocs("判定事例", []); },
   act: function(){ dvCur(50, 55); }},
  {title: "アドレスバーに注目: /datasets/ の後ろが「事例ナレッジのID」",
   body: "この英数字はDifyが自動で付けた住所です(自分で決める番号ではありません)。アプリはこの住所でナレッジを探しに行きます。",
   url: DV_URL_DOCS, hl: DV_ID, t: 6400,
   render: function(){ return scrKbDocs("判定事例", []); },
   act: function(){ dvCurTo("dv-urlmark", 400); }},
  {title: "IDを選択してコピー",
   body: "③の「事例ナレッジのID」欄に貼ります。ハイフンも含めて全部です。",
   url: DV_URL_DOCS, hl: DV_ID, t: 5000,
   render: function(){ return scrKbDocs("判定事例", []); },
   act: function(){ dvCurTo("dv-urlmark", 200); dvClick(900);
     dvLater(function(){ dvUrlSet(DV_URL_DOCS, DV_ID, "コピーしました"); }, 1300); }},
  {title: "次はナレッジ用のAPIキー。「サービスAPI」を押す(場所は版で違う)",
   body: "アプリのAPIキー(app-…)とは別に、ナレッジ側のキー(dataset-…)が要ります。1.12以降はナレッジ一覧の右上「サービスAPI」、1.9〜1.11はナレッジを開いた左メニューの一番下「サービスAPI」、1.8以前はナレッジ一覧の左上のタブ「API ACCESS」。どれも無ければ権限(ナレッジ管理者ロール)が原因なので管理者へ。",
   url: DV_HOST + "/datasets", t: 8000,
   render: function(){ return scrKbList(["判定事例"]); },
   act: function(){ dvCurTo("dv-svcapi", 300); dvClick(1100);
     dvLater(function(){ $("dvScreen").innerHTML = scrKbList(["判定事例"], {card: true}); dvHl("dv-apicard", 100); }, 1500); }},
  {title: "カードの「サービスAPIエンドポイント」のURLも控える",
   body: "…/v1 で終わるこのURLが、③の「DifyのURL」欄に入れる値です(④⑤の接続設定でも同じ)。緑の「サービス中」は、ナレッジのAPIが使える状態という印です。",
   url: DV_HOST + "/datasets", t: 5400,
   render: function(){ return scrKbList(["判定事例"], {card: true}); },
   act: function(){ dvHl("dv-apiurl", 300); dvCurTo("dv-apiurl", 500); }},
  {title: "「APIキー」→「新しいシークレットキーを作成」",
   body: "キーの一覧が開きます。まだ無ければ「新しいシークレットキーを作成」。範囲を聞かれたら「特定のナレッジベース」で「判定事例」だけを選ぶのが安全です(社内の他のナレッジには触れないキーになります。古い版は範囲が選べず全ナレッジ共通)。ボタンが灰色、または押すと「You don't have the permission to access the requested resource…」と出るときは権限不足です。作成できるのはオーナー/管理者なので頼んでください(一覧を見るだけなら誰でも可)。",
   url: DV_HOST + "/datasets", t: 6400,
   render: function(){ return scrApi(true, false); },
   act: function(){ dvCurTo("dv-newkey", 400); dvClick(1500); }},
  {title: "dataset- で始まるキーをコピー(app- とは別物)",
   body: "③の「ナレッジAPIキー」欄に貼ります。キーは他人に見せないでください(このキーを入れて作ったDSLファイルも同様です)。キーが作れない場合はこの欄を空のままで構いません(⑤の仮ナレッジモードで学習できます)。",
   url: DV_HOST + "/datasets", t: 5600,
   render: function(){ return scrApi(true, true); },
   act: function(){ dvHl("dv-keytext", 300); dvCurTo("dv-keytext", 500); dvClick(1400); }},
  {title: "③に戻って「自己学習を入れる」にチェック → 3つを貼る",
   body: "「設定込みでDSLを作る」欄に、コピーしたID・URL・キーを貼ります(キーが無ければ空欄のままでOK)。",
   url: DV_TOOL, t: 7400,
   render: function(){ return scrTool3(["", "", ""], false); },
   act: function(){
     dvCurTo("dv-lc1", 300); dvType("dv-lc1", DV_ID, 800, 18);
     dvCurTo("dv-lc2", 2400); dvType("dv-lc2", DV_HOST + "/v1", 2700, 28);
     dvCurTo("dv-lc3", 3900); dvType("dv-lc3", DV_KEY, 4200, 28);
   }},
  {title: "「DSLを作る」→ DSL(YAML)を保存",
   body: "ナレッジの選択と環境変数3つが書き込まれたDSLファイルができます。",
   url: DV_TOOL, t: 5400,
   render: function(){ return scrTool3([DV_ID, DV_HOST + "/v1", DV_KEY], true); },
   act: function(){ dvCurTo("dv-run", 300); dvClick(1100); dvCurTo("dv-save", 2300); dvClick(3100); }},
  {title: "Difyのスタジオで「アプリを作成」→「DSLファイルをインポート」",
   body: "ツリーを直して作り替えるときも同じ手順です(古いアプリは残るので、確認してから消せます)。",
   url: DV_HOST + "/apps", t: 5000,
   render: function(){ return scrStudio({menu: true, apps: [{name: "契約書 相手勘定判定(一発選択)"}, {name: "契約書 相手勘定判定(ツリー)"}]}); },
   act: function(){ dvCurTo("dv-import", 400); dvClick(1400); }},
  {title: "保存したDSLファイルを選んで「インポート」",
   body: "", url: DV_HOST + "/apps", t: 4000,
   render: function(){ return scrStudio({importFile: "contract-account-classification-pick.yml", importNote: "(③で保存したファイル)",
                                          apps: [{name: "契約書 相手勘定判定(一発選択)"}, {name: "契約書 相手勘定判定(ツリー)"}]}); },
   act: function(){ dvCurTo("dv-importbtn", 400); dvClick(1400); }},
  {title: "「類似事例の検索」には「判定事例」が選択済み",
   body: "公開前チェックリストの「ナレッジベースは必須です」は出ません。環境変数3つも入力済みです。",
   url: DV_HOST + "/app/2b7e4c9a/workflow", t: 6400,
   render: function(){ return scrOrch(false); },
   act: function(){ dvHl("dv-krnode", 300); dvCurTo("dv-krnode", 400); dvHl("dv-kbchip", 1000); dvHl("dv-checklist", 1700); }},
  {title: "「公開する」で完了",
   body: "これで自己学習つきのアプリが使えます。", url: DV_HOST + "/app/2b7e4c9a/workflow", t: 4800,
   render: function(){ return scrOrch(false); },
   act: function(){ dvCurTo("dv-publish", 300); dvClick(1100);
     dvLater(function(){ $("dvScreen").innerHTML = scrOrch(true); dvCurTo("dv-publish", 0); }, 1500); }},
  {title: "使い始めると、「正解: ◯◯」の返信でカードが溜まる",
   body: "判定結果に対して「正解: 科目名 [コード]」と返すと、アプリが判定事例カードを作って事例ナレッジに保存します。",
   url: DV_HOST + "/chat/2b7e4c9a", t: 6200,
   render: function(){ return scrChat(DV_CHAT_MSGS); },
   act: function(){ dvCur(60, 60); dvHl("dv-teach", 600); dvHl("dv-saved", 1900); }},
  {title: "ナレッジを見ると、カードが1枚増えている",
   body: "これが自己学習の中身です。同じ1つのナレッジを3形式のアプリで共用できます。次からは似た契約の判定前に、このカードが自動で参照されます。",
   url: DV_URL_DOCS, t: 6500,
   render: function(){ return scrKbDocs("判定事例", ["判定事例: 事務所賃貸借契約"]); },
   act: function(){ dvHl("dv-row0", 500); dvCur(50, 45); }}
];

dvSetup(DV_STEPS, {
  name: "空の事例ナレッジの作り方",
  idle: "上の「▶ 再生」で始まります。<br>Difyで空のナレッジを作る → IDとキーを控える → ③に貼って生成 → インポートして公開、までを通しで見られます。",
  capT: "ステップ一覧(右)から始めたい場面を選ぶこともできます",
  capB: "用語: 事例ナレッジ=Difyの「ナレッジ」機能に作る保管庫(アプリの外)。環境変数=アプリの中の設定欄。この動画では、その保管庫を作って住所(ID)と鍵(dataset-キー)を控え、③でアプリに書き込みます。"
});
if($("dvGo")) $("dvGo").onclick = function(){
  $("dvCard").scrollIntoView({behavior: "smooth", block: "start"});
  dvPlayFrom(0);
};
