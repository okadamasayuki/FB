// ============================================================ ブラウザで採点(④ページ固有のUI)
// コア(evXxx / EV_*)は eval_common.js にあり、ビルド時に一緒に埋め込まれる。
// このセクションだけが通信する(通信先は brUrl に入力された自社DifyのURLのみ)。
var BR_FORMATS = [["tree", "ツリー判定形式", "brKeyTree"], ["flat", "コード2段選択形式", "brKeyFlat"],
                  ["pick", "コード一発選択形式", "brKeyPick"]];
var BR_MARK = {ok: "○", ng: "×", ask: "?", error: "E", skip: "-", none: "判"};
// raw=取り込んだままの一覧 / items=ラッパーを降りた後の一覧 / amb=「フォルダ全体=1決裁」か「サブフォルダ=決裁」か判断が分かれた情報
var BR = {raw: [], items: [], cases: [], results: {}, running: false, stopFlag: false, aborters: [], excl: {},
          amb: null, rootAsCase: undefined};

async function brBuildCases(items){
  var r = await evBuildCases(items, BR.excl, {rootAsCase: BR.rootAsCase});
  BR.items = r.items;
  BR.amb = r.ambiguous;
  return r.cases;
}
// 正解の表示(「科目名 [コード]」。コードだけ・科目名だけのときはその片方)
function brExpect(c){
  return (c.expect_name + (c.expect_code ? " [" + c.expect_code + "]" : "")).trim();
}
// 結果セルの文字: 印+アプリの答え(科目 [コード])
function brCellText(r){
  return BR_MARK[r[0]] + (r[2] ? " " + r[2] : (r[0] === "ask" ? " (質問で停止)" : ""));
}

// 互換ラッパー(戻り値 [回答, エラー])。コアは evRunOne
async function brRunOne(base, key, docs, timeoutSec){
  var r = await evRunOne(base, key, docs, timeoutSec,
                         {aborters: BR.aborters, stopped: function(){ return BR.stopFlag; }});
  return [r.answer, r.err];
}

async function brIngest(items){
  BR.excl = {};
  BR.results = {};
  BR.raw = items;
  BR.rootAsCase = undefined;
  BR.cases = await brBuildCases(items);
  brRenderSummary();
  brRenderTable();
  $("brRun").disabled = !BR.cases.length;
  $("brRun").textContent = "採点を実行";
  $("brDlMd").disabled = true;
  $("brReport").style.display = "none";
  $("brProg").textContent = "";
}

async function brRebuild(){
  BR.results = {};
  BR.cases = await brBuildCases(BR.raw);
  brRenderSummary();
  brRenderTable();
  $("brRun").disabled = !BR.cases.length;
  $("brRun").textContent = "採点を実行";
}

// 「フォルダ全体=1決裁」か「サブフォルダ=決裁」か判断が分かれるときの切り替え(取り込み直後に表示)
function brAmbHtml(){
  if(!BR.amb) return "";
  // 実際に採用している読み取り方(未指定なら evBuildCases の既定: 書類入りサブフォルダが2つ以上ならサブフォルダ=決裁)
  var sub = (typeof BR.rootAsCase === "boolean") ? !BR.rootAsCase : BR.amb.nSub >= 2;
  return '<div style="margin:6px 0 0"><b>読み取り方</b>(「' + esc(BR.amb.root) + '」の直下にも、その中のサブフォルダにも書類があります): '
    + '<label style="margin-right:8px"><input type="radio" name="brRoot" value="sub"' + (sub ? " checked" : "")
    + "> サブフォルダ(" + BR.amb.nSub + "個)をそれぞれ1決裁にする(直下のファイル " + BR.amb.directDocs + "件は読み飛ばし)</label>"
    + '<label><input type="radio" name="brRoot" value="root"' + (sub ? "" : " checked")
    + "> フォルダ全体を1決裁にする(下位フォルダの書類も添付)</label></div>";
}
function brBindAmb(){
  $("brSummary").querySelectorAll('input[name="brRoot"]').forEach(function(rb){
    rb.onchange = function(){ BR.rootAsCase = rb.value === "root"; brRebuild(); };
  });
}

function brRenderSummary(){
  var cases = BR.cases;
  var used = {};
  cases.forEach(function(c){ c.docs.forEach(function(d){ used[d.name] = 1; }); });
  if(!cases.length){
    var seen = {};
    BR.items.forEach(function(it){ var e = evExt(it.rel) || "(拡張子なし)"; seen[e] = (seen[e] || 0) + 1; });
    $("brSummary").innerHTML = '<div class="warnbox">決裁が見つかりません。サブフォルダ(=1決裁)の中に決裁書類'
      + "(PDF・Word・Excel・PowerPoint・テキスト・画像)を置いてください。正解.txt は無くても判定結果だけ出せます(採点には必要)。<br>"
      + "読み取ったファイル " + BR.items.length + "件: " + Object.keys(seen).sort().map(function(e){ return e + " " + seen[e]; }).join(" / ")
      + "。対象の拡張子: " + EV_DOC_EXTS.join(" ") + "</div>" + brAmbHtml();
    brBindAmb();
    $("brOpts").style.display = "none";
    return;
  }
  var nDocs = 0, byExt = {}, noAns = 0, badAns = 0, skipped = [];
  cases.forEach(function(c){
    nDocs += c.docs.length;
    c.docs.forEach(function(d){ var e = evExt(d.name); byExt[e] = (byExt[e] || 0) + 1; });
    if(!c.has_answer) noAns++;
    else if(!c.expect_code && !c.expect_name) badAns++;
  });
  var inCase = new Set();
  cases.forEach(function(c){ c.docs.forEach(function(d){ inCase.add(d.file); }); if(c.ansFile) inCase.add(c.ansFile); });
  BR.items.forEach(function(it){ if(!inCase.has(it.file)) skipped.push(it.rel); });
  var parts = Object.keys(byExt).sort().map(function(e){ return e + " " + byExt[e]; });
  $("brSummary").innerHTML = "<b>" + cases.length + "決裁</b>(文書 " + nDocs + "ファイル: " + parts.join(" / ") + ")を読み取りました。"
    + (noAns ? ' <span style="color:#0f6b3f">正解.txt が無い決裁 ' + noAns + "件は採点せず、各形式の判定結果(科目とコード)だけ表示します。</span>" : "")
    + (badAns ? ' <span style="color:#b42318">正解.txt はあるが読めない決裁が ' + badAns + "件あります(1行目に「科目名 [10桁コード]」かコードを書いてください)。</span>" : "")
    + (skipped.length ? " 決裁に含めなかったファイル " + skipped.length + "件(" + skipped.slice(0, 5).map(esc).join(" / ") + (skipped.length > 5 ? " …" : "") + ")。" : "")
    + " まだ送信していません。「採点を実行」で開始します。" + brAmbHtml();
  brBindAmb();
  var exts = {};
  BR.items.forEach(function(it){ var e = evExt(it.rel.split("/").pop()); if(EV_DOC_EXTS.indexOf(e) >= 0) exts[e] = 1; });
  $("brExts").innerHTML = "対象の拡張子: " + Object.keys(exts).sort().map(function(e){
    return '<label style="margin-right:8px"><input type="checkbox" data-ext="' + e + '" ' + (BR.excl[e] ? "" : "checked") + "> " + e + "</label>";
  }).join("");
  $("brExts").querySelectorAll("input[data-ext]").forEach(function(cb){
    cb.onchange = function(){
      BR.excl[cb.getAttribute("data-ext")] = !cb.checked;
      brRebuild();
    };
  });
  $("brOpts").style.display = "block";
}

function brActiveFormats(){
  return BR_FORMATS.filter(function(f){ return $(f[2]).value.trim(); });
}
function brLimitedCases(){
  var lim = parseInt($("brLimit").value, 10) || 0;
  return lim > 0 ? BR.cases.slice(0, lim) : BR.cases;
}

function brRenderTable(){
  var cases = brLimitedCases();
  if(!cases.length){ $("brTableWrap").innerHTML = ""; return; }
  var fmts = brActiveFormats();
  var h = '<div class="note" style="margin:4px 0">○=正解 ×=不正解 ?=質問で停止 E=エラー 判=正解なし(判定結果だけ)。各セルにはアプリの答え(科目 [コード])も表示します</div>'
    + '<table style="border-collapse:collapse;font-size:12px;width:100%"><tr>'
    + '<th style="border:1px solid var(--line);padding:3px 6px;text-align:left">決裁</th>'
    + '<th style="border:1px solid var(--line);padding:3px 6px;text-align:left">正解</th>'
    + fmts.map(function(f){ return '<th style="border:1px solid var(--line);padding:3px 6px">' + f[1] + "</th>"; }).join("") + "</tr>";
  cases.forEach(function(c, i){
    var expect = brExpect(c);
    h += "<tr><td style=\"border:1px solid var(--line);padding:3px 6px\">" + esc(c.label) + "</td>"
      + "<td style=\"border:1px solid var(--line);padding:3px 6px\">" + esc(expect || (c.has_answer ? "(読めない)" : "(なし: 判定だけ)")) + "</td>"
      + fmts.map(function(f){
          var r = BR.results[i + "/" + f[0]];
          return '<td id="br-cell-' + i + "-" + f[0] + '" style="border:1px solid var(--line);padding:3px 6px;text-align:center"'
            + (r ? ' title="' + esc(r[1]).replace(/"/g, "&quot;") + '"' : "") + ">"
            + (r ? esc(brCellText(r)) : "") + "</td>";
        }).join("") + "</tr>";
  });
  $("brTableWrap").innerHTML = h + "</table>";
}

async function brRunAll(){
  var base = $("brUrl").value.trim().replace(/\/+$/, "");
  var fmts = brActiveFormats();
  if(!base){ $("brProg").textContent = "APIサーバー(…/v1)を入力してください。"; return; }
  if(!fmts.length){ $("brProg").textContent = "APIキーを1つ以上入力してください。"; return; }
  brSaveCfg();
  var cases = brLimitedCases();
  var timeoutSec = parseInt($("brTimeout").value, 10) || 300;
  var par = Math.max(1, Math.min(6, parseInt($("brPar").value, 10) || 3));
  var queue = [];
  cases.forEach(function(c, i){
    fmts.forEach(function(f){ if(!BR.results[i + "/" + f[0]]) queue.push([i, c, f]); });
  });
  if(!queue.length){ $("brProg").textContent = "残りのタスクはありません(結果は下の表のとおり)。"; return; }
  BR.running = true;
  BR.stopFlag = false;
  $("brRun").disabled = true;
  $("brStop").disabled = false;
  brRenderTable();
  var total = cases.length * fmts.length;
  var t0 = Date.now();
  function progress(){
    var done = Object.keys(BR.results).length;
    var sec = Math.round((Date.now() - t0) / 1000);
    $("brProg").textContent = "実行中… " + done + " / " + total + " 完了(経過 " + Math.floor(sec / 60) + "分" + (sec % 60) + "秒)"
      + (BR.stopFlag ? " — 停止中(実行中の呼び出しを打ち切っています)" : "");
  }
  progress();
  var idx = 0;
  async function worker(){
    while(!BR.stopFlag && idx < queue.length){
      var job = queue[idx++];
      var i = job[0], c = job[1], f = job[2];
      var cell = $("br-cell-" + i + "-" + f[0]);
      if(cell) cell.textContent = "…";
      var res = await brRunOne(base, $(f[2]).value.trim(), c.docs, timeoutSec);
      if(BR.stopFlag && res[1] === "stopped"){ if(cell) cell.textContent = ""; break; }
      BR.results[i + "/" + f[0]] = evGrade(res[0], res[1], c.expect_name, c.expect_code);
      if(cell){ cell.textContent = brCellText(BR.results[i + "/" + f[0]]); cell.title = BR.results[i + "/" + f[0]][1]; }
      progress();
    }
  }
  var workers = [];
  for(var w = 0; w < par; w++) workers.push(worker());
  await Promise.all(workers);
  BR.running = false;
  $("brStop").disabled = true;
  var done = Object.keys(BR.results).length;
  if(done){
    $("brDlMd").disabled = false;
    $("brReport").textContent = brBuildReport(cases, fmts);
    $("brReport").style.display = "block";
  }
  if(BR.stopFlag && done < total){
    $("brRun").disabled = false;
    $("brRun").textContent = "再開(残り " + (total - done) + ")";
    $("brProg").textContent = "停止しました: " + done + " / " + total + " 完了。「再開」で続きから回せます(ページを再読み込みするとやり直しです)。";
  }else{
    $("brRun").disabled = false;
    $("brRun").textContent = "採点を実行";
    var sec = Math.round((Date.now() - t0) / 1000);
    $("brProg").textContent = "完了: " + done + " / " + total + "(" + Math.floor(sec / 60) + "分" + (sec % 60) + "秒)。下に採点結果を表示しました。";
  }
}

function brBuildReport(cases, fmts){
  var lines = ["# 契約書判定の採点結果(3形式比較・ブラウザ版)", "",
               "## 📊 正答率(" + cases.length + "決裁)", "",
               "| 形式 | 正答率 | 正解 | 不正解 | 質問で停止 | エラー |", "|---|---|---|---|---|---|"];
  var stats = {};
  var noneCases = cases.filter(function(c){ return !c.expect_code && !c.expect_name; }).length;
  BR_FORMATS.forEach(function(f){
    if(!$(f[2]).value.trim()){ lines.push("| " + f[1] + " | (キー未設定) | - | - | - | - |"); return; }
    var c = {ok: 0, ng: 0, ask: 0, error: 0};
    var graded = 0;
    cases.forEach(function(_, i){
      var r = BR.results[i + "/" + f[0]];
      if(r && r[0] !== "none"){ c[r[0]] = (c[r[0]] || 0) + 1; graded++; }
    });
    if(!graded){ lines.push("| " + f[1] + " | " + (noneCases ? "(正解なしのため採点なし)" : "(未実行)") + " | - | - | - | - |"); return; }
    var rate = 100.0 * (c.ok || 0) / graded;
    stats[f[0]] = rate;
    lines.push("| " + f[1] + " | **" + Math.round(rate) + "%** (" + (c.ok || 0) + "/" + graded + ") | "
      + (c.ok || 0) + " | " + (c.ng || 0) + " | " + (c.ask || 0) + " | " + (c.error || 0) + " |");
  });
  if(noneCases) lines.push("", "※ 正解なし(判定結果だけ)の決裁 " + noneCases + "件は正答率に含めていません。");
  var keys = Object.keys(stats);
  if(keys.length){
    var top = Math.max.apply(null, keys.map(function(k){ return stats[k]; }));
    var names = BR_FORMATS.filter(function(f){ return stats[f[0]] === top; }).map(function(f){ return f[1]; });
    lines.push("", "**いちばん正答率が高い形式: " + names.join("、") + "(" + Math.round(top) + "%)**", "",
               "※ 3形式とも回答は「キャッシュの相手勘定1科目+確定コード」の同じ形なので、"
               + "採点基準も同一です(正解のコード、コードが無ければ科目名が回答に含まれるか)。");
  }
  lines.push("", "## 📋 1決裁ごとの結果(○=正解 ×=不正解 ?=質問で停止 E=エラー 判=正解なし(判定結果だけ) -=キー未設定。印の後ろはアプリの答え)", "",
             "| # | 決裁 | 正解 | " + BR_FORMATS.map(function(f){ return f[1]; }).join(" | ") + " |",
             "|---|---|---|" + "---|".repeat(BR_FORMATS.length));
  cases.forEach(function(c, i){
    var expect = brExpect(c);
    var marks = BR_FORMATS.map(function(f){
      if(!$(f[2]).value.trim()) return "-";
      var r = BR.results[i + "/" + f[0]];
      return r ? brCellText(r) : "(未実行)";
    });
    lines.push("| " + (i + 1) + " | " + c.label + " | " + (expect || (c.has_answer ? "(読めない)" : "(なし)")) + " | " + marks.join(" | ") + " |");
  });
  var misses = [];
  cases.forEach(function(c, i){
    fmts.forEach(function(f){
      var r = BR.results[i + "/" + f[0]];
      if(!r || (r[0] !== "ng" && r[0] !== "ask")) return;
      var expect = brExpect(c);
      misses.push("- 形式: " + f[1] + " / 決裁: " + c.label + " / 正解: " + expect
        + "\n  アプリの回答(抜粋): " + (r[0] === "ask" ? "(質問で停止)" : "") + r[1].slice(0, 300));
    });
  });
  lines.push("", "## 🎓 どこに何を書けば次から正解になるか(学習の書き込み先)", "");
  if(!misses.length){
    lines.push("誤答がないため、追記は不要です。");
  }else{
    lines.push(
      "どれもDifyの各判定アプリの「アプリ設定 → 環境変数」に**行を追記するだけ**です(再インポート不要・即反映)。",
      "",
      "- **どの形式にも効く**: `accounting_policy` に「◯◯のような契約(見分けられる条件)は「正解科目」に分類する」を1行。",
      "  相手勘定の取り違え(敷金・手数料など付随の行を選んだ等)も、ここに「◯◯契約の主目的は◯◯」の形で書く",
      "- **ツリー判定形式**: 正解科目が属する細分の `rules_*` の該当行に、見分ける条件を書き足す",
      "- **コード2段選択形式**: `codes10_list` の該当行の定義に条件を書き足す(7桁の選び間違いなら `codes7_list`)",
      "- **コード一発選択形式**: `codes_list` の正解科目の行の定義に条件を書き足す",
      "- 正解科目がどの候補一覧にも無い場合は、分類ツリーに科目を足して③で各形式を再生成する",
      "",
      "具体的な追記文を作りたいときは、下の「誤答一覧」をそのまま判定アプリのチャットに貼り、",
      "「この誤答をなくすには、上の書き込み先のどこに、どんな行を追記すべきか。コピペできる形で提案して」と続けてください。",
      "追記したら、もう一度この採点を実行して正答率が上がったか確認してください(効果は保証ではありません)。",
      "", "### 誤答一覧", "");
    misses.forEach(function(m){ lines.push(m); });
  }
  return lines.join("\n") + "\n";
}

async function brConnTest(){
  var base = $("brUrl").value.trim().replace(/\/+$/, "");
  if(!base){ $("brTestOut").textContent = "APIサーバー(…/v1)を入力してください。"; return; }
  brSaveCfg();
  var fmts = brActiveFormats();
  if(!fmts.length){
    // キー未入力: URLだけで疎通(CORSに引っかかるか)を事前チェックする
    $("brTestOut").textContent = "キーが未入力なので、URLの疎通(CORSに引っかかるか)だけ確認します…";
    $("brTestOut").textContent = await evProbeUrl(base, BR.aborters);
    return;
  }
  $("brTestOut").textContent = "接続テスト中…";
  var out = [];
  for(var i = 0; i < fmts.length; i++){
    var f = fmts[i];
    var key = $(f[2]).value.trim();
    var msg;
    try{
      var r = await evFetch(base + "/info", {headers: {Authorization: "Bearer " + key}}, 30, BR.aborters);
      if(r.status === 404) r = await evFetch(base + "/parameters", {headers: {Authorization: "Bearer " + key}}, 30, BR.aborters);
      if(r.ok) msg = "✅ 接続OK";
      else if(r.status === 401) msg = "❌ HTTP 401 — キーが違います(app-… のキーか確認。dataset-… は別物)。届いてはいるのでCORSは通っています";
      else if(r.status === 404) msg = "❌ HTTP 404 — URLを確認してください(末尾は /v1。アプリの「APIアクセス」に出る「API サーバー」のURLで、アドレス欄の …/app/… ではありません)";
      else msg = "❌ HTTP " + r.status;
    }catch(e){
      msg = "❌ 通信できません — URLの誤り・社内ネットワーク外・またはDify側のCORS設定";
    }
    out.push(f[1] + ": " + msg);
  }
  if(out.join("\n").indexOf("通信できません") >= 0) out.push(evCorsHint(base));
  $("brTestOut").innerHTML = out.map(esc).join("<br>");
}

function brSaveCfg(){
  try{
    if($("brSaveCfg").checked){
      localStorage.setItem("kanjoBrEval", JSON.stringify({
        url: $("brUrl").value, tree: $("brKeyTree").value, flat: $("brKeyFlat").value, pick: $("brKeyPick").value}));
    }else{
      localStorage.removeItem("kanjoBrEval");
    }
  }catch(e){}
}

(function brInit(){
  try{
    var cfg = JSON.parse(localStorage.getItem("kanjoBrEval") || "null");
    if(cfg){
      $("brUrl").value = cfg.url || "";
      $("brKeyTree").value = cfg.tree || "";
      $("brKeyFlat").value = cfg.flat || "";
      $("brKeyPick").value = cfg.pick || "";
      $("brSaveCfg").checked = true;
    }
  }catch(e){}
  $("brSaveCfg").onchange = brSaveCfg;
  $("brTest").onclick = brConnTest;
  $("brRun").onclick = brRunAll;
  $("brStop").onclick = function(){
    BR.stopFlag = true;
    BR.aborters.slice().forEach(function(c){ try{ c.abort(); }catch(e){} });
  };
  $("brDlMd").onclick = function(){ save(brBuildReport(brLimitedCases(), brActiveFormats()), "採点結果.md"); };
  var drop = $("brDrop");
  drop.onclick = function(e){ if(e.target !== $("brDir")) $("brDir").click(); };
  $("brDir").onchange = function(){
    var items = [];
    for(var i = 0; i < this.files.length; i++){
      var f = this.files[i];
      items.push({rel: (f.webkitRelativePath || f.name), file: f});
    }
    if(items.length) brIngest(items);
  };
  drop.ondragover = function(e){ e.preventDefault(); drop.style.borderColor = "var(--accent)"; };
  drop.ondragleave = function(){ drop.style.borderColor = "#b6bdc6"; };
  drop.ondrop = function(e){
    e.preventDefault();
    drop.style.borderColor = "#b6bdc6";
    var out = [];
    var jobs = [];
    for(var i = 0; i < e.dataTransfer.items.length; i++){
      var entry = e.dataTransfer.items[i].webkitGetAsEntry && e.dataTransfer.items[i].webkitGetAsEntry();
      if(entry) jobs.push(evWalkEntry(entry, "", out));
    }
    Promise.all(jobs).then(function(){ if(out.length) brIngest(out); });
  };
})();
