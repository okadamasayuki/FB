// ============================================================ 自動保存(①②②-2③で共用)
// tools/sync_state_store.py が各ページのマーカー間に埋め込む(HTML側は直接編集しない)。
// 入力した内容と読み込んだファイルを「このブラウザの中」にだけ保存し、ページを開き直しても続きから使えるようにする。
//   保存先: IndexedDB(データベース kanjoTool / ストア kv / キー "<ツール名>:<項目名>")。
//           IndexedDB が使えないブラウザ(プライベートモード等)では localStorage("kanjo:kv:…")に退避。
//   通信はしない。データはこのブラウザのプロファイル内に留まる(同じPCの別ブラウザや別PCには写らない)。
//   ON/OFF: localStorage の kanjoAutosave("0" でOFF)。全ツール共通。OFFにすると保存済みの内容も消す。
//   各ページは KS.setup({tool, saveAll, restore, onClear}) を1回呼び、入力のたびに KS.save(項目名, 値を返す関数) を呼ぶ
//   (0.4秒まとめてから書く)。ファイルなど大きいものは読み込んだ直後に KS.put(項目名, 値) で書く。
//   まとめ版の右上「保存した内容をすべて消す」は KS.clearAll()(④⑤の接続設定・⑤の仮ナレッジ・③の任意保存も含む)。
var KS = (function(){
  var DB_NAME = "kanjoTool", STORE = "kv", FLAG = "kanjoAutosave", LS_PREFIX = "kanjo:kv:";
  var S = {tool: "", dbp: null, timers: {}, pending: {}, restoring: false, hooks: {}, noteEl: null};

  function lsGet(k){ try{ return localStorage.getItem(k); }catch(e){ return null; } }
  function lsSet(k, v){ try{ localStorage.setItem(k, v); return true; }catch(e){ return false; } }
  function lsDel(k){ try{ localStorage.removeItem(k); }catch(e){} }
  function lsKeys(prefix){
    var out = [];
    try{
      for(var i = 0; i < localStorage.length; i++){
        var k = localStorage.key(i);
        if(k && k.indexOf(prefix) === 0) out.push(k);
      }
    }catch(e){}
    return out;
  }
  function enabled(){ return lsGet(FLAG) !== "0"; }
  function setEnabled(on){ if(on) lsDel(FLAG); else lsSet(FLAG, "0"); }

  // ---- 保存先(IndexedDB。開けなければ null を返し、localStorage に退避する)
  function openDb(){
    if(S.dbp) return S.dbp;
    S.dbp = new Promise(function(resolve){
      var idb = null, req = null;
      try{ idb = window.indexedDB; }catch(e){}
      if(!idb){ resolve(null); return; }
      try{ req = idb.open(DB_NAME, 1); }catch(e){ resolve(null); return; }
      req.onupgradeneeded = function(){
        var db = req.result;
        if(!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
      };
      req.onsuccess = function(){
        var db = req.result;
        db.onversionchange = function(){ try{ db.close(); }catch(e){} S.dbp = null; };
        resolve(db);
      };
      req.onerror = function(){ resolve(null); };
      req.onblocked = function(){ resolve(null); };
    });
    return S.dbp;
  }
  function tx(db, mode, fn){
    return new Promise(function(resolve, reject){
      var t, req;
      try{ t = db.transaction(STORE, mode); req = fn(t.objectStore(STORE)); }catch(e){ reject(e); return; }
      t.oncomplete = function(){ resolve(req ? req.result : undefined); };
      t.onerror = function(){ reject(t.error); };
      t.onabort = function(){ reject(t.error || new Error("aborted")); };
    });
  }
  function key(name){ return S.tool + ":" + name; }

  // ページを離れる瞬間の保存は IndexedDB(非同期)が間に合わないことがあるので、同期の localStorage に控え(#spill)も書き、
  // 次に開いたとき get() が控えを優先して拾い、IndexedDB に移す。IndexedDB への書き込みが済めば控えは消す
  function spillKey(name){ return LS_PREFIX + key(name) + "#spill"; }
  function get(name){
    var spill = lsGet(spillKey(name));
    if(spill !== null){
      try{
        var sv = JSON.parse(spill);
        set(name, sv);   // 移し替え(完了時に控えを消す)
        return Promise.resolve(sv);
      }catch(e){ lsDel(spillKey(name)); }
    }
    return openDb().then(function(db){
      if(db) return tx(db, "readonly", function(st){ return st.get(key(name)); });
      var raw = lsGet(LS_PREFIX + key(name));
      return raw === null ? undefined : JSON.parse(raw);
    }).catch(function(){ return undefined; });
  }
  function set(name, value){
    return openDb().then(function(db){
      if(db) return tx(db, "readwrite", function(st){ st.put(Date.now(), key("_t")); return st.put(value, key(name)); });
      lsSet(LS_PREFIX + key("_t"), String(Date.now()));
      if(!lsSet(LS_PREFIX + key(name), JSON.stringify(value))) throw new Error("このブラウザの保存領域がいっぱいです");
    }).then(function(){ lsDel(spillKey(name)); })
      .catch(function(e){ note("⚠️ 保存できませんでした: " + (e && e.message ? e.message : e)); });
  }
  function del(name){
    return openDb().then(function(db){
      lsDel(LS_PREFIX + key(name));
      if(db) return tx(db, "readwrite", function(st){ return st.delete(key(name)); });
    }).catch(function(){});
  }
  function delPrefix(prefix){
    return openDb().then(function(db){
      lsKeys(LS_PREFIX + prefix).forEach(lsDel);
      if(db) return tx(db, "readwrite", function(st){ return st.delete(IDBKeyRange.bound(prefix, prefix + "\uffff")); });
    }).catch(function(){});
  }
  function clearTool(){ return delPrefix(S.tool + ":"); }            // このページの分だけ
  function clearStore(){                                              // ①〜③の自動保存をすべて
    return openDb().then(function(db){
      lsKeys(LS_PREFIX).forEach(lsDel);
      if(db) return tx(db, "readwrite", function(st){ return st.clear(); });
    }).catch(function(){});
  }
  function clearAll(){                                                // + kanjo で始まる localStorage(③の任意保存・④⑤の接続設定・⑤の仮ナレッジ)。ON/OFF の設定だけ残す
    return clearStore().then(function(){ lsKeys("kanjo").forEach(function(k){ if(k !== FLAG) lsDel(k); }); });
  }

  // ---- 入力のたびに呼ばれる保存(0.4秒まとめて書く)。ページを離れるときは待たずに書く
  function cancelPending(){
    Object.keys(S.timers).forEach(function(k){ clearTimeout(S.timers[k]); });
    S.timers = {}; S.pending = {};
  }
  function flushOne(name, leaving){
    clearTimeout(S.timers[name]); delete S.timers[name];
    var fn = S.pending[name]; delete S.pending[name];
    if(!fn || !enabled()) return;
    var v;
    try{ v = fn(); }catch(e){ return; }
    if(leaving){ try{ lsSet(spillKey(name), JSON.stringify(v)); }catch(e){} }   // 同期の控え(大きすぎて入らなければ IndexedDB だけ)
    set(name, v);
  }
  function save(name, fn, delay){
    if(S.restoring || !enabled()) return;
    S.pending[name] = fn;
    clearTimeout(S.timers[name]);
    S.timers[name] = setTimeout(function(){ flushOne(name); }, delay == null ? 400 : delay);
  }
  function put(name, value){
    if(S.restoring || !enabled()) return Promise.resolve();
    return set(name, value);
  }
  function flush(leaving){ Object.keys(S.pending).forEach(function(k){ flushOne(k, leaving); }); }
  window.addEventListener("pagehide", function(){ flush(true); });
  document.addEventListener("visibilitychange", function(){ if(document.visibilityState === "hidden") flush(true); });

  // ---- 画面: 見出し下の1行(ON/OFF・このページの保存内容を消す・状態表示)
  function note(text){ if(S.noteEl) S.noteEl.textContent = text || ""; }
  function fmtTime(t){
    var d = new Date(t);
    return (d.getMonth() + 1) + "/" + d.getDate() + " " + d.getHours() + ":" + ("0" + d.getMinutes()).slice(-2);
  }
  function reloadPage(){
    try{
      var fe = window.frameElement;   // まとめ版(iframe srcdoc)では iframe の中身を入れ直す
      if(fe && fe.hasAttribute("srcdoc")){ fe.srcdoc = fe.getAttribute("srcdoc"); return; }
    }catch(e){}
    location.reload();
  }
  function banner(o){
    var css = document.createElement("style");
    css.textContent = ".ks-banner{font-size:12px;color:var(--sub,#5b6169);border:1px dashed var(--line,#d8dce1);border-radius:8px;"
      + "padding:6px 10px;margin:-8px 0 16px;background:var(--card,#fff);display:flex;flex-wrap:wrap;gap:4px 12px;align-items:center;line-height:1.6}"
      + ".ks-banner label{cursor:pointer;white-space:nowrap}"
      + ".ks-banner button{padding:3px 10px;font-size:12px;border:1px solid var(--line,#d8dce1);border-radius:6px;background:#fff;"
      + "color:inherit;font-family:inherit;cursor:pointer;white-space:nowrap}"
      + ".ks-banner button:hover{border-color:var(--accent,#2f6fed)}"
      + ".ks-banner .ks-note{color:var(--accent,#2f6fed)}";
    document.head.appendChild(css);
    var el = document.createElement("div");
    el.className = "ks-banner"; el.id = "ksBanner";
    el.innerHTML = '<span>💾 入力内容と読み込んだファイルは<b>このブラウザの中にだけ</b>自動保存され、ページを開き直しても残ります'
      + '(外部への送信はありません)。' + (o.extra ? o.extra : "") + '</span>'
      + '<label title="OFFにすると、①〜③がこのブラウザに保存した内容も消えます"><input type="checkbox" id="ksOn"> 自動保存する(全ツール共通)</label>'
      + '<button type="button" id="ksClear">このページの保存内容を消す</button>'
      + '<span class="ks-note" id="ksNote"></span>';
    var lead = document.querySelector("p.lead");
    if(lead && lead.parentNode) lead.parentNode.insertBefore(el, lead.nextSibling);
    else document.body.insertBefore(el, document.body.firstChild);
    S.noteEl = el.querySelector("#ksNote");
    var on = el.querySelector("#ksOn");
    on.checked = enabled();
    on.onchange = function(){
      if(on.checked){
        setEnabled(true);
        if(S.hooks.saveAll){ try{ S.hooks.saveAll(); }catch(e){} }
        note("自動保存をONにしました(いまの内容を保存しました)");
      }else{
        setEnabled(false);
        cancelPending();
        clearStore().then(function(){ note("自動保存をOFFにし、①〜③の保存済みの内容を消しました"); });
      }
    };
    el.querySelector("#ksClear").onclick = function(){
      if(!confirm("このページがこのブラウザに保存した内容(入力・読み込んだファイル" + (o.clearExtra ? "・" + o.clearExtra : "")
                  + ")を消して、開いた直後の状態に戻します。よろしいですか?")) return;
      cancelPending();
      S.restoring = true;   // 再読込までのあいだ保存が走らないように
      var p = clearTool();
      if(S.hooks.onClear){ try{ S.hooks.onClear(); }catch(e){} }
      p.then(reloadPage, reloadPage);
    };
  }
  function setup(o){
    S.tool = o.tool;
    S.hooks = o;
    banner(o);
    if(!enabled()){ api.ready = Promise.resolve(false); return api.ready; }
    S.restoring = true;
    api.ready = Promise.resolve().then(function(){ return o.restore ? o.restore(get) : false; }).then(function(did){
      S.restoring = false;
      if(!did) return false;
      return get("_t").then(function(t){ note("前回の内容を復元しました" + (t ? "(" + fmtTime(t) + " 保存)" : "")); return true; });
    }, function(e){
      S.restoring = false;
      note("前回の内容を復元できませんでした: " + (e && e.message ? e.message : e));
      return false;
    });
    return api.ready;
  }
  var api = {setup: setup, save: save, put: put, get: get, del: del, flush: flush,
             clearTool: clearTool, clearStore: clearStore, clearAll: clearAll,
             enabled: enabled, setEnabled: setEnabled, note: note, ready: Promise.resolve(false)};
  Object.defineProperty(api, "restoring", {get: function(){ return S.restoring; }});
  return api;
})();
